<?php
/**
 * Visitor Management System - Public Kiosk
 * Version: 9.0 FINAL — Guest name OPTIONAL + instant photo capture
 *
 * CHANGELOG v9.0 (from v8.9):
 *   ── CHANGED: Guest name is now OPTIONAL at the kiosk. The visitor may
 *      type a name, or click "Skip", or press Escape, or click the
 *      backdrop — every path proceeds to photo capture and entry.
 *   ── CHANGED: The name modal no longer shows a red asterisk, and the
 *      "Cancel" button has been replaced with "Skip".
 *   ── CHANGED: askGuestName() resolves with '' (empty string) instead of
 *      null. The guest-entry click handler never aborts on missing name.
 *   ── CHANGED: Success card shows the server-returned name. When the
 *      visitor skipped, the server auto-generates "Guest N" and that is
 *      what is displayed.
 *   ── PRESERVED: Instant photo capture (no countdown), shutter sound
 *      plays after the shot, camera poller, manual "Capture Now" /
 *      "Skip Photo" buttons, all book/member/scan handlers, cover flow,
 *      stats, purpose chart, quote, footer, language switcher,
 *      HTML-entity helpers.
 *
 * PRESERVED (from v8.9):
 *   • Instant photo capture for unauthorized book exits and guest entry
 *   • No countdown timer, no beeps during wait
 *   • Guest photo saved to uploads/guest_photos/
 *   • Filename stored in entry_exit_logs.guest_photo
 *   • Book scan pipeline, member lookup, cover flow, stats, purpose
 *     chart, quote, footer, language switcher
 *   • HTML-entity helpers (vms_normalize_text / vms_plain / vms_h)
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

// ============================================================
// SESSION — start ONCE, before any output
// ============================================================
if (session_status() === PHP_SESSION_NONE) {
    session_name('CGISESSID');
    if (isset($_COOKIE['CGISESSID'])) {
        session_id($_COOKIE['CGISESSID']);
    }
    session_start();
}

// ============================================================
// BASE PATHS + CONFIG
// ============================================================
$adminPath   = '/usr/share/koha/intranet/cgi-bin/visitor';
$configFile  = $adminPath . '/includes/config.php';

if (file_exists($configFile)) {
    if (!defined('APP_VERSION')) require_once $configFile;
} else {
    if (!defined('APP_VERSION')) require_once __DIR__ . '/../includes/config.php';
}

// ============================================================
// LOAD SUPPORT FILES (idempotent guards)
// ============================================================
if (!function_exists('getDB'))              require_once __DIR__ . '/../includes/functions.php';
if (!function_exists('getKoha'))            require_once __DIR__ . '/../includes/koha.php';
if (!function_exists('startSecureSession')) require_once __DIR__ . '/../includes/auth.php';
if (!function_exists('__'))                 require_once __DIR__ . '/../includes/languages.php';

// Optional alerts module
$alertsFile = $adminPath . '/includes/alerts.php';
if (file_exists($alertsFile)) {
    require_once $alertsFile;
} else {
    $altAlerts = __DIR__ . '/../includes/alerts.php';
    if (file_exists($altAlerts)) require_once $altAlerts;
}

// ============================================================
// HTML ENTITY HELPERS
// ============================================================
if (!function_exists('vms_normalize_text')) {
    function vms_normalize_text($value) {
        if ($value === null) return '';
        return html_entity_decode((string)$value, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    }
}
if (!function_exists('vms_plain')) {
    function vms_plain($value) {
        return vms_normalize_text($value);
    }
}
if (!function_exists('vms_h')) {
    function vms_h($value) {
        return htmlspecialchars(
            vms_normalize_text($value),
            ENT_QUOTES | ENT_HTML5,
            'UTF-8'
        );
    }
}

// ============================================================
// LANGUAGE — set from ?lang=xx and force a reload once
// ============================================================
$availableLanguages = function_exists('getAvailableLanguages')
    ? getAvailableLanguages()
    : ['en' => 'English'];

$lang = $_SESSION['visitor_lang'] ?? 'en';

if (isset($_GET['lang'])) {
    $requested = preg_replace('/[^a-z]/', '', strtolower($_GET['lang']));
    if ($requested !== '' && array_key_exists($requested, $availableLanguages)) {
        $changed = ($requested !== $lang);
        $_SESSION['visitor_lang'] = $requested;
        $lang = $requested;

        if ($changed) {
            $cleanUrl = strtok($_SERVER['REQUEST_URI'], '?');
            header('Location: ' . $cleanUrl);
            exit;
        }
    }
}

// ============================================================
// DATABASE + SETTINGS
// ============================================================
$db       = getDB();
$settings = getSettings();

$institutionName       = vms_normalize_text($settings['institution_name']        ?? 'Library');
$publicHeaderTitle     = vms_normalize_text($settings['public_header_title']     ?? $institutionName);
$publicHeaderSubtitle  = vms_normalize_text($settings['public_header_subtitle']  ?? 'Library Entry/Exit System');
$publicHeaderLayout    = $settings['public_header_layout']        ?? 'centered';
$publicHeaderBgColor   = $settings['public_header_bg_color']      ?? '#1e3c72';
$publicHeaderTextColor = $settings['public_header_text_color']    ?? '#ffffff';
$publicHeaderHeight    = $settings['public_header_height']        ?? '80px';
$publicShowHeaderLogo  = $settings['public_show_header_logo']     ?? 1;
$publicShowInstName    = $settings['public_show_institution_name']?? 1;
$primaryColor          = $settings['primary_color']               ?? '#1e3c72';
$secondaryColor        = $settings['secondary_color']             ?? '#2a5298';
$accentColor           = $settings['accent_color']                ?? '#ffc107';
$bodyBg                = $settings['body_bg']                     ?? '#f0f2f5';
$fontFamily            = $settings['font_family']                 ?? 'Inter';
$showQuote             = $settings['show_quote']                  ?? 1;
$showLiveStats         = $settings['show_live_stats']             ?? 1;
$showPurposeChart      = $settings['show_purpose_chart']          ?? 1;
$showCoverFlow         = $settings['show_cover_flow']             ?? 1;
$guestEnabled          = $settings['guest_enabled']               ?? 1;
$autoRefresh           = $settings['auto_refresh']                ?? 10;
$requirePurpose        = $settings['require_purpose']             ?? 1;
$defaultPurpose        = $settings['default_purpose']             ?? 'Reading/Study';
$footerText            = vms_normalize_text($settings['footer_text'] ?? '');
$footerBg              = $settings['footer_bg']                   ?? '#1e3c72';
$footerTextColor       = $settings['footer_text_color']           ?? '#ffffff';
$showFooterLogo        = $settings['show_footer_logo']            ?? 1;

// Auto-record and camera settings
$bookAutoRecord        = $settings['book_unauthorized_alert']     ?? 1;
$bookCameraEnabled     = $settings['book_exit_photo']             ?? 1;
$bookCameraAutoCapture = $settings['book_camera_auto_capture']    ?? 1;
$cameraCountdownSec    = max(3, min(10, (int)($settings['book_camera_countdown'] ?? 5)));

// ============================================================
// LOGO + BACKGROUND
// ============================================================
$headerLogo = function_exists('getPublicHeaderLogo') ? getPublicHeaderLogo() : null;
if (empty($headerLogo) && function_exists('getInstitutionLogo')) {
    $headerLogo = getInstitutionLogo();
}
$headerBgImage = function_exists('getPublicHeaderBg') ? getPublicHeaderBg() : null;

// ============================================================
// AVATAR
// ============================================================
$defaultAvatar = function_exists('getDefaultAvatar')
    ? getDefaultAvatar()
    : 'data:image/svg+xml;base64,' . base64_encode(
        '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100">'
      . '<rect width="100" height="100" fill="#1e3c72"/>'
      . '<text x="50" y="55" font-size="40" text-anchor="middle" fill="#fff">👤</text>'
      . '</svg>'
    );

// ============================================================
// PURPOSE LIST
// ============================================================
if (!function_exists('vms_purpose_options')) {
    function vms_purpose_options(): array {
        if (function_exists('getPurposeOptions')) {
            $out = [];
            foreach (getPurposeOptions() as $value => $meta) {
                $out[$value] = ['icon' => $meta['icon'] ?? '', 'label' => $meta['label'] ?? $value];
            }
            return $out;
        }
        return [
            'Reading/Study'     => ['icon' => '📚', 'label' => 'Reading/Study'],
            'Computer Uses'     => ['icon' => '💻', 'label' => 'Computer Uses'],
            'Book Issue/Return' => ['icon' => '🔄', 'label' => 'Book Issue/Return'],
            'Research'          => ['icon' => '🔬', 'label' => 'Research'],
            'Meeting'           => ['icon' => '👥', 'label' => 'Meeting'],
            'Event'             => ['icon' => '🎉', 'label' => 'Event/Program'],
            'Other'             => ['icon' => '📝', 'label' => 'Other'],
        ];
    }
}
if (!function_exists('vms_valid_purpose')) {
    function vms_valid_purpose(string $p): string {
        return array_key_exists($p, vms_purpose_options()) ? $p : 'Reading/Study';
    }
}

// ============================================================
// GUEST PHOTO SAVER + MIGRATION HELPER
// ============================================================
if (!function_exists('vms_save_guest_photo')) {
    function vms_save_guest_photo(?string $dataUrl): ?string
    {
        if (empty($dataUrl) || !is_string($dataUrl)) return null;

        if (!preg_match('#^data:image/(jpeg|jpg|png|webp);base64,#i', $dataUrl, $m)) {
            return null;
        }
        $ext = strtolower($m[1]);
        if ($ext === 'jpeg') $ext = 'jpg';

        $raw = base64_decode(substr($dataUrl, strlen($m[0])), true);
        if ($raw === false || strlen($raw) < 200) return null;
        if (strlen($raw) > 3 * 1024 * 1024) return null;

        $baseDir = defined('UPLOAD_PATH') ? UPLOAD_PATH : (__DIR__ . '/../uploads');
        $dir     = rtrim($baseDir, '/') . '/guest_photos/';
        if (!is_dir($dir)) {
            @mkdir($dir, 0777, true);
            @chmod($dir, 0777);
        }
        if (!is_dir($dir) || !is_writable($dir)) {
            error_log('[kiosk] guest photo dir not writable: ' . $dir);
            return null;
        }

        $filename = 'guest_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
        $target   = $dir . $filename;

        if (@file_put_contents($target, $raw) === false) {
            error_log('[kiosk] failed to write guest photo: ' . $target);
            return null;
        }
        @chmod($target, 0644);
        return $filename;
    }
}

if (!function_exists('vms_ensure_guest_photo_column')) {
    function vms_ensure_guest_photo_column(PDO $db): void
    {
        static $done = false;
        if ($done) return;
        $done = true;
        try {
            $cols = $db->query("SHOW COLUMNS FROM entry_exit_logs")->fetchAll(PDO::FETCH_COLUMN);
            if (!in_array('guest_photo', $cols, true)) {
                $db->exec("ALTER TABLE entry_exit_logs
                           ADD COLUMN guest_photo VARCHAR(255) NULL
                           AFTER member_category");
            }
        } catch (PDOException $e) {
            error_log('[kiosk] guest_photo migration: ' . $e->getMessage());
        }
    }
}

// ============================================================
// HELPERS: PATRON PHOTO / MEMBER SEARCH / BOOK COVERS
// ============================================================
if (!function_exists('getPatronImageBase64')) {
    function getPatronImageBase64($borrowernumber) {
        $koha = getKoha();
        if (!$koha || empty($borrowernumber)) return null;
        try {
            $stmt = $koha->prepare("SELECT imagefile FROM patronimage WHERE borrowernumber = ? LIMIT 1");
            $stmt->execute([$borrowernumber]);
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($row && !empty($row['imagefile'])) return base64_encode($row['imagefile']);
        } catch (Exception $e) {}
        return null;
    }
}

if (!function_exists('findKohaMember')) {
    function findKohaMember($admno) {
        $variations = array_unique(array_filter([
            $admno, trim($admno), strtoupper($admno), strtolower($admno),
            preg_replace('/[^0-9]/', '', $admno),
            preg_replace('/[^a-zA-Z0-9]/', '', $admno),
        ]));

        foreach ($variations as $candidate) {
            if (strlen($candidate) < 2) continue;
            $member = getKohaMember($candidate);
            if ($member && !empty($member['cardnumber'])) {
                if (empty($member['photo_base64']) && !empty($member['borrowernumber'])) {
                    $img = getPatronImageBase64($member['borrowernumber']);
                    if ($img) $member['photo_base64'] = 'data:image/jpeg;base64,' . $img;
                }
                return $member;
            }
        }

        $koha = getKoha();
        if ($koha) {
            try {
                $stmt = $koha->prepare("
                    SELECT borrowernumber, cardnumber, userid, surname, firstname, title,
                           categorycode, email, phone, address, city
                    FROM borrowers
                    WHERE cardnumber = ? OR userid = ?
                       OR (surname LIKE ? OR firstname LIKE ?)
                    LIMIT 1
                ");
                $searchTerm = '%' . $admno . '%';
                $stmt->execute([$admno, $admno, $searchTerm, $searchTerm]);
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                if ($row) {
                    $full_name = trim(($row['title'] ?? '') . ' ' . ($row['firstname'] ?? '') . ' ' . ($row['surname'] ?? ''));
                    if (empty($full_name)) $full_name = $row['cardnumber'] ?? 'Unknown';
                    $member = [
                        'borrowernumber'       => $row['borrowernumber'],
                        'cardnumber'           => $row['cardnumber'],
                        'userid'               => $row['userid'],
                        'full_name'            => $full_name,
                        'categorycode'         => $row['categorycode'],
                        'category_description' => '',
                        'email'                => $row['email'] ?? '',
                        'phone'                => $row['phone'] ?? '',
                        'address'              => $row['address'] ?? '',
                    ];
                    if (!empty($row['categorycode'])) {
                        try {
                            $catStmt = $koha->prepare("SELECT description FROM categories WHERE categorycode = ?");
                            $catStmt->execute([$row['categorycode']]);
                            $catRow = $catStmt->fetch(PDO::FETCH_ASSOC);
                            if ($catRow) $member['category_description'] = $catRow['description'];
                        } catch (Exception $e) {}
                    }
                    if (!empty($row['borrowernumber'])) {
                        $img = getPatronImageBase64($row['borrowernumber']);
                        if ($img) $member['photo_base64'] = 'data:image/jpeg;base64,' . $img;
                    }
                    return $member;
                }
            } catch (Exception $e) {}
        }
        return false;
    }
}

if (!function_exists('getNewArrivals')) {
    function getNewArrivals($limit = 12) {
        $koha = getKoha();
        if (!$koha) return [];
        try {
            $stmt = $koha->prepare("
                SELECT
                    b.biblionumber, b.title, b.author, b.abstract, b.isbn,
                    b.copyrightdate, b.publishercode, b.publicationyear,
                    b.subtitle, b.seriestitle, b.notes, b.itemtype,
                    (SELECT imageurl FROM biblioimages WHERE biblionumber = b.biblionumber LIMIT 1) as cover_image,
                    (SELECT COUNT(*) FROM items WHERE biblionumber = b.biblionumber
                        AND notforloan = 0 AND damaged = 0 AND itemlost = 0 AND withdrawn = 0) as available_copies,
                    (SELECT COUNT(*) FROM items i
                       JOIN issues iss ON i.itemnumber = iss.itemnumber
                      WHERE i.biblionumber = b.biblionumber AND iss.returndate IS NULL) as issued_copies
                FROM biblio b
                WHERE b.datecreated >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
                ORDER BY b.datecreated DESC LIMIT ?
            ");
            $stmt->execute([$limit]);
            return $stmt->fetchAll();
        } catch (PDOException $e) {
            return [];
        }
    }
}

if (!function_exists('getBookCover')) {
    function getBookCover($biblionumber, $title, $author, $isbn = '') {
        $koha = getKoha();
        if ($koha) {
            try {
                $stmt = $koha->prepare("SELECT imageurl FROM biblioimages WHERE biblionumber = ? LIMIT 1");
                $stmt->execute([$biblionumber]);
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                if ($row && !empty($row['imageurl'])) return $row['imageurl'];
            } catch (Exception $e) {}
        }
        if (!empty($isbn)) {
            return "https://covers.openlibrary.org/b/isbn/" . urlencode($isbn) . "-M.jpg";
        }
        $initials = '';
        foreach (explode(' ', $title, 3) as $w) {
            if (!empty($w[0])) $initials .= strtoupper($w[0]);
        }
        $initials = substr($initials, 0, 3);
        $colors = ['#e74c3c','#3498db','#2ecc71','#f39c12','#9b59b6','#1abc9c','#e67e22','#2980b9'];
        $color = $colors[abs(crc32($title)) % count($colors)];
        $svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 280">'
             . '<rect width="200" height="280" fill="' . $color . '" rx="8"/>'
             . '<text x="100" y="140" font-family="Arial" font-size="60" font-weight="bold" fill="white" text-anchor="middle" dominant-baseline="central">' . $initials . '</text>'
             . '<text x="100" y="220" font-family="Arial" font-size="12" fill="rgba(255,255,255,0.85)" text-anchor="middle">' . htmlspecialchars(substr($title, 0, 22)) . '</text>'
             . '</svg>';
        return 'data:image/svg+xml;base64,' . base64_encode($svg);
    }
}

// ============================================================
// BULLETPROOF UNAUTHORIZED BOOK RECORDER
// ============================================================
if (!function_exists('vms_book_exit_columns')) {
    function vms_book_exit_columns($db) {
        static $cache = null;
        if ($cache !== null) return $cache;
        try {
            $stmt = $db->query("SHOW COLUMNS FROM book_exit_logs");
            $cache = $stmt->fetchAll(PDO::FETCH_COLUMN);
        } catch (PDOException $e) {
            $cache = [];
        }
        return $cache;
    }
}

if (!function_exists('vms_save_unauth_photo')) {
    function vms_save_unauth_photo($photoData, $prefix = 'kiosk_unauth') {
        if (empty($photoData)) return '';
        $baseDir = defined('UPLOAD_PATH') ? UPLOAD_PATH : (__DIR__ . '/../uploads');
        $uploadDir = rtrim($baseDir, '/') . '/book_exit_photos/';
        if (!is_dir($uploadDir)) {
            @mkdir($uploadDir, 0777, true);
            @chmod($uploadDir, 0777);
        }
        if (!is_dir($uploadDir) || !is_writable($uploadDir)) {
            error_log('[VMS kiosk] photo dir not writable: ' . $uploadDir);
            return '';
        }
        $imageData = base64_decode(preg_replace('#^data:image/\w+;base64,#i', '', $photoData));
        if ($imageData === false || strlen($imageData) < 100) return '';
        $filename = $prefix . '_' . date('Ymd_His') . '_' . random_int(1000, 9999) . '.jpg';
        if (@file_put_contents($uploadDir . $filename, $imageData) === false) {
            error_log('[VMS kiosk] failed to write photo: ' . $uploadDir . $filename);
            return '';
        }
        @chmod($uploadDir . $filename, 0666);
        return $filename;
    }
}

if (!function_exists('vms_record_unauthorized_book_exit')) {
    function vms_record_unauthorized_book_exit($db, $book, $photoData = '', $gateNumber = 'KIOSK') {
        $result = ['ok' => false, 'log_id' => null, 'error' => '', 'hint' => ''];

        if (!$db) {
            $result['error'] = 'No DB connection';
            return $result;
        }
        if (!$book || empty($book['barcode'])) {
            $result['error'] = 'Invalid book payload (missing barcode)';
            return $result;
        }

        $barcode     = $book['barcode']            ?? '';
        $title       = $book['title']              ?? '';
        $author      = $book['author']             ?? '';
        $memberName  = $book['member_name']        ?? '';
        $memberAdmno = $book['member_cardnumber']  ?? '';

        $photoPath = vms_save_unauth_photo($photoData, 'kiosk_unauth');

        $columns = vms_book_exit_columns($db);
        if (empty($columns)) {
            $result['error'] = 'book_exit_logs table not found or not readable';
            return $result;
        }

        $desired = [
            'book_barcode'  => $barcode,
            'book_title'    => $title,
            'book_author'   => $author,
            'member_admno'  => $memberAdmno,
            'member_name'   => $memberName,
            'is_authorized' => 0,
            'photo_path'    => $photoPath,
            'notes'         => 'Auto-recorded by public kiosk',
            'gate_number'   => $gateNumber,
            'alert_sent'    => 0,
            'staff_id'      => null,
        ];

        $payload = [];
        foreach ($desired as $col => $val) {
            if (in_array($col, $columns, true)) {
                $payload[$col] = $val;
            }
        }
        if (empty($payload['book_barcode'] ?? null)) {
            $result['error'] = 'book_barcode column missing';
            return $result;
        }

        try {
            $cols         = implode(', ', array_map(fn($c) => "`$c`", array_keys($payload)));
            $placeholders = implode(', ', array_fill(0, count($payload), '?'));
            $sql          = "INSERT INTO book_exit_logs ($cols) VALUES ($placeholders)";
            $stmt = $db->prepare($sql);
            $stmt->execute(array_values($payload));
            $result['ok']     = true;
            $result['log_id'] = (int)$db->lastInsertId();
        } catch (PDOException $e) {
            $msg = $e->getMessage();

            if (strpos($msg, '1442') !== false ||
                stripos($msg, 'already used by statement') !== false) {
                error_log('[VMS kiosk] TRIGGER RECURSION detected: ' . $msg);
                $result['error'] = 'MySQL trigger recursion on book_exit_logs (error 1442).';
                $result['hint']  = 'Open /cgi-bin/koha/visitor/fix_trigger.php and drop the buggy trigger, OR run: DROP TRIGGER IF EXISTS trg_auto_book_alert; DROP TRIGGER IF EXISTS trg_guest_counter;';
                return $result;
            }

            error_log('[VMS kiosk] attempt1 failed: ' . $msg);

            $minimal = [];
            foreach (['book_barcode','book_title','is_authorized'] as $c) {
                if (in_array($c, $columns, true) && isset($desired[$c])) {
                    $minimal[$c] = $desired[$c];
                }
            }
            if (isset($minimal['is_authorized'])) $minimal['is_authorized'] = 0;

            try {
                $cols         = implode(', ', array_map(fn($c) => "`$c`", array_keys($minimal)));
                $placeholders = implode(', ', array_fill(0, count($minimal), '?'));
                $sql          = "INSERT INTO book_exit_logs ($cols) VALUES ($placeholders)";
                $stmt = $db->prepare($sql);
                $stmt->execute(array_values($minimal));
                $result['ok']     = true;
                $result['log_id'] = (int)$db->lastInsertId();
            } catch (PDOException $e2) {
                $msg2 = $e2->getMessage();
                if (strpos($msg2, '1442') !== false ||
                    stripos($msg2, 'already used by statement') !== false) {
                    $result['error'] = 'MySQL trigger recursion (error 1442) on book_exit_logs.';
                    $result['hint']  = 'Run /cgi-bin/koha/visitor/fix_trigger.php, OR execute: DROP TRIGGER IF EXISTS trg_auto_book_alert;';
                } else {
                    $result['error'] = 'Insert failed: ' . $msg2;
                }
                error_log('[VMS kiosk] attempt2 failed: ' . $msg2);
                return $result;
            }
        }

        if ($result['ok'] && $result['log_id']) {
            $logId = $result['log_id'];

            try {
                if (function_exists('addToAlertQueue')) {
                    addToAlertQueue($logId, $barcode, $title, $photoPath);
                } else {
                    $alertCols = [];
                    try {
                        $alertCols = $db->query("SHOW COLUMNS FROM book_alerts")->fetchAll(PDO::FETCH_COLUMN);
                    } catch (PDOException $e) {}
                    if (!empty($alertCols)) {
                        $db->prepare("
                            INSERT INTO book_alerts
                                (log_id, book_barcode, book_title, photo_path,
                                 acknowledged, resolved, created_at)
                            VALUES (?, ?, ?, ?, 0, 0, NOW())
                        ")->execute([$logId, $barcode, $title, $photoPath]);
                    }
                }
            } catch (PDOException $e) {
                error_log('[VMS kiosk] alert insert: ' . $e->getMessage());
            }

            if (function_exists('sendUnauthorizedBookAlert')) {
                try {
                    $sent = sendUnauthorizedBookAlert([
                        'barcode'     => $barcode,
                        'title'       => $title,
                        'author'      => $author,
                        'member_name' => $memberName,
                        'member_id'   => $memberAdmno,
                        'photo_path'  => $photoPath,
                        'staff_name'  => 'Kiosk (auto)',
                        'gate_number' => $gateNumber,
                        'timestamp'   => date('Y-m-d H:i:s'),
                    ]);
                    if ($sent && in_array('alert_sent', $columns, true)) {
                        try {
                            $db->prepare("UPDATE book_exit_logs SET alert_sent = 1 WHERE id = ?")
                               ->execute([$logId]);
                        } catch (PDOException $e) {
                            error_log('[VMS kiosk] alert_sent update skipped: ' . $e->getMessage());
                        }
                    }
                } catch (Exception $e) {
                    error_log('[VMS kiosk] notify: ' . $e->getMessage());
                }
            }
        }

        return $result;
    }
}

// ============================================================
// FETCH DATA
// ============================================================
$stats       = function_exists('getCurrentStats') ? getCurrentStats() : ['inside'=>0,'today'=>0,'male'=>0,'female'=>0,'other'=>0];
$quote       = function_exists('getRandomQuote')  ? getRandomQuote()  : ['text'=>'Reading is to the mind what exercise is to the body.','author'=>'Joseph Addison'];
$newArrivals = $showCoverFlow ? getNewArrivals(12) : [];

// ============================================================
// AJAX HANDLERS
// ============================================================
if (isset($_GET['ajax'])) {
    header('Content-Type: application/json; charset=utf-8');
    $action = $_GET['ajax'];

    if ($action === 'debug_book_record') {
        $cols = vms_book_exit_columns($db);
        $testInsert = null;
        try {
            $dummyBook = ['barcode' => '__DEBUG__', 'title' => 'Debug Entry', 'author' => ''];
            $testInsert = vms_record_unauthorized_book_exit($db, $dummyBook, '', 'DEBUG');
            if (!empty($testInsert['log_id'])) {
                try {
                    $db->prepare("DELETE FROM book_exit_logs WHERE id = ?")->execute([$testInsert['log_id']]);
                    $testInsert['cleaned_up'] = true;
                } catch (PDOException $e) {}
            }
        } catch (Exception $e) {
            $testInsert = ['ok' => false, 'error' => $e->getMessage()];
        }
        echo json_encode([
            'success'          => true,
            'book_exit_logs'   => $cols,
            'book_auto_record' => (bool)$bookAutoRecord,
            'test_insert'      => $testInsert,
        ], JSON_PRETTY_PRINT);
        exit;
    }

    if ($action === 'check_book') {
        $barcode = trim($_GET['barcode'] ?? '');
        $book = getKohaBook($barcode);
        if (!$book) {
            echo json_encode(['is_book' => false, 'message' => 'Not a book barcode']);
            exit;
        }
        $isAuthorized = !empty($book['borrowernumber']);
        $member = null;
        if ($isAuthorized && !empty($book['member_cardnumber'])) {
            $member = getKohaMember($book['member_cardnumber']);
            if ($member && empty($member['photo_base64']) && !empty($member['borrowernumber'])) {
                $img = getPatronImageBase64($member['borrowernumber']);
                if ($img) $member['photo_base64'] = 'data:image/jpeg;base64,' . $img;
            }
        }
        echo json_encode([
            'is_book'       => true,
            'book'          => $book,
            'is_authorized' => $isAuthorized,
            'member'        => $member,
        ]);
        exit;
    }

    if ($action === 'record_unauthorized_book') {
        $barcode   = trim($_POST['barcode'] ?? '');
        $photoData = trim($_POST['photo_data'] ?? '');
        $gate      = trim($_POST['gate'] ?? 'KIOSK');

        if ($barcode === '') {
            echo json_encode(['success' => false, 'error' => 'Barcode required']);
            exit;
        }
        if (!($bookAutoRecord ?? 1)) {
            echo json_encode(['success' => false, 'error' => 'Auto-record disabled in settings']);
            exit;
        }

        $book = getKohaBook($barcode);
        if (!$book) {
            echo json_encode(['success' => false, 'error' => 'Book not found in Koha']);
            exit;
        }
        if (!empty($book['borrowernumber'])) {
            echo json_encode(['success' => false, 'error' => 'Book is authorized — nothing to record']);
            exit;
        }

        $recordResult = vms_record_unauthorized_book_exit($db, $book, $photoData, $gate);

        if ($recordResult['ok']) {
            clearCache('stats');
            echo json_encode([
                'success'   => true,
                'log_id'    => $recordResult['log_id'],
                'had_photo' => !empty($photoData),
                'message'   => 'Unauthorized book exit recorded',
            ]);
        } else {
            error_log('[VMS kiosk] record failed: ' . ($recordResult['error'] ?? 'unknown'));
            echo json_encode([
                'success' => false,
                'error'   => $recordResult['error'] ?: 'Failed to record',
                'hint'    => $recordResult['hint']  ?? '',
            ]);
        }
        exit;
    }

    if ($action === 'get_member') {
        $admno = trim($_GET['admno'] ?? '');
        if (strlen($admno) < 2) { echo json_encode(['error' => __('valid_id')]); exit; }
        $member = findKohaMember($admno);
        if ($member) {
            $check = $db->prepare("SELECT id FROM entry_exit_logs WHERE admno = ? AND status = 'inside'");
            $check->execute([$member['cardnumber']]);
            $member['is_inside'] = (bool)$check->fetch();
            echo json_encode(['member' => $member, 'is_inside' => $member['is_inside']]);
        } else {
            echo json_encode(['error' => __('member_not_found') . ': ' . htmlspecialchars($admno)]);
        }
        exit;
    }

    if ($action === 'toggle') {
        $admno   = trim($_POST['admno'] ?? '');
        $purpose = vms_valid_purpose(trim($_POST['purpose'] ?? $defaultPurpose));
        if (strlen($admno) < 2) { echo json_encode(['error' => __('valid_id')]); exit; }
        $member = findKohaMember($admno);
        if (!$member) { echo json_encode(['error' => __('member_not_found')]); exit; }

        $check = $db->prepare("SELECT id FROM entry_exit_logs WHERE admno = ? AND status = 'inside'");
        $check->execute([$member['cardnumber']]);
        $existing = $check->fetch();

        if ($existing) {
            $db->prepare("UPDATE entry_exit_logs SET exit_time = NOW(), status = 'exited' WHERE id = ?")
               ->execute([$existing['id']]);
            clearCache('stats');
            echo json_encode(['success' => true, 'action' => 'exit', 'message' => __('exit_recorded')]);
        } else {
            $db->prepare("
                INSERT INTO entry_exit_logs
                    (admno, member_name, member_category, entry_date, entry_time, purpose, status, entry_type)
                VALUES (?, ?, ?, CURDATE(), CURTIME(), ?, 'inside', 'member')
            ")->execute([
                $member['cardnumber'],
                $member['full_name'],
                $member['category_description'] ?? $member['categorycode'],
                $purpose
            ]);
            clearCache('stats');
            echo json_encode(['success' => true, 'action' => 'entry', 'message' => __('entry_recorded')]);
        }
        exit;
    }

    if ($action === 'stats') {
        $catStats = $db->query("SELECT member_category, COUNT(*) AS count FROM entry_exit_logs WHERE status='inside' GROUP BY member_category")->fetchAll(PDO::FETCH_KEY_PAIR);
        echo json_encode([
            'insideCount'   => $stats['inside'] ?? 0,
            'todayVisitors' => $stats['today']  ?? 0,
            'maleCount'     => $stats['male']   ?? 0,
            'femaleCount'   => $stats['female'] ?? 0,
            'otherCount'    => $stats['other']  ?? 0,
            'categoryStats' => $catStats ?: [],
        ]);
        exit;
    }

    if ($action === 'get_purpose_stats') {
        $purposes = $db->query("
            SELECT purpose, COUNT(*) as count FROM entry_exit_logs
             WHERE entry_date = CURDATE()
             GROUP BY purpose ORDER BY count DESC
        ")->fetchAll();
        echo json_encode(['success'=>true, 'purposes'=>$purposes]);
        exit;
    }

    // ============================================================
    // v9.0 — GUEST ENTRY (name optional, photo optional)
    // ============================================================
    if ($action === 'guest_entry') {
        if (!$guestEnabled) { echo json_encode(['error' => 'Guest mode disabled']); exit; }

        $guestName = trim($_POST['guest_name'] ?? '');
        $photoData = trim($_POST['photo_data'] ?? '');
        $guestPurpose = vms_valid_purpose(trim($_POST['purpose'] ?? $defaultPurpose));

        // v9.0 — name is optional. If empty, we auto-generate below.

        if ($guestName !== '') {
            if (function_exists('mb_substr')) {
                $guestName = mb_substr($guestName, 0, 120, 'UTF-8');
            } else {
                $guestName = substr($guestName, 0, 120);
            }
        }

        vms_ensure_guest_photo_column($db);

        $photoFilename = '';
        if ($photoData !== '') {
            $photoFilename = vms_save_guest_photo($photoData);
            if ($photoFilename === null) $photoFilename = '';
        }

        $guestNum = (int)$db->query("SELECT guest_daily_counter FROM settings LIMIT 1")->fetchColumn() ?: 1;

        // v9.0 — auto-generate a placeholder name if the visitor skipped
        $autoNamed = false;
        if ($guestName === '') {
            $guestName = 'Guest ' . $guestNum;
            $autoNamed = true;
        }

        $prefix   = $settings['guest_prefix']  ?? 'GUEST-';
        $padding  = (int)($settings['guest_padding'] ?? 4);
        $admno    = $prefix . str_pad($guestNum, $padding, '0', STR_PAD_LEFT);

        try {
            $db->prepare("
                INSERT INTO entry_exit_logs
                    (admno, member_name, member_category, guest_photo,
                     entry_date, entry_time, purpose, status, entry_type)
                VALUES (?, ?, 'Guest', ?, CURDATE(), CURTIME(), ?, 'inside', 'guest')
            ")->execute([$admno, $guestName, $photoFilename ?: null, $guestPurpose]);

            $db->query("UPDATE settings SET guest_daily_counter = guest_daily_counter + 1");
            clearCache('stats');
            clearCache('settings_all');

            logActivity(
                $_SESSION['koha_user_id'] ?? 0,
                'GUEST_ENTRY',
                "Guest '{$guestName}' entered ({$admno})" .
                ($photoFilename !== '' ? ' [photo]' : '') .
                ($autoNamed ? ' [auto-named]' : '')
            );

            echo json_encode([
                'success'      => true,
                'guest_number' => $guestNum,
                'guest_id'     => $admno,
                'guest_name'   => $guestName,
                'auto_named'   => $autoNamed,
                'had_photo'    => $photoFilename !== '',
                'message'      => 'Welcome ' . $guestName . ' — entered as ' . $admno,
            ]);
        } catch (PDOException $e) {
            error_log('[kiosk] guest insert: ' . $e->getMessage());
            echo json_encode(['error' => 'Failed to record guest entry']);
        }
        exit;
    }

    // ============================================================
    // GUEST EXIT (last active)
    // ============================================================
    if ($action === 'guest_exit_last') {
        if (!$guestEnabled) { echo json_encode(['error' => 'Guest mode disabled']); exit; }

        $guest = null;
        try {
            $guest = $db->query("
                SELECT id, member_name, admno, guest_photo
                  FROM entry_exit_logs
                 WHERE status='inside' AND member_category='Guest'
                 ORDER BY entry_time DESC LIMIT 1
            ")->fetch();
        } catch (PDOException $e) {
            $guest = $db->query("
                SELECT id, member_name, admno
                  FROM entry_exit_logs
                 WHERE status='inside' AND member_category='Guest'
                 ORDER BY entry_time DESC LIMIT 1
            ")->fetch();
        }

        if (!$guest) { echo json_encode(['error' => __('no_active_guests')]); exit; }

        $db->prepare("UPDATE entry_exit_logs SET exit_time=NOW(), status='exited' WHERE id=?")
           ->execute([$guest['id']]);
        clearCache('stats');

        $name = trim((string)($guest['member_name'] ?? ''));
        $msg  = $name !== ''
            ? 'Goodbye ' . $name . ' — exit recorded.'
            : __('guest_exit_success');

        echo json_encode([
            'success'     => true,
            'guest_name'  => $name,
            'guest_id'    => $guest['admno'] ?? '',
            'guest_photo' => $guest['guest_photo'] ?? '',
            'message'     => $msg,
        ]);
        exit;
    }

    echo json_encode(['error' => 'Invalid action']);
    exit;
}

$pageTitle = __('title', $lang);
?>
<!DOCTYPE html>
<html lang="<?= htmlspecialchars($lang) ?>" dir="<?= $lang === 'ar' ? 'rtl' : 'ltr' ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="auto-refresh" content="<?= (int)$autoRefresh ?>">
<meta name="default-avatar" content="<?= vms_h($defaultAvatar) ?>">
<meta name="csrf-token" content="<?= vms_h(function_exists('generateCSRFToken') ? generateCSRFToken() : '') ?>">
<meta name="book-camera-enabled" content="<?= (int)$bookCameraEnabled ?>">
<meta name="book-camera-auto-capture" content="<?= (int)$bookCameraAutoCapture ?>">
<title><?= vms_h($institutionName) ?> - <?= vms_h($pageTitle) ?></title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link href="https://fonts.googleapis.com/css2?family=<?= urlencode($fontFamily) ?>:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

<style>
:root {
    --primary-color: <?= $primaryColor ?>;
    --secondary-color: <?= $secondaryColor ?>;
    --accent-color: <?= $accentColor ?>;
    --body-bg: <?= $bodyBg ?>;
    --font-family: '<?= $fontFamily ?>', sans-serif;
    --header-bg-color: <?= $publicHeaderBgColor ?>;
    --header-text-color: <?= $publicHeaderTextColor ?>;
    --header-height: <?= $publicHeaderHeight ?>;
    --footer-bg: <?= $footerBg ?>;
    --footer-text-color: <?= $footerTextColor ?>;
}
* { box-sizing: border-box; margin: 0; padding: 0; }
body {
    font-family: var(--font-family);
    background: var(--body-bg);
    min-height: 100vh;
    padding: 10px;
}

html[dir="rtl"] .header-left  { direction: rtl; }
html[dir="rtl"] .footer-text  { direction: rtl; }
html[dir="rtl"] .lang-dropdown-menu { right: auto; left: 0; }

/* ─── HEADER ─── */
.public-header {
    background: var(--header-bg-color);
    color: var(--header-text-color);
    padding: 15px 0;
    border-radius: 20px;
    margin-bottom: 28px;
    box-shadow: 0 8px 30px rgba(0,0,0,.15);
    min-height: var(--header-height);
    position: relative;
    z-index: 5;
}
.header-container {
    display: flex;
    align-items: center;
    justify-content: space-between;
    max-width: 1500px;
    margin: 0 auto;
    padding: 0 24px;
    gap: 15px;
    flex-wrap: wrap;
}
.header-container.centered { flex-direction: column; text-align: center; }
.header-left { display: flex; align-items: center; gap: 15px; flex-wrap: wrap; }
.header-container.centered .header-left { justify-content: center; }
.header-logo { max-height: 55px; border-radius: 8px; }
.header-title h1 { font-size: 1.8rem; font-weight: 800; margin: 0; letter-spacing: -0.5px; }
.header-title p  { margin: 0; opacity: .85; font-size: .95rem; }

.lang-dropdown { position: relative; }
.lang-btn {
    background: rgba(255,255,255,.15);
    border: 1px solid rgba(255,255,255,.25);
    color: var(--header-text-color);
    padding: 8px 16px;
    border-radius: 30px;
    cursor: pointer;
    font-size: .85rem;
    font-weight: 500;
    display: flex;
    align-items: center;
    gap: 8px;
}
.lang-dropdown-menu {
    position: absolute;
    top: calc(100% + 8px);
    right: 0;
    background: #fff;
    border-radius: 16px;
    box-shadow: 0 12px 40px rgba(0,0,0,.3);
    min-width: 220px;
    max-height: 420px;
    overflow-y: auto;
    padding: 8px 0;
    z-index: 99999;
    display: none;
}
.lang-dropdown-menu.show { display: block; }
.lang-item {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 8px 20px;
    color: #2c3e50;
    text-decoration: none;
    font-size: .85rem;
}
.lang-item:hover { background: #f0f2f5; color: var(--primary-color); }
.lang-item.active { background: var(--primary-color); color: #fff; }

/* ─── LAYOUT ─── */
.kiosk-container { max-width: 1500px; margin: 0 auto; padding: 0 15px; }
.kiosk-row { display: flex; flex-wrap: wrap; gap: 24px; }
.kiosk-left  { flex: 0 0 calc(70% - 12px); width: calc(70% - 12px); }
.kiosk-right { flex: 0 0 calc(30% - 12px); width: calc(30% - 12px); }

/* ─── SCANNER CARD ─── */
.scanner-card {
    background: rgba(255,255,255,.95);
    border-radius: 24px;
    padding: 24px 28px 28px;
    box-shadow: 0 4px 24px rgba(0,0,0,.06);
    min-height: 700px;
    position: relative;
    border: 1px solid rgba(30,60,114,.06);
    overflow: visible;
}
.guest-btn {
    min-width: 90px;
    height: 90px;
    border-radius: 30px;
    display: inline-flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 3px;
    font-weight: 700;
    padding: 10px 14px;
    border: none;
    cursor: pointer;
    box-shadow: 0 4px 16px rgba(0,0,0,.10);
    position: absolute;
    top: 20px;
    z-index: 10;
    color: #fff;
}
.guest-btn-left  { left: 20px; background: var(--primary-color); }
.guest-btn-right { right: 20px; background: #dc3545; }
.guest-btn .fa-fingerprint { font-size: 2.2rem; }
.guest-btn:disabled { opacity: .6; cursor: not-allowed; }
html[dir="rtl"] .guest-btn-left  { left: auto; right: 20px; }
html[dir="rtl"] .guest-btn-right { right: auto; left: 20px; }

.scanner-card h2 { font-weight: 700; color: var(--primary-color); font-size: 1.6rem; }
.scanner-input {
    font-size: 1.4rem;
    text-align: center;
    height: 65px;
    border-radius: 60px;
    border: 2px solid var(--primary-color);
    padding: 0 25px;
    max-width: 420px;
    margin: 0 auto;
    transition: all .3s;
    display: block;
    width: 100%;
}
.scanner-input:focus {
    border-color: var(--accent-color);
    box-shadow: 0 0 0 4px rgba(255,193,7,.2);
    outline: none;
}
.scanner-input:disabled { opacity: .6; }

/* ─── PURPOSE SELECTOR ─── */
.purpose-selector {
    max-width: 420px;
    margin: 16px auto 0;
    position: relative;
    z-index: 3;
    background: #fff;
    border-radius: 12px;
    padding: 12px 14px;
    border: 1px solid #e9ecef;
    box-shadow: 0 2px 8px rgba(0,0,0,.04);
}
.purpose-selector label {
    font-size: .8rem;
    font-weight: 600;
    color: var(--primary-color);
    margin-bottom: 6px;
    display: block;
}
.purpose-selector select {
    width: 100%;
    padding: 10px 14px;
    border-radius: 10px;
    border: 1.5px solid #dee2e6;
    background: #fff;
    font-size: .95rem;
    cursor: pointer;
    position: relative;
    z-index: 3;
}
.purpose-selector select:focus {
    border-color: var(--primary-color);
    box-shadow: 0 0 0 3px rgba(30,60,114,.12);
    outline: none;
}

/* ─── SCAN RESULT WRAPPER ─── */
.scan-result-wrapper {
    position: relative;
    min-height: 260px;
    margin-top: 16px;
    pointer-events: auto;
}
.scan-result-wrapper > .content-container {
    position: relative;
    z-index: 1;
    opacity: 1;
    visibility: visible;
    background: rgba(248,249,250,.4);
    border-radius: 20px;
    padding: 16px;
    transition: opacity .4s, visibility .4s;
}
.scan-result-wrapper > .content-container.hidden {
    opacity: 0;
    visibility: hidden;
    pointer-events: none;
}
.scan-result-wrapper > .result-area {
    position: absolute;
    top: 0; left: 0; right: 0;
    opacity: 0;
    visibility: hidden;
    pointer-events: none;
    padding: 4px;
    transition: opacity .4s, visibility .4s;
}
.scan-result-wrapper > .result-area.visible {
    opacity: 1;
    visibility: visible;
    pointer-events: auto;
}

/* ─── COVER FLOW ─── */
.cover-flow-container {
    position: relative;
    width: 100%;
    height: 340px;
    margin: 10px 0 5px;
    overflow: hidden;
    touch-action: pan-y;
}
.cover-flow-track {
    display: flex;
    gap: 18px;
    position: absolute;
    left: 50%;
    transform: translateX(-50%);
    transition: transform .8s cubic-bezier(.25,.46,.45,.94);
    padding: 10px 0;
    align-items: center;
    height: 100%;
}
.cover-item {
    flex: 0 0 160px;
    height: 230px;
    border-radius: 12px;
    overflow: hidden;
    box-shadow: 0 8px 30px rgba(0,0,0,.15);
    transition: all .5s ease;
    cursor: pointer;
    position: relative;
    transform: scale(.85);
    opacity: .6;
}
.cover-item.active { transform: scale(1); opacity: 1; z-index: 5; }
.cover-item.prev, .cover-item.next { transform: scale(.92); opacity: .8; z-index: 3; }
.cover-item img { width: 100%; height: 100%; object-fit: cover; }
.cover-item .cover-info {
    position: absolute;
    bottom: 0; left: 0; right: 0;
    padding: 12px 10px 8px;
    background: linear-gradient(transparent, rgba(0,0,0,.8));
    color: #fff; font-size: .7rem;
    opacity: 0; transition: opacity .3s;
}
.cover-item:hover .cover-info { opacity: 1; }
.cover-item .cover-info .title  { font-weight: 600; font-size: .8rem; }
.cover-item .cover-info .author { font-size: .65rem; opacity: .8; }
.cover-item .cover-info .status {
    display: inline-block;
    padding: 1px 8px;
    border-radius: 10px;
    font-size: .55rem;
    font-weight: 600;
    margin-top: 2px;
}
.cover-item .cover-info .status.available { background: #28a745; }
.cover-item .cover-info .status.issued    { background: #ffc107; color: #212529; }
.cover-nav-btn {
    position: absolute;
    top: 50%; transform: translateY(-50%);
    background: rgba(255,255,255,.9);
    border: none;
    border-radius: 50%;
    width: 40px; height: 40px;
    display: flex; align-items: center; justify-content: center;
    font-size: 1.2rem;
    cursor: pointer;
    box-shadow: 0 4px 15px rgba(0,0,0,.1);
    z-index: 20;
    color: var(--primary-color);
}
.cover-nav-btn.prev { left: 5px; }
.cover-nav-btn.next { right: 5px; }
.cover-dots { display: flex; justify-content: center; gap: 8px; margin-top: 6px; }
.cover-dot  { width: 8px; height: 8px; border-radius: 50%; background: #dce4ed; border: none; padding: 0; cursor: pointer; }
.cover-dot.active { background: var(--primary-color); width: 24px; border-radius: 4px; }

/* ─── MEMBER / BOOK RESULTS ─── */
.member-photo {
    width: 160px; height: 160px;
    border-radius: 16px;
    object-fit: cover;
    border: 4px solid var(--primary-color);
    margin: 12px auto; display: block;
    background: #f8f9fa;
}
.greeting-message {
    font-size: 1.1rem; font-weight: 700;
    padding: 10px; border-radius: 60px;
    margin: 10px 0;
    animation: fadeInUp .35s ease;
}
.greeting-welcome { background: #d1e7dd; color: #0f5132; }
.greeting-thanks  { background: #f8d7da; color: #842029; }
@keyframes fadeInUp {
    from { opacity: 0; transform: translateY(20px); }
    to   { opacity: 1; transform: translateY(0); }
}

.book-alert { border-radius: 16px; padding: 16px; margin-top: 12px; }
.book-alert.unauthorized {
    background: #f8d7da; border: 1px solid #f5c6cb; color: #721c24;
    animation: pulseGlow 1s ease-in-out 2;
}
.book-alert.authorized { background: #d4edda; border: 1px solid #c3e6cb; color: #155724; }
.book-alert .book-title  { font-weight: 700; font-size: 1.05rem; margin-bottom: 2px; }
.book-alert .book-meta   { font-size: .8rem; opacity: .85; }
.book-alert .book-status { font-weight: 700; margin-top: 6px; }
.book-alert .recorded-tag {
    display: inline-block;
    margin-top: 6px;
    background: #1e3c72;
    color: #fff;
    font-size: .7rem;
    font-weight: 600;
    padding: 2px 10px;
    border-radius: 12px;
}
.book-alert .error-hint {
    margin-top: 8px;
    padding: 8px 12px;
    background: #fff3cd;
    border-left: 3px solid #ffc107;
    border-radius: 6px;
    font-size: .78rem;
    color: #856404;
    word-break: break-word;
}
@keyframes pulseGlow {
    0%, 100% { box-shadow: 0 0 0 0 rgba(220, 53, 69, 0.3); }
    50%      { box-shadow: 0 0 0 12px rgba(220, 53, 69, 0); }
}

/* ─── CAMERA MODAL ─── */
.camera-modal-backdrop {
    position: fixed;
    inset: 0;
    background: rgba(0,0,0,.55);
    z-index: 99999;
    display: none;
    backdrop-filter: blur(3px);
}
.camera-modal-backdrop.open { display: block; }

.camera-modal {
    position: fixed;
    top: 50%; left: 50%;
    transform: translate(-50%, -50%) scale(0.9);
    width: min(92vw, 480px);
    background: #fff;
    border-radius: 20px;
    padding: 18px;
    box-shadow: 0 30px 80px rgba(0,0,0,.5);
    z-index: 100000;
    display: none;
    flex-direction: column;
    align-items: center;
    gap: 12px;
    opacity: 0;
    transition: opacity .25s, transform .25s;
}
.camera-modal.open {
    display: flex;
    opacity: 1;
    transform: translate(-50%, -50%) scale(1);
}

.camera-header {
    width: 100%;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 8px;
}
.camera-header .title {
    font-weight: 700;
    color: #dc3545;
    font-size: 1.05rem;
    display: flex;
    align-items: center;
    gap: 8px;
}
.camera-header .subtitle { font-size: .78rem; color: #6c757d; }

.camera-frame {
    position: relative;
    width: 100%;
    aspect-ratio: 4 / 3;
    border-radius: 14px;
    overflow: hidden;
    background: #000;
    border: 3px solid #dc3545;
}
.camera-frame video {
    width: 100%; height: 100%;
    object-fit: cover;
    display: block;
}

.camera-actions {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
    justify-content: center;
    width: 100%;
}
.camera-actions .btn { min-width: 130px; }

.camera-status-text {
    font-size: .78rem;
    color: #6c757d;
    text-align: center;
    min-height: 18px;
}

/* ─── GUEST NAME MODAL (v9.0 — optional) ─── */
.guest-name-backdrop {
    position: fixed;
    inset: 0;
    background: rgba(0,0,0,.55);
    z-index: 100002;
    display: none;
    align-items: center;
    justify-content: center;
    backdrop-filter: blur(3px);
    padding: 16px;
}
.guest-name-backdrop.open { display: flex; }

.guest-name-modal {
    background: #fff;
    border-radius: 20px;
    padding: 26px;
    width: min(92vw, 440px);
    box-shadow: 0 30px 80px rgba(0,0,0,.5);
    animation: guestModalIn .25s ease;
}
@keyframes guestModalIn {
    from { opacity: 0; transform: translateY(12px) scale(.96); }
    to   { opacity: 1; transform: translateY(0)     scale(1); }
}
.guest-name-modal h3 {
    margin: 0 0 6px;
    color: var(--primary-color);
    font-size: 1.25rem;
    font-weight: 800;
    display: flex;
    align-items: center;
    gap: 10px;
}
.guest-name-modal p {
    margin: 0 0 16px;
    color: #6c757d;
    font-size: .9rem;
    line-height: 1.4;
}
.guest-name-modal .form-label {
    font-weight: 600;
    font-size: .85rem;
    color: #2c3e50;
    margin-bottom: 6px;
}
.guest-name-modal .form-label .opt-hint {
    font-weight: 500;
    color: #6c757d;
    font-size: .78rem;
}
.guest-name-modal .form-control {
    padding: 12px 14px;
    border: 2px solid #dee2e6;
    border-radius: 10px;
    font-size: 1rem;
    width: 100%;
    outline: none;
    transition: border-color .2s, box-shadow .2s;
}
.guest-name-modal .form-control:focus {
    border-color: var(--primary-color);
    box-shadow: 0 0 0 3px rgba(30,60,114,.12);
}
.guest-name-modal .error-hint {
    font-size: .78rem;
    color: #dc3545;
    min-height: 16px;
    margin-top: 4px;
}
.guest-name-modal .actions {
    display: flex;
    gap: 10px;
    margin-top: 18px;
}
.guest-name-modal .actions button {
    flex: 1;
    padding: 11px 14px;
    border-radius: 10px;
    cursor: pointer;
    font-weight: 600;
    font-size: .95rem;
    border: none;
    transition: all .15s;
}
.guest-name-modal .btn-cancel {
    background: #f8f9fa;
    color: #495057;
    border: 1px solid #dee2e6;
}
.guest-name-modal .btn-cancel:hover { background: #e9ecef; }
.guest-name-modal .btn-primary-custom {
    background: var(--primary-color);
    color: #fff;
}
.guest-name-modal .btn-primary-custom:hover {
    filter: brightness(1.1);
    transform: translateY(-1px);
}

/* ─── STATS ─── */
.stats-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 12px; margin-bottom: 16px; }
.stat-card-static {
    background: #fff; border-radius: 20px;
    padding: 14px 10px; text-align: center;
    box-shadow: 0 2px 12px rgba(0,0,0,.04);
    min-height: 85px;
    display: flex; flex-direction: column; align-items: center; justify-content: center;
}
.stat-card-static h3 { font-size: 1.3rem; font-weight: 700; margin: 0; color: var(--primary-color); }
.stat-card-static p  { margin: 0; font-size: .75rem; color: #6c757d; }
.stats-card {
    background: #fff; border-radius: 20px;
    padding: 18px 20px;
    box-shadow: 0 2px 12px rgba(0,0,0,.04);
}
.stats-card h4 { font-size: .95rem; font-weight: 600; color: var(--primary-color); margin-bottom: 0; }
.stat-number { font-size: 1.6rem; font-weight: 800; color: var(--primary-color); }
.stat-card-inner {
    background: #f8f9fa; border-radius: 12px;
    padding: 8px 14px; margin-bottom: 5px;
}
.progress-purpose { height: 6px; border-radius: 10px; background: #e9ecef; overflow: hidden; }
.progress-bar-purpose { background: var(--primary-color); height: 100%; transition: width .6s; }

.info-card { background: #fff; border-radius: 20px; padding: 18px 22px; box-shadow: 0 2px 12px rgba(0,0,0,.04); }
.info-card h5 { font-weight: 600; color: var(--primary-color); font-size: .95rem; }
.quote-text { font-style: italic; font-size: .85rem; color: #495057; }
.quote-author { font-size: .75rem; color: #6c757d; }

/* ─── TOAST ─── */
.vms-toast-container {
    position: fixed;
    top: 20px; left: 50%;
    transform: translateX(-50%);
    z-index: 100001;
    display: flex;
    flex-direction: column;
    gap: 10px;
    max-width: 420px;
    width: calc(100% - 40px);
    pointer-events: none;
}
.vms-toast {
    background: #fff;
    border-radius: 12px;
    padding: 12px 16px;
    box-shadow: 0 12px 40px rgba(0,0,0,.18);
    display: flex;
    align-items: flex-start;
    gap: 12px;
    border-left: 4px solid var(--primary-color);
    pointer-events: auto;
    animation: slideDown .3s ease;
}
.vms-toast.success { border-left-color: #28a745; }
.vms-toast.danger  { border-left-color: #dc3545; }
.vms-toast.warning { border-left-color: #ffc107; }
.vms-toast.info    { border-left-color: #17a2b8; }
.vms-toast .toast-icon { font-size: 1.2rem; flex-shrink: 0; }
.vms-toast.success .toast-icon { color: #28a745; }
.vms-toast.danger  .toast-icon { color: #dc3545; }
.vms-toast.warning .toast-icon { color: #ffc107; }
.vms-toast.info    .toast-icon { color: #17a2b8; }
.vms-toast .toast-content { flex: 1; }
.vms-toast .toast-msg   { font-size: .85rem; color: #2c3e50; }
.vms-toast .toast-close {
    background: none; border: none;
    color: #adb5bd; cursor: pointer;
    padding: 0; font-size: 1rem;
}
@keyframes slideDown {
    from { opacity: 0; transform: translateY(-12px); }
    to   { opacity: 1; transform: translateY(0); }
}

/* ─── FOOTER ─── */
.footer {
    margin-top: 20px;
    padding: 8px 20px;
    background: var(--footer-bg);
    color: var(--footer-text-color);
    border-radius: 20px;
    font-size: .72rem;
}
.footer-inner {
    display: grid;
    grid-template-columns: 1fr auto 1fr;
    align-items: center;
    gap: 12px;
    max-width: 1500px;
    margin: 0 auto;
    min-height: 34px;
}
.footer-logo { max-height: 28px; justify-self: start; }
.footer-text { display: flex; align-items: center; justify-content: center; gap: 8px; flex-wrap: wrap; }
.footer-link { color: #ffd700; text-decoration: none; font-weight: 600; }
.footer-link:hover { color: #fff; }

/* ─── RESPONSIVE ─── */
@media (max-width: 992px) {
    .kiosk-left, .kiosk-right { flex: 0 0 100%; width: 100%; }
}
@media (max-width: 768px) {
    .header-title h1 { font-size: 1.2rem; }
    .header-logo { max-height: 40px; }
    .guest-btn { position: static; width: auto; height: 65px; min-width: 60px; font-size: .7rem; border-radius: 24px; margin: 4px; }
    .guest-btn .fa-fingerprint { font-size: 1.6rem; }
    .scanner-card { min-height: auto; padding: 18px 16px 20px; }
    .member-photo { width: 120px; height: 120px; }
    .cover-flow-container { height: 260px; }
    .cover-item { flex: 0 0 120px; height: 170px; }
    .guest-name-modal { padding: 20px; }
}
@media (max-width: 480px) {
    .cover-flow-container { height: 200px; }
    .cover-item { flex: 0 0 90px; height: 130px; }
    .cover-info { display: none; }
    .footer-sep { display: none; }
}
</style>
</head>
<body>

<!-- ============================================================
HEADER
============================================================ -->
<header class="public-header">
    <div class="header-container <?= htmlspecialchars($publicHeaderLayout) ?>">
        <div class="header-left">
            <?php if ($publicShowHeaderLogo && $headerLogo): ?>
                <img src="<?= vms_h($headerLogo) ?>" alt="<?= vms_h($institutionName) ?>" class="header-logo">
            <?php endif; ?>
            <div class="header-title">
                <h1><?= vms_h($publicHeaderTitle) ?></h1>
                <p><?= vms_h($publicHeaderSubtitle) ?></p>
            </div>
        </div>
        <div class="header-right">
            <div class="lang-dropdown">
                <button class="lang-btn" onclick="toggleLanguageDropdown()" id="langToggle" type="button">
                    <i class="fas fa-globe"></i>
                    <span><?= strtoupper($lang) ?></span>
                    <i class="fas fa-chevron-down" style="font-size:.6rem;opacity:.6;"></i>
                </button>
                <div class="lang-dropdown-menu" id="langDropdown">
                    <?php
                    $flags = function_exists('getLanguageFlags')
                        ? getLanguageFlags()
                        : ['en'=>'🇬🇧','hi'=>'🇮🇳','ar'=>'🇸🇦','ml'=>'🇮🇳','ta'=>'🇮🇳','te'=>'🇮🇳',
                           'fr'=>'🇫🇷','es'=>'🇪🇸','de'=>'🇩🇪','pt'=>'🇵🇹','ru'=>'🇷🇺','zh'=>'🇨🇳','ja'=>'🇯🇵'];
                    foreach ($availableLanguages as $code => $name): ?>
                        <a href="?lang=<?= urlencode($code) ?>" class="lang-item <?= $lang === $code ? 'active' : '' ?>">
                            <span><?= $flags[$code] ?? '🌐' ?></span>
                            <?= vms_h($name) ?>
                            <?php if ($lang === $code): ?><i class="fas fa-check ms-auto"></i><?php endif; ?>
                        </a>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</header>

<!-- ============================================================
MAIN
============================================================ -->
<div class="kiosk-container">
    <div class="kiosk-row">
        <div class="kiosk-left">
            <div class="scanner-card">

                <?php if ($guestEnabled): ?>
                    <button id="guestEntryBtn" class="guest-btn guest-btn-left" type="button">
                        <i class="fas fa-fingerprint"></i>
                        <span><?= vms_h(__('guest_entry', $lang)) ?></span>
                    </button>
                    <button id="guestExitBtn" class="guest-btn guest-btn-right" type="button">
                        <i class="fas fa-fingerprint"></i>
                        <span><?= vms_h(__('guest_exit', $lang)) ?></span>
                    </button>
                <?php endif; ?>

                <h2 class="text-center" style="margin-top: 80px;"><?= vms_h(__('title', $lang)) ?></h2>
                <p class="text-muted small text-center"><?= vms_h(__('scan_prompt', $lang)) ?></p>

                <input type="text" id="scanInput" class="scanner-input"
                       placeholder="<?= vms_h(__('scan_placeholder', $lang)) ?>" autofocus autocomplete="off">

                <?php if ($requirePurpose): ?>
                <div class="purpose-selector">
                    <label for="purposeSelect">
                        <i class="fas fa-tag text-primary"></i> <?= vms_h(__('purpose_label', $lang)) ?>
                    </label>
                    <select id="purposeSelect" name="purpose" onchange="onPurposeChange(this)">
                        <?php foreach (vms_purpose_options() as $value => $meta):
                            $sel   = ($defaultPurpose === $value) ? ' selected' : '';
                            $i18nKey = strtolower(str_replace(['/',' '], ['_','_'], $value));
                            $label = function_exists('__') ? __($i18nKey, $lang) : $meta['label'];
                            if ($label === $i18nKey) $label = $meta['label'];
                        ?>
                            <option value="<?= htmlspecialchars($value, ENT_QUOTES) ?>"<?= $sel ?>>
                                <?= $meta['icon'] ?> <?= vms_h($label) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <?php endif; ?>

                <input type="hidden" id="selectedPurpose" value="<?= htmlspecialchars($defaultPurpose) ?>">

                <div class="scan-result-wrapper">
                    <div id="contentContainer" class="content-container">
                        <?php if ($showCoverFlow && !empty($newArrivals)): ?>
                            <div class="cover-flow-container" id="coverFlowContainer">
                                <button class="cover-nav-btn prev" id="coverPrev" type="button"><i class="fas fa-chevron-left"></i></button>
                                <div class="cover-flow-track" id="coverFlowTrack">
                                    <?php foreach ($newArrivals as $i => $book):
                                        $cover = getBookCover($book['biblionumber'], $book['title'], $book['author'], $book['isbn'] ?? '');
                                        $avail = (int)($book['available_copies'] ?? 0);
                                    ?>
                                        <div class="cover-item <?= $i === 0 ? 'active' : '' ?>">
                                            <img src="<?= vms_h($cover) ?>" alt="" loading="lazy">
                                            <div class="cover-info">
                                                <div class="title"><?= vms_h(substr($book['title'], 0, 30)) ?></div>
                                                <div class="author"><?= vms_h($book['author'] ?? '') ?></div>
                                                <span class="status <?= $avail ? 'available' : 'issued' ?>">
                                                    <?= $avail ? vms_h(__('available', $lang)) : vms_h(__('issued', $lang)) ?>
                                                </span>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                                <button class="cover-nav-btn next" id="coverNext" type="button"><i class="fas fa-chevron-right"></i></button>
                            </div>
                            <div class="cover-dots" id="coverDots">
                                <?php foreach ($newArrivals as $i => $book): ?>
                                    <button class="cover-dot <?= $i === 0 ? 'active' : '' ?>" data-index="<?= $i ?>"></button>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div id="resultArea" class="result-area"></div>
                </div>

            </div>
        </div>

        <div class="kiosk-right">
            <div class="stats-grid">
                <div class="stat-card-static">
                    <i class="fas fa-calendar-alt text-primary"></i>
                    <h3><?= date('d M Y') ?></h3>
                    <p><?= vms_h(__('today', $lang)) ?></p>
                </div>
                <div class="stat-card-static">
                    <i class="fas fa-clock text-warning"></i>
                    <h3 id="currentTime"><?= date('h:i:s A') ?></h3>
                    <p><?= vms_h(__('current_time', $lang)) ?></p>
                </div>
            </div>

            <?php if ($showLiveStats): ?>
            <div class="stats-card">
                <h4><i class="fas fa-chart-line"></i> <?= vms_h(__('live_status', $lang)) ?></h4>
                <hr>
                <div id="statsArea">
                    <div class="text-center py-3">
                        <div class="spinner-border text-primary spinner-border-sm"></div>
                        <?= vms_h(__('loading', $lang)) ?>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <?php if ($showPurposeChart): ?>
    <div class="row g-4 mt-2">
        <div class="col-12">
            <div class="info-card">
                <h5><i class="fas fa-chart-pie"></i> <?= vms_h(__('purpose_distribution', $lang)) ?></h5>
                <div id="purposeStatsContainer">
                    <div class="text-center py-2">
                        <i class="fas fa-spinner fa-spin"></i> <?= vms_h(__('loading', $lang)) ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <?php if ($showQuote): ?>
    <div class="row g-4 mt-2">
        <div class="col-12">
            <div class="info-card">
                <h5><i class="fas fa-quote-left"></i> <?= vms_h(__('quote_of_the_day', $lang)) ?></h5>
                <div class="quote-text">"<?= vms_h($quote['text']) ?>"</div>
                <div class="quote-author">— <?= vms_h($quote['author']) ?></div>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <footer class="footer">
        <div class="footer-inner">
            <?php if ($showFooterLogo && $headerLogo): ?>
                <img src="<?= vms_h($headerLogo) ?>" class="footer-logo" alt="">
            <?php else: ?>
                <span></span>
            <?php endif; ?>
            <div class="footer-text">
                <span>&copy; <?= date('Y') ?> <strong><?= vms_h($institutionName) ?></strong></span>
                <span class="footer-sep">•</span>
                <span><?= vms_h(__('all_rights_reserved', $lang)) ?></span>
                <span class="footer-sep">•</span>
                <span><?= vms_h(__('designed_by', $lang)) ?>
                    <a href="https://www.linkedin.com/in/sameermon-m-559692186"
                       target="_blank" rel="noopener noreferrer" class="footer-link">Sameermon M</a>
                </span>
            </div>
            <span></span>
        </div>
    </footer>
</div>

<!-- ============================================================
CAMERA MODAL — instant capture
============================================================ -->
<div class="camera-modal-backdrop" id="cameraBackdrop"></div>
<div class="camera-modal" id="cameraModal" role="dialog" aria-modal="true">
    <div class="camera-header">
        <div>
            <div class="title" id="cameraModalTitle"><i class="fas fa-camera"></i> Capturing Photo…</div>
            <div class="subtitle" id="cameraModalSubtitle">Please look at the camera</div>
        </div>
    </div>

    <div class="camera-frame">
        <video id="cameraVideo" autoplay playsinline muted></video>
        <canvas id="cameraCanvas" style="display:none;"></canvas>
    </div>

    <div class="camera-status-text" id="cameraStatusText">Starting camera…</div>

    <div class="camera-actions">
        <button type="button" class="btn btn-danger" id="cameraCaptureNow" onclick="captureKioskPhoto(true)">
            <i class="fas fa-camera me-1"></i> Capture Now
        </button>
        <button type="button" class="btn btn-outline-secondary" onclick="skipKioskPhoto()">
            <i class="fas fa-forward me-1"></i> Skip Photo
        </button>
    </div>
</div>

<!-- ============================================================
GUEST NAME MODAL — v9.0 (optional)
============================================================ -->
<div class="guest-name-backdrop" id="guestNameBackdrop">
    <div class="guest-name-modal" role="dialog" aria-modal="true" aria-labelledby="guestNameTitle">
        <h3 id="guestNameTitle">
            <i class="fas fa-user-plus"></i>
            <span><?= vms_h(__('guest_entry', $lang)) ?></span>
        </h3>
        <p><?= vms_h(__('guest_name_prompt', $lang) ?: 'You may enter your name, or skip to continue as an unnamed guest.') ?></p>

        <label class="form-label" for="guestNameInput">
            <?= vms_h(__('guest_name', $lang) ?: 'Guest Name') ?>
            <span class="opt-hint">(<?= vms_h(__('optional', $lang) ?: 'optional') ?>)</span>
        </label>
        <input type="text" id="guestNameInput" class="form-control"
               autocomplete="off" maxlength="120"
               placeholder="<?= vms_h(__('guest_name_placeholder', $lang) ?: 'Your full name (optional)') ?>">
        <div class="error-hint" id="guestNameError"></div>

        <div class="actions">
            <button type="button" class="btn-cancel" id="guestNameSkip">
                <?= vms_h(__('skip', $lang) ?: 'Skip') ?>
            </button>
            <button type="button" class="btn-primary-custom" id="guestNameOk">
                <?= vms_h(__('continue', $lang) ?: 'Continue') ?>
                <i class="fas fa-arrow-right ms-1"></i>
            </button>
        </div>
    </div>
</div>

<!-- ============================================================
SCRIPTS
============================================================ -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<script>
/* ============================================================
   TRANSLATIONS FOR JS (server-rendered)
   ============================================================ */
const I18N = {
    <?php
    $jsKeys = [
        'welcome','goodbye','to_library','loading','processing',
        'entry_recorded','exit_recorded','member_not_found','valid_id',
        'book_authorized','book_unauthorized','network_error',
        'guest_entry_success','guest_exit_success','no_active_guests',
        'currently_inside','visitors_today','male','female','other',
        'inside_by_category','entry_success','exit_success',
        'purpose_label','scan_prompt','scan_placeholder',
        'not_recognised','book_not_found','id_not_recognised',
        'guest_name','guest_name_placeholder','guest_name_prompt',
        'cancel','continue','guest_entry','skip','optional'
    ];
    $pairs = [];
    foreach ($jsKeys as $k) {
        $pairs[] = "'" . $k . "': " . json_encode(vms_plain(__($k, $lang)), JSON_UNESCAPED_UNICODE);
    }
    echo implode(",\n    ", $pairs);
    ?>
};
function t(key, fallback) { return (I18N && I18N[key]) ? I18N[key] : (fallback || key); }

/* ============================================================
   GLOBAL STATE
   ============================================================ */
const KIOSK = {
    ajaxUrl: (function () {
        try { return window.location.origin + window.location.pathname; }
        catch (e) { return window.location.href.split('?')[0].split('#')[0]; }
    })(),
    defaultAvatar: document.querySelector('meta[name="default-avatar"]')?.content || '',
    autoRefresh: parseInt(document.querySelector('meta[name="auto-refresh"]')?.content || '10', 10) * 1000,
    bookCameraEnabled: (document.querySelector('meta[name="book-camera-enabled"]')?.content || '1') === '1',
    isProcessing: false,
    scanTimer: null,
    currentLang: <?= json_encode($lang) ?>,

    pendingUnauthBook: null,
    cameraStream: null,
    cameraCaptureTriggered: false,
    cameraPollTimer: null,

    cameraMode: 'unauth',
    guestName: '',
    pendingGuestResolver: null,
};

/* ============================================================
   UTILITIES
   ============================================================ */
function escapeHtml(str) {
    if (str == null) return '';
    const d = document.createElement('div');
    d.textContent = String(str);
    return d.innerHTML;
}
function clearScanInput() {
    const i = document.getElementById('scanInput');
    if (i) i.value = '';
}
function log(...args) { console.log('[KIOSK]', ...args); }

/* ============================================================
   TOAST
   ============================================================ */
function showToast(message, type = 'info', duration = 4000) {
    let container = document.getElementById('vmsToastContainer');
    if (!container) {
        container = document.createElement('div');
        container.id = 'vmsToastContainer';
        container.className = 'vms-toast-container';
        document.body.appendChild(container);
    }
    const icons = {
        success: 'fa-check-circle',
        danger:  'fa-exclamation-triangle',
        warning: 'fa-exclamation-circle',
        info:    'fa-info-circle'
    };
    const toast = document.createElement('div');
    toast.className = 'vms-toast ' + type;
    toast.innerHTML =
        '<div class="toast-icon"><i class="fas ' + (icons[type] || icons.info) + '"></i></div>' +
        '<div class="toast-content"><div class="toast-msg">' + escapeHtml(message) + '</div></div>' +
        '<button class="toast-close"><i class="fas fa-times"></i></button>';
    toast.querySelector('.toast-close').addEventListener('click', () => toast.remove());
    container.appendChild(toast);
    setTimeout(() => {
        toast.style.transition = 'opacity .3s, transform .3s';
        toast.style.opacity = '0';
        toast.style.transform = 'translateY(-12px)';
        setTimeout(() => toast.remove(), 300);
    }, duration);
}

/* ============================================================
   SHUTTER SOUND
   ============================================================ */
function shutterSound() {
    try {
        const AudioCtx = window.AudioContext || window.webkitAudioContext;
        if (!AudioCtx) return;
        const ctx = new AudioCtx();
        const now = ctx.currentTime;
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'square';
        osc.frequency.setValueAtTime(1600, now);
        osc.frequency.setValueAtTime(900, now + 0.04);
        gain.gain.setValueAtTime(0.20, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.09);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now);
        osc.stop(now + 0.10);
        setTimeout(() => { try { ctx.close(); } catch (e) {} }, 500);
    } catch (e) {}
}

/* ============================================================
   PURPOSE DROPDOWN
   ============================================================ */
function onPurposeChange(el) {
    const hidden = document.getElementById('selectedPurpose');
    if (hidden) hidden.value = el.value;
}
function getSelectedPurpose() {
    const hidden = document.getElementById('selectedPurpose');
    if (hidden && hidden.value) return hidden.value;
    const sel = document.getElementById('purposeSelect');
    return sel ? sel.value : 'Reading/Study';
}

/* ============================================================
   RESULT AREA
   ============================================================ */
function showResult(html) {
    const content = document.getElementById('contentContainer');
    const result  = document.getElementById('resultArea');
    if (content) content.classList.add('hidden');
    if (result) {
        result.innerHTML = html;
        result.classList.add('visible');
    }
    if (window.__coverTimer) { clearInterval(window.__coverTimer); window.__coverTimer = null; }
}
function backToContent(delay = 5000) {
    setTimeout(() => {
        const result  = document.getElementById('resultArea');
        const content = document.getElementById('contentContainer');
        if (result)  result.classList.remove('visible');
        if (content) content.classList.remove('hidden');
        setTimeout(() => {
            if (result && !result.classList.contains('visible')) result.innerHTML = '';
        }, 300);
        if (window.__coverRestart) window.__coverRestart();
    }, delay);
}
function cooldown(ms = 500) {
    const i = document.getElementById('scanInput');
    if (!i) return;
    i.disabled = true;
    i.style.opacity = '0.6';
    setTimeout(() => {
        i.disabled = false;
        i.style.opacity = '1';
        i.focus();
    }, ms);
}

/* ============================================================
   FETCH HELPERS
   ============================================================ */
async function fetchWithRetry(url, options = {}, retries = 3) {
    try {
        const response = await fetch(url, options);
        if (response.status >= 400 && response.status < 500) {
            try { return await response.json(); }
            catch (e) { throw new Error('HTTP ' + response.status); }
        }
        if (!response.ok) throw new Error('HTTP ' + response.status);
        return await response.json();
    } catch (error) {
        if (retries > 0 && !/HTTP 4/.test(error.message)) {
            await new Promise(r => setTimeout(r, 800));
            return fetchWithRetry(url, options, retries - 1);
        }
        throw error;
    }
}
function fetchJson(url, opts) {
    return fetchWithRetry(url, opts || { credentials: 'same-origin' });
}

/* ============================================================
   SCAN PIPELINE
   ============================================================ */
async function processScan(value) {
    value = (value || '').trim();
    if (value.length < 2 || KIOSK.isProcessing) return;

    KIOSK.isProcessing = true;
    log('processScan:', value);

    let book = null;
    try { book = await fetchJson(KIOSK.ajaxUrl + '?ajax=check_book&barcode=' + encodeURIComponent(value)); }
    catch (e) { log('check_book error:', e); book = null; }

    if (book && book.is_book) {
        await handleBook(book);
        KIOSK.isProcessing = false;
        return;
    }

    let member = null;
    try { member = await fetchJson(KIOSK.ajaxUrl + '?ajax=get_member&admno=' + encodeURIComponent(value)); }
    catch (e) { log('get_member error:', e); member = null; }

    if (member && member.member) {
        await handleMember(value, member);
        KIOSK.isProcessing = false;
        return;
    }

    showResult(
        '<div class="alert alert-warning text-center">' +
            '<i class="fas fa-question-circle me-2"></i>' +
            escapeHtml(t('not_recognised', 'ID not recognised')) +
            ': <strong>' + escapeHtml(value) + '</strong>' +
        '</div>'
    );
    clearScanInput();
    cooldown();
    backToContent(4000);
    KIOSK.isProcessing = false;
}

/* ============================================================
   BOOK HANDLER
   ============================================================ */
async function handleBook(info) {
    const b    = info.book || {};
    const auth = !!info.is_authorized;
    const member = info.member;

    if (auth) {
        showResult(
            '<div class="book-alert authorized">' +
                '<div class="d-flex align-items-start">' +
                    '<span style="font-size:2rem;margin-right:12px;">✅</span>' +
                    '<div>' +
                        '<div class="book-title">' + escapeHtml(b.title || 'Untitled') + '</div>' +
                        '<div class="book-meta">' + escapeHtml(b.author || '') + ' · ' + escapeHtml(b.barcode || '') + '</div>' +
                        '<div class="book-status">' + escapeHtml(t('book_authorized', 'Authorized exit')) + '</div>' +
                        (member && member.full_name
                            ? '<div class="book-meta mt-1"><i class="fas fa-user me-1"></i> ' + escapeHtml(member.full_name) + '</div>'
                            : '') +
                    '</div>' +
                '</div>' +
            '</div>'
        );
        clearScanInput();
        cooldown();
        backToContent(6000);
        return;
    }

    log('unauthorized book detected:', b);
    KIOSK.pendingUnauthBook = b;
    KIOSK.cameraMode = 'unauth';

    showResult(
        '<div class="book-alert unauthorized">' +
            '<div class="d-flex align-items-start">' +
                '<span style="font-size:2rem;margin-right:12px;">⚠️</span>' +
                '<div>' +
                    '<div class="book-title">' + escapeHtml(b.title || 'Untitled') + '</div>' +
                    '<div class="book-meta">' + escapeHtml(b.author || '') + ' · ' + escapeHtml(b.barcode || '') + '</div>' +
                    '<div class="book-status">' + escapeHtml(t('book_unauthorized', 'Unauthorized exit!')) + '</div>' +
                    '<div class="book-meta mt-1">' +
                        '<i class="fas fa-camera me-1"></i> Capturing photo…' +
                    '</div>' +
                '</div>' +
            '</div>' +
        '</div>'
    );

    if (!KIOSK.bookCameraEnabled || !navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        log('camera unavailable, recording without photo');
        await recordUnauthorizedBook('');
        clearScanInput();
        cooldown();
        backToContent(7000);
        return;
    }

    setCameraModalLabels(
        'Unauthorized Book Exit',
        'Photo captures instantly',
        'Capture Now'
    );
    openCameraModal();
    const inp = document.getElementById('scanInput');
    if (inp) inp.disabled = true;
}

/* ============================================================
   CAMERA MODAL — instant capture
   ============================================================ */
function setCameraModalLabels(titleHtml, subtitle, captureBtnText) {
    const titleEl = document.getElementById('cameraModalTitle');
    const subEl   = document.getElementById('cameraModalSubtitle');
    const capBtn  = document.getElementById('cameraCaptureNow');
    if (titleEl) titleEl.innerHTML = '<i class="fas fa-camera"></i> ' + titleHtml;
    if (subEl)   subEl.textContent = subtitle;
    if (capBtn)  capBtn.innerHTML = '<i class="fas fa-camera me-1"></i> ' + captureBtnText;
}

function openCameraModal() {
    log('opening camera modal (instant capture)');

    const backdrop = document.getElementById('cameraBackdrop');
    const modal    = document.getElementById('cameraModal');
    const video    = document.getElementById('cameraVideo');
    const statusTxt= document.getElementById('cameraStatusText');

    if (!modal || !video) {
        if (KIOSK.cameraMode === 'guest') {
            resolveGuestPhoto('');
        } else {
            recordUnauthorizedBook('');
        }
        return;
    }

    KIOSK.cameraCaptureTriggered = false;
    KIOSK.cameraMode = KIOSK.cameraMode || 'unauth';

    backdrop?.classList.add('open');
    modal.classList.add('open');

    statusTxt.textContent = 'Starting camera…';

    function tryCapture() {
        if (KIOSK.cameraCaptureTriggered) return;

        const v = document.getElementById('cameraVideo');
        if (!v) return;

        if (v.readyState >= 2 && v.videoWidth > 0 && v.videoHeight > 0) {
            if (KIOSK.cameraPollTimer) {
                clearInterval(KIOSK.cameraPollTimer);
                KIOSK.cameraPollTimer = null;
            }
            log('first frame ready — capturing immediately');
            requestAnimationFrame(() => captureKioskPhoto(true));
            return;
        }
    }

    if (KIOSK.cameraPollTimer) {
        clearInterval(KIOSK.cameraPollTimer);
        KIOSK.cameraPollTimer = null;
    }

    navigator.mediaDevices.getUserMedia({
        video: { facingMode: { ideal: 'environment' }, width: { ideal: 1280 }, height: { ideal: 960 } },
        audio: false
    })
    .then(stream => {
        log('camera stream acquired');
        KIOSK.cameraStream = stream;
        video.srcObject = stream;

        video.onloadedmetadata = () => {
            const p = video.play();
            if (p && typeof p.catch === 'function') p.catch(() => {});
        };

        KIOSK.cameraPollTimer = setInterval(tryCapture, 30);

        video.addEventListener('loadeddata',   tryCapture, { once: true });
        video.addEventListener('canplay',      tryCapture, { once: true });
        video.addEventListener('playing',      tryCapture, { once: true });

        setTimeout(() => {
            if (!KIOSK.cameraCaptureTriggered) {
                log('safety net — capturing after timeout');
                if (KIOSK.cameraPollTimer) {
                    clearInterval(KIOSK.cameraPollTimer);
                    KIOSK.cameraPollTimer = null;
                }
                captureKioskPhoto(true);
            }
        }, 2500);

        statusTxt.textContent = 'Capturing…';
    })
    .catch(err => {
        log('camera error:', err);
        statusTxt.textContent = 'Camera unavailable — continuing without photo…';
        setTimeout(() => {
            closeCameraModal();
            if (KIOSK.cameraMode === 'guest') {
                resolveGuestPhoto('');
            } else {
                recordUnauthorizedBook('');
            }
        }, 300);
    });
}

function closeCameraModal() {
    log('closing camera modal');
    const backdrop = document.getElementById('cameraBackdrop');
    const modal    = document.getElementById('cameraModal');
    const video    = document.getElementById('cameraVideo');

    backdrop?.classList.remove('open');
    modal?.classList.remove('open');

    if (KIOSK.cameraPollTimer) {
        clearInterval(KIOSK.cameraPollTimer);
        KIOSK.cameraPollTimer = null;
    }
    if (KIOSK.cameraStream) {
        try { KIOSK.cameraStream.getTracks().forEach(t => t.stop()); }
        catch (e) {}
        KIOSK.cameraStream = null;
    }
    if (video) video.srcObject = null;
}

function captureKioskPhoto(isAuto = false) {
    if (KIOSK.cameraCaptureTriggered) return;
    const video  = document.getElementById('cameraVideo');
    const canvas = document.getElementById('cameraCanvas');
    if (!video || !canvas || !video.videoWidth) {
        log('capture: video not ready, continuing without photo');
        KIOSK.cameraCaptureTriggered = true;
        closeCameraModal();
        if (KIOSK.cameraMode === 'guest') {
            resolveGuestPhoto('');
        } else {
            recordUnauthorizedBook('');
        }
        return;
    }
    KIOSK.cameraCaptureTriggered = true;

    canvas.width  = video.videoWidth;
    canvas.height = video.videoHeight;
    canvas.getContext('2d').drawImage(video, 0, 0);

    let photoData = '';
    try { photoData = canvas.toDataURL('image/jpeg', 0.82); }
    catch (e) { log('toDataURL failed:', e); }

    shutterSound();
    log('photo captured, length:', photoData.length);

    closeCameraModal();

    if (KIOSK.cameraMode === 'guest') {
        resolveGuestPhoto(photoData);
    } else {
        recordUnauthorizedBook(photoData);
    }
}

function skipKioskPhoto() {
    log('user skipped photo');
    KIOSK.cameraCaptureTriggered = true;
    closeCameraModal();
    if (KIOSK.cameraMode === 'guest') {
        resolveGuestPhoto('');
    } else {
        recordUnauthorizedBook('');
    }
}

/* ============================================================
   GUEST PHOTO PROMISE RESOLVER
   ============================================================ */
function resolveGuestPhoto(dataUrl) {
    if (typeof KIOSK.pendingGuestResolver === 'function') {
        const fn = KIOSK.pendingGuestResolver;
        KIOSK.pendingGuestResolver = null;
        fn(dataUrl || '');
    }
}

function captureGuestPhoto() {
    return new Promise((resolve) => {
        KIOSK.cameraMode = 'guest';
        KIOSK.pendingGuestResolver = resolve;

        setCameraModalLabels(
            'Guest Photo',
            'Photo captures instantly',
            'Capture Photo'
        );
        openCameraModal();
    });
}

/* ============================================================
   RECORD UNAUTHORIZED BOOK EXIT
   ============================================================ */
async function recordUnauthorizedBook(photoData) {
    const b = KIOSK.pendingUnauthBook;
    if (!b || !b.barcode) {
        log('record: nothing pending');
        showToast('Nothing to record', 'warning');
        return;
    }

    log('recording unauthorized book:', b.barcode, 'photo:', photoData ? 'yes' : 'no');

    try {
        const body = new URLSearchParams();
        body.append('barcode', b.barcode);
        if (photoData) body.append('photo_data', photoData);
        body.append('gate', 'KIOSK');

        const res = await fetchJson(KIOSK.ajaxUrl + '?ajax=record_unauthorized_book', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            credentials: 'same-origin',
            body: body.toString()
        });

        log('record response:', res);

        if (res.success) {
            showToast('🚨 Unauthorized book exit recorded', 'danger', 6000);
            showResult(
                '<div class="book-alert unauthorized">' +
                    '<div class="d-flex align-items-start">' +
                        '<span style="font-size:2rem;margin-right:12px;">⚠️</span>' +
                        '<div>' +
                            '<div class="book-title">' + escapeHtml(b.title || 'Untitled') + '</div>' +
                            '<div class="book-meta">' + escapeHtml(b.author || '') + ' · ' + escapeHtml(b.barcode || '') + '</div>' +
                            '<div class="book-status">' + escapeHtml(t('book_unauthorized', 'Unauthorized exit!')) + '</div>' +
                            '<div class="recorded-tag"><i class="fas fa-check me-1"></i> Incident #' + res.log_id + ' recorded' +
                                (res.had_photo ? ' · photo saved' : '') +
                            '</div>' +
                        '</div>' +
                    '</div>' +
                '</div>'
            );
        } else {
            log('record failed:', res.error);
            showToast('⚠️ ' + (res.error || 'Failed to record'), 'danger', 8000);
            showResult(
                '<div class="book-alert unauthorized">' +
                    '<div class="d-flex align-items-start">' +
                        '<span style="font-size:2rem;margin-right:12px;">⚠️</span>' +
                        '<div>' +
                            '<div class="book-title">' + escapeHtml(b.title || 'Untitled') + '</div>' +
                            '<div class="book-meta">' + escapeHtml(b.barcode || '') + '</div>' +
                            '<div class="book-status text-danger">Recording failed</div>' +
                            '<div class="book-meta mt-1 small">' + escapeHtml(res.error || 'Unknown error') + '</div>' +
                            (res.hint ? '<div class="error-hint"><i class="fas fa-wrench me-1"></i> ' + escapeHtml(res.hint) + '</div>' : '') +
                        '</div>' +
                    '</div>' +
                '</div>'
            );
        }
    } catch (e) {
        log('record network error:', e);
        showToast(t('network_error', 'Network error'), 'danger');
        showResult(
            '<div class="book-alert unauthorized">' +
                '<div class="d-flex align-items-start">' +
                    '<span style="font-size:2rem;margin-right:12px;">⚠️</span>' +
                    '<div>' +
                        '<div class="book-title">' + escapeHtml(b.title || 'Untitled') + '</div>' +
                        '<div class="book-meta">' + escapeHtml(b.barcode || '') + '</div>' +
                        '<div class="book-status text-danger">Network error — incident not saved</div>' +
                    '</div>' +
                '</div>' +
            '</div>'
        );
    } finally {
        KIOSK.pendingUnauthBook = null;
        KIOSK.cameraCaptureTriggered = false;
        KIOSK.cameraMode = 'unauth';
        clearScanInput();
        cooldown(800);
        backToContent(7000);
    }
}

/* ============================================================
   MEMBER HANDLER
   ============================================================ */
async function handleMember(barcode, info) {
    const m = info.member;
    const purpose = getSelectedPurpose();

    showResult(
        '<div class="text-center"><div class="spinner-border text-primary spinner-border-sm"></div> ' +
            escapeHtml(t('processing', 'Processing...')) +
        '</div>'
    );

    let res;
    try {
        const body = new URLSearchParams();
        body.append('admno', barcode);
        body.append('purpose', purpose);
        res = await fetchJson(KIOSK.ajaxUrl + '?ajax=toggle', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            credentials: 'same-origin',
            body: body.toString()
        });
    } catch (e) {
        showResult('<div class="alert alert-danger text-center">' + escapeHtml(t('network_error', 'Network error')) + '</div>');
        backToContent(4000);
        return;
    }

    if (!res.success) {
        showResult('<div class="alert alert-danger text-center">' + escapeHtml(res.error || 'Failed') + '</div>');
        backToContent(4000);
        return;
    }

    const entering = res.action === 'entry';
    const first = (m.full_name || '').split(' ')[0] || 'Member';
    const photo = m.photo_base64 || KIOSK.defaultAvatar;

    showResult(
        '<div class="text-center p-3 bg-light rounded-4">' +
            '<div class="greeting-message ' + (entering ? 'greeting-welcome' : 'greeting-thanks') + '">' +
                '<i class="fas ' + (entering ? 'fa-hand-peace' : 'fa-smile-wink') + '"></i> ' +
                (entering ? escapeHtml(t('welcome', 'Welcome')) : escapeHtml(t('goodbye', 'Goodbye'))) +
                ' ' + escapeHtml(first) + (entering ? ' 👋' : ' 🙏') +
            '</div>' +
            '<img src="' + escapeHtml(photo) + '" class="member-photo" alt="" ' +
                 'onerror="this.onerror=null;this.src=\'' + KIOSK.defaultAvatar + '\';">' +
            '<h5 class="mt-2">' + escapeHtml(m.full_name || '') + '</h5>' +
            '<div><span class="badge bg-primary">' + escapeHtml(m.category_description || m.categorycode || 'Member') + '</span></div>' +
            '<div class="mt-1 small"><i class="fas fa-id-card"></i> ' + escapeHtml(m.cardnumber || '') + '</div>' +
            '<div class="mt-1 small text-muted"><i class="fas fa-tag"></i> ' +
                escapeHtml(t('purpose_label', 'Purpose')) + ': ' + escapeHtml(purpose) +
            '</div>' +
        '</div>'
    );

    loadStats();
    refreshPurposeStats();
    clearScanInput();
    cooldown();
    backToContent(5000);
}

/* ============================================================
   STATS
   ============================================================ */
function renderStats(s) {
    const el = document.getElementById('statsArea');
    if (!el) return;
    let catHtml = '';
    if (s.categoryStats) {
        for (const [k, v] of Object.entries(s.categoryStats)) {
            catHtml += '<div class="d-flex justify-content-between small"><span>' + escapeHtml(k) + '</span><span class="fw-bold">' + v + '</span></div>';
        }
    }
    el.innerHTML =
        '<div class="stat-card-inner d-flex justify-content-between"><span><i class="fas fa-building me-2"></i>' +
            escapeHtml(t('currently_inside', 'Currently Inside')) +
        '</span><span class="stat-number">' + (s.insideCount || 0) + '</span></div>' +
        '<div class="stat-card-inner d-flex justify-content-between"><span><i class="fas fa-calendar-day me-2"></i>' +
            escapeHtml(t('visitors_today', 'Visitors Today')) +
        '</span><span class="stat-number">' + (s.todayVisitors || 0) + '</span></div>' +
        '<div class="stat-card-inner d-flex justify-content-between"><span>👨 ' +
            escapeHtml(t('male', 'Male')) +
        '</span><strong>' + (s.maleCount || 0) + '</strong></div>' +
        '<div class="stat-card-inner d-flex justify-content-between"><span>👩 ' +
            escapeHtml(t('female', 'Female')) +
        '</span><strong>' + (s.femaleCount || 0) + '</strong></div>' +
        (catHtml ? '<div class="stat-card-inner"><i class="fas fa-chart-pie me-2"></i>' +
            escapeHtml(t('inside_by_category', 'By Category')) + catHtml + '</div>' : '');
}

function renderPurpose(s) {
    const el = document.getElementById('purposeStatsContainer');
    if (!el) return;
    if (!s.purposes || !s.purposes.length) {
        el.innerHTML = '<div class="text-center text-muted">' + escapeHtml(t('recent_activity_empty', 'No data for today')) + '</div>';
        return;
    }
    const total = s.purposes.reduce((a, b) => a + parseInt(b.count || 0), 0);
    let html = '';
    s.purposes.forEach(p => {
        const pc = total > 0 ? ((p.count / total) * 100).toFixed(1) : 0;
        html += '<div class="col-md-4 col-sm-6">' +
            '<div class="d-flex justify-content-between small fw-semibold"><span>' + escapeHtml(p.purpose) + '</span><span>' + p.count + ' (' + pc + '%)</span></div>' +
            '<div class="progress-purpose mt-1 mb-2"><div class="progress-bar-purpose" style="width:' + pc + '%;"></div></div>' +
            '</div>';
    });
    el.innerHTML = html;
}

async function loadStats() {
    const el = document.getElementById('statsArea');
    if (el) el.innerHTML = '<div class="text-center py-3"><div class="spinner-border text-primary spinner-border-sm"></div></div>';
    try {
        const data = await fetchJson(KIOSK.ajaxUrl + '?ajax=stats');
        renderStats(data);
    } catch (e) { /* ignore */ }
}
async function refreshPurposeStats() {
    try {
        const data = await fetchJson(KIOSK.ajaxUrl + '?ajax=get_purpose_stats');
        renderPurpose(data);
    } catch (e) { /* ignore */ }
}

/* ============================================================
   COVER FLOW
   ============================================================ */
function initCoverFlow() {
    const container = document.getElementById('coverFlowContainer');
    if (!container) return;
    const track = document.getElementById('coverFlowTrack');
    const dots  = document.querySelectorAll('.cover-dot');
    const prev  = document.getElementById('coverPrev');
    const next  = document.getElementById('coverNext');
    if (!track || !dots.length) return;

    let idx = 0;
    const total = dots.length;
    let timer = null;

    function update(i) {
        const items = track.querySelectorAll('.cover-item');
        if (!items.length) return;
        const w = items[0].offsetWidth || 160;
        const gap = 18;
        const stride = w + gap;
        if (i < 0) i = total - 1;
        if (i >= total) i = 0;
        idx = i;
        const offset = -(i * stride) + (container.offsetWidth / 2) - (w / 2);
        track.style.transform = 'translateX(' + offset + 'px)';
        items.forEach((it, k) => {
            it.classList.remove('active', 'prev', 'next');
            if (k === i) it.classList.add('active');
            else if (Math.abs(k - i) === 1) it.classList.add(k < i ? 'prev' : 'next');
        });
        dots.forEach((d, k) => d.classList.toggle('active', k === i));
    }
    function start() { stop(); timer = setInterval(() => update(idx + 1), 5000); window.__coverTimer = timer; }
    function stop()  { if (timer) { clearInterval(timer); timer = null; window.__coverTimer = null; } }
    window.__coverRestart = start;

    if (prev) prev.addEventListener('click', e => { e.stopPropagation(); stop(); update(idx - 1); setTimeout(start, 3000); });
    if (next) next.addEventListener('click', e => { e.stopPropagation(); stop(); update(idx + 1); setTimeout(start, 3000); });
    dots.forEach((d, i) => d.addEventListener('click', e => { e.stopPropagation(); stop(); update(i); setTimeout(start, 3000); }));

    document.addEventListener('keydown', e => {
        if (document.activeElement && document.activeElement.id === 'scanInput') return;
        if (e.key === 'ArrowLeft')  { stop(); update(idx - 1); setTimeout(start, 3000); }
        if (e.key === 'ArrowRight') { stop(); update(idx + 1); setTimeout(start, 3000); }
    });

    let touchStartX = 0;
    container.addEventListener('touchstart', e => {
        touchStartX = e.changedTouches[0].screenX;
        stop();
    }, { passive: true });
    container.addEventListener('touchend', e => {
        const diff = touchStartX - e.changedTouches[0].screenX;
        if (Math.abs(diff) > 30) {
            if (diff > 0) update(idx + 1);
            else update(idx - 1);
        }
        setTimeout(start, 3000);
    }, { passive: true });

    window.addEventListener('resize', () => update(idx));
    update(0);
    setTimeout(start, 3000);
}

/* ============================================================
   LANGUAGE DROPDOWN
   ============================================================ */
function toggleLanguageDropdown() {
    const d = document.getElementById('langDropdown');
    if (!d) return;
    d.classList.toggle('show');
}
document.addEventListener('click', e => {
    const d = document.getElementById('langDropdown');
    const t = document.getElementById('langToggle');
    if (d && t && !d.contains(e.target) && !t.contains(e.target)) d.classList.remove('show');
});

/* ============================================================
   v9.0 — GUEST NAME MODAL (OPTIONAL)
   Resolves with a string (user typed a name) or '' (skipped).
   Never rejects, never blocks the flow.
   ============================================================ */
function askGuestName() {
    return new Promise((resolve) => {
        const backdrop = document.getElementById('guestNameBackdrop');
        const input    = document.getElementById('guestNameInput');
        const errorEl  = document.getElementById('guestNameError');
        const btnOk    = document.getElementById('guestNameOk');
        const btnSkip  = document.getElementById('guestNameSkip');

        if (!backdrop || !input || !btnOk || !btnSkip) {
            // Fallback — modal is missing; treat as skipped
            resolve('');
            return;
        }

        input.value = '';
        if (errorEl) errorEl.textContent = '';
        backdrop.classList.add('open');
        setTimeout(() => input.focus(), 60);

        function cleanup() {
            backdrop.classList.remove('open');
            btnOk.removeEventListener('click', onOk);
            btnSkip.removeEventListener('click', onSkip);
            backdrop.removeEventListener('click', onBackdrop);
            input.removeEventListener('keydown', onKey);
        }
        function onOk() {
            const v = input.value.trim();
            cleanup();
            resolve(v);   // '' is fine — server auto-generates a name
        }
        function onSkip() {
            cleanup();
            resolve('');  // explicit skip
        }
        function onBackdrop(e) {
            if (e.target === backdrop) onSkip();
        }
        function onKey(e) {
            if (e.key === 'Enter')  onOk();
            if (e.key === 'Escape') onSkip();
        }

        btnOk.addEventListener('click', onOk);
        btnSkip.addEventListener('click', onSkip);
        backdrop.addEventListener('click', onBackdrop);
        input.addEventListener('keydown', onKey);
    });
}

/* ============================================================
   INIT
   ============================================================ */
document.addEventListener('DOMContentLoaded', () => {

    setInterval(() => {
        const el = document.getElementById('currentTime');
        if (el) el.textContent = new Date().toLocaleTimeString(
            KIOSK.currentLang === 'ar' ? 'ar-SA' : 'en-US',
            { hour12: true }
        );
    }, 1000);

    setTimeout(() => { loadStats(); refreshPurposeStats(); }, 400);
    setInterval(() => { loadStats(); refreshPurposeStats(); }, KIOSK.autoRefresh || 10000);

    const input = document.getElementById('scanInput');
    if (input) {
        input.focus();
        input.addEventListener('input', function () {
            const v = this.value.trim();
            if (v.length < 2) return;
            if (KIOSK.scanTimer) clearTimeout(KIOSK.scanTimer);
            KIOSK.scanTimer = setTimeout(() => processScan(v), 500);
        });
        input.addEventListener('keypress', function (e) {
            if (e.key === 'Enter') {
                if (KIOSK.scanTimer) clearTimeout(KIOSK.scanTimer);
                processScan(this.value);
            }
        });
    }

    const sel = document.getElementById('purposeSelect');
    if (sel) {
        sel.addEventListener('change', function () { onPurposeChange(this); });
        sel.addEventListener('click',     e => e.stopPropagation());
        sel.addEventListener('mousedown', e => e.stopPropagation());
        sel.addEventListener('touchstart',e => e.stopPropagation(), { passive: true });
    }

    /* ----------------------------------------------------------
       v9.0 — Guest Entry: optional name → instant photo → submit
       ---------------------------------------------------------- */
    const ge = document.getElementById('guestEntryBtn');
    if (ge) ge.addEventListener('click', async function () {
        if (this.disabled) return;
        this.disabled = true;

        try {
            // 1. Optional name — '' is a valid result (skip)
            const guestName = await askGuestName();

            const purpose = getSelectedPurpose();

            // 2. Instant photo capture
            let photoData = '';
            if (KIOSK.bookCameraEnabled && navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
                try { photoData = await captureGuestPhoto(); }
                catch (e) { log('guest photo capture failed:', e); photoData = ''; }
            }

            // 3. Submit — guest_name may be empty; server auto-generates "Guest N"
            const body = new URLSearchParams();
            body.append('purpose', purpose);
            body.append('guest_name', guestName);   // possibly ''
            if (photoData) body.append('photo_data', photoData);

            const data = await fetchJson(KIOSK.ajaxUrl + '?ajax=guest_entry', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                credentials: 'same-origin',
                body: body.toString()
            });

            if (data.success) {
                const safeName = escapeHtml(data.guest_name || guestName || 'Guest');
                const photoTag = data.had_photo
                    ? '<div class="text-success small mb-1"><i class="fas fa-camera"></i> Photo captured</div>'
                    : '';
                const autoTag = data.auto_named
                    ? '<div class="text-muted small mb-1"><i class="fas fa-info-circle"></i> Anonymous guest</div>'
                    : '';

                showResult(
                    '<div class="text-center p-3 bg-light rounded-4">' +
                        '<div class="greeting-message greeting-welcome">' +
                            '<i class="fas fa-hand-peace"></i> ' +
                            escapeHtml(t('welcome', 'Welcome')) + ' ' + safeName +
                        '</div>' +
                        photoTag +
                        autoTag +
                        '<img src="' + KIOSK.defaultAvatar + '" class="member-photo" alt="">' +
                        '<h5 class="mt-2">' + safeName + '</h5>' +
                        '<div><span class="badge bg-secondary">Guest</span></div>' +
                        '<div class="mt-1 small"><i class="fas fa-id-card"></i> ' + escapeHtml(data.guest_id) + '</div>' +
                        '<div class="mt-1 small text-muted"><i class="fas fa-tag"></i> ' +
                            escapeHtml(t('purpose_label', 'Purpose')) + ': ' + escapeHtml(purpose) +
                        '</div>' +
                    '</div>'
                );
                showToast(data.message || t('guest_entry_success', 'Guest entered'), 'success');
                loadStats();
                refreshPurposeStats();
                clearScanInput();
                cooldown();
                backToContent(5000);
            } else {
                showToast(data.error || 'Guest entry failed', 'danger');
            }
        } catch (e) {
            log('guest entry error:', e);
            showToast(t('network_error', 'Network error'), 'danger');
        } finally {
            this.disabled = false;
        }
    });

    /* ----------------------------------------------------------
       Guest Exit
       ---------------------------------------------------------- */
    const gx = document.getElementById('guestExitBtn');
    if (gx) gx.addEventListener('click', async function () {
        if (this.disabled) return;
        this.disabled = true;
        try {
            const data = await fetchJson(KIOSK.ajaxUrl + '?ajax=guest_exit_last');
            if (data.success) {
                showToast(data.message || t('guest_exit_success', 'Guest exited'), 'success');
                loadStats();
                refreshPurposeStats();
                showResult(
                    '<div class="alert alert-info text-center">' +
                        escapeHtml(data.message || 'Guest exited') +
                    '</div>'
                );
                backToContent(3000);
            } else {
                showToast(data.error || 'Failed', 'danger');
            }
        } catch (e) {
            showToast(t('network_error', 'Network error'), 'danger');
        } finally {
            this.disabled = false;
        }
    });

    initCoverFlow();
});

/* ============================================================
   GLOBAL EXPORTS
   ============================================================ */
window.KIOSK = KIOSK;
window.getSelectedPurpose = getSelectedPurpose;
window.onPurposeChange = onPurposeChange;
window.processScan = processScan;
window.toggleLanguageDropdown = toggleLanguageDropdown;
window.captureKioskPhoto = captureKioskPhoto;
window.skipKioskPhoto = skipKioskPhoto;
window.askGuestName = askGuestName;
window.captureGuestPhoto = captureGuestPhoto;
</script>

</body>
</html>
