/**
 * Visitor Management System — External Kiosk JS
 * Version: 8.5 FINAL
 *
 * Optional external companion for index.php. If you prefer to keep inline
 * scripts out of the HTML, drop this file in and add the following near the
 * bottom of the page:
 *     <script src="kiosk.js" defer></script>
 *
 * It auto-detects #scanInput and drives the same ajax.php actions.
 */

(function () {
    'use strict';

    const KIOSK = {
        ajaxUrl:       (document.querySelector('meta[name="ajax-url"]')?.content) || 'ajax.php',
        csrf:          (document.querySelector('meta[name="csrf-token"]')?.content) || '',
        defaultAvatar: (document.querySelector('meta[name="default-avatar"]')?.content) || '',
        autoRefresh:   parseInt(document.querySelector('meta[name="auto-refresh"]')?.content || '10', 10) * 1000,
        currentLang:   document.documentElement.lang || 'en',
        busy:          false,
        scanTimer:     null,
        coverTimer:    null,
    };

    // ---------- Utilities ----------
    function escapeHtml(s) {
        if (s === null || s === undefined) return '';
        const d = document.createElement('div');
        d.textContent = String(s);
        return d.innerHTML;
    }
    function clearScanInput() {
        const i = document.getElementById('scanInput');
        if (i) i.value = '';
    }
    function getSelectedPurpose() {
        const sel = document.getElementById('purposeSelect');
        return sel ? sel.value : 'Reading/Study';
    }
    function fetchJson(url, opts) {
        return fetch(url, opts || { credentials: 'same-origin' })
            .then(r => r.ok ? r.json() : Promise.reject(new Error('HTTP ' + r.status)));
    }

    // ---------- Toast ----------
    function showToast(msg, type = 'info') {
        document.querySelectorAll('.kiosk-toast').forEach(el => el.remove());
        const t = document.createElement('div');
        t.className = 'kiosk-toast alert alert-' + type + ' shadow-lg';
        t.style.cssText = 'position:fixed;top:20px;left:50%;transform:translateX(-50%);z-index:99999;min-width:280px;border-radius:50px;text-align:center;';
        t.innerHTML = escapeHtml(msg);
        document.body.appendChild(t);
        setTimeout(() => t.remove(), 4000);
    }

    // ---------- Result area ----------
    function showResult(html) {
        const c = document.getElementById('contentContainer');
        const r = document.getElementById('resultArea');
        if (c) c.classList.add('hidden');
        if (r) { r.innerHTML = html; r.classList.add('visible'); }
        if (KIOSK.coverTimer) { clearInterval(KIOSK.coverTimer); KIOSK.coverTimer = null; }
    }
    function backToContent(delay = 5000) {
        setTimeout(() => {
            const r = document.getElementById('resultArea');
            const c = document.getElementById('contentContainer');
            if (r) r.classList.remove('visible');
            if (c) c.classList.remove('hidden');
            setTimeout(() => { if (r && !r.classList.contains('visible')) r.innerHTML = ''; }, 300);
            if (window.__coverRestart) window.__coverRestart();
        }, delay);
    }
    function cooldown() {
        const i = document.getElementById('scanInput');
        if (!i) return;
        i.disabled = true;
        setTimeout(() => { i.disabled = false; i.focus(); }, 500);
    }

    // ---------- Scan pipeline ----------
    async function processScan(value) {
        value = (value || '').trim();
        if (value.length < 2 || KIOSK.busy) return;
        KIOSK.busy = true;

        let book = null;
        try { book = await fetchJson(KIOSK.ajaxUrl + '?action=check_book&barcode=' + encodeURIComponent(value)); }
        catch (e) { book = null; }

        if (book && book.is_book) {
            await handleBook(book);
            KIOSK.busy = false;
            return;
        }

        let member = null;
        try { member = await fetchJson(KIOSK.ajaxUrl + '?action=get_member&admno=' + encodeURIComponent(value)); }
        catch (e) { member = null; }

        if (member && member.member) {
            await handleMember(value, member);
            KIOSK.busy = false;
            return;
        }

        showResult('<div class="alert alert-warning text-center"><i class="fas fa-question-circle me-2"></i>Not recognised: ' + escapeHtml(value) + '</div>');
        clearScanInput(); cooldown(); backToContent(4000);
        KIOSK.busy = false;
    }

    async function handleBook(info) {
        const b = info.book || {};
        const auth = !!info.is_authorized;
        const cls = auth ? 'authorized' : 'unauthorized';
        const icon = auth ? '✅' : '⚠️';

        try {
            const body = new URLSearchParams();
            body.append('barcode',      b.barcode || '');
            body.append('is_authorized',auth ? '1' : '0');
            body.append('member_admno', b.member_cardnumber || '');
            body.append('member_name',  b.member_name || '');
            body.append('csrf_token',   KIOSK.csrf);
            await fetchJson(KIOSK.ajaxUrl + '?action=log_book_exit', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: body.toString()
            });
        } catch (e) { /* non-fatal */ }

        showResult(
            '<div class="book-alert ' + cls + '">' +
                '<div class="d-flex align-items-start">' +
                    '<span style="font-size:2rem;margin-right:12px;">' + icon + '</span>' +
                    '<div>' +
                        '<div><strong>' + escapeHtml(b.title || 'Untitled') + '</strong></div>' +
                        '<div class="small">' + escapeHtml(b.author || '') + ' · ' + escapeHtml(b.barcode || '') + '</div>' +
                        '<div><strong>' + (auth ? 'Authorized exit' : 'Unauthorized exit!') + '</strong></div>' +
                        (auth && b.member_name ? '<div class="small">Issued to: ' + escapeHtml(b.member_name) + '</div>' : '') +
                    '</div>' +
                '</div>' +
            '</div>'
        );
        clearScanInput(); cooldown(); backToContent(7000);
    }

    async function handleMember(barcode, info) {
        const m = info.member;
        const purpose = getSelectedPurpose();

        showResult('<div class="text-center"><div class="spinner-border text-primary spinner-border-sm"></div> Processing...</div>');

        let res;
        try {
            const body = new URLSearchParams();
            body.append('admno', barcode);
            body.append('purpose', purpose);
            body.append('csrf_token', KIOSK.csrf);
            res = await fetchJson(KIOSK.ajaxUrl + '?action=toggle', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: body.toString()
            });
        } catch (e) {
            showResult('<div class="alert alert-danger text-center">Network error</div>');
            backToContent(4000); return;
        }

        if (!res.success) {
            showResult('<div class="alert alert-danger text-center">' + escapeHtml(res.error || 'Failed') + '</div>');
            backToContent(4000); return;
        }

        const entering = res.action === 'entry';
        const first = (m.full_name || '').split(' ')[0] || 'Member';

        showResult(
            '<div class="text-center p-3 bg-light rounded-4">' +
                '<div class="greeting-message ' + (entering ? 'greeting-welcome' : 'greeting-thanks') + '">' +
                    '<i class="fas ' + (entering ? 'fa-hand-peace' : 'fa-smile-wink') + '"></i> ' +
                    (entering ? 'Welcome' : 'Goodbye') + ' ' + escapeHtml(first) +
                '</div>' +
                '<img src="' + escapeHtml(m.photo_base64 || KIOSK.defaultAvatar) + '" class="member-photo" alt="">' +
                '<h5 class="mt-2">' + escapeHtml(m.full_name || '') + '</h5>' +
                '<div><span class="badge bg-primary">' + escapeHtml(m.category_description || m.categorycode || 'Member') + '</span></div>' +
                '<div class="mt-1 small"><i class="fas fa-id-card"></i> ' + escapeHtml(m.cardnumber || '') + '</div>' +
                '<div class="mt-1 small text-muted"><i class="fas fa-tag"></i> Purpose: ' + escapeHtml(purpose) + '</div>' +
            '</div>'
        );

        loadStats(); refreshPurposeStats();
        clearScanInput(); cooldown(); backToContent(5000);
    }

    // ---------- Stats ----------
    function renderStats(s) {
        const el = document.getElementById('statsArea');
        if (!el) return;
        let catHtml = '';
        if (s.categoryStats) {
            for (const [k, v] of Object.entries(s.categoryStats)) {
                catHtml += '<div class="d-flex justify-content-between small"><span>' + escapeHtml(k) + '</span><span class="fw-bold">' + v + '</span></div>';
            }
        }
        el.innerHTML =
            '<div class="stat-card-inner d-flex justify-content-between"><span><i class="fas fa-building me-2"></i>Currently Inside</span><span class="stat-number">' + (s.insideCount || 0) + '</span></div>' +
            '<div class="stat-card-inner d-flex justify-content-between"><span><i class="fas fa-calendar-day me-2"></i>Visitors Today</span><span class="stat-number">' + (s.todayVisitors || 0) + '</span></div>' +
            '<div class="stat-card-inner d-flex justify-content-between"><span>👨 Male</span><strong>' + (s.maleCount || 0) + '</strong></div>' +
            '<div class="stat-card-inner d-flex justify-content-between"><span>👩 Female</span><strong>' + (s.femaleCount || 0) + '</strong></div>' +
            (catHtml ? '<div class="stat-card-inner"><i class="fas fa-chart-pie me-2"></i>By Category' + catHtml + '</div>' : '');
    }

    function renderPurpose(s) {
        const el = document.getElementById('purposeStatsContainer');
        if (!el) return;
        if (!s.purposes || !s.purposes.length) {
            el.innerHTML = '<div class="text-center text-muted">No data for today</div>';
            return;
        }
        const total = s.purposes.reduce((a, b) => a + parseInt(b.count || 0), 0);
        let html = '';
        s.purposes.forEach(p => {
            const pc = total > 0 ? ((p.count / total) * 100).toFixed(1) : 0;
            html += '<div class="col-md-4 col-sm-6">' +
                '<div class="d-flex justify-content-between small fw-semibold"><span>' + escapeHtml(p.purpose) + '</span><span>' + p.count + ' (' + pc + '%)</span></div>' +
                '<div class="progress-purpose mt-1 mb-2"><div class="progress-bar-purpose" style="width:' + pc + '%;"></div></div>' +
                '</div>';
        });
        el.innerHTML = html;
    }

    async function loadStats() {
        const el = document.getElementById('statsArea');
        if (el) el.innerHTML = '<div class="text-center py-3"><div class="spinner-border text-primary spinner-border-sm"></div></div>';
        try {
            const data = await fetchJson(KIOSK.ajaxUrl + '?action=stats');
            renderStats(data);
        } catch (e) { /* ignore */ }
    }

    async function refreshPurposeStats() {
        try {
            const data = await fetchJson(KIOSK.ajaxUrl + '?action=get_purpose_stats');
            renderPurpose(data);
        } catch (e) { /* ignore */ }
    }

    // ---------- Cover flow ----------
    function initCoverFlow() {
        const container = document.getElementById('coverFlowContainer');
        if (!container) return;
        const track = document.getElementById('coverFlowTrack');
        const dots  = document.querySelectorAll('.cover-dot');
        const prev  = document.getElementById('coverPrev');
        const next  = document.getElementById('coverNext');
        if (!track || !dots.length) return;

        let idx = 0;
        const total = dots.length;
        let timer = null;

        function update(i) {
            const items = track.querySelectorAll('.cover-item');
            if (!items.length) return;
            const w = items[0].offsetWidth || 160;
            const stride = w + 18;
            if (i < 0) i = total - 1;
            if (i >= total) i = 0;
            idx = i;
            const offset = -(i * stride) + (container.offsetWidth / 2) - (w / 2);
            track.style.transform = 'translateX(' + offset + 'px)';
            items.forEach((it, k) => {
                it.classList.remove('active', 'prev', 'next');
                if (k === i) it.classList.add('active');
                else if (Math.abs(k - i) === 1) it.classList.add(k < i ? 'prev' : 'next');
            });
            dots.forEach((d, k) => d.classList.toggle('active', k === i));
        }
        function start() { stop(); timer = setInterval(() => update(idx + 1), 5000); KIOSK.coverTimer = timer; window.__coverTimer = timer; }
        function stop()  { if (timer) { clearInterval(timer); timer = null; KIOSK.coverTimer = null; window.__coverTimer = null; } }
        window.__coverRestart = start;

        if (prev) prev.addEventListener('click', e => { e.stopPropagation(); stop(); update(idx - 1); setTimeout(start, 3000); });
        if (next) next.addEventListener('click', e => { e.stopPropagation(); stop(); update(idx + 1); setTimeout(start, 3000); });
        dots.forEach((d, i) => d.addEventListener('click', e => { e.stopPropagation(); stop(); update(i); setTimeout(start, 3000); }));
        window.addEventListener('resize', () => update(idx));
        update(0);
        setTimeout(start, 3000);
    }

    // ---------- Language dropdown ----------
    function toggleLanguageDropdown() {
        const d = document.getElementById('langDropdown');
        if (d) d.classList.toggle('show');
    }
    document.addEventListener('click', e => {
        const d = document.getElementById('langDropdown');
        const t = document.getElementById('langToggle');
        if (d && t && !d.contains(e.target) && !t.contains(e.target)) d.classList.remove('show');
    });

    // ---------- Guests ----------
    async function guestEntry() {
        const btn = document.getElementById('guestEntryBtn');
        if (btn) btn.disabled = true;
        try {
            const body = new URLSearchParams();
            body.append('purpose', getSelectedPurpose());
            body.append('csrf_token', KIOSK.csrf);
            const data = await fetchJson(KIOSK.ajaxUrl + '?action=guest_entry', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: body.toString()
            });
            if (data.success) {
                showResult(
                    '<div class="text-center p-3 bg-light rounded-4">' +
                        '<div class="greeting-message greeting-welcome"><i class="fas fa-hand-peace"></i> Welcome Guest ' + data.guest_number + '</div>' +
                        '<img src="' + KIOSK.defaultAvatar + '" class="member-photo" alt="">' +
                        '<h5 class="mt-2">Guest ' + data.guest_number + '</h5>' +
                        '<div><span class="badge bg-secondary">Guest</span></div>' +
                        '<div class="mt-1 small"><i class="fas fa-id-card"></i> ' + escapeHtml(data.guest_id) + '</div>' +
                    '</div>'
                );
                showToast(data.message || 'Guest entered', 'success');
                loadStats(); refreshPurposeStats(); clearScanInput(); cooldown(); backToContent(5000);
            } else {
                showToast(data.error || 'Guest entry failed', 'danger');
            }
        } catch (e) { showToast('Network error', 'danger'); }
        finally { if (btn) btn.disabled = false; }
    }

    async function guestExit() {
        const btn = document.getElementById('guestExitBtn');
        if (btn) btn.disabled = true;
        try {
            const data = await fetchJson(KIOSK.ajaxUrl + '?action=guest_exit_last');
            if (data.success) {
                showToast(data.message || 'Guest exited', 'success');
                loadStats(); refreshPurposeStats();
            } else {
                showToast(data.error || 'Failed', 'danger');
            }
        } catch (e) { showToast('Network error', 'danger'); }
        finally { if (btn) btn.disabled = false; }
    }

    // ---------- Init ----------
    function boot() {
        setInterval(() => {
            const el = document.getElementById('currentTime');
            if (el) el.textContent = new Date().toLocaleTimeString(
                KIOSK.currentLang === 'ar' ? 'ar-SA' : 'en-US', { hour12: true });
        }, 1000);

        setTimeout(() => { loadStats(); refreshPurposeStats(); }, 400);
        setInterval(() => { loadStats(); refreshPurposeStats(); }, KIOSK.autoRefresh || 10000);

        const input = document.getElementById('scanInput');
        if (input) {
            input.focus();
            input.addEventListener('input', function () {
                const v = this.value.trim();
                if (v.length < 2) return;
                if (KIOSK.scanTimer) clearTimeout(KIOSK.scanTimer);
                KIOSK.scanTimer = setTimeout(() => processScan(v), 500);
            });
            input.addEventListener('keypress', function (e) {
                if (e.key === 'Enter') {
                    if (KIOSK.scanTimer) clearTimeout(KIOSK.scanTimer);
                    processScan(this.value);
                }
            });
        }

        const sel = document.getElementById('purposeSelect');
        if (sel) {
            sel.addEventListener('change', function () {
                const h = document.getElementById('selectedPurpose');
                if (h) h.value = this.value;
            });
        }

        document.getElementById('guestEntryBtn')?.addEventListener('click', guestEntry);
        document.getElementById('guestExitBtn')?.addEventListener('click', guestExit);

        initCoverFlow();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot, { once: true });
    } else {
        boot();
    }

    // Expose for debugging
    window.KIOSK = KIOSK;
    window.processScan = processScan;
    window.loadStats = loadStats;
    window.showToast = showToast;
    window.toggleLanguageDropdown = toggleLanguageDropdown;
})();
