<?php
/**
 * Visitor Management System — Backup Download
 * Version: 8.6 FINAL
 */

require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

startSecureSession();
requireKohaLogin();

$file = basename($_GET['file'] ?? '');
if ($file === '' || strpos($file, 'visitor_backup_') !== 0 || substr($file, -4) !== '.sql') {
    http_response_code(400);
    die('Invalid file');
}

// Try the same candidate directories as backup.php
$candidates = [];
if (defined('LOGS_PATH')) $candidates[] = rtrim(LOGS_PATH, '/') . '/backups';
$candidates[] = __DIR__ . '/logs/backups';
$candidates[] = sys_get_temp_dir() . '/vms_backups';

$path = null;
foreach ($candidates as $dir) {
    $p = rtrim($dir, '/') . '/' . $file;
    if (file_exists($p) && is_readable($p)) { $path = $p; break; }
}

if ($path === null) {
    http_response_code(404);
    die('File not found');
}

while (ob_get_level() > 0) { ob_end_clean(); }
header('Content-Type: application/sql; charset=utf-8');
header('Content-Disposition: attachment; filename="' . $file . '"');
header('Content-Length: ' . filesize($path));
header('Cache-Control: private, max-age=0, must-revalidate');
header('Pragma: public');
readfile($path);
exit;
