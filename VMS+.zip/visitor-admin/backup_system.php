<?php
/**
 * ============================================================
 * KOHA + VMS — SINGLE-FILE BACKUP SYSTEM (v2 — SELF-CONTAINED)
 * ============================================================
 * Place at: /usr/share/koha/intranet/cgi-bin/koha/visitor/backup_system.php
 *
 * ONLY requires: includes/config.php + includes/db.php
 * All other logic is contained in this file.
 *
 * Modes:
 *   (none) / ui    → Full UI
 *   ?mode=list     → JSON list
 *   ?mode=create   → POST: create + download
 *   ?mode=download → ?file=X&token=Y
 *   ?mode=delete   → ?file=X&token=Y  (JSON)
 *   ?mode=prune    → ?days=N&token=Y  (JSON)
 *   ?mode=restore  → POST upload + restore
 *   --cron / cron  → CLI scheduled backup
 * ============================================================
 */

// ============================================================
// 0. DIAGNOSTICS — show errors on a debug flag
// ============================================================
$DEBUG = isset($_GET['debug']) || (php_sapi_name() === 'cli');
if ($DEBUG) {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
} else {
    error_reporting(E_ALL);
    ini_set('display_errors', 0);
    ini_set('log_errors', 1);
}

// ============================================================
// 1. MODE DETECTION
// ============================================================
$IS_CLI  = (php_sapi_name() === 'cli');
$IS_CRON = $IS_CLI
        || (($_GET['mode'] ?? '') === 'cron')
        || (in_array('--cron', $argv ?? [], true));

// ============================================================
// 2. LOCATE AND LOAD config.php ONLY
// ============================================================
$candidates = [
    __DIR__ . '/includes/config.php',
    dirname(__DIR__) . '/includes/config.php',
    __DIR__ . '/../includes/config.php',
    '/usr/share/koha/intranet/cgi-bin/koha/visitor/includes/config.php',
];

$configFile = null;
foreach ($candidates as $c) {
    if (is_file($c)) { $configFile = $c; break; }
}

if (!$configFile) {
    http_response_code(500);
    $msg = "config.php not found. Looked in:\n  " . implode("\n  ", $candidates);
    if ($IS_CLI) { fwrite(STDERR, $msg . "\n"); exit(1); }
    die('<pre style="padding:20px;background:#fee;color:#900">' . htmlspecialchars($msg) . '</pre>');
}

define('BK_INCLUDES_DIR', dirname($configFile));
require_once $configFile;

// Load db.php — gives us getDB() + getKoha()
$dbFile = BK_INCLUDES_DIR . '/db.php';
if (!is_file($dbFile)) {
    http_response_code(500);
    die('db.php not found in ' . BK_INCLUDES_DIR);
}
require_once $dbFile;

// ============================================================
// 3. GUARANTEED HELPERS (define if not already present)
// ============================================================
if (!function_exists('bk_session_start')) {
    function bk_session_start(): void {
        if (session_status() === PHP_SESSION_NONE) {
            session_name('CGISESSID');
            if (!empty($_COOKIE['CGISESSID'])) {
                session_id($_COOKIE['CGISESSID']);
            }
            @session_start();
        }
    }
}

if (!function_exists('bk_log')) {
    function bk_log(int $userId, string $action, string $details): void {
        try {
            $db = function_exists('getDB') ? getDB() : null;
            if (!$db) return;
            $db->prepare("INSERT INTO activity_log (user_id, username, action, details, ip_address, user_agent, created_at)
                          VALUES (?,?,?,?,?,?,NOW())")
               ->execute([
                   $userId,
                   $_SESSION['koha_username'] ?? 'system',
                   $action,
                   $details,
                   $_SERVER['REMOTE_ADDR'] ?? '',
                   substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 500),
               ]);
        } catch (Throwable $e) {
            error_log('[BK log] ' . $e->getMessage());
        }
    }
}

if (!function_exists('bk_current_user')) {
    /**
     * Return ['id'=>int, 'username'=>string] or null if not logged in.
     * Reads from the Koha session table directly — does NOT depend on auth.php.
     */
    function bk_current_user(): ?array {
        bk_session_start();

        // If auth.php already set these, use them
        if (!empty($_SESSION['koha_logged_in']) && !empty($_SESSION['koha_user_id'])) {
            return [
                'id'       => (int)$_SESSION['koha_user_id'],
                'username' => $_SESSION['koha_username'] ?? 'admin',
            ];
        }

        $sid = $_COOKIE['CGISESSID'] ?? '';
        if ($sid === '') return null;

        $koha = function_exists('getKoha') ? getKoha() : null;
        if (!$koha) return null;

        try {
            // Modern Koha session format (22.11+)
            $stmt = $koha->prepare("SELECT a_session FROM sessions WHERE id = ? LIMIT 1");
            $stmt->execute([$sid]);
            $row = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($row && !empty($row['a_session'])) {
                $blob = $row['a_session'];
                // Extract cardnumber or id or userid
                $card = null; $uid = null;
                if (preg_match('/^cardnumber:\s*(.+)$/mi', $blob, $m)) $card = trim($m[1]);
                if (preg_match('/^id:\s*(.+)$/mi',         $blob, $m)) $uid  = trim($m[1]);
                if (preg_match('/^userid:\s*(.+)$/mi',     $blob, $m)) $uid  = trim($m[1]);

                $key = $card ?: $uid;
                if ($key) {
                    $s = $koha->prepare("SELECT borrowernumber, userid, cardnumber FROM borrowers
                                         WHERE cardnumber = ? OR userid = ? LIMIT 1");
                    $s->execute([$key, $key]);
                    $b = $s->fetch(PDO::FETCH_ASSOC);
                    if ($b) {
                        // Cache in PHP session
                        $_SESSION['koha_logged_in'] = true;
                        $_SESSION['koha_user_id']   = (int)$b['borrowernumber'];
                        $_SESSION['koha_username']  = $b['cardnumber'] ?: $b['userid'] ?: 'admin';
                        return [
                            'id'       => (int)$b['borrowernumber'],
                            'username' => $_SESSION['koha_username'],
                        ];
                    }
                }
            }

            // Legacy format fallback
            $stmt = $koha->prepare("SELECT borrowernumber FROM sessions WHERE sessionid = ? AND lasttime > UNIX_TIMESTAMP() - 3600 LIMIT 1");
            $stmt->execute([$sid]);
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($row) {
                $_SESSION['koha_logged_in'] = true;
                $_SESSION['koha_user_id']   = (int)$row['borrowernumber'];
                $_SESSION['koha_username']  = 'koha_user';
                return ['id' => (int)$row['borrowernumber'], 'username' => 'koha_user'];
            }
        } catch (Throwable $e) {
            error_log('[BK session] ' . $e->getMessage());
        }
        return null;
    }
}

if (!function_exists('bk_require_user')) {
    function bk_require_user(): array {
        $u = bk_current_user();
        if (!$u) {
            http_response_code(401);
            echo '<!DOCTYPE html><html><body style="font-family:sans-serif;padding:60px;text-align:center;background:#f0f2f5">';
            echo '<div style="background:#fff;padding:40px;border-radius:16px;max-width:520px;margin:auto;box-shadow:0 10px 30px rgba(0,0,0,.08)">';
            echo '<h2 style="color:#dc3545;margin-top:0">🔒 Not Logged In</h2>';
            echo '<p>Please log in to Koha first, then return to this page.</p>';
            echo '<p><a href="' . htmlspecialchars(KOHA_INTRANET_URL ?? '/cgi-bin/koha/mainpage.pl') . '/cgi-bin/koha/mainpage.pl" ';
            echo 'style="display:inline-block;padding:10px 20px;background:#1e3c72;color:#fff;text-decoration:none;border-radius:8px">Go to Koha Login</a></p>';
            echo '<p style="font-size:12px;color:#888;margin-top:24px">';
            echo 'If you are already logged in, your session may have expired. Re-login and try again.';
            echo '</p></div></body></html>';
            exit;
        }
        return $u;
    }
}

if (!function_exists('bk_csrf')) {
    function bk_csrf(): string {
        bk_session_start();
        if (empty($_SESSION['bk_csrf'])) {
            $_SESSION['bk_csrf'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['bk_csrf'];
    }
}

if (!function_exists('bk_check_csrf')) {
    function bk_check_csrf(?string $token): bool {
        bk_session_start();
        return !empty($token) && !empty($_SESSION['bk_csrf'])
            && hash_equals($_SESSION['bk_csrf'], $token);
    }
}

// ============================================================
// 4. BACKUP CONFIGURATION
// ============================================================
const BK_PREFIX          = 'koha_vms_backup';
const BK_STAMP_FMT       = 'Y-m-d_H-i-s';
const BK_CHUNK           = 500;
const BK_RETENTION_DAYS  = 30;
const BK_MAX_RESTORE     = 2147483648; // 2 GB
const BK_RATE_LIMIT      = 30;         // downloads per hour
const BK_ENCRYPTION_KEY  = '';         // set to 32+ chars to enable AES-256-GCM

const BK_SKIP_DATA = [
    'vms' => [
        'activity_log', 'session_logs', 'occupancy_snapshots',
    ],
    'koha' => [
        'sessions', 'session_cache', 'search_cache', 'action_logs',
        'zebraqueue', 'message_queue', 'background_jobs',
        'import_batches', 'import_batch_profiles', 'import_records',
        'import_items', 'tmp_holdsqueue', 'tmp_hits',
    ],
];

// ============================================================
// 5. BACKUP DIRECTORY
// ============================================================
function bk_dir(): array {
    $cands = [];
    if (defined('LOGS_PATH'))  $cands[] = rtrim(LOGS_PATH, '/')  . '/backups';
    if (defined('ROOT_PATH'))  $cands[] = rtrim(ROOT_PATH, '/')  . '/logs/backups';
    $cands[] = __DIR__ . '/logs/backups';
    $cands[] = sys_get_temp_dir() . '/vms_backups';

    foreach ($cands as $d) {
        if (!is_dir($d)) { @mkdir($d, 0775, true); @chmod($d, 0775); }
        if (is_dir($d) && is_writable($d)) return ['path' => $d, 'writable' => true];
    }
    $fallback = sys_get_temp_dir() . '/vms_backups';
    @mkdir($fallback, 0775, true);
    return ['path' => $fallback, 'writable' => is_writable($fallback)];
}

// ============================================================
// 6. SQL DUMP HELPERS
// ============================================================
function bk_q(PDO $db, $v): string {
    if ($v === null) return 'NULL';
    if (is_int($v) || is_float($v)) return (string)$v;
    if (is_bool($v)) return $v ? '1' : '0';
    if (is_string($v) && preg_match('/[\x00-\x08\x0B\x0C\x0E-\x1F]/', $v)) {
        return '0x' . bin2hex($v);
    }
    return $db->quote((string)$v);
}

function bk_create(PDO $db, string $kind, string $name): ?array {
    $safe = str_replace('`', '``', $name);
    try {
        switch ($kind) {
            case 'table':
                $row = $db->query("SHOW CREATE TABLE `$safe`")->fetch(PDO::FETCH_ASSOC);
                if (!$row) return null;
                $vals = array_values($row);
                $ddl  = $vals[1] ?? '';
                $type = stripos($ddl, 'CREATE VIEW') !== false ? 'view' : 'table';
                return ['type' => $type, 'ddl' => $ddl];
            case 'trigger':
                $s = $db->prepare("SHOW CREATE TRIGGER `$safe`"); $s->execute();
                $r = $s->fetch(PDO::FETCH_ASSOC);
                return $r ? ['type' => 'trigger', 'ddl' => $r['SQL Original Statement'] ?? ''] : null;
            case 'event':
                $s = $db->prepare("SHOW CREATE EVENT `$safe`"); $s->execute();
                $r = $s->fetch(PDO::FETCH_ASSOC);
                return $r ? ['type' => 'event', 'ddl' => $r['Create Event'] ?? ''] : null;
            case 'procedure':
                $s = $db->prepare("SHOW CREATE PROCEDURE `$safe`"); $s->execute();
                $r = $s->fetch(PDO::FETCH_ASSOC);
                return $r ? ['type' => 'procedure', 'ddl' => $r['Create Procedure'] ?? ''] : null;
            case 'function':
                $s = $db->prepare("SHOW CREATE FUNCTION `$safe`"); $s->execute();
                $r = $s->fetch(PDO::FETCH_ASSOC);
                return $r ? ['type' => 'function', 'ddl' => $r['Create Function'] ?? ''] : null;
        }
    } catch (Throwable $e) {
        error_log("[BK create $kind $name] " . $e->getMessage());
    }
    return null;
}

function bk_obj(PDO $db, string $name, string $type, string $ddl, bool $skip): string {
    $safe = str_replace('`', '``', $name);
    switch ($type) {
        case 'view':
            return "-- View `$name`\nDROP VIEW IF EXISTS `$safe`;\n$ddl;\n\n";
        case 'trigger':
            return "-- Trigger `$name`\nDROP TRIGGER IF EXISTS `$safe`;\nDELIMITER ;;\n$ddl;;\nDELIMITER ;\n\n";
        case 'event':
            return "-- Event `$name`\nDROP EVENT IF EXISTS `$safe`;\nDELIMITER ;;\n$ddl;;\nDELIMITER ;\n\n";
        case 'procedure':
        case 'function':
            return "-- " . ucfirst($type) . " `$name`\nDROP $type IF EXISTS `$safe`;\nDELIMITER ;;\n$ddl;;\nDELIMITER ;\n\n";
        default:
            $out  = "-- Table `$name`\nDROP TABLE IF EXISTS `$safe`;\n$ddl;\n\n";
            if ($skip) return $out . "-- (data skipped)\n\n";
            try { $rows = $db->query("SELECT * FROM `$safe`"); }
            catch (Throwable $e) { return $out . "-- ERROR: " . $e->getMessage() . "\n\n"; }
            if ($rows) {
                $buf = []; $n = 0;
                while ($r = $rows->fetch(PDO::FETCH_ASSOC)) {
                    $vals = array_map(fn($v) => bk_q($db, $v), array_values($r));
                    $buf[] = '(' . implode(',', $vals) . ')';
                    $n++;
                    if (count($buf) >= BK_CHUNK) {
                        $out .= "INSERT INTO `$safe` VALUES\n" . implode(",\n", $buf) . ";\n";
                        $buf = [];
                    }
                }
                if ($buf) $out .= "INSERT INTO `$safe` VALUES\n" . implode(",\n", $buf) . ";\n";
                if ($n) $out .= "\n";
            }
            return $out;
    }
}

function bk_dump_db(PDO $db, string $name, array $skip): array {
    $objs   = $db->query("SHOW FULL TABLES")->fetchAll(PDO::FETCH_NUM);
    $tables = []; $views = [];
    foreach ($objs as $o) {
        if (($o[1] ?? '') === 'VIEW') $views[] = $o[0];
        else                          $tables[] = $o[0];
    }
    $trig = $ev = $pr = $fn = [];
    try { $trig = $db->query("SHOW TRIGGERS")->fetchAll(PDO::FETCH_COLUMN, 0) ?: []; } catch (Throwable $e) {}
    try { $ev   = $db->query("SHOW EVENTS")->fetchAll(PDO::FETCH_COLUMN, 1)   ?: []; } catch (Throwable $e) {}
    try { $pr   = $db->query("SHOW PROCEDURE STATUS WHERE Db = DATABASE()")->fetchAll(PDO::FETCH_COLUMN, 1) ?: []; } catch (Throwable $e) {}
    try { $fn   = $db->query("SHOW FUNCTION STATUS WHERE Db = DATABASE()")->fetchAll(PDO::FETCH_COLUMN, 1)  ?: []; } catch (Throwable $e) {}

    $sql  = "-- ============================================================\n";
    $sql .= "-- Database: $name\n";
    $sql .= "-- Generated: " . date('c') . "\n";
    $sql .= "-- ============================================================\n\n";
    $sql .= "SET SQL_MODE='NO_AUTO_VALUE_ON_ZERO';\n";
    $sql .= "SET time_zone='+00:00';\n";
    $sql .= "SET NAMES utf8mb4;\n";
    $sql .= "SET FOREIGN_KEY_CHECKS=0;\n";
    $sql .= "SET UNIQUE_CHECKS=0;\n\n";

    foreach ($tables as $t) {
        $m = bk_create($db, 'table', $t);
        if ($m) $sql .= bk_obj($db, $t, $m['type'], $m['ddl'], in_array($t, $skip, true));
    }
    if ($views) {
        $sql .= "-- Views\n";
        foreach ($views as $v) {
            $m = bk_create($db, 'view', $v);
            if ($m) $sql .= bk_obj($db, $v, 'view', $m['ddl'], false);
        }
    }
    if ($trig) {
        $sql .= "-- Triggers\n";
        foreach ($trig as $t) {
            $m = bk_create($db, 'trigger', $t);
            if ($m) $sql .= bk_obj($db, $t, 'trigger', $m['ddl'], false);
        }
    }
    if ($ev) {
        $sql .= "-- Events\n";
        foreach ($ev as $e) {
            $m = bk_create($db, 'event', $e);
            if ($m) $sql .= bk_obj($db, $e, 'event', $m['ddl'], false);
        }
    }
    if ($pr || $fn) {
        $sql .= "-- Routines\n";
        foreach ($pr as $p) { $m = bk_create($db, 'procedure', $p); if ($m) $sql .= bk_obj($db, $p, 'procedure', $m['ddl'], false); }
        foreach ($fn as $f) { $m = bk_create($db, 'function',  $f); if ($m) $sql .= bk_obj($db, $f, 'function',  $m['ddl'], false); }
    }

    $sql .= "SET FOREIGN_KEY_CHECKS=1;\nSET UNIQUE_CHECKS=1;\n-- End of $name\n\n";

    return [
        'sql'  => $sql,
        'meta' => [
            'database' => $name,
            'tables'   => count($tables),
            'views'    => count($views),
            'triggers' => count($trig),
            'events'   => count($ev),
            'procedures'=> count($pr),
            'functions'=> count($fn),
            'bytes'    => strlen($sql),
        ],
    ];
}

// ============================================================
// 7. CRYPTO + FILE WRITE
// ============================================================
function bk_enc(string $p, string $k): string {
    $k = substr(hash('sha256', $k, true), 0, 32);
    $iv = random_bytes(12); $tag = '';
    $c = openssl_encrypt($p, 'aes-256-gcm', $k, OPENSSL_RAW_DATA, $iv, $tag, '', 16);
    if ($c === false) throw new RuntimeException('encrypt failed');
    return base64_encode($iv . $tag . $c);
}
function bk_dec(string $e, string $k): string {
    $r = base64_decode($e, true);
    if ($r === false || strlen($r) < 28) throw new RuntimeException('bad ciphertext');
    $k = substr(hash('sha256', $k, true), 0, 32);
    $iv = substr($r,0,12); $tag = substr($r,12,16); $ct = substr($r,28);
    $out = openssl_decrypt($ct, 'aes-256-gcm', $k, OPENSSL_RAW_DATA, $iv, $tag);
    if ($out === false) throw new RuntimeException('decrypt failed');
    return $out;
}

function bk_write(string $target, string $data): array {
    $tmp = $target . '.tmp.' . bin2hex(random_bytes(4));
    if (@file_put_contents($tmp, $data, LOCK_EX) === false) {
        throw new RuntimeException("Write failed: $tmp");
    }
    if (!@rename($tmp, $target)) {
        @unlink($tmp);
        throw new RuntimeException("Rename failed: $target");
    }
    @chmod($target, 0640);
    return ['bytes' => filesize($target), 'sha256' => hash_file('sha256', $target)];
}

function bk_inspect(string $path): array {
    if (!is_file($path)) return ['valid' => false];
    $fh = @fopen($path, 'rb'); if (!$fh) return ['valid' => false];
    $h = fread($fh, 8192); fclose($fh);
    if (substr($h, 0, 2) === "\x1f\x8b") $h = @gzdecode($h) ?: '';
    return [
        'valid'    => true,
        'has_vms'  => (bool)preg_match('/Database:\s*`?(visitor_management)/', $h),
        'has_koha' => (bool)preg_match('/Database:\s*`?(koha_library)/', $h),
        'bytes'    => filesize($path),
        'mtime'    => filemtime($path),
    ];
}

function bk_prune(string $dir, int $days): int {
    $cut = time() - $days * 86400; $n = 0;
    foreach (glob(rtrim($dir,'/') . '/' . BK_PREFIX . '_*.sql*') ?: [] as $f) {
        if (is_file($f) && filemtime($f) < $cut) {
            if (@unlink($f)) { @unlink($f . '.manifest.json'); $n++; }
        }
    }
    return $n;
}

function bk_split(string $sql): array {
    $out = []; $len = strlen($sql); $i = 0; $buf = ''; $d = ';'; $dl = 1;
    while ($i < $len) {
        if ($buf === '' && substr($sql, $i, 2) === '--') {
            $e = strpos($sql, "\n", $i); if ($e === false) break; $i = $e + 1; continue;
        }
        if ($buf === '' && preg_match('/^DELIMITER\s+(\S+)/i', substr($sql, $i), $m)) {
            $d = $m[1]; $dl = strlen($d); $i += strlen($m[0]);
            while ($i < $len && ($sql[$i] === "\n" || $sql[$i] === "\r")) $i++;
            continue;
        }
        $c = $sql[$i];
        if ($c === "'" || $c === '"' || $c === '`') {
            $q = $c; $buf .= $c; $i++;
            while ($i < $len) {
                $buf .= $sql[$i];
                if ($sql[$i] === '\\' && $q !== '`') { $i++; if ($i < $len) { $buf .= $sql[$i]; $i++; } continue; }
                if ($sql[$i] === $q) {
                    if ($i+1 < $len && $sql[$i+1] === $q) { $buf .= $sql[$i+1]; $i += 2; continue; }
                    $i++; break;
                }
                $i++;
            }
            continue;
        }
        if (substr($sql, $i, $dl) === $d) {
            $t = trim($buf); if ($t !== '') $out[] = $t;
            $buf = ''; $i += $dl; continue;
        }
        $buf .= $c; $i++;
    }
    $t = trim($buf); if ($t !== '') $out[] = $t;
    return $out;
}

function bk_fmt(int $b): string {
    if ($b >= 1073741824) return number_format($b/1073741824,2).' GB';
    if ($b >= 1048576)    return number_format($b/1048576,2).' MB';
    if ($b >= 1024)       return number_format($b/1024,1).' KB';
    return $b.' B';
}
function h($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

// ============================================================
// 8. CRON MODE — run before any HTTP output
// ============================================================
if ($IS_CRON) {
    $log = fn(string $m) => fwrite(STDOUT, '['.date('c').'] '.$m.PHP_EOL);
    $log('Backup cron starting.');

    try {
        $dir  = bk_dir();
        if (!$dir['writable']) throw new RuntimeException('No writable backup dir.');

        $pieces = [];
        $meta   = ['source' => 'cron', 'generated_at' => date('c')];

        if (function_exists('getDB')) {
            $db = getDB();
            if ($db) {
                $r = bk_dump_db($db, defined('DB_NAME') ? DB_NAME : 'visitor_management',
                                BK_SKIP_DATA['vms'] ?? []);
                $pieces[] = $r['sql'];
                $meta['databases']['vms'] = $r['meta'];
                $log("VMS: {$r['meta']['tables']} tables, {$r['meta']['bytes']} bytes");
            }
        }
        if (function_exists('getKoha')) {
            $k = getKoha();
            if ($k) {
                $r = bk_dump_db($k, defined('KOHA_DB') ? KOHA_DB : 'koha_library',
                                BK_SKIP_DATA['koha'] ?? []);
                $pieces[] = $r['sql'];
                $meta['databases']['koha'] = $r['meta'];
                $log("Koha: {$r['meta']['tables']} tables, {$r['meta']['bytes']} bytes");
            }
        }

        if (!$pieces) throw new RuntimeException('No databases reachable.');

        $suffix = count($pieces) === 2 ? 'both' : 'vms';
        $stamp  = date(BK_STAMP_FMT);
        $sql    = implode("\n\n-- ==== NEXT DB ====\n\n", $pieces);
        $meta['plain_sha256'] = hash('sha256', $sql);

        $compressed = false;
        if (function_exists('gzencode')) {
            $gz = gzencode($sql, 9);
            if ($gz !== false) { $sql = $gz; $compressed = true; }
        }
        $encrypted = false;
        if (BK_ENCRYPTION_KEY !== '') {
            $sql = bk_enc($sql, BK_ENCRYPTION_KEY);
            $encrypted = true;
        }

        $ext = '.sql' . ($compressed ? '.gz' : '') . ($encrypted ? '.enc' : '');
        $filename = BK_PREFIX . '_' . $suffix . '_' . $stamp . $ext;
        $target   = rtrim($dir['path'], '/') . '/' . $filename;

        $info = bk_write($target, $sql);
        $meta['file_sha256'] = $info['sha256'];
        $meta['file_bytes']  = $info['bytes'];
        @file_put_contents($target . '.manifest.json', json_encode($meta, JSON_PRETTY_PRINT));

        $log("Wrote: $filename ({$info['bytes']} bytes)");
        $pruned = bk_prune($dir['path'], BK_RETENTION_DAYS);
        $log("Pruned: $pruned file(s)");
        $log('Done.');
        exit(0);

    } catch (Throwable $e) {
        fwrite(STDERR, '['.date('c').'] BACKUP FAILED: '.$e->getMessage().PHP_EOL);
        exit(1);
    }
}

// ============================================================
// 9. WEB MODES
// ============================================================
$user    = bk_require_user();
$dirInfo = bk_dir();
$db      = function_exists('getDB')   ? getDB()   : null;
$koha    = function_exists('getKoha') ? getKoha() : null;
$csrf    = bk_csrf();
$mode    = $_GET['mode'] ?? 'ui';

// ---------------- list (JSON) ----------------
if ($mode === 'list') {
    header('Content-Type: application/json');
    $files = glob(rtrim($dirInfo['path'],'/') . '/' . BK_PREFIX . '_*.sql*') ?: [];
    $out = [];
    foreach ($files as $f) {
        if (str_ends_with($f, '.manifest.json')) continue;
        $i = bk_inspect($f);
        $out[] = [
            'name'  => basename($f),
            'bytes' => filesize($f),
            'mtime' => filemtime($f),
            'gz'    => str_ends_with($f, '.gz') || str_ends_with($f, '.gz.enc'),
            'enc'   => str_ends_with($f, '.enc'),
            'vms'   => $i['has_vms']  ?? false,
            'koha'  => $i['has_koha'] ?? false,
        ];
    }
    usort($out, fn($a,$b)=>$b['mtime']-$a['mtime']);
    echo json_encode(['ok'=>true, 'files'=>$out]);
    exit;
}

// ---------------- download ----------------
if ($mode === 'download') {
    $file  = basename($_GET['file'] ?? '');
    $token = $_GET['token'] ?? '';

    if (!preg_match('/^' . preg_quote(BK_PREFIX,'/') . '_[a-z]+_[0-9_\-]+\.sql(\.gz)?(\.enc)?$/', $file)) {
        http_response_code(400); die('Bad filename.');
    }
    if (!bk_check_csrf($token)) { http_response_code(403); die('Bad token.'); }

    $realDir  = realpath($dirInfo['path']);
    $realPath = realpath(rtrim($dirInfo['path'],'/') . '/' . $file);
    if (!$realPath || !$realDir || strpos($realPath, $realDir) !== 0 || !is_file($realPath)) {
        http_response_code(404); die('Not found.');
    }

    // Rate limit
    $rlk = 'bk_dl_' . ($user['id'] ?? 0);
    $cnt = $_SESSION[$rlk] ?? 0;
    if ($cnt >= BK_RATE_LIMIT) { http_response_code(429); die('Rate limit.'); }
    $_SESSION[$rlk] = $cnt + 1;

    bk_log($user['id'] ?? 0, 'BACKUP_DOWNLOAD', "Downloaded: $file");

    $mime = 'application/sql';
    if (str_ends_with($file, '.gz'))     $mime = 'application/gzip';
    if (str_ends_with($file, '.enc'))    $mime = 'application/octet-stream';
    if (str_ends_with($file, '.gz.enc')) $mime = 'application/octet-stream';

    while (ob_get_level() > 0) ob_end_clean();
    $size = filesize($realPath);
    header('Content-Type: '.$mime);
    header('Content-Disposition: attachment; filename="' . $file . '"');
    header('Content-Length: ' . $size);
    header('X-Content-Type-Options: nosniff');
    header('Cache-Control: no-store');
    readfile($realPath);
    exit;
}

// ---------------- delete (JSON) ----------------
if ($mode === 'delete') {
    header('Content-Type: application/json');
    $file  = basename($_GET['file'] ?? '');
    $token = $_GET['token'] ?? '';
    if (!bk_check_csrf($token)) { echo json_encode(['ok'=>false,'error'=>'Bad token']); exit; }

    if (!preg_match('/^' . preg_quote(BK_PREFIX,'/') . '_[a-z]+_[0-9_\-]+\.sql(\.gz)?(\.enc)?$/', $file)) {
        echo json_encode(['ok'=>false,'error'=>'Bad filename']); exit;
    }
    $realPath = rtrim($dirInfo['path'],'/') . '/' . $file;
    if (!is_file($realPath)) { echo json_encode(['ok'=>false,'error'=>'Not found']); exit; }

    $ok = @unlink($realPath);
    @unlink($realPath . '.manifest.json');
    if ($ok) bk_log($user['id'] ?? 0, 'BACKUP_DELETE', "Deleted: $file");
    echo json_encode(['ok'=>$ok]);
    exit;
}

// ---------------- prune (JSON) ----------------
if ($mode === 'prune') {
    header('Content-Type: application/json');
    $days  = max(1, (int)($_GET['days'] ?? BK_RETENTION_DAYS));
    $token = $_GET['token'] ?? '';
    if (!bk_check_csrf($token)) { echo json_encode(['ok'=>false,'error'=>'Bad token']); exit; }

    $n = bk_prune($dirInfo['path'], $days);
    bk_log($user['id'] ?? 0, 'BACKUP_PRUNE', "Pruned $n file(s) older than $days days");
    echo json_encode(['ok'=>true,'pruned'=>$n]);
    exit;
}

// ---------------- create (POST, downloads file) ----------------
if ($mode === 'create' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!bk_check_csrf($_POST['csrf'] ?? '')) {
        http_response_code(403); die('Bad CSRF token.');
    }

    set_time_limit(0);
    @ini_set('memory_limit', '512M');

    $wantVms  = !empty($_POST['vms']);
    $wantKoha = !empty($_POST['koha']);
    if (!$wantVms && !$wantKoha) $wantVms = $wantKoha = true;

    $pieces = [];
    $meta   = ['source' => 'web', 'user' => $user['username'], 'generated_at' => date('c')];

    if ($wantVms && $db) {
        $r = bk_dump_db($db, defined('DB_NAME') ? DB_NAME : 'visitor_management',
                        BK_SKIP_DATA['vms'] ?? []);
        $pieces[] = $r['sql'];
        $meta['databases']['vms'] = $r['meta'];
    }
    if ($wantKoha && $koha) {
        $r = bk_dump_db($koha, defined('KOHA_DB') ? KOHA_DB : 'koha_library',
                        BK_SKIP_DATA['koha'] ?? []);
        $pieces[] = $r['sql'];
        $meta['databases']['koha'] = $r['meta'];
    }

    if (!$pieces) { http_response_code(500); die('No databases to back up.'); }

    $suffix = count($pieces) === 2 ? 'both' : ($wantKoha ? 'koha' : 'vms');
    $stamp  = date(BK_STAMP_FMT);
    $sql    = implode("\n\n-- ==== NEXT DB ====\n\n", $pieces);
    $meta['plain_sha256'] = hash('sha256', $sql);

    $compressed = false;
    if (function_exists('gzencode')) {
        $gz = gzencode($sql, 9);
        if ($gz !== false) { $sql = $gz; $compressed = true; }
    }
    $encrypted = false;
    if (BK_ENCRYPTION_KEY !== '') {
        $sql = bk_enc($sql, BK_ENCRYPTION_KEY);
        $encrypted = true;
    }

    $ext      = '.sql' . ($compressed ? '.gz' : '') . ($encrypted ? '.enc' : '');
    $filename = BK_PREFIX . '_' . $suffix . '_' . $stamp . $ext;
    $target   = rtrim($dirInfo['path'], '/') . '/' . $filename;

    try {
        $info = bk_write($target, $sql);
    } catch (Throwable $e) {
        http_response_code(500);
        die('Write failed: ' . h($e->getMessage()));
    }

    $meta['file_sha256'] = $info['sha256'];
    $meta['file_bytes']  = $info['bytes'];
    @file_put_contents($target . '.manifest.json', json_encode($meta, JSON_PRETTY_PRINT));

    bk_log($user['id'] ?? 0, 'BACKUP_CREATE', "Created: $filename");

    // Stream the file
    while (ob_get_level() > 0) ob_end_clean();
    $size = filesize($target);
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Content-Length: ' . $size);
    header('X-Content-Type-Options: nosniff');
    header('Cache-Control: no-store');
    readfile($target);
    exit;
}

// ---------------- restore (POST upload) ----------------
if ($mode === 'restore' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!bk_check_csrf($_POST['csrf'] ?? '')) {
        http_response_code(403); die('Bad CSRF token.');
    }

    set_time_limit(0);
    @ini_set('memory_limit', '1024M');

    $file = $_FILES['backup'] ?? null;
    if (!$file || $file['error'] !== UPLOAD_ERR_OK) {
        die('Upload failed: ' . ($file['error'] ?? 'no file'));
    }
    if ($file['size'] > BK_MAX_RESTORE) {
        die('File too large (max ' . bk_fmt(BK_MAX_RESTORE) . ')');
    }

    $raw = file_get_contents($file['tmp_name']);
    if ($raw === false) die('Cannot read uploaded file.');

    // Detect encryption
    if (BK_ENCRYPTION_KEY !== '' && str_contains($raw, '=') && strlen($raw) > 100) {
        // Base64-encoded encrypted content (starts with base64 chars only)
        $trimmed = trim($raw);
        if (preg_match('/^[A-Za-z0-9+\/=\r\n]+$/', substr($trimmed, 0, 200))) {
            $dec = bk_dec($trimmed, BK_ENCRYPTION_KEY);
            if ($dec !== false) $raw = $dec;
        }
    }

    // Decompress if gzip
    if (substr($raw, 0, 2) === "\x1f\x8b") {
        $raw = @gzdecode($raw);
        if ($raw === false) die('gzdecode failed.');
    }

    if (!is_string($raw) || strlen($raw) < 10) {
        die('File is empty or invalid.');
    }

    $stmts = bk_split($raw);
    if (empty($stmts)) die('No SQL statements found.');

    $errors = 0; $ok = 0;
    $dbs = ['vms' => $db, 'koha' => $koha];

    foreach ($dbs as $label => $conn) {
        if (!$conn) continue;
        foreach ($stmts as $stmt) {
            try {
                $conn->exec($stmt);
                $ok++;
            } catch (Throwable $e) {
                $errors++;
                error_log("[BK restore $label] " . $e->getMessage());
            }
        }
    }

    bk_log($user['id'] ?? 0, 'BACKUP_RESTORE', "Restored: {$ok} ok, {$errors} errors");

    header('Content-Type: text/html; charset=utf-8');
    echo '<!DOCTYPE html><html><head><meta charset="utf-8"><title>Restore Result</title>';
    echo '<style>body{font-family:sans-serif;padding:40px;background:#f0f2f5}';
    echo '.box{background:#fff;padding:30px;border-radius:16px;max-width:600px;margin:auto;box-shadow:0 10px 30px rgba(0,0,0,.08)}';
    echo 'h2{margin-top:0;color:#1e3c72}</style></head><body>';
    echo '<div class="box"><h2>✅ Restore Complete</h2>';
    echo "<p><strong>$ok</strong> statements executed successfully.</p>";
    if ($errors > 0) {
        echo "<p style='color:#dc3545'><strong>$errors</strong> statement(s) failed (see error log).</p>";
    }
    echo '<p><a href="?' . h($_SERVER['QUERY_STRING'] ?? '') . '" style="display:inline-block;padding:10px 20px;background:#1e3c72;color:#fff;text-decoration:none;border-radius:8px">Back to Backup Manager</a></p>';
    echo '</div></body></html>';
    exit;
}

// ============================================================
// 10. FULL UI
// ============================================================
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Koha + VMS Backup Manager</title>
<style>
* { box-sizing: border-box; margin: 0; padding: 0; }
body {
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    background: #f0f2f5; color: #333; padding: 24px;
}
.wrap { max-width: 960px; margin: 0 auto; }
h1 { font-size: 1.5rem; color: #1e3c72; margin-bottom: 4px; }
.sub { color: #888; font-size: .85rem; margin-bottom: 24px; }
.card {
    background: #fff; border-radius: 14px; padding: 24px;
    box-shadow: 0 4px 16px rgba(0,0,0,.06); margin-bottom: 20px;
}
.card h2 { font-size: 1.1rem; color: #1e3c72; margin-bottom: 14px; }
label { display: block; font-size: .85rem; color: #555; margin-bottom: 4px; }
select, input[type=text], input[type=file] {
    width: 100%; padding: 10px 12px; border: 1px solid #ddd;
    border-radius: 8px; font-size: .95rem; margin-bottom: 14px;
}
.btn {
    display: inline-block; padding: 10px 22px; border: none;
    border-radius: 8px; font-size: .95rem; cursor: pointer;
    text-decoration: none; font-weight: 600;
}
.btn-primary { background: #1e3c72; color: #fff; }
.btn-primary:hover { background: #162d55; }
.btn-danger { background: #dc3545; color: #fff; }
.btn-danger:hover { background: #b52a37; }
.btn-sm { padding: 6px 14px; font-size: .8rem; }
.btn-outline {
    background: transparent; color: #1e3c72;
    border: 1.5px solid #1e3c72;
}
.btn-outline:hover { background: #eef2f9; }
table { width: 100%; border-collapse: collapse; font-size: .85rem; }
th, td { padding: 10px 12px; text-align: left; border-bottom: 1px solid #eee; }
th { color: #666; font-weight: 600; background: #fafafa; }
tr:hover td { background: #f8f9ff; }
.badge {
    display: inline-block; padding: 2px 8px; border-radius: 20px;
    font-size: .7rem; font-weight: 600; text-transform: uppercase;
}
.badge-vms { background: #e3f2fd; color: #1565c0; }
.badge-koha { background: #fce4ec; color: #c62828; }
.badge-gz { background: #e8f5e9; color: #2e7d32; }
.badge-enc { background: #fff3e0; color: #e65100; }
.msg { padding: 12px 16px; border-radius: 8px; margin-bottom: 16px; font-size: .88rem; }
.msg-ok { background: #e8f5e9; color: #2e7d32; }
.msg-err { background: #fdecea; color: #c62828; }
.spinner {
    display: none; width: 18px; height: 18px;
    border: 2px solid #ccc; border-top-color: #1e3c72;
    border-radius: 50%; animation: spin .6s linear infinite;
    vertical-align: middle; margin-left: 8px;
}
@keyframes spin { to { transform: rotate(360deg); } }
.flex { display: flex; gap: 14px; flex-wrap: wrap; align-items: end; }
.flex > * { flex: 1; min-width: 140px; }
.path { font-size: .75rem; color: #999; word-break: break-all; margin-top: 10px; }
@media (max-width: 600px) {
    body { padding: 12px; }
    .card { padding: 16px; }
    th, td { padding: 8px 6px; font-size: .78rem; }
}
</style>
</head>
<body>
<div class="wrap">

<h1>🗄️ Koha + VMS Backup Manager</h1>
<p class="sub">
    Logged in as <strong><?= h($user['username']) ?></strong>
    &middot; <?= date('Y-m-d H:i') ?>
</p>

<?php if (empty($dirInfo['writable'])): ?>
<div class="msg msg-err">⚠️ Backup directory is not writable. Backups may fail.</div>
<?php endif; ?>

<!-- CREATE BACKUP -->
<div class="card">
    <h2>📦 Create New Backup</h2>
    <form method="POST" action="?mode=create" id="createForm">
        <input type="hidden" name="csrf" value="<?= h($csrf) ?>">
        <div class="flex">
            <div>
                <label>Databases</label>
                <select name="db_select" id="dbSelect">
                    <option value="both">Both (VMS + Koha)</option>
                    <option value="vms">VMS Only</option>
                    <option value="koha">Koha Only</option>
                </select>
            </div>
            <div>
                <label>Include data from</label>
                <div style="padding:10px 0;font-size:.85rem;color:#555">
                    (Sensitive tables like sessions, logs, and caches are always skipped)
                </div>
            </div>
            <div>
                <label>&nbsp;</label>
                <button type="submit" class="btn btn-primary" id="createBtn">
                    Create &amp; Download
                    <span class="spinner" id="spin"></span>
                </button>
            </div>
        </div>
        <input type="hidden" name="vms"  id="vmsFlag"  value="1">
        <input type="hidden" name="koha" id="kohaFlag" value="1">
    </form>
</div>

<!-- BACKUP FILES -->
<div class="card">
    <h2>📂 Existing Backups</h2>
    <div id="fileList">Loading…</div>
</div>

<!-- RESTORE -->
<div class="card">
    <h2>♻️ Restore from Backup</h2>
    <form method="POST" action="?mode=restore" enctype="multipart/form-data"
          onsubmit="return confirm('⚠️ This will overwrite tables in the target database(s). Continue?')">
        <input type="hidden" name="csrf" value="<?= h($csrf) ?>">
        <label>Upload SQL / gzip / encrypted backup file</label>
        <input type="file" name="backup" accept=".sql,.gz,.enc" required>
        <button type="submit" class="btn btn-danger">Restore Now</button>
    </form>
</div>

<!-- MAINTENANCE -->
<div class="card">
    <h2>🧹 Maintenance</h2>
    <div class="flex">
        <div>
            <label>Prune backups older than (days)</label>
            <input type="number" id="pruneDays" value="<?= (int)BK_RETENTION_DAYS ?>" min="1" style="width:100px">
        </div>
        <div>
            <label>&nbsp;</label>
            <button class="btn btn-outline btn-sm" onclick="prune()">Prune Old Backups</button>
        </div>
    </div>
    <p class="path">Backup directory: <code><?= h($dirInfo['path']) ?></code></p>
</div>

</div>

<script>
const CSRF = <?= json_encode($csrf) ?>;

// Sync database select → flags
document.getElementById('dbSelect').addEventListener('change', function() {
    const v = this.value;
    document.getElementById('vmsFlag').value  = (v === 'koha') ? '' : '1';
    document.getElementById('kohaFlag').value = (v === 'vms')  ? '' : '1';
});

// Show spinner on create
document.getElementById('createForm').addEventListener('submit', function() {
    document.getElementById('spin').style.display = 'inline-block';
    document.getElementById('createBtn').disabled = true;
});

// Load file list
async function loadFiles() {
    const el = document.getElementById('fileList');
    el.innerHTML = 'Loading…';
    try {
        const r = await fetch('?mode=list');
        const j = await r.json();
        if (!j.ok || !j.files.length) {
            el.innerHTML = '<p style="color:#888;padding:12px 0">No backups found. Create one above.</p>';
            return;
        }
        let html = `<table><thead><tr>
            <th>File</th><th>Size</th><th>Created</th><th>Tags</th><th>Actions</th>
        </tr></thead><tbody>`;
        for (const f of j.files) {
            const date = new Date(f.mtime * 1000).toLocaleString();
            let tags = '';
            if (f.vms)  tags += '<span class="badge badge-vms">VMS</span> ';
            if (f.koha) tags += '<span class="badge badge-koha">Koha</span> ';
            if (f.gz)   tags += '<span class="badge badge-gz">GZ</span> ';
            if (f.enc)  tags += '<span class="badge badge-enc">ENC</span> ';
            html += `<tr>
                <td style="font-family:monospace;font-size:.78rem">${esc(f.name)}</td>
                <td>${fmtBytes(f.bytes)}</td>
                <td>${date}</td>
                <td>${tags}</td>
                <td style="white-space:nowrap">
                    <a class="btn btn-outline btn-sm"
                       href="?mode=download&file=${encodeURIComponent(f.name)}&token=${CSRF}">
                       ⬇ Download</a>
                    <button class="btn btn-danger btn-sm"
                            onclick="delFile('${esc(f.name)}')">✕</button>
                </td>
            </tr>`;
        }
        html += '</tbody></table>';
        el.innerHTML = html;
    } catch (e) {
        el.innerHTML = '<p style="color:#c62828">Error loading files: ' + e.message + '</p>';
    }
}

function esc(s) { const d = document.createElement('div'); d.textContent = s; return d.innerHTML; }
function fmtBytes(b) {
    if (b >= 1073741824) return (b/1073741824).toFixed(2) + ' GB';
    if (b >= 1048576)    return (b/1048576).toFixed(2) + ' MB';
    if (b >= 1024)       return (b/1024).toFixed(1) + ' KB';
    return b + ' B';
}

async function delFile(name) {
    if (!confirm('Delete "' + name + '"? This cannot be undone.')) return;
    const r = await fetch('?mode=delete&file=' + encodeURIComponent(name) + '&token=' + CSRF);
    const j = await r.json();
    if (!j.ok) { alert('Delete failed: ' + (j.error || 'unknown')); return; }
    loadFiles();
}

async function prune() {
    const days = document.getElementById('pruneDays').value;
    if (!confirm('Delete all backups older than ' + days + ' days?')) return;
    const r = await fetch('?mode=prune&days=' + days + '&token=' + CSRF);
    const j = await r.json();
    if (!j.ok) { alert('Prune failed.'); return; }
    alert('Pruned ' + j.pruned + ' file(s).');
    loadFiles();
}

loadFiles();
</script>
</body>
</html>
