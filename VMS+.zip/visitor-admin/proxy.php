<?php
/**
 * Universal ISBN-Fetcher Proxy — Single File
 * Version: 3.0 FINAL
 *
 * Purpose:
 *   Safely forward browser requests to third-party APIs (OCLC, LoC, BL, xISBN,
 *   Crossref, Wikidata, OpenLibrary, Internet Archive, Gutendex, etc.) that
 *   either (a) block CORS from browsers, or (b) require server-side signing.
 *
 * SECURITY MODEL:
 *   - Strict host allowlist (extend only when needed)
 *   - HTTPS-only upstream by default
 *   - No credential forwarding from client
 *   - No arbitrary URL passthrough
 *   - 12-second connect+read timeout
 *   - Response size capped at 2 MB
 *   - Optional per-IP rate limiting (file-based)
 *   - SSRF-safe (blocks private IPs even if a host somehow resolves to one)
 *
 * USAGE:
 *   GET /proxy.php?url=<url-encoded-upstream-url>
 *
 * Example:
 *   /proxy.php?url=https%3A%2F%2Fclassify.oclc.org%2Fclassify2%2FClassify%3Fisbn%3D...
 */

declare(strict_types=1);
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', sys_get_temp_dir() . '/proxy_php_errors.log');

// ============================================================
// CONFIG
// ============================================================
const ALLOWED_HOSTS = [
    // Library / bibliographic
    'classify.oclc.org',
    'lx2.loc.gov',
    'sru.bl.uk',
    'xisbn.worldcat.org',
    'openlibrary.org',
    'covers.openlibrary.org',
    'archive.org',
    'gutendex.com',
    'api.crossref.org',
    'query.wikidata.org',
    'api.isbndb.com',
    'api.nytimes.com',
    // Optional fallbacks
    'www.googleapis.com',
];

const UPSTREAM_TIMEOUT      = 12;      // seconds
const MAX_RESPONSE_BYTES    = 2 * 1024 * 1024; // 2 MB
const RATE_LIMIT_WINDOW     = 60;      // seconds
const RATE_LIMIT_MAX        = 60;      // requests per window per IP
const RATE_LIMIT_DIR        = '/tmp/isbn_proxy_ratelimit';

const DEFAULT_USER_AGENT    = 'ISBN-Fetcher-Proxy/3.0 (Koha)';
const ALLOW_INSECURE_HTTP   = false;   // set true only if you truly need HTTP

// ============================================================
// HELPERS
// ============================================================

/**
 * Send a plain-text error and exit.
 */
function fail(int $status, string $message): void
{
    if (!headers_sent()) {
        http_response_code($status);
        header('Content-Type: text/plain; charset=utf-8');
        header('X-Content-Type-Options: nosniff');
        header('Cache-Control: no-store');
    }
    echo $message;
    exit;
}

/**
 * Check if a host or IP is private / reserved.
 */
function isPrivateHost(string $host): bool
{
    // If host is already an IP, test directly
    if (filter_var($host, FILTER_VALIDATE_IP)) {
        return !filter_var(
            $host,
            FILTER_VALIDATE_IP,
            FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE
        );
    }
    // Otherwise resolve and check every A/AAAA record
    $records = @dns_get_record($host, DNS_A | DNS_AAAA) ?: [];
    foreach ($records as $rec) {
        $ip = $rec['ip'] ?? $rec['ipv6'] ?? '';
        if ($ip && !filter_var(
            $ip,
            FILTER_VALIDATE_IP,
            FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE
        )) {
            return true;
        }
    }
    return false;
}

/**
 * File-based rate limiter per client IP.
 */
function rateLimit(string $ip): bool
{
    if (!is_dir(RATE_LIMIT_DIR)) {
        @mkdir(RATE_LIMIT_DIR, 0770, true);
    }
    $file = RATE_LIMIT_DIR . '/' . md5($ip) . '.json';
    $now = time();
    $data = ['window_start' => $now, 'count' => 0];
    if (file_exists($file)) {
        $raw = @file_get_contents($file);
        if ($raw !== false) {
            $decoded = json_decode($raw, true);
            if (is_array($decoded)) {
                $data = $decoded;
            }
        }
    }
    if ($now - (int)$data['window_start'] >= RATE_LIMIT_WINDOW) {
        $data = ['window_start' => $now, 'count' => 0];
    }
    $data['count'] = (int)$data['count'] + 1;
    @file_put_contents($file, json_encode($data), LOCK_EX);
    return $data['count'] <= RATE_LIMIT_MAX;
}

/**
 * Detect content type from response body / headers.
 */
function detectContentType(string $body, array $headers): string
{
    // First try upstream Content-Type
    foreach ($headers as $h) {
        if (stripos($h, 'content-type:') === 0) {
            $ct = trim(substr($h, 13));
            if ($ct !== '') {
                return $ct;
            }
        }
    }
    // Fallback: sniff body
    $trim = ltrim($body);
    if (strncmp($trim, '<?xml', 5) === 0) return 'application/xml; charset=utf-8';
    if (strncmp($trim, '{', 1) === 0 || strncmp($trim, '[', 1) === 0) return 'application/json; charset=utf-8';
    if (stripos($trim, '<html') !== false) return 'text/html; charset=utf-8';
    return 'text/plain; charset=utf-8';
}

// ============================================================
// INPUT VALIDATION
// ============================================================
$rawUrl = $_GET['url'] ?? '';
if ($rawUrl === '' || !is_string($rawUrl)) {
    fail(400, 'Missing url parameter');
}

// Decode (browsers may double-encode)
$url = urldecode($rawUrl);
if (!filter_var($url, FILTER_VALIDATE_URL)) {
    fail(400, 'Invalid URL');
}

$parts = parse_url($url);
if (!$parts || empty($parts['host']) || empty($parts['scheme'])) {
    fail(400, 'Malformed URL');
}

$scheme = strtolower($parts['scheme']);
$host   = strtolower($parts['host']);
$port   = isset($parts['port']) ? (int)$parts['port'] : ($scheme === 'https' ? 443 : 80);

// Enforce scheme
if ($scheme !== 'https' && !ALLOW_INSECURE_HTTP) {
    fail(403, 'Only HTTPS upstream allowed');
}
if ($scheme !== 'https' && $scheme !== 'http') {
    fail(403, 'Unsupported scheme');
}

// Enforce host allowlist
if (!in_array($host, ALLOWED_HOSTS, true)) {
    fail(403, 'Host not allowed: ' . htmlspecialchars($host, ENT_QUOTES));
}

// Block private IPs
if (isPrivateHost($host)) {
    fail(403, 'Private/reserved host not allowed');
}

// Only allow standard ports
if (!in_array($port, [80, 443], true)) {
    fail(403, 'Non-standard port not allowed');
}

// ============================================================
// RATE LIMIT
// ============================================================
$clientIp = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
$clientIp = trim(explode(',', $clientIp)[0]);
if (!rateLimit($clientIp)) {
    fail(429, 'Rate limit exceeded');
}

// ============================================================
// FETCH UPSTREAM
// ============================================================
$ch = curl_init();
curl_setopt_array($ch, [
    CURLOPT_URL              => $url,
    CURLOPT_RETURNTRANSFER   => true,
    CURLOPT_FOLLOWLOCATION   => false,
    CURLOPT_CONNECTTIMEOUT   => UPSTREAM_TIMEOUT,
    CURLOPT_TIMEOUT          => UPSTREAM_TIMEOUT,
    CURLOPT_USERAGENT        => DEFAULT_USER_AGENT,
    CURLOPT_SSL_VERIFYPEER   => true,
    CURLOPT_SSL_VERIFYHOST   => 2,
    CURLOPT_HTTPHEADER       => [
        'Accept: application/json, application/xml, text/xml, */*',
        'Accept-Language: en',
        'Cache-Control: no-cache',
    ],
    CURLOPT_HEADER           => true,   // capture headers
    CURLOPT_ENCODING         => '',     // accept gzip/deflate
    CURLOPT_MAXREDIRS        => 0,
    CURLOPT_PROTOCOLS        => CURLPROTO_HTTPS | (ALLOW_INSECURE_HTTP ? CURLPROTO_HTTP : 0),
    CURLOPT_REDIR_PROTOCOLS  => CURLPROTO_HTTPS | (ALLOW_INSECURE_HTTP ? CURLPROTO_HTTP : 0),
]);

$response = curl_exec($ch);
$errno    = curl_errno($ch);
$error    = curl_error($ch);
$httpCode = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
$headerSize = (int)curl_getinfo($ch, CURLINFO_HEADER_SIZE);
curl_close($ch);

if ($response === false || $errno !== 0) {
    error_log("proxy.php curl error: $error");
    fail(502, 'Upstream fetch failed: ' . $error);
}

$rawHeaders = substr($response, 0, $headerSize);
$body       = substr($response, $headerSize);
$headerLines = array_filter(explode("\r\n", $rawHeaders));

// Cap response size
if (strlen($body) > MAX_RESPONSE_BYTES) {
    $body = substr($body, 0, MAX_RESPONSE_BYTES);
}

// ============================================================
// OUTPUT
// ============================================================
$contentType = detectContentType($body, $headerLines);

if (!headers_sent()) {
    http_response_code($httpCode ?: 200);
    header('Content-Type: ' . $contentType);
    header('X-Content-Type-Options: nosniff');
    header('Cache-Control: public, max-age=300');
    header('X-Proxy-Source: isbn-fetcher-proxy/3.0');
}

echo $body;