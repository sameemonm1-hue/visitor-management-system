<?php
/**
 * VMS — Fix book_exit_logs trigger recursion (MySQL error 1442)
 * Version: 1.0
 *
 * Run once from the browser:
 *   http://<your-host>/cgi-bin/koha/visitor/fix_trigger.php
 *
 * What it does:
 *   1. Lists every trigger on book_exit_logs
 *   2. Shows each trigger's full SQL definition
 *   3. Drops the buggy trigger(s) with one click
 *   4. Optional: recreates a CORRECTED version that only INSERTs into
 *      book_alerts and never UPDATEs book_exit_logs
 *   5. Runs a live test INSERT to prove the fix works
 *
 * SAFE: read-only until you click a button. No data is ever dropped.
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

// ============================================================
// FIND includes/config.php
// ============================================================
$possiblePaths = [
    __DIR__ . '/includes',
    dirname(__DIR__) . '/includes',
    '/usr/share/koha/intranet/cgi-bin/koha/visitor/includes',
];
$includePath = null;
foreach ($possiblePaths as $p) {
    if (file_exists($p . '/config.php')) { $includePath = $p; break; }
}
if (!$includePath) die('Could not find includes/config.php');

require_once $includePath . '/config.php';
require_once $includePath . '/db.php';

$db = getDB();
if (!$db) die('No DB connection');

$message = '';
$error   = '';
$action  = $_POST['action'] ?? $_GET['action'] ?? '';

// ============================================================
// ACTION: Drop a trigger
// ============================================================
if ($action === 'drop' && !empty($_POST['trigger_name'])) {
    $name = preg_replace('/[^a-zA-Z0-9_]/', '', $_POST['trigger_name']);
    if ($name === '') {
        $error = 'Invalid trigger name';
    } else {
        try {
            $db->exec("DROP TRIGGER IF EXISTS `$name`");
            $message = "✅ Dropped trigger: <code>" . htmlspecialchars($name) . "</code>";
        } catch (PDOException $e) {
            $error = 'Drop failed: ' . $e->getMessage();
        }
    }
}

// ============================================================
// ACTION: Drop ALL triggers on book_exit_logs
// ============================================================
if ($action === 'drop_all') {
    $dropped = [];
    $failed  = [];
    try {
        $stmt = $db->query("SHOW TRIGGERS LIKE 'book_exit_logs'");
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $t) {
            $tn = $t['Trigger'] ?? '';
            if ($tn === '') continue;
            try {
                $db->exec("DROP TRIGGER IF EXISTS `" . preg_replace('/[^a-zA-Z0-9_]/', '', $tn) . "`");
                $dropped[] = $tn;
            } catch (PDOException $e) {
                $failed[] = $tn . ' → ' . $e->getMessage();
            }
        }
        if ($dropped) {
            $message = '✅ Dropped ' . count($dropped) . ' trigger(s): <code>' . implode(', ', array_map('htmlspecialchars', $dropped)) . '</code>';
        } else {
            $message = 'No triggers to drop.';
        }
        if ($failed) {
            $error = 'Some failed: ' . implode(' | ', array_map('htmlspecialchars', $failed));
        }
    } catch (PDOException $e) {
        $error = 'Could not list/drop triggers: ' . $e->getMessage();
    }
}

// ============================================================
// ACTION: Recreate a correct trigger
// ============================================================
if ($action === 'recreate') {
    $triggerName = 'trg_auto_book_alert';
    try {
        $db->exec("DROP TRIGGER IF EXISTS `$triggerName`");
        $db->exec("
            CREATE TRIGGER `$triggerName`
            AFTER INSERT ON book_exit_logs
            FOR EACH ROW
            BEGIN
                IF NEW.is_authorized = 0 THEN
                    INSERT INTO book_alerts
                        (log_id, book_barcode, book_title, photo_path,
                         acknowledged, resolved, created_at)
                    VALUES
                        (NEW.id, NEW.book_barcode, NEW.book_title,
                         COALESCE(NEW.photo_path, ''),
                         0, 0, NOW());
                END IF;
            END
        ");
        $message = "✅ Recreated corrected trigger <code>$triggerName</code> — " .
                   "it only INSERTs into <code>book_alerts</code> and never UPDATEs " .
                   "<code>book_exit_logs</code>, so error 1442 cannot occur.";
    } catch (PDOException $e) {
        $error = 'Recreate failed: ' . $e->getMessage();
    }
}

// ============================================================
// ACTION: Live test INSERT (rolled back)
// ============================================================
$testResult = null;
if ($action === 'test') {
    try {
        $db->beginTransaction();
        $stmt = $db->prepare("
            INSERT INTO book_exit_logs
                (book_barcode, book_title, is_authorized)
            VALUES ('__FIX_TEST__', 'Trigger Fix Test', 0)
        ");
        $stmt->execute();
        $id = $db->lastInsertId();
        $db->rollBack();
        $testResult = ['ok' => true, 'insert_id' => $id];
    } catch (PDOException $e) {
        try { $db->rollBack(); } catch (Exception $e2) {}
        $testResult = ['ok' => false, 'error' => $e->getMessage()];
    }
}

// ============================================================
// List all triggers on book_exit_logs
// ============================================================
$triggers = [];
try {
    $stmt = $db->query("SHOW TRIGGERS LIKE 'book_exit_logs'");
    $triggers = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $error = $error ?: ('Could not list triggers: ' . $e->getMessage());
}

// Also list triggers on book_alerts (informational)
$alertTriggers = [];
try {
    $stmt = $db->query("SHOW TRIGGERS LIKE 'book_alerts'");
    $alertTriggers = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>VMS — Fix book_exit_logs Trigger</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
body { background:#f0f2f5; padding:30px; font-family:'Inter',system-ui,sans-serif; }
.box { max-width: 960px; margin:0 auto; background:#fff; border-radius:20px; padding:36px;
       box-shadow:0 12px 40px rgba(0,0,0,.08); }
h1 { color:#1e3c72; font-weight:800; font-size:1.6rem; margin-bottom:4px; }
.lead { color:#6c757d; font-size:.9rem; margin-bottom:24px; }
pre { background:#0f172a; color:#e2e8f0; padding:16px 20px; border-radius:12px;
      font-size:.8rem; overflow-x:auto; line-height:1.55; margin:10px 0;
      white-space: pre-wrap; word-break: break-word; }
.trigger-card { background:#fff5f5; border-left:4px solid #dc3545; border-radius:12px;
                padding:16px 20px; margin-bottom:14px; }
.trigger-card.ok { background:#f0fff4; border-left-color:#28a745; }
.trigger-card h6 { margin:0 0 6px; font-weight:700; color:#0f172a; }
.trigger-card .meta { font-size:.78rem; color:#6c757d; }
.trigger-card .actions { margin-top:10px; display:flex; gap:8px; flex-wrap:wrap; }
.step { background:#f8fafc; border-radius:12px; padding:18px 22px; margin-bottom:18px;
        border-left:4px solid #1e3c72; }
.step h5 { color:#1e3c72; font-weight:700; font-size:1rem; margin-bottom:8px; }
.btn { border-radius:10px; font-weight:600; padding:8px 18px; }
.btn-danger { background:#dc3545; border-color:#dc3545; }
.btn-primary { background:#1e3c72; border-color:#1e3c72; }
.btn-success { background:#28a745; border-color:#28a745; }
.btn-warning { background:#ffc107; border-color:#ffc107; color:#212529; }
.test-ok { background:#d4edda; color:#155724; padding:14px 18px; border-radius:12px; border-left:4px solid #28a745; }
.test-fail { background:#f8d7da; color:#721c24; padding:14px 18px; border-radius:12px; border-left:4px solid #dc3545; }
.big-icon { font-size: 3rem; margin-bottom: 12px; }
</style>
</head>
<body>
<div class="box">
    <div class="text-center mb-3">
        <div class="big-icon text-warning"><i class="fas fa-wrench"></i></div>
        <h1>Fix <code>book_exit_logs</code> Trigger</h1>
        <p class="lead">MySQL error 1442 — a trigger on this table is trying to UPDATE the same table.<br>
        Drop it or replace it with the corrected version below.</p>
    </div>

    <?php if ($message): ?>
        <div class="alert alert-success"><i class="fas fa-check-circle me-2"></i><?= $message ?></div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="alert alert-danger"><i class="fas fa-exclamation-triangle me-2"></i><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <!-- ═══════════════════════════════════════════════════════ -->
    <!-- STEP 1 — current triggers                              -->
    <!-- ═══════════════════════════════════════════════════════ -->
    <div class="step">
        <h5><i class="fas fa-bolt me-1"></i> Step 1 — Current triggers on <code>book_exit_logs</code></h5>
        <?php if (empty($triggers)): ?>
            <div class="trigger-card ok">
                <h6>✅ No triggers found</h6>
                <div class="meta">
                    The table is clean. If you still see error 1442, check <code>SHOW TRIGGERS;</code> in MySQL —
                    another trigger might reference this table under a different name.
                </div>
            </div>
        <?php else: ?>
            <?php foreach ($triggers as $t):
                $tn = $t['Trigger'] ?? '';
                $stmtSql = $t['Statement'] ?? '';
                $isSuspicious = stripos($stmtSql, 'book_exit_logs') !== false;
            ?>
                <div class="trigger-card <?= $isSuspicious ? '' : 'ok' ?>">
                    <h6>
                        <?php if ($isSuspicious): ?>
                            <i class="fas fa-exclamation-triangle text-danger me-1"></i>
                            <span class="text-danger"><?= htmlspecialchars($tn) ?> — BUGGY (updates own table)</span>
                        <?php else: ?>
                            <i class="fas fa-check-circle text-success me-1"></i>
                            <?= htmlspecialchars($tn) ?>
                        <?php endif; ?>
                    </h6>
                    <div class="meta">
                        <strong>Timing:</strong> <?= htmlspecialchars($t['Timing'] ?? '') ?> &nbsp;|&nbsp;
                        <strong>Event:</strong> <?= htmlspecialchars($t['Event'] ?? '') ?> &nbsp;|&nbsp;
                        <strong>Table:</strong> <?= htmlspecialchars($t['Table'] ?? '') ?>
                    </div>
                    <?php if ($stmtSql !== ''): ?>
                        <pre><?= htmlspecialchars($stmtSql) ?></pre>
                    <?php endif; ?>
                    <div class="actions">
                        <form method="POST" style="display:inline"
                              onsubmit="return confirm('Drop trigger <?= htmlspecialchars($tn) ?>?');">
                            <input type="hidden" name="action" value="drop">
                            <input type="hidden" name="trigger_name" value="<?= htmlspecialchars($tn) ?>">
                            <button type="submit" class="btn btn-danger btn-sm">
                                <i class="fas fa-trash me-1"></i> Drop this trigger
                            </button>
                        </form>
                    </div>
                </div>
            <?php endforeach; ?>

            <form method="POST" class="mt-3"
                  onsubmit="return confirm('Drop ALL triggers on book_exit_logs?');">
                <input type="hidden" name="action" value="drop_all">
                <button type="submit" class="btn btn-warning btn-sm">
                    <i class="fas fa-broom me-1"></i> Drop ALL triggers on this table
                </button>
            </form>
        <?php endif; ?>
    </div>

    <!-- ═══════════════════════════════════════════════════════ -->
    <!-- STEP 2 — test                                          -->
    <!-- ═══════════════════════════════════════════════════════ -->
    <div class="step">
        <h5><i class="fas fa-vial me-1"></i> Step 2 — Test the fix</h5>
        <p style="font-size:.88rem;color:#475569;">
            Runs a real INSERT into <code>book_exit_logs</code> inside a transaction that is
            <strong>rolled back</strong>. Nothing is saved.
        </p>
        <form method="POST">
            <input type="hidden" name="action" value="test">
            <button type="submit" class="btn btn-success">
                <i class="fas fa-play me-1"></i> Run test INSERT
            </button>
        </form>

        <?php if ($testResult !== null): ?>
            <?php if ($testResult['ok']): ?>
                <div class="test-ok mt-3">
                    <strong>✅ Insert works!</strong><br>
                    Inserted row id = <code><?= (int)$testResult['insert_id'] ?></code> (rolled back — nothing persisted).<br>
                    <span class="small">You can now go back to the kiosk and scan an unauthorized book again.</span>
                </div>
            <?php else: ?>
                <div class="test-fail mt-3">
                    <strong>❌ Still failing.</strong><br>
                    <code><?= htmlspecialchars($testResult['error']) ?></code>
                    <div class="mt-2 small">
                        Check <code>SHOW TRIGGERS;</code> in MySQL — another trigger (possibly on a different
                        table) may still be invoking an UPDATE that touches <code>book_exit_logs</code>.
                    </div>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>

    <!-- ═══════════════════════════════════════════════════════ -->
    <!-- STEP 3 — optional: recreate a correct trigger          -->
    <!-- ═══════════════════════════════════════════════════════ -->
    <div class="step">
        <h5><i class="fas fa-check-double me-1"></i> Step 3 — (Optional) Recreate a correct trigger</h5>
        <p style="font-size:.88rem;color:#475569;">
            The VMS already creates alert rows from PHP — a database trigger is <strong>not required</strong>.
            But if you want one for safety, this corrected version only <strong>INSERTs</strong> into
            <code>book_alerts</code> and never touches <code>book_exit_logs</code>, so error 1442 cannot occur.
        </p>
        <form method="POST" onsubmit="return confirm('Recreate trigger trg_auto_book_alert?');">
            <input type="hidden" name="action" value="recreate">
            <button type="submit" class="btn btn-primary btn-sm">
                <i class="fas fa-redo me-1"></i> Recreate corrected <code>trg_auto_book_alert</code>
            </button>
        </form>
    </div>

    <!-- ═══════════════════════════════════════════════════════ -->
    <!-- Triggers on book_alerts (informational only)           -->
    <!-- ═══════════════════════════════════════════════════════ -->
    <?php if (!empty($alertTriggers)): ?>
    <div class="step">
        <h5><i class="fas fa-info-circle me-1"></i> Triggers on <code>book_alerts</code> (informational)</h5>
        <?php foreach ($alertTriggers as $t): ?>
            <div class="trigger-card ok">
                <h6><?= htmlspecialchars($t['Trigger'] ?? '') ?></h6>
                <div class="meta">
                    <strong>Timing:</strong> <?= htmlspecialchars($t['Timing'] ?? '') ?> &nbsp;|&nbsp;
                    <strong>Event:</strong> <?= htmlspecialchars($t['Event'] ?? '') ?>
                </div>
                <?php if (!empty($t['Statement'])): ?>
                    <pre><?= htmlspecialchars($t['Statement']) ?></pre>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <!-- Recommended action -->
    <div class="alert alert-info small mt-4">
        <i class="fas fa-info-circle me-1"></i>
        <strong>Recommended:</strong>
        Drop every trigger on <code>book_exit_logs</code> (Step 1). The VMS writes its own alerts from PHP
        in <code>index.php → vms_record_unauthorized_book_exit()</code> and <code>alerts.php → addToAlertQueue()</code>,
        so no trigger is needed. Leave the table trigger-free for maximum reliability.
    </div>

    <div class="mt-4 text-center">
        <a href="index.php" class="btn btn-outline-secondary">
            <i class="fas fa-arrow-left me-1"></i> Back to Visitor Management
        </a>
        <a href="fix_trigger.php" class="btn btn-outline-primary">
            <i class="fas fa-sync me-1"></i> Refresh this page
        </a>
    </div>
</div>
</body>
</html>