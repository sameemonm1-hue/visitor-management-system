<?php
/**
 * Visitor Management System - Entry Management
 * Version: 7.5 FINAL – Purpose list from canonical source
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

// Auto-detect paths
$possiblePaths = [
    __DIR__ . '/includes',
    dirname(__DIR__) . '/includes',
    '/usr/share/koha/intranet/cgi-bin/koha/visitor/includes',
    '/usr/share/koha/intranet/cgi-bin/visitor/includes',
];

$includePath = null;
foreach ($possiblePaths as $path) {
    if (file_exists($path . '/config.php')) {
        $includePath = $path;
        break;
    }
}

if (!$includePath) {
    $testPath = __DIR__;
    for ($i = 0; $i < 5; $i++) {
        $testPath = dirname($testPath);
        if (file_exists($testPath . '/includes/config.php')) {
            $includePath = $testPath . '/includes';
            break;
        }
    }
}

if (!$includePath) {
    die('Could not find includes directory.');
}

define('VMS_INCLUDES', $includePath);
require_once VMS_INCLUDES . '/config.php';
require_once VMS_INCLUDES . '/functions.php';
require_once VMS_INCLUDES . '/koha.php';
require_once VMS_INCLUDES . '/auth.php';

startSecureSession();
requireKohaLogin();

$db = getDB();
$user = getCurrentUser();
$settings = getSettings();
$lang = $_SESSION['visitor_lang'] ?? 'en'; // UPDATED
$message = '';
$searchError = '';
$searchResult = null;

// Handle search
if (isset($_POST['search_member'])) {
    $admno = trim($_POST['admno']);
    if (strlen($admno) < 2) {
        $searchError = 'Please enter a valid ID';
    } else {
        $member = getKohaMember($admno);
        if ($member) {
            $check = $db->prepare("SELECT id FROM entry_exit_logs WHERE admno = ? AND status = 'inside'");
            $check->execute([$member['cardnumber']]);
            $member['is_inside'] = (bool)$check->fetch();
            $searchResult = $member;
        } else {
            $searchError = 'Member not found in Koha';
        }
    }
}

// Handle entry recording
if (isset($_POST['record_entry'])) {
    $admno = trim($_POST['admno']);
    // UPDATED: whitelist purpose
    $purpose = vms_valid_purpose(trim($_POST['purpose'] ?? ($settings['default_purpose'] ?? 'Reading/Study')));

    $member = getKohaMember($admno);
    if (!$member) {
        $message = 'Member not found';
    } else {
        $check = $db->prepare("SELECT id FROM entry_exit_logs WHERE admno = ? AND status = 'inside'");
        $check->execute([$member['cardnumber']]);
        if ($check->fetch()) {
            $message = '⚠️ Member is already inside';
        } else {
            $insert = $db->prepare("
                INSERT INTO entry_exit_logs
                (admno, member_name, member_category, entry_date, entry_time, purpose, status, staff_id, gate_number)
                VALUES (?, ?, ?, CURDATE(), CURTIME(), ?, 'inside', ?, ?)
            ");
            $insert->execute([
                $member['cardnumber'],
                $member['full_name'],
                $member['category_description'] ?? $member['categorycode'],
                $purpose,
                $user['id'] ?? 0,
                $_SERVER['REMOTE_ADDR'] ?? 'Unknown'
            ]);

            logActivity($user['id'] ?? 0, 'ENTRY', "Entry recorded for {$member['full_name']}");
            $message = "✅ Entry recorded for {$member['full_name']}";
            $searchResult = null;
            clearCache('stats');
        }
    }
}

// Handle guest entry
if (isset($_POST['guest_entry'])) {
    if (!($settings['guest_enabled'] ?? 1)) {
        $message = '⚠️ Guest mode is disabled';
    } else {
        $guestNum = $db->query("SELECT guest_daily_counter FROM settings LIMIT 1")->fetchColumn() ?: 1;
        $prefix = $settings['guest_prefix'] ?? 'GUEST-';
        $padding = (int)($settings['guest_padding'] ?? 4);
        $formattedNum = str_pad($guestNum, $padding, '0', STR_PAD_LEFT);
        $admno = $prefix . $formattedNum;

        // UPDATED: whitelist guest purpose (falls back to default)
        $guestPurpose = vms_valid_purpose(trim($_POST['guest_purpose'] ?? ($settings['default_purpose'] ?? 'Reading/Study')));

        $insert = $db->prepare("
            INSERT INTO entry_exit_logs
            (admno, member_name, member_category, entry_date, entry_time, purpose, status, entry_type, staff_id, gate_number)
            VALUES (?, ?, ?, CURDATE(), CURTIME(), ?, 'inside', 'guest', ?, ?)
        ");
        $insert->execute([
            $admno,
            "Guest $guestNum",
            'Guest',
            $guestPurpose,
            $user['id'] ?? 0,
            $_SERVER['REMOTE_ADDR'] ?? 'Unknown'
        ]);

        $db->query("UPDATE settings SET guest_daily_counter = guest_daily_counter + 1");
        logActivity($user['id'] ?? 0, 'GUEST_ENTRY', "Guest entry: $admno");
        $message = "✅ Guest $guestNum entered successfully";
        clearCache('stats');
    }
}

// Get currently inside
$inside = $db->query("
    SELECT * FROM entry_exit_logs
    WHERE status = 'inside'
    ORDER BY entry_time DESC
    LIMIT 50
")->fetchAll();

$guestCount = $db->query("SELECT COUNT(*) FROM entry_exit_logs WHERE status = 'inside' AND entry_type = 'guest'")->fetchColumn();

$pageTitle = 'Entry Management';
include __DIR__ . '/header.php';
?>

<style>
.entry-search-card {
    background: #f8f9fa;
    border-radius: 16px;
    padding: 20px;
    margin-bottom: 20px;
    border: 1px solid #e9ecef;
}
.member-result-card {
    background: white;
    border-radius: 16px;
    padding: 20px;
    border: 1px solid #e9ecef;
    margin-top: 16px;
}
.member-avatar {
    width: 80px;
    height: 80px;
    border-radius: 50%;
    object-fit: cover;
    border: 3px solid #1e3c72;
}
@media (max-width: 768px) {
    .member-avatar { width: 60px; height: 60px; }
}
</style>

<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
        <h4 class="mb-0"><i class="fas fa-sign-in-alt me-2 text-primary"></i>Entry Management</h4>
        <div class="d-flex gap-2">
            <span class="badge bg-primary rounded-pill px-3 py-2">
                <i class="fas fa-users me-1"></i> <?= count($inside) ?> Inside
            </span>
            <?php if ($guestCount > 0): ?>
                <span class="badge bg-success rounded-pill px-3 py-2">
                    <i class="fas fa-user-friends me-1"></i> <?= $guestCount ?> Guests
                </span>
            <?php endif; ?>
        </div>
    </div>

    <?php if ($message): ?>
        <div class="alert alert-<?= strpos($message, '⚠️') !== false ? 'warning' : 'success' ?> alert-dismissible fade show">
            <?= htmlspecialchars($message) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    <?php if ($searchError): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <?= htmlspecialchars($searchError) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="entry-search-card">
        <div class="row g-3">
            <div class="col-12">
                <ul class="nav nav-tabs" role="tablist">
                    <li class="nav-item">
                        <button class="nav-link active" data-bs-toggle="tab" data-bs-target="#memberTab">
                            <i class="fas fa-user me-1"></i> Member
                        </button>
                    </li>
                    <?php if ($settings['guest_enabled'] ?? 1): ?>
                        <li class="nav-item">
                            <button class="nav-link" data-bs-toggle="tab" data-bs-target="#guestTab">
                                <i class="fas fa-user-friends me-1"></i> Guest
                            </button>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>

            <div class="col-12">
                <div class="tab-content">
                    <div class="tab-pane fade show active" id="memberTab">
                        <form method="POST" class="row g-3">
                            <div class="col-12 col-md-5">
                                <label class="form-label fw-semibold">Member ID / Barcode</label>
                                <div class="input-group">
                                    <span class="input-group-text bg-primary text-white"><i class="fas fa-id-card"></i></span>
                                    <input type="text" name="admno" class="form-control form-control-lg"
                                           placeholder="Enter Member ID" required autofocus>
                                </div>
                            </div>
                            <div class="col-12 col-md-4">
                                <label class="form-label fw-semibold">Purpose</label>
                                <!-- UPDATED: canonical purpose options -->
                                <select name="purpose" class="form-select form-select-lg">
                                    <?= renderPurposeOptions($settings['default_purpose'] ?? 'Reading/Study', $lang) ?>
                                </select>
                            </div>
                            <div class="col-12 col-md-3 d-flex align-items-end">
                                <button type="submit" name="search_member" class="btn btn-primary w-100 btn-lg">
                                    <i class="fas fa-search me-2"></i> Find Member
                                </button>
                            </div>
                        </form>
                    </div>

                    <?php if ($settings['guest_enabled'] ?? 1): ?>
                        <div class="tab-pane fade" id="guestTab">
                            <div class="row g-3">
                                <div class="col-12">
                                    <div class="alert alert-info">
                                        <i class="fas fa-info-circle me-2"></i>
                                        Guest entries are automatically generated with a unique ID.
                                        <br><small>Current guest prefix: <strong><?= htmlspecialchars($settings['guest_prefix'] ?? 'GUEST-') ?></strong></small>
                                    </div>
                                </div>
                                <div class="col-12 col-md-6">
                                    <label class="form-label fw-semibold">Guest Purpose</label>
                                    <!-- UPDATED: canonical purpose options -->
                                    <select name="guest_purpose" class="form-select form-select-lg" id="guestPurpose">
                                        <?= renderPurposeOptions($settings['default_purpose'] ?? 'Reading/Study', $lang) ?>
                                    </select>
                                </div>
                                <div class="col-12 col-md-6 d-flex align-items-end">
                                    <form method="POST" class="w-100">
                                        <button type="submit" name="guest_entry" class="btn btn-success w-100 btn-lg">
                                            <i class="fas fa-user-friends me-2"></i> Add Guest Entry
                                        </button>
                                    </form>
                                </div>
                                <div class="col-12">
                                    <div class="text-muted small">
                                        <i class="fas fa-info-circle me-1"></i>
                                        Max guests inside: <?= (int)($settings['guest_max_inside'] ?? 50) ?> |
                                        Active guests: <span class="fw-bold text-success"><?= $guestCount ?></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <?php if (isset($searchResult)): ?>
            <div class="member-result-card">
                <div class="row align-items-center">
                    <div class="col-12 col-md-2 text-center mb-3 mb-md-0">
                        <?php if (!empty($searchResult['photo_base64'])): ?>
                            <img src="<?= $searchResult['photo_base64'] ?>" class="member-avatar" alt="Photo" loading="lazy">
                        <?php else: ?>
                            <div class="member-avatar bg-primary d-flex align-items-center justify-content-center mx-auto"
                                 style="color:white;font-size:2rem;font-weight:bold;">
                                <?= substr($searchResult['full_name'], 0, 1) ?>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="col-12 col-md-6">
                        <h5 class="mb-1"><?= htmlspecialchars($searchResult['full_name']) ?></h5>
                        <div class="d-flex flex-wrap gap-2">
                            <span class="badge bg-primary">
                                <?= htmlspecialchars($searchResult['category_description'] ?? $searchResult['categorycode']) ?>
                            </span>
                            <span class="badge bg-secondary">
                                <?= htmlspecialchars($searchResult['cardnumber']) ?>
                            </span>
                            <?php if ($searchResult['is_inside']): ?>
                                <span class="badge bg-success"><i class="fas fa-circle me-1"></i> Inside</span>
                            <?php else: ?>
                                <span class="badge bg-secondary">Outside</span>
                            <?php endif; ?>
                        </div>
                        <?php if (!empty($searchResult['department'])): ?>
                            <div class="mt-1 small text-muted">
                                <i class="fas fa-building me-1"></i> <?= htmlspecialchars($searchResult['department']) ?>
                            </div>
                        <?php endif; ?>
                        <?php if (!empty($searchResult['email'])): ?>
                            <div class="small text-muted">
                                <i class="fas fa-envelope me-1"></i> <?= htmlspecialchars($searchResult['email']) ?>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="col-12 col-md-4 text-center text-md-end mt-3 mt-md-0">
                        <?php if (!$searchResult['is_inside']): ?>
                            <form method="POST">
                                <input type="hidden" name="admno" value="<?= htmlspecialchars($searchResult['cardnumber']) ?>">
                                <input type="hidden" name="purpose" value="<?= htmlspecialchars(vms_valid_purpose($settings['default_purpose'] ?? 'Reading/Study')) ?>">
                                <button type="submit" name="record_entry" class="btn btn-success btn-lg w-100 w-md-auto">
                                    <i class="fas fa-sign-in-alt me-2"></i> Record Entry
                                </button>
                            </form>
                        <?php else: ?>
                            <div class="alert alert-warning mb-0">
                                <i class="fas fa-exclamation-triangle me-2"></i> Already inside
                            </div>
                            <a href="exits.php?admno=<?= urlencode($searchResult['cardnumber']) ?>"
                               class="btn btn-danger mt-2">
                                <i class="fas fa-sign-out-alt me-2"></i> Exit Now
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <div class="card shadow-sm">
        <div class="card-header bg-white d-flex justify-content-between align-items-center flex-wrap gap-2">
            <h5 class="mb-0"><i class="fas fa-users me-2"></i>Currently Inside Library</h5>
            <span class="badge bg-primary rounded-pill px-3 py-2"><?= count($inside) ?> Members</span>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover mb-0" id="insideTable">
                    <thead class="table-light">
                        <tr>
                            <th>Member</th>
                            <th>ID</th>
                            <th>Entry Time</th>
                            <th>Purpose</th>
                            <th>Type</th>
                            <th>Duration</th>
                            <th class="text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($inside)): ?>
                            <tr>
                                <td colspan="7" class="text-center py-4 text-muted">
                                    <i class="fas fa-check-circle text-success me-2"></i> No members currently inside
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($inside as $row): ?>
                                <tr>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <div class="rounded-circle bg-secondary text-white d-flex align-items-center justify-content-center me-2"
                                                 style="width:32px;height:32px;font-size:0.8rem;font-weight:bold;flex-shrink:0;">
                                                <?= substr($row['member_name'] ?? 'U', 0, 1) ?>
                                            </div>
                                            <span class="fw-semibold"><?= htmlspecialchars($row['member_name']) ?></span>
                                        </div>
                                    </td>
                                    <td><code><?= htmlspecialchars($row['admno']) ?></code></td>
                                    <td><?= htmlspecialchars($row['entry_time']) ?></td>
                                    <td><?= htmlspecialchars($row['purpose'] ?? 'N/A') ?></td>
                                    <td>
                                        <span class="badge <?= ($row['entry_type'] ?? 'member') === 'guest' ? 'bg-success' : 'bg-primary' ?>">
                                            <?= ucfirst($row['entry_type'] ?? 'Member') ?>
                                        </span>
                                    </td>
                                    <td><span class="badge bg-warning text-dark"><?= timeAgo($row['entry_time']) ?></span></td>
                                    <td class="text-center">
                                        <a href="exits.php?admno=<?= urlencode($row['admno']) ?>"
                                           class="btn btn-sm btn-danger">
                                            <i class="fas fa-sign-out-alt"></i> Exit
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const table = document.getElementById('insideTable');
    if (!table) return;
    const cardBody = table.closest('.card-body');
    if (cardBody) {
        const searchDiv = document.createElement('div');
        searchDiv.className = 'p-3 border-bottom';
        searchDiv.innerHTML = `
            <div class="d-flex gap-2">
                <input type="text" id="tableSearch" class="form-control form-control-sm"
                       placeholder="Search members..." style="max-width:300px;">
                <button class="btn btn-sm btn-outline-secondary" onclick="clearTableSearch()">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        `;
        cardBody.insertBefore(searchDiv, table);
        document.getElementById('tableSearch').addEventListener('input', function() {
            const filter = this.value.toLowerCase();
            const rows = table.getElementsByTagName('tbody')[0]?.getElementsByTagName('tr') || [];
            for (let i = 0; i < rows.length; i++) {
                const text = rows[i].textContent.toLowerCase();
                rows[i].style.display = text.includes(filter) ? '' : 'none';
            }
        });
    }
});
function clearTableSearch() {
    const input = document.getElementById('tableSearch');
    if (input) {
        input.value = '';
        input.dispatchEvent(new Event('input'));
        input.focus();
    }
}
</script>

<?php include __DIR__ . '/footer.php'; ?>
