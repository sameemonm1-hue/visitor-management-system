<?php
/**
 * Visitor Management System — Database Backup Utility
 * Version: 8.6 FINAL
 *
 * Fixes (v8.6):
 *   • Handles views returned by SHOW TABLES (uses array_values()[1] for DDL
 *     instead of hard-coded 'Create Table' key → fixes "Undefined array key"
 *     warning when the entry_exit view is present).
 *   • Auto-creates logs/backups, chmods it, and falls back to a writable
 *     temp directory if the primary dir isn't writable (fixes "Permission
 *     denied" on locked-down Koha installs).
 *   • Skips views for INSERT dumps but still writes their CREATE VIEW DDL.
 *   • Graceful error reporting to the admin UI.
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

// ============================================================
// INCLUDE PATH DETECTION
// ============================================================
$possiblePaths = [
    __DIR__ . '/includes',
    dirname(__DIR__) . '/includes',
    '/usr/share/koha/intranet/cgi-bin/koha/visitor/includes',
    '/usr/share/koha/intranet/cgi-bin/visitor/includes',
];
$includePath = null;
foreach ($possiblePaths as $path) {
    if (file_exists($path . '/config.php')) { $includePath = $path; break; }
}
if (!$includePath) die('Could not find includes directory.');

define('VMS_INCLUDES', $includePath);
require_once VMS_INCLUDES . '/config.php';
require_once VMS_INCLUDES . '/functions.php';
require_once VMS_INCLUDES . '/auth.php';

startSecureSession();
requireKohaLogin();

// ============================================================
// RESOLVE A WRITABLE BACKUP DIRECTORY
// ------------------------------------------------------------
// Preference order:
//   1. <visitor>/logs/backups     (canonical)
//   2. LOGS_PATH/backups          (config-defined)
//   3. sys_get_temp_dir()/vms_backups  (always writable)
// ============================================================
function vms_resolve_backup_dir(): array
{
    $candidates = [];
    if (defined('LOGS_PATH')) $candidates[] = rtrim(LOGS_PATH, '/') . '/backups';
    $candidates[] = __DIR__ . '/logs/backups';
    $candidates[] = sys_get_temp_dir() . '/vms_backups';

    foreach ($candidates as $dir) {
        if (!is_dir($dir)) {
            @mkdir($dir, 0775, true);
            @chmod($dir, 0775);
        }
        if (is_dir($dir) && is_writable($dir)) {
            return ['path' => $dir, 'writable' => true, 'fallback' => false];
        }
    }

    // Last resort: temp dir (always writable)
    $tmp = sys_get_temp_dir() . '/vms_backups';
    if (!is_dir($tmp)) {
        @mkdir($tmp, 0775, true);
    }
    return ['path' => $tmp, 'writable' => is_writable($tmp), 'fallback' => true];
}

$backupDirInfo = vms_resolve_backup_dir();
$backupDir     = $backupDirInfo['path'];

$db       = getDB();
$settings = getSettings();
$user     = getCurrentUser();

$message = '';
$error   = '';

// ============================================================
// DUMP HELPERS
// ============================================================
/**
 * Quote a PHP value for a SQL INSERT/REPLACE statement.
 */
function vms_sql_quote(PDO $db, $value): string
{
    if ($value === null) return 'NULL';
    if (is_int($value) || is_float($value)) return (string)$value;
    return $db->quote((string)$value);
}

/**
 * Return ['type' => 'table'|'view', 'ddl' => '...'] for one row of SHOW CREATE.
 *
 * MariaDB/MySQL return different keys depending on object type:
 *   - Table → 'Create Table'
 *   - View  → 'Create View'
 *   - Some forks → 'Create View' with different casing
 *
 * The safest approach is to grab the 2nd value of the row (index 1),
 * which is the DDL by contract.
 */
function vms_show_create(PDO $db, string $name): array
{
    $stmt = $db->query("SHOW CREATE TABLE `" . str_replace('`','``',$name) . "`");
    $row  = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$row) return ['type' => 'table', 'ddl' => ''];

    $values = array_values($row);           // [name, DDL]
    $ddl    = $values[1] ?? '';

    // Detect view by inspecting the DDL prefix
    $type = (stripos($ddl, 'CREATE VIEW') !== false) ? 'view' : 'table';

    return ['type' => $type, 'ddl' => $ddl];
}

/**
 * Dump structure + data for one object.
 */
function vms_dump_object(PDO $db, string $name, string $type, string $ddl): string
{
    $safe = str_replace('`', '``', $name);

    if ($type === 'view') {
        return "-- ---------- View structure for `{$name}` ----------\n"
             . "DROP VIEW IF EXISTS `{$safe}`;\n"
             . $ddl . ";\n\n";
    }

    // Table
    $out  = "-- ---------- Table structure for `{$name}` ----------\n";
    $out .= "DROP TABLE IF EXISTS `{$safe}`;\n";
    $out .= $ddl . ";\n\n";

    // Data (chunked — safe for large tables)
    $rows = $db->query("SELECT * FROM `{$safe}`");
    if ($rows) {
        $buffer = [];
        $counter = 0;
        while ($row = $rows->fetch(PDO::FETCH_ASSOC)) {
            $vals = array_map(fn($v) => vms_sql_quote($db, $v), array_values($row));
            $buffer[] = '(' . implode(',', $vals) . ')';
            $counter++;

            // Emit INSERT in chunks of 500 rows to keep each statement small
            if (count($buffer) >= 500) {
                $out .= "INSERT INTO `{$safe}` VALUES\n" . implode(",\n", $buffer) . ";\n";
                $buffer = [];
            }
        }
        if (!empty($buffer)) {
            $out .= "INSERT INTO `{$safe}` VALUES\n" . implode(",\n", $buffer) . ";\n";
        }
        if ($counter > 0) {
            $out .= "\n";
        }
    }

    return $out;
}

// ============================================================
// CREATE BACKUP
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_backup'])) {
    try {
        if (!$backupDirInfo['writable']) {
            throw new Exception(
                'Backup directory is not writable: ' . $backupDir .
                '. Please run: sudo chown -R www-data:www-data ' . $backupDir .
                ' && sudo chmod 775 ' . $backupDir
            );
        }

        $timestamp = date('Y-m-d_H-i-s');
        $filename  = "visitor_backup_{$timestamp}.sql";
        $filepath  = rtrim($backupDir, '/') . '/' . $filename;

        // ---------- Enumerate all objects ----------
        $objects = $db->query("SHOW FULL TABLES")->fetchAll(PDO::FETCH_NUM);
        // SHOW FULL TABLES → row = [name, type]   type = 'BASE TABLE' | 'VIEW'
        $tables = [];
        $views  = [];
        foreach ($objects as $o) {
            if (($o[1] ?? '') === 'VIEW') $views[]  = $o[0];
            else                         $tables[] = $o[0];
        }

        // ---------- Header ----------
        $sql  = "-- ============================================================\n";
        $sql .= "-- VMS Database Backup\n";
        $sql .= "-- Generated: " . date('Y-m-d H:i:s') . "\n";
        $sql .= "-- Database:  " . (defined('DB_NAME') ? DB_NAME : 'unknown') . "\n";
        $sql .= "-- Tables:    " . count($tables) . "\n";
        $sql .= "-- Views:     " . count($views)  . "\n";
        $sql .= "-- ============================================================\n\n";
        $sql .= "SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';\n";
        $sql .= "SET time_zone = '+00:00';\n";
        $sql .= "SET NAMES utf8mb4;\n";
        $sql .= "SET FOREIGN_KEY_CHECKS = 0;\n\n";

        // ---------- Tables (structure + data) ----------
        foreach ($tables as $table) {
            $meta = vms_show_create($db, $table);
            $sql .= vms_dump_object($db, $table, $meta['type'], $meta['ddl']);
        }

        // ---------- Views (structure only) ----------
        if (!empty($views)) {
            $sql .= "-- ============================================================\n";
            $sql .= "-- Views\n";
            $sql .= "-- ============================================================\n\n";
            foreach ($views as $view) {
                $meta = vms_show_create($db, $view);
                $sql .= vms_dump_object($db, $view, $meta['type'], $meta['ddl']);
            }
        }

        $sql .= "SET FOREIGN_KEY_CHECKS = 1;\n";
        $sql .= "-- Backup completed at " . date('Y-m-d H:i:s') . "\n";

        // ---------- Write file ----------
        $written = @file_put_contents($filepath, $sql);
        if ($written === false) {
            throw new Exception(
                'Failed to write backup file: ' . $filepath .
                ' (directory: ' . $backupDir . ', writable: ' .
                (is_writable($backupDir) ? 'yes' : 'no') . ')'
            );
        }
        @chmod($filepath, 0640);

        $size = filesize($filepath) ?: 0;
        logActivity($user['id'] ?? 0, 'BACKUP_CREATE', "Backup created: $filename ($size bytes)");

        // ---------- Stream to browser ----------
        while (ob_get_level() > 0) { ob_end_clean(); }
        header('Content-Type: application/sql; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Content-Length: ' . $size);
        header('Cache-Control: private, max-age=0, must-revalidate');
        header('Pragma: public');
        readfile($filepath);
        exit;

    } catch (Throwable $e) {
        $error = $e->getMessage();
    }
}

// ============================================================
// DELETE BACKUP
// ============================================================
if (isset($_GET['delete'])) {
    $file = basename($_GET['delete']);
    $path = rtrim($backupDir, '/') . '/' . $file;
    if (file_exists($path)
        && strpos($file, 'visitor_backup_') === 0
        && substr($file, -4) === '.sql'
    ) {
        @unlink($path);
        $message = 'Backup deleted.';
    } else {
        $error = 'Invalid file.';
    }
}

// ============================================================
// LIST BACKUPS
// ============================================================
$backups = [];
$files = glob(rtrim($backupDir, '/') . '/visitor_backup_*.sql') ?: [];
foreach ($files as $f) {
    $backups[] = [
        'name' => basename($f),
        'size' => filesize($f),
        'date' => filemtime($f),
    ];
}
usort($backups, fn($a, $b) => $b['date'] - $a['date']);

// DB size
$dbSize = 0;
try {
    $stmt = $db->prepare("
        SELECT SUM(data_length + index_length)
          FROM information_schema.TABLES
         WHERE table_schema = ?
    ");
    $stmt->execute([DB_NAME]);
    $dbSize = (int)($stmt->fetchColumn() ?: 0);
} catch (PDOException $e) { /* ignore */ }

$pageTitle = 'Backup & Restore';
include __DIR__ . '/header.php';
?>

<style>
.backup-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 14px 18px;
    background: #f8f9fa;
    border-radius: 10px;
    margin-bottom: 8px;
    transition: all .3s;
    border-left: 4px solid #1e3c72;
}
.backup-item:hover { background: #e9ecef; transform: translateX(3px); }
.backup-name { font-family: monospace; font-weight: 600; color: #1e3c72; }
.backup-meta { font-size: .75rem; color: #6c757d; margin-top: 2px; }
.big-icon { font-size: 3.5rem; margin-bottom: 16px; }
</style>

<div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
    <h4 class="mb-0"><i class="fas fa-database me-2 text-primary"></i>Backup &amp; Restore</h4>
    <span class="badge bg-primary rounded-pill px-3 py-2">
        DB Size: <?= number_format($dbSize / 1024 / 1024, 2) ?> MB
    </span>
</div>

<?php if ($backupDirInfo['fallback']): ?>
    <div class="alert alert-warning">
        <i class="fas fa-exclamation-triangle me-2"></i>
        Primary backup directory is not writable. Backups will be stored in
        <code><?= htmlspecialchars($backupDir) ?></code> (temporary).
        To fix permanently run:
        <code>chown -R www-data:www-data <?= htmlspecialchars(__DIR__ . '/logs/backups') ?></code>
    </div>
<?php endif; ?>

<?php if ($message): ?>
    <div class="alert alert-success alert-dismissible fade show">
        <?= htmlspecialchars($message) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>
<?php if ($error): ?>
    <div class="alert alert-danger alert-dismissible fade show">
        <i class="fas fa-exclamation-circle me-2"></i><?= htmlspecialchars($error) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<div class="row g-4">
    <div class="col-lg-4">
        <div class="card shadow-sm text-center">
            <div class="card-body py-5">
                <i class="fas fa-download big-icon text-primary"></i>
                <h5>Create New Backup</h5>
                <p class="text-muted small">
                    Download a complete SQL dump of your database
                    (tables + data + views).
                </p>
                <form method="POST">
                    <button type="submit" name="create_backup" class="btn btn-primary btn-lg w-100"
                            <?= $backupDirInfo['writable'] ? '' : 'disabled' ?>>
                        <i class="fas fa-download me-2"></i>Create &amp; Download
                    </button>
                </form>
                <div class="small text-muted mt-2">
                    Saved to: <code><?= htmlspecialchars($backupDir) ?></code>
                </div>
            </div>
        </div>

        <div class="card shadow-sm mt-3">
            <div class="card-header bg-white"><h6 class="mb-0"><i class="fas fa-info-circle me-2"></i>About Backups</h6></div>
            <div class="card-body">
                <ul class="small text-muted mb-0" style="padding-left:20px;">
                    <li>Includes all tables, data, and views</li>
                    <li>Files are stored in <code>logs/backups/</code></li>
                    <li>Restore: <code>mysql -u user -p db &lt; backup.sql</code></li>
                    <li>Keep backups off-server for safety</li>
                </ul>
            </div>
        </div>
    </div>

    <div class="col-lg-8">
        <div class="card shadow-sm">
            <div class="card-header bg-white d-flex justify-content-between align-items-center">
                <h6 class="mb-0"><i class="fas fa-history me-2"></i>Backup History</h6>
                <span class="badge bg-secondary"><?= count($backups) ?> backups</span>
            </div>
            <div class="card-body">
                <?php if (empty($backups)): ?>
                    <div class="text-center text-muted py-5">
                        <i class="fas fa-archive fa-3x mb-3 d-block" style="opacity:.2;"></i>
                        <p>No backups yet. Create your first backup!</p>
                    </div>
                <?php else: foreach ($backups as $b): ?>
                    <div class="backup-item">
                        <div style="flex:1;min-width:0;">
                            <div class="backup-name text-truncate">
                                <i class="fas fa-file-code me-1"></i><?= htmlspecialchars($b['name']) ?>
                            </div>
                            <div class="backup-meta">
                                <i class="fas fa-clock me-1"></i><?= date('d M Y, H:i:s', $b['date']) ?>
                                · <i class="fas fa-hdd me-1"></i><?= number_format($b['size'] / 1024, 1) ?> KB
                            </div>
                        </div>
                        <div class="d-flex gap-2">
                            <a href="backup_download.php?file=<?= urlencode($b['name']) ?>"
                               class="btn btn-sm btn-outline-primary">
                                <i class="fas fa-download"></i>
                            </a>
                            <a href="?delete=<?= urlencode($b['name']) ?>"
                               class="btn btn-sm btn-outline-danger"
                               onclick="return confirm('Delete this backup?');">
                                <i class="fas fa-trash"></i>
                            </a>
                        </div>
                    </div>
                <?php endforeach; endif; ?>
            </div>
        </div>
    </div>
</div>

<?php include __DIR__ . '/footer.php'; ?>
