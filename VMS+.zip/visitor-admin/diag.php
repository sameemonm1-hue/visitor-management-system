<?php
/**
 * Visitor Management System — diag.php
 * Version: 1.0
 *
 * Read-only diagnostic tool for the VMS family.
 * Checks everything end-to-end and prints a single-page report.
 *
 * • Safe to run on production — all writes are rolled back.
 * • No dependencies on VMS config beyond locating includes/config.php.
 * • Auto-detects VMS + Koha DB from config.
 * • Prints color-coded pass / warn / fail rows.
 *
 * Access: http://localhost:8081/cgi-bin/koha/visitor/diag.php
 */

error_reporting(E_ALL);
@ini_set('display_errors', '1');
@ini_set('log_errors', '1');

$startTime = microtime(true);

// ============================================================
// 1. LOCATE includes/config.php
// ============================================================
$possiblePaths = [
    __DIR__ . '/includes',
    dirname(__DIR__) . '/includes',
    '/usr/share/koha/intranet/cgi-bin/koha/visitor/includes',
    '/usr/share/koha/intranet/cgi-bin/visitor/includes',
];
$includePath = null;
foreach ($possiblePaths as $p) {
    if (file_exists($p . '/config.php')) { $includePath = $p; break; }
}
if (!$includePath) {
    die('<pre style="padding:20px;color:#c00;font-family:monospace;">'
      . "Could not find includes/config.php in any of:\n"
      . implode("\n", $possiblePaths) . "\n\n"
      . "Fix: place diag.php next to your other VMS pages.\n"
      . '</pre>');
}
define('VMS_INCLUDES', $includePath);

// ============================================================
// 2. REPORT COLLECTOR
// ============================================================
$R = [];  // report rows
function add(string $section, string $label, string $status, string $detail = ''): void {
    global $R;
    $R[] = compact('section', 'label', 'status', 'detail');
}
function pass(string $s, string $l, string $d = '') { add($s, $l, 'pass', $d); }
function warn(string $s, string $l, string $d = '') { add($s, $l, 'warn', $d); }
function fail(string $s, string $l, string $d = '') { add($s, $l, 'fail', $d); }
function info(string $s, string $l, string $d = '') { add($s, $l, 'info', $d); }

// ============================================================
// 3. PHP ENVIRONMENT
// ============================================================
$s = 'PHP Environment';
info($s, 'PHP version', PHP_VERSION);
info($s, 'SAPI', php_sapi_name());
info($s, 'OS', PHP_OS);
info($s, 'memory_limit', (string)ini_get('memory_limit'));
info($s, 'max_execution_time', (string)ini_get('max_execution_time') . 's');

$requiredExt = ['pdo_mysql','gd','json','mbstring','curl','intl','zip','openssl'];
foreach ($requiredExt as $ext) {
    if (extension_loaded($ext)) {
        pass($s, "Extension: $ext", 'loaded');
    } else {
        fail($s, "Extension: $ext", 'MISSING — install php-' . str_replace('_', '-', $ext));
    }
}
$optionalExt = ['apcu','redis','imagick','bcmath'];
foreach ($optionalExt as $ext) {
    if (extension_loaded($ext)) pass($s, "Optional: $ext", 'loaded');
    else warn($s, "Optional: $ext", 'not loaded (fine)');
}

// Session + error handling
if (session_status() === PHP_SESSION_ACTIVE) pass($s, 'Session', 'active');
else warn($s, 'Session', 'not started (may start on request)');
if (ini_get('display_errors')) warn($s, 'display_errors', 'ON — disable in production');
else pass($s, 'display_errors', 'off');
if (ini_get('log_errors')) pass($s, 'log_errors', 'on — path: ' . (ini_get('error_log') ?: 'default'));
else warn($s, 'log_errors', 'off');

// ============================================================
// 4. LOAD VMS CONFIG (safe)
// ============================================================
$s = 'VMS Config';
$configPath = VMS_INCLUDES . '/config.php';
info($s, 'config.php path', $configPath);
if (is_readable($configPath)) pass($s, 'config.php readable', 'yes');
else fail($s, 'config.php readable', 'NO — check permissions');
if (is_writable($configPath)) warn($s, 'config.php writable', 'should NOT be writable for security');
else pass($s, 'config.php writable', 'no (good)');

require_once $configPath;

$configConstants = ['DB_HOST','DB_NAME','DB_USER','DB_CHARSET','KOHA_HOST','KOHA_DB','KOHA_USER','KOHA_INTRANET_URL','KOHA_OPAC_URL','APP_VERSION'];
foreach ($configConstants as $c) {
    if (defined($c)) {
        $val = constant($c);
        if (in_array($c, ['DB_USER','KOHA_USER'])) $val = $val;
        elseif (strpos($c, 'PASS') !== false) $val = '***';
        info($s, "Constant: $c", (string)$val);
    } else {
        warn($s, "Constant: $c", 'not defined');
    }
}

// Localhost check
if (defined('KOHA_INTRANET_URL') && strpos(KOHA_INTRANET_URL, '127.0.1.1') !== false) {
    fail($s, 'KOHA_INTRANET_URL', 'uses 127.0.1.1 — change to localhost');
} elseif (defined('KOHA_INTRANET_URL')) {
    pass($s, 'KOHA_INTRANET_URL', 'OK');
}

// ============================================================
// 5. LOAD HELPERS (safe — optional files)
// ============================================================
$s = 'VMS Includes';
foreach (['functions.php','koha.php','auth.php','db.php','alerts.php','footer_partial.php'] as $f) {
    $path = VMS_INCLUDES . '/' . $f;
    if (file_exists($path)) {
        if (@require_once $path) pass($s, $f, 'loaded');
        else fail($s, $f, 'error while loading');
    } else {
        warn($s, $f, 'not found (may be optional)');
    }
}

// ============================================================
// 6. VMS DATABASE CONNECTION
// ============================================================
$s = 'VMS Database';
$vmsDb = null;
try {
    if (function_exists('getDB')) {
        $vmsDb = getDB();
        pass($s, 'Connection', 'via getDB()');
    } elseif (defined('DB_HOST') && defined('DB_NAME')) {
        $vmsDb = new PDO(
            'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . (defined('DB_CHARSET') ? DB_CHARSET : 'utf8mb4'),
            DB_USER,
            defined('DB_PASS') ? DB_PASS : '',
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]
        );
        pass($s, 'Connection', 'direct PDO');
    } else {
        fail($s, 'Connection', 'no config constants');
    }

    if ($vmsDb) {
        $ver = $vmsDb->query("SELECT VERSION()")->fetchColumn();
        info($s, 'MySQL version', (string)$ver);
        $dbName = $vmsDb->query("SELECT DATABASE()")->fetchColumn();
        info($s, 'Current DB', (string)$dbName);
        info($s, 'Charset', (string)$vmsDb->query("SELECT @@character_set_database")->fetchColumn());
        info($s, 'Collation', (string)$vmsDb->query("SELECT @@collation_database")->fetchColumn());
        info($s, 'Timezone', (string)$vmsDb->query("SELECT @@session.time_zone")->fetchColumn());
        info($s, 'sql_mode', (string)$vmsDb->query("SELECT @@session.sql_mode")->fetchColumn());
    }
} catch (Throwable $e) {
    fail($s, 'Connection', $e->getMessage());
}

// ============================================================
// 7. KOHA DATABASE CONNECTION
// ============================================================
$s = 'Koha Database';
$kohaDb = null;
try {
    if (function_exists('getKoha')) {
        $kohaDb = getKoha();
        if ($kohaDb) pass($s, 'Connection', 'via getKoha()');
        else warn($s, 'Connection', 'getKoha() returned null');
    } elseif (defined('KOHA_HOST') && defined('KOHA_DB')) {
        $kohaDb = new PDO(
            'mysql:host=' . KOHA_HOST . ';dbname=' . KOHA_DB . ';charset=utf8mb4',
            KOHA_USER,
            defined('KOHA_PASS') ? KOHA_PASS : '',
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]
        );
        pass($s, 'Connection', 'direct PDO');
    } else {
        warn($s, 'Connection', 'no KOHA_* constants — some pages will fail');
    }
    if ($kohaDb) {
        $ver = $kohaDb->query("SELECT VERSION()")->fetchColumn();
        info($s, 'MySQL version', (string)$ver);
    }
} catch (Throwable $e) {
    fail($s, 'Connection', $e->getMessage());
}

// ============================================================
// 8. SCHEMA INTEGRITY (VMS)
// ============================================================
if ($vmsDb) {
    $s = 'VMS Schema';

    // Count tables
    try {
        $tableCount = (int)$vmsDb->query("
            SELECT COUNT(*) FROM information_schema.TABLES
            WHERE table_schema = DATABASE() AND table_type='BASE TABLE'
        ")->fetchColumn();
        if ($tableCount >= 41) pass($s, 'Total tables', "$tableCount (expected ≥ 41)");
        elseif ($tableCount >= 30) warn($s, 'Total tables', "$tableCount (some optional missing)");
        else fail($s, 'Total tables', "$tableCount — schema incomplete");
    } catch (Throwable $e) {}

    // Critical tables
    $criticalTables = [
        'settings','entry_exit_logs','book_exit_logs','book_alerts',
        'activity_log','purpose_stats','notifications_queue',
        'occupancy_snapshots','appointments','feedback',
        'computers','computer_sessions','computer_policies',
        'computer_attendance','system_users','system_user_logins',
        'schema_migrations','visitor_goals','badge_queue','audit_trail',
        'lost_found','recommendations','quotes','notices','ebooks',
        'book_metadata_cache','institutions','members','users',
        'session_logs','notification_logs','module_permissions',
        'user_preferences','quick_actions','login_cards',
        'staff_profiles','api_keys','classification_data',
        'members_extra','vms_stock_verification_sessions',
        'vms_stock_verification_scans',
    ];
    $missing = [];
    foreach ($criticalTables as $t) {
        try {
            $exists = $vmsDb->query("SHOW TABLES LIKE " . $vmsDb->quote($t))->rowCount() > 0;
            if (!$exists) $missing[] = $t;
        } catch (Throwable $e) { $missing[] = $t; }
    }
    if (empty($missing)) pass($s, 'All critical tables', count($criticalTables) . ' present');
    else fail($s, 'Missing tables', implode(', ', $missing));

    // Views
    try {
        $views = $vmsDb->query("
            SELECT TABLE_NAME FROM information_schema.VIEWS
            WHERE TABLE_SCHEMA = DATABASE()
        ")->fetchAll(PDO::FETCH_COLUMN);
        if (in_array('entry_exit', $views)) pass($s, 'View: entry_exit', 'present');
        else warn($s, 'View: entry_exit', 'missing — kiosk compatibility may break');
        info($s, 'Total views', (string)count($views));
    } catch (Throwable $e) {}

    // Triggers
    try {
        $triggers = $vmsDb->query("
            SELECT TRIGGER_NAME FROM information_schema.TRIGGERS
            WHERE TRIGGER_SCHEMA = DATABASE()
        ")->fetchAll(PDO::FETCH_COLUMN);
        $allowed = ['trg_purpose_stats','trg_stock_scan_update'];
        $bad = array_diff($triggers, $allowed);
        if (empty($triggers)) warn($s, 'Triggers', 'none — purpose_stats aggregation will not run');
        elseif (empty($bad)) pass($s, 'Triggers', implode(', ', $triggers));
        else fail($s, 'Triggers', 'unexpected: ' . implode(', ', $bad));
    } catch (Throwable $e) {}

    // book_exit_logs columns
    try {
        $cols = $vmsDb->query("SHOW COLUMNS FROM book_exit_logs")->fetchAll(PDO::FETCH_COLUMN);
        $want = ['book_barcode','book_title','book_author','book_isbn','is_authorized','photo_path','gate_number','staff_id','alert_sent','alert_sent_at','acknowledged','notes','exit_time','created_at'];
        $missing = array_diff($want, $cols);
        if (empty($missing)) pass($s, 'book_exit_logs columns', 'complete');
        else fail($s, 'book_exit_logs columns', 'missing: ' . implode(', ', $missing));
    } catch (Throwable $e) {}

    // Stock verification columns
    try {
        $cols = $vmsDb->query("SHOW COLUMNS FROM vms_stock_verification_scans")->fetchAll(PDO::FETCH_COLUMN);
        $want = ['id','session_id','itemnumber','barcode','status','scanned_at','scan_duration_ms'];
        $missing = array_diff($want, $cols);
        if (empty($missing)) pass($s, 'stock_verification_scans columns', 'complete');
        else fail($s, 'stock_verification_scans columns', 'missing: ' . implode(', ', $missing));
    } catch (Throwable $e) {}
}

// ============================================================
// 9. SETTINGS + SEEDS
// ============================================================
if ($vmsDb) {
    $s = 'Settings & Seeds';

    try {
        $row = $vmsDb->query("SELECT * FROM settings WHERE id = 1 LIMIT 1")->fetch();
        if ($row) {
            pass($s, 'settings row id=1', 'present');
            info($s, 'institution_name', (string)($row['institution_name'] ?? ''));
            info($s, 'alert_sound_enabled', (string)($row['alert_sound_enabled'] ?? ''));
            info($s, 'book_unauthorized_alert', (string)($row['book_unauthorized_alert'] ?? ''));
        } else {
            fail($s, 'settings row id=1', 'MISSING — run schema.sql');
        }
    } catch (Throwable $e) {
        fail($s, 'settings', $e->getMessage());
    }

    foreach ([
        'computer_policies'     => ['min' => 4,  'label' => 'Computer policies'],
        'quotes'                => ['min' => 8,  'label' => 'Quotes'],
        'quick_actions'         => ['min' => 10, 'label' => 'Quick actions'],
        'login_cards'           => ['min' => 4,  'label' => 'Login cards'],
        'staff_profiles'        => ['min' => 2,  'label' => 'Staff profiles'],
        'classification_data'   => ['min' => 30, 'label' => 'Classification entries'],
        'system_users'          => ['min' => 1,  'label' => 'System users'],
        'api_keys'              => ['min' => 1,  'label' => 'API keys'],
    ] as $table => $meta) {
        try {
            $count = (int)$vmsDb->query("SELECT COUNT(*) FROM `$table`")->fetchColumn();
            if ($count >= $meta['min']) pass($s, $meta['label'], "$count rows");
            else warn($s, $meta['label'], "only $count row(s) — expected ≥ {$meta['min']}");
        } catch (Throwable $e) {}
    }

    // Migrations
    try {
        $versions = $vmsDb->query("SELECT version FROM schema_migrations ORDER BY id")->fetchAll(PDO::FETCH_COLUMN);
        if (empty($versions)) warn($s, 'Migrations', 'no rows in schema_migrations');
        else pass($s, 'Migrations', implode(' → ', $versions));
    } catch (Throwable $e) {}
}

// ============================================================
// 10. KOHA TABLES
// ============================================================
if ($kohaDb) {
    $s = 'Koha Tables';
    foreach (['borrowers','items','biblio','biblioitems','issues','categories','branches','sessions','patronimage'] as $t) {
        try {
            $exists = $kohaDb->query("SHOW TABLES LIKE " . $kohaDb->quote($t))->rowCount() > 0;
            if ($exists) pass($s, $t, 'present');
            else warn($s, $t, 'missing (may be optional)');
        } catch (Throwable $e) {
            fail($s, $t, $e->getMessage());
        }
    }
    // Count borrowers
    try {
        $b = (int)$kohaDb->query("SELECT COUNT(*) FROM borrowers")->fetchColumn();
        info($s, 'borrowers', number_format($b) . ' rows');
    } catch (Throwable $e) {}
}

// ============================================================
// 11. FILESYSTEM
// ============================================================
$s = 'Filesystem';
$baseDir = __DIR__;
$runtimeDirs = ['uploads', 'uploads/logos', 'uploads/book_exit_photos', 'logs', 'cache'];
foreach ($runtimeDirs as $d) {
    $path = $baseDir . '/' . $d;
    if (is_dir($path)) {
        if (is_writable($path)) pass($s, "Dir: $d", 'writable');
        else fail($s, "Dir: $d", 'NOT writable — chmod 777');
    } else {
        warn($s, "Dir: $d", 'missing');
    }
}

// File counts
foreach (['uploads','logs','cache'] as $d) {
    if (is_dir($baseDir . '/' . $d)) {
        $count = iterator_count(new FilesystemIterator($baseDir . '/' . $d, FilesystemIterator::SKIP_DOTS));
        info($s, "$d files", (string)$count);
    }
}

// Helper scripts
$scripts = [
    'schema.sql','fix_trigger.php','test.php',
    'header.php','footer.php','footer_partial.php',
    'dashboard.php','entries.php','exits.php','logs.php',
    'members.php','books.php','alerts.php','reports.php',
    'settings.php','backup.php','profile.php','feedback.php',
    'occupancy.php','appointments.php','evacuation.php','guests.php',
    'class.php','isbn.php','labels.php','idcards.php','system.php','stock_verify.php',
];
$present = 0; $missingScripts = [];
foreach ($scripts as $scr) {
    if (file_exists($baseDir . '/' . $scr) || file_exists(VMS_INCLUDES . '/' . $scr)) $present++;
    else $missingScripts[] = $scr;
}
info($s, 'Known pages present', "$present / " . count($scripts));
if (!empty($missingScripts)) {
    info($s, 'Missing (optional)', implode(', ', $missingScripts));
}

// ============================================================
// 12. LIVE ROUND-TRIP TEST (rolled back)
// ============================================================
if ($vmsDb) {
    $s = 'Live Test';
    try {
        $vmsDb->beginTransaction();

        $vmsDb->exec("
            INSERT INTO entry_exit_logs
                (admno, member_name, member_category, entry_date, entry_time,
                 purpose, status, entry_type)
            VALUES ('__DIAG__', 'Diag Test', 'Test', CURDATE(), CURTIME(),
                    'Testing', 'inside', 'member')
        ");
        $logId = $vmsDb->lastInsertId();

        $vmsDb->exec("
            INSERT INTO book_exit_logs
                (book_barcode, book_title, is_authorized)
            VALUES ('__DIAG__', 'Diag Test Book', 0)
        ");
        $bookId = $vmsDb->lastInsertId();

        $vmsDb->rollBack();

        pass($s, 'entry_exit_logs INSERT', "would be id $logId");
        pass($s, 'book_exit_logs INSERT (trigger-safe)', "would be id $bookId");
    } catch (Throwable $e) {
        try { $vmsDb->rollBack(); } catch (Throwable $x) {}
        $is1442 = strpos($e->getMessage(), '1442') !== false;
        fail($s, 'INSERT test', $e->getMessage() . ($is1442 ? ' — run fix_trigger.php' : ''));
    }
}

// ============================================================
// 13. ERROR LOG
// ============================================================
$s = 'Error Log';
$logPath = ini_get('error_log') ?: ($baseDir . '/logs/error.log');
if (is_readable($logPath) && is_file($logPath)) {
    $tail = @file($logPath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    if ($tail) {
        $last5 = array_slice($tail, -5);
        foreach ($last5 as $line) {
            info($s, 'Recent', substr($line, 0, 200));
        }
    } else {
        info($s, 'Tail', 'log is empty');
    }
    $sizeKb = round(filesize($logPath) / 1024, 1);
    info($s, 'Log size', "$sizeKb KB");
} else {
    warn($s, 'Error log', 'not readable at ' . $logPath);
}

// ============================================================
// 14. HTTP + SESSION
// ============================================================
$s = 'HTTP / Session';
info($s, 'Server time', date('Y-m-d H:i:s'));
info($s, 'Timezone', date_default_timezone_get());
info($s, 'PHP timezone', date_default_timezone_get());
if (!empty($_SERVER['HTTP_HOST'])) info($s, 'Request host', $_SERVER['HTTP_HOST']);
if (!empty($_SERVER['REQUEST_URI'])) info($s, 'Request URI', $_SERVER['REQUEST_URI']);
if (!empty($_SERVER['REMOTE_ADDR'])) info($s, 'Client IP', $_SERVER['REMOTE_ADDR']);
if (!empty($_COOKIE['CGISESSID'])) pass($s, 'Koha session cookie', 'present');
else warn($s, 'Koha session cookie', 'missing — you may not be logged in');

// ============================================================
// 15. PERMISSION CHECK (current CLI user)
// ============================================================
$s = 'Runtime user';
$who = function_exists('posix_getpwuid') ? posix_getpwuid(posix_geteuid()) : null;
if ($who) info($s, 'Current user', $who['name'] . ' (uid ' . $who['uid'] . ')');
info($s, 'Script path', __FILE__);
info($s, 'Script dir', __DIR__);

// ============================================================
// 16. SUMMARY
// ============================================================
$totalPass = count(array_filter($R, fn($r) => $r['status'] === 'pass'));
$totalWarn = count(array_filter($R, fn($r) => $r['status'] === 'warn'));
$totalFail = count(array_filter($R, fn($r) => $r['status'] === 'fail'));
$totalInfo = count(array_filter($R, fn($r) => $r['status'] === 'info'));
$duration  = round((microtime(true) - $startTime) * 1000, 1);

// Overall verdict
if ($totalFail > 0) $verdict = 'danger';
elseif ($totalWarn > 0) $verdict = 'warning';
else $verdict = 'success';

$verdictText = [
    'success' => '✅ All checks passed',
    'warning' => '⚠️  Passed with warnings',
    'danger'  => '❌ Some critical checks failed',
][$verdict];

// ============================================================
// 17. RENDER
// ============================================================
$sections = [];
foreach ($R as $r) { $sections[$r['section']][] = $r; }
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>VMS Diagnostics</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
:root {
    --diag-primary: #1e3c72;
    --diag-bg: #f0f2f5;
}
* { box-sizing: border-box; }
body {
    font-family: 'Inter', -apple-system, sans-serif;
    background: var(--diag-bg);
    padding: 24px;
    color: #1e293b;
    margin: 0;
}
.diag-wrap { max-width: 1200px; margin: 0 auto; }

.diag-header {
    background: linear-gradient(135deg, #1e3c72, #2a5298);
    color: #fff;
    border-radius: 18px;
    padding: 24px 30px;
    margin-bottom: 22px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 14px;
    box-shadow: 0 12px 40px rgba(30,60,114,.18);
}
.diag-header h1 { margin: 0; font-size: 1.5rem; font-weight: 800; }
.diag-header p { margin: 4px 0 0; opacity: .85; font-size: .85rem; }

.summary {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
    gap: 12px;
    margin-bottom: 20px;
}
.summary .box {
    background: #fff;
    border-radius: 14px;
    padding: 16px 20px;
    border-left: 4px solid #94a3b8;
    box-shadow: 0 2px 10px rgba(0,0,0,.04);
}
.summary .box.pass    { border-left-color: #10b981; }
.summary .box.warn    { border-left-color: #f59e0b; }
.summary .box.fail    { border-left-color: #ef4444; }
.summary .box.info    { border-left-color: #0ea5e9; }
.summary .box .num    { font-size: 1.8rem; font-weight: 800; line-height: 1.1; }
.summary .box.pass .num { color: #10b981; }
.summary .box.warn .num { color: #f59e0b; }
.summary .box.fail .num { color: #ef4444; }
.summary .box.info .num { color: #0ea5e9; }
.summary .box .lbl    { font-size: .7rem; color: #6c757d; text-transform: uppercase; letter-spacing: .5px; margin-top: 4px; }

.verdict {
    background: #fff;
    border-radius: 14px;
    padding: 20px 24px;
    text-align: center;
    margin-bottom: 20px;
    font-size: 1.1rem;
    font-weight: 700;
    box-shadow: 0 2px 10px rgba(0,0,0,.04);
}
.verdict.success { background: #d4edda; color: #14532d; border-left: 6px solid #10b981; }
.verdict.warning { background: #fff3cd; color: #713f12; border-left: 6px solid #f59e0b; }
.verdict.danger  { background: #f8d7da; color: #7f1d1d; border-left: 6px solid #ef4444; }

.section {
    background: #fff;
    border-radius: 14px;
    margin-bottom: 16px;
    box-shadow: 0 2px 10px rgba(0,0,0,.04);
    overflow: hidden;
}
.section-head {
    padding: 14px 22px;
    background: #f8fafc;
    border-bottom: 1px solid #e9edf2;
    font-weight: 700;
    color: var(--diag-primary);
    display: flex;
    justify-content: space-between;
    align-items: center;
    cursor: pointer;
    user-select: none;
}
.section-head .badges { display: flex; gap: 6px; }
.section-head .badge-pill {
    font-size: .65rem;
    padding: 3px 10px;
    border-radius: 20px;
    font-weight: 700;
}
.badge-pill.pass { background: #d4edda; color: #14532d; }
.badge-pill.warn { background: #fff3cd; color: #713f12; }
.badge-pill.fail { background: #f8d7da; color: #7f1d1d; }
.badge-pill.info { background: #dbeafe; color: #1e3a8a; }

.section-body { display: block; }
.section-body.collapsed { display: none; }

.row-item {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    gap: 12px;
    padding: 10px 22px;
    border-bottom: 1px solid #f1f5f9;
    font-size: .85rem;
}
.row-item:last-child { border-bottom: none; }
.row-item .label { flex: 1; color: #334155; }
.row-item .detail {
    flex: 2;
    color: #64748b;
    font-family: 'SF Mono', 'Consolas', monospace;
    font-size: .78rem;
    word-break: break-word;
    text-align: right;
}
.row-item .icon { width: 22px; text-align: center; font-size: .9rem; flex-shrink: 0; }
.row-item.pass .icon { color: #10b981; }
.row-item.warn .icon { color: #f59e0b; }
.row-item.fail .icon { color: #ef4444; }
.row-item.info .icon { color: #0ea5e9; }
.row-item.fail { background: #fff5f5; }
.row-item.warn { background: #fffbeb; }

.actions {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    margin-top: 20px;
    justify-content: center;
}
.actions .btn {
    padding: 10px 22px;
    border-radius: 12px;
    font-weight: 600;
}
</style>
</head>
<body>
<div class="diag-wrap">

    <div class="diag-header">
        <div>
            <h1><i class="fas fa-stethoscope me-2"></i>VMS Diagnostics</h1>
            <p>Full end-to-end health check — database, schema, seeds, filesystem, runtime</p>
        </div>
        <div style="text-align:right;font-size:.8rem;opacity:.9;">
            <div><i class="fas fa-clock me-1"></i><?= date('Y-m-d H:i:s') ?></div>
            <div><i class="fas fa-tachometer-alt me-1"></i><?= $duration ?> ms</div>
            <div><i class="fas fa-user me-1"></i><?= htmlspecialchars($who['name'] ?? 'unknown') ?></div>
        </div>
    </div>

    <div class="summary">
        <div class="box pass"><div class="num"><?= $totalPass ?></div><div class="lbl">Passed</div></div>
        <div class="box warn"><div class="num"><?= $totalWarn ?></div><div class="lbl">Warnings</div></div>
        <div class="box fail"><div class="num"><?= $totalFail ?></div><div class="lbl">Failed</div></div>
        <div class="box info"><div class="num"><?= $totalInfo ?></div><div class="lbl">Info</div></div>
    </div>

    <div class="verdict <?= $verdict ?>">
        <?= $verdictText ?>
    </div>

    <?php foreach ($sections as $sectionName => $rows):
        $sc = ['pass'=>0,'warn'=>0,'fail'=>0,'info'=>0];
        foreach ($rows as $r) $sc[$r['status']]++;
    ?>
        <div class="section">
            <div class="section-head" onclick="this.nextElementSibling.classList.toggle('collapsed')">
                <span><i class="fas fa-folder-open me-2"></i><?= htmlspecialchars($sectionName) ?></span>
                <span class="badges">
                    <?php if ($sc['pass']): ?><span class="badge-pill pass"><?= $sc['pass'] ?> pass</span><?php endif; ?>
                    <?php if ($sc['warn']): ?><span class="badge-pill warn"><?= $sc['warn'] ?> warn</span><?php endif; ?>
                    <?php if ($sc['fail']): ?><span class="badge-pill fail"><?= $sc['fail'] ?> fail</span><?php endif; ?>
                    <?php if ($sc['info']): ?><span class="badge-pill info"><?= $sc['info'] ?> info</span><?php endif; ?>
                </span>
            </div>
            <div class="section-body <?= $sc['fail'] > 0 ? '' : 'collapsed' ?>">
                <?php foreach ($rows as $r): ?>
                    <div class="row-item <?= $r['status'] ?>">
                        <span class="icon">
                            <?php if ($r['status'] === 'pass'): ?><i class="fas fa-check-circle"></i>
                            <?php elseif ($r['status'] === 'warn'): ?><i class="fas fa-exclamation-triangle"></i>
                            <?php elseif ($r['status'] === 'fail'): ?><i class="fas fa-times-circle"></i>
                            <?php else: ?><i class="fas fa-info-circle"></i><?php endif; ?>
                        </span>
                        <span class="label"><?= htmlspecialchars($r['label']) ?></span>
                        <span class="detail"><?= htmlspecialchars($r['detail']) ?></span>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    <?php endforeach; ?>

    <div class="actions">
        <a href="dashboard.php" class="btn btn-primary"><i class="fas fa-chart-pie me-2"></i>Dashboard</a>
        <a href="test.php" class="btn btn-outline-primary"><i class="fas fa-flask me-2"></i>System Test</a>
        <a href="fix_trigger.php" class="btn btn-outline-danger"><i class="fas fa-wrench me-2"></i>Fix Triggers</a>
        <a href="settings.php" class="btn btn-outline-secondary"><i class="fas fa-cog me-2"></i>Settings</a>
        <button onclick="location.reload()" class="btn btn-outline-success"><i class="fas fa-sync me-2"></i>Re-run Diagnostics</button>
    </div>

    <p style="text-align:center;color:#94a3b8;font-size:.75rem;margin-top:24px;">
        Diagnostics do not modify any data — all INSERTs are rolled back.
        </p>
</div>

<script>
// Persist collapsed state in sessionStorage
document.querySelectorAll('.section-head').forEach(head => {
    head.addEventListener('click', () => {
        const name = head.textContent.trim();
        try {
            const state = JSON.parse(sessionStorage.getItem('diag_sections') || '{}');
            const body = head.nextElementSibling;
            state[name] = body.classList.contains('collapsed') ? 'open' : 'closed';
            sessionStorage.setItem('diag_sections', JSON.stringify(state));
        } catch (e) {}
    });
});
</script>
</body>
</html>
