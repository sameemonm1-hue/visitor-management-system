<?php
/**
 * Occupancy Snapshot Cron
 * Run every minute via cron:
 * * * * * * php /path/to/cron_snapshots.php
 * 
 * This creates occupancy snapshots for analytics
 */

$possiblePaths = [__DIR__ . '/includes', '/usr/share/koha/intranet/cgi-bin/koha/visitor/includes'];
$includePath = null;
foreach ($possiblePaths as $p) { if (file_exists($p . '/config.php')) { $includePath = $p; break; } }
require_once $includePath . '/config.php';

$db = getDB();
if (!$db) exit(1);

$settings = getSettings();
$inside = (int)$db->query("SELECT COUNT(*) FROM entry_exit_logs WHERE status = 'inside'")->fetchColumn();
$guests = (int)$db->query("SELECT COUNT(*) FROM entry_exit_logs WHERE status = 'inside' AND entry_type = 'guest'")->fetchColumn();
$capacity = (int)($settings['max_capacity'] ?? 100);
$percent = $capacity > 0 ? round(($inside / $capacity) * 100, 2) : 0;

$snapTime = date('Y-m-d H:i:00');

try {
    $db->prepare("
        INSERT INTO occupancy_snapshots 
        (snapshot_time, inside_count, guest_count, total_count, capacity, occupancy_percent)
        VALUES (?, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE 
            inside_count = VALUES(inside_count),
            guest_count = VALUES(guest_count),
            total_count = VALUES(total_count),
            occupancy_percent = VALUES(occupancy_percent)
    ")->execute([$snapTime, $inside, $guests, $inside, $capacity, $percent]);
    
    echo "Snapshot recorded: $inside inside\n";
} catch (PDOException $e) {
    error_log("Snapshot error: " . $e->getMessage());
    exit(1);
}