<?php
/**
 * Visitor Management System - Book Management with Advanced Alerts
 * Version: 8.1 - Complete Monitoring & Alert System + EDIT unauthorized records
 *
 * Changelog v8.1:
 *  - Auto-records every unauthorized book exit into book_exit_logs (existing).
 *  - NEW: "Edit" button on every row → opens Edit Modal.
 *  - NEW: Edit modal lets staff correct barcode, title, author, member,
 *         authorization status, section/gate, notes and alert_sent flag.
 *  - NEW: AJAX action update_book_log (see ajax.php).
 *  - NEW: Inline row-data attributes so the modal opens instantly.
 *  - All existing features preserved (scan, photo, alerts, monitoring,
 *    live feed, CSV export, delete, clear, manual alert).
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

// Auto-detect paths
$possiblePaths = [
    __DIR__ . '/includes',
    dirname(__DIR__) . '/includes',
    '/usr/share/koha/intranet/cgi-bin/koha/visitor/includes',
    '/usr/share/koha/intranet/cgi-bin/visitor/includes',
];

$includePath = null;
foreach ($possiblePaths as $path) {
    if (file_exists($path . '/config.php')) {
        $includePath = $path;
        break;
    }
}

if (!$includePath) {
    $testPath = __DIR__;
    for ($i = 0; $i < 5; $i++) {
        $testPath = dirname($testPath);
        if (file_exists($testPath . '/includes/config.php')) {
            $includePath = $testPath . '/includes';
            break;
        }
    }
}

if (!$includePath) {
    die('Could not find includes directory.');
}

define('VMS_INCLUDES', $includePath);
require_once VMS_INCLUDES . '/config.php';
require_once VMS_INCLUDES . '/functions.php';
require_once VMS_INCLUDES . '/koha.php';
require_once VMS_INCLUDES . '/auth.php';
require_once VMS_INCLUDES . '/alerts.php';

startSecureSession();
requireKohaLogin();

$db = getDB();
$user = getCurrentUser();
$settings = getSettings();
$message = '';
$bookError = '';
$bookResult = null;
$alertMessage = '';
$cameraEnabled = $settings['book_camera_auto_capture'] ?? 1;

// Handle book scan
if (isset($_POST['scan_book'])) {
    $barcode = trim($_POST['barcode']);
    $book = getKohaBook($barcode);
    if (!$book) {
        $bookError = 'Book not found in Koha';
    } else {
        $bookResult = $book;
        
        // Check if book is unauthorized (not issued) - show immediate alert
        if (empty($book['borrowernumber'])) {
            $alertMessage = '⚠️ UNAUTHORIZED BOOK DETECTED: This book is not issued to anyone!';
        }
    }
}

// Handle book exit recording (auto-record on unauthorized)
if (isset($_POST['record_book_exit'])) {
    $barcode = trim($_POST['barcode']);
    $isAuthorized = (int)$_POST['is_authorized'];
    $memberAdmno = trim($_POST['member_admno'] ?? '');
    $memberName = trim($_POST['member_name'] ?? '');
    $photoData = $_POST['photo_data'] ?? '';
    $isGuest = isset($_POST['is_guest']) ? (int)$_POST['is_guest'] : 0;
    
    $book = getKohaBook($barcode);
    if ($book) {
        $photoPath = '';
        if (!empty($photoData) && !$isAuthorized && ($settings['book_exit_photo'] ?? 1)) {
            $uploadDir = UPLOAD_PATH . '/book_exit_photos/';
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0777, true);
                chmod($uploadDir, 0777);
            }
            $imageData = base64_decode(preg_replace('#^data:image/\w+;base64,#i', '', $photoData));
            if ($imageData !== false) {
                $filename = 'unauthorized_' . time() . '_' . rand(1000, 9999) . '.jpg';
                if (file_put_contents($uploadDir . $filename, $imageData)) {
                    $photoPath = $filename;
                    chmod($uploadDir . $filename, 0666);
                }
            }
        }
        
        $insert = $db->prepare("INSERT INTO book_exit_logs (book_barcode, book_title, book_author, member_admno, member_name, is_authorized, staff_id, photo_path, notes, gate_number, alert_sent) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $notes = $isGuest ? 'Guest exit' : '';
        $gateNumber = $_POST['gate_number'] ?? 'MAIN';
        $alertSent = 0;
        
        // Send alerts for unauthorized exits
        if (!$isAuthorized) {
            $alertResult = sendUnauthorizedBookAlert([
                'barcode' => $barcode,
                'title' => $book['title'],
                'author' => $book['author'] ?? '',
                'member_name' => $memberName,
                'member_id' => $memberAdmno,
                'photo_path' => $photoPath,
                'staff_name' => $user['full_name'],
                'gate_number' => $gateNumber,
                'timestamp' => date('Y-m-d H:i:s')
            ]);
            $alertSent = $alertResult ? 1 : 0;
        }
        
        $insert->execute([$barcode, $book['title'], $book['author'] ?? '', $memberAdmno, $memberName, $isAuthorized, $user['id'], $photoPath, $notes, $gateNumber, $alertSent]);
        
        $logId = $db->lastInsertId();
        
        logActivity($user['id'], 'BOOK_EXIT', "Book exit: $barcode" . ($isAuthorized ? ' (Authorized)' : ' (UNAUTHORIZED)') . ($isGuest ? ' (Guest)' : ''));
        
        if (!$isAuthorized) {
            $message = '⚠️ UNAUTHORIZED BOOK EXIT LOGGED! Alert has been sent to security team.';
            // Add to alert queue for display
            addToAlertQueue($logId, $barcode, $book['title'], $photoPath);
        } else {
            $message = 'Book exit logged successfully.';
        }
        
        $bookResult = null;
    }
}

// Handle alert acknowledgment
if (isset($_POST['acknowledge_alert'])) {
    $alertId = (int)$_POST['alert_id'];
    $ackNote = trim($_POST['ack_note'] ?? '');
    
    $update = $db->prepare("UPDATE book_alerts SET acknowledged = 1, acknowledged_by = ?, acknowledged_at = NOW(), ack_note = ? WHERE id = ?");
    $update->execute([$user['id'], $ackNote, $alertId]);
    
    logActivity($user['id'], 'ALERT_ACK', "Acknowledged alert #$alertId");
    $message = 'Alert acknowledged.';
}

// Get logs
$logs = $db->query("SELECT * FROM book_exit_logs ORDER BY created_at DESC LIMIT 100")->fetchAll();
$unauthorized = $db->query("SELECT COUNT(*) FROM book_exit_logs WHERE is_authorized = 0")->fetchColumn();
$guestCount = $db->query("SELECT COUNT(*) FROM entry_exit_logs WHERE status = 'inside' AND entry_type = 'guest'")->fetchColumn();

// Get unacknowledged alerts
$pendingAlerts = getPendingAlerts(10);
$alertStats = getAlertStatistics();

$pageTitle = 'Books';
include __DIR__ . '/header.php';
?>

<style>
/* Alert Animations */
@keyframes alertPulse {
    0%, 100% { box-shadow: 0 0 0 0 rgba(220, 53, 69, 0.7); }
    50% { box-shadow: 0 0 0 15px rgba(220, 53, 69, 0); }
}

@keyframes slideInRight {
    from { transform: translateX(100%); opacity: 0; }
    to { transform: translateX(0); opacity: 1; }
}

@keyframes blink {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.5; }
}

.alert-banner {
    background: linear-gradient(135deg, #dc3545, #c82333);
    color: white;
    padding: 15px 20px;
    border-radius: 12px;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    animation: alertPulse 2s infinite;
    cursor: pointer;
    transition: all 0.3s ease;
}

.alert-banner:hover {
    transform: scale(1.01);
    box-shadow: 0 8px 30px rgba(220, 53, 69, 0.4);
}

.alert-banner .alert-icon {
    font-size: 2rem;
    margin-right: 15px;
    animation: blink 1s infinite;
}

.alert-banner .alert-content {
    flex: 1;
}

.alert-banner .alert-title {
    font-size: 1.1rem;
    font-weight: 700;
    margin-bottom: 2px;
}

.alert-banner .alert-subtitle {
    font-size: 0.85rem;
    opacity: 0.9;
}

.alert-banner .alert-badge {
    background: white;
    color: #dc3545;
    padding: 5px 15px;
    border-radius: 20px;
    font-weight: 700;
    font-size: 1.2rem;
}

/* Live Alert Feed */
.alert-feed {
    position: fixed;
    top: 80px;
    right: 20px;
    width: 380px;
    max-height: calc(100vh - 120px);
    overflow-y: auto;
    z-index: 9999;
    display: none;
}

.alert-feed.show {
    display: block;
}

.alert-feed-item {
    background: white;
    border-radius: 16px;
    padding: 15px;
    margin-bottom: 12px;
    box-shadow: 0 8px 30px rgba(0, 0, 0, 0.15);
    border-left: 4px solid #dc3545;
    animation: slideInRight 0.3s ease;
}

.alert-feed-item.acknowledged {
    border-left-color: #28a745;
    opacity: 0.7;
}

.alert-feed-item .feed-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 8px;
}

.alert-feed-item .feed-title {
    font-weight: 700;
    color: #dc3545;
    font-size: 0.9rem;
}

.alert-feed-item .feed-time {
    font-size: 0.75rem;
    color: #6c757d;
}

.alert-feed-item .feed-body {
    font-size: 0.85rem;
}

.alert-feed-item .feed-photo {
    width: 60px;
    height: 60px;
    border-radius: 8px;
    object-fit: cover;
    margin-top: 8px;
}

.alert-feed-item .feed-actions {
    margin-top: 10px;
    display: flex;
    gap: 8px;
}

/* Monitoring Dashboard */
.monitor-stats {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
    gap: 15px;
    margin-bottom: 20px;
}

.monitor-stat {
    background: white;
    border-radius: 16px;
    padding: 20px;
    text-align: center;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
    border: 1px solid rgba(0, 0, 0, 0.05);
}

.monitor-stat.danger {
    background: linear-gradient(135deg, #fff5f5, #ffe0e0);
    border-color: #dc3545;
}

.monitor-stat .stat-value {
    font-size: 2rem;
    font-weight: 800;
    color: #1e3c72;
}

.monitor-stat.danger .stat-value {
    color: #dc3545;
}

.monitor-stat .stat-label {
    font-size: 0.8rem;
    color: #6c757d;
    margin-top: 5px;
}

.monitor-stat .stat-icon {
    font-size: 1.5rem;
    margin-bottom: 10px;
}

/* Security Alert Modal */
.security-modal .modal-content {
    border: none;
    border-radius: 20px;
    overflow: hidden;
}

.security-modal .modal-header {
    background: linear-gradient(135deg, #dc3545, #c82333);
    color: white;
    border: none;
    padding: 20px 25px;
}

.security-modal .modal-body {
    padding: 25px;
}

.security-modal .alert-photo {
    width: 150px;
    height: 150px;
    border-radius: 12px;
    object-fit: cover;
    border: 3px solid #dc3545;
}

/* Notification Sound Indicator */
.sound-indicator {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    font-size: 0.75rem;
    color: #6c757d;
}

.sound-indicator .dot {
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background: #28a745;
    animation: blink 1s infinite;
}

/* Table Enhancements */
.table-danger-row {
    background: #fff5f5 !important;
}

.table-danger-row:hover {
    background: #ffe0e0 !important;
}

/* Edit Modal */
.edit-modal .modal-content {
    border: none;
    border-radius: 18px;
    overflow: hidden;
}

.edit-modal .modal-header {
    background: linear-gradient(135deg, #1e3c72, #2a5298);
    color: white;
    border: none;
    padding: 18px 24px;
}

.edit-modal .modal-header .btn-close {
    filter: invert(1) brightness(2);
}

.edit-modal .modal-body {
    padding: 24px;
}

.edit-modal .form-label {
    font-weight: 600;
    font-size: 0.82rem;
    color: #1e3c72;
}

.edit-modal .form-control,
.edit-modal .form-select {
    border-radius: 10px;
    border: 1.5px solid #e2e8f0;
    padding: 9px 14px;
}

.edit-modal .form-control:focus,
.edit-modal .form-select:focus {
    border-color: #1e3c72;
    box-shadow: 0 0 0 3px rgba(30, 60, 114, 0.12);
}

.edit-modal .modal-footer {
    border-top: 1px solid #e9ecef;
    padding: 14px 24px;
    background: #f8fafc;
}

/* Responsive */
@media (max-width: 768px) {
    .alert-feed {
        width: calc(100% - 40px);
        right: 20px;
        left: 20px;
    }
    
    .alert-banner {
        flex-direction: column;
        text-align: center;
        gap: 10px;
    }
    
    .alert-banner .alert-icon {
        margin-right: 0;
        margin-bottom: 10px;
    }
}
</style>

<!-- Sound for alerts -->
<audio id="alertSound" preload="auto">
    <source src="data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmwhBSuBzvLZiTYIG2m98OScTgwOUarm7blmGgU7k9n1unEiBC13yO/eizEIHWq+8+OWT",
          type="audio/wav">
</audio>

<div class="container-fluid">
    <!-- UNAUTHORIZED ALERT BANNER -->
    <?php if ($unauthorized > 0 && ($settings['book_unauthorized_alert'] ?? 1)): ?>
        <div class="alert-banner" onclick="toggleAlertFeed()">
            <div class="alert-icon">
                <i class="fas fa-exclamation-triangle"></i>
            </div>
            <div class="alert-content">
                <div class="alert-title">🚨 UNAUTHORIZED BOOK EXITS DETECTED</div>
                <div class="alert-subtitle">
                    <?= number_format($unauthorized) ?> unauthorized exit(s) recorded. 
                    Click to view live alerts.
                </div>
            </div>
            <div class="alert-badge"><?= $unauthorized ?></div>
        </div>
    <?php endif; ?>
    
    <!-- Header -->
    <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
        <h4 class="mb-0"><i class="fas fa-book me-2 text-primary"></i>Book Management & Monitoring</h4>
        <div class="d-flex gap-2 align-items-center">
            <div class="sound-indicator">
                <span class="dot"></span>
                <span>Live monitoring active</span>
            </div>
            <?php if ($guestCount > 0): ?>
                <span class="badge bg-success rounded-pill px-3 py-2">
                    <i class="fas fa-user-friends me-1"></i> <?= $guestCount ?> Guests Inside
                </span>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Monitoring Stats Dashboard -->
    <div class="monitor-stats">
        <div class="monitor-stat <?= $unauthorized > 0 ? 'danger' : '' ?>">
            <div class="stat-icon text-danger"><i class="fas fa-exclamation-triangle"></i></div>
            <div class="stat-value"><?= number_format($unauthorized) ?></div>
            <div class="stat-label">Unauthorized Exits</div>
        </div>
        <div class="monitor-stat">
            <div class="stat-icon text-primary"><i class="fas fa-book"></i></div>
            <div class="stat-value"><?= number_format(count($logs)) ?></div>
            <div class="stat-label">Total Book Exits</div>
        </div>
        <div class="monitor-stat">
            <div class="stat-icon text-warning"><i class="fas fa-clock"></i></div>
            <div class="stat-value"><?= date('H:i') ?></div>
            <div class="stat-label">Last Check</div>
        </div>
        <div class="monitor-stat">
            <div class="stat-icon text-success"><i class="fas fa-shield-alt"></i></div>
            <div class="stat-value"><?= $alertStats['acknowledged'] ?? 0 ?></div>
            <div class="stat-label">Alerts Handled</div>
        </div>
    </div>
    
    <?php if ($message): ?>
        <div class="alert <?= strpos($message, 'UNAUTHORIZED') !== false ? 'alert-danger' : 'alert-success' ?> alert-dismissible fade show">
            <?= htmlspecialchars($message) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <?php if ($bookError): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <i class="fas fa-exclamation-circle me-2"></i>
            <?= htmlspecialchars($bookError) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <?php if ($alertMessage): ?>
        <div class="alert alert-warning alert-dismissible fade show border-warning">
            <i class="fas fa-bell me-2"></i>
            <?= htmlspecialchars($alertMessage) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <!-- Scan Book Card -->
    <div class="card mb-4 shadow-sm">
        <div class="card-header bg-white">
            <h5 class="mb-0"><i class="fas fa-search me-2"></i>Scan Book</h5>
        </div>
        <div class="card-body">
            <form method="POST" class="row g-3" id="scanForm">
                <div class="col-12 col-md-8">
                    <div class="input-group input-group-lg">
                        <span class="input-group-text bg-primary text-white"><i class="fas fa-barcode"></i></span>
                        <input type="text" name="barcode" id="barcodeInput" class="form-control" 
                               placeholder="Scan Book Barcode" required autofocus autocomplete="off">
                    </div>
                </div>
                <div class="col-12 col-md-4">
                    <button type="submit" name="scan_book" class="btn btn-primary w-100 btn-lg">
                        <i class="fas fa-search me-2"></i> Scan Book
                    </button>
                </div>
            </form>
            
            <div class="mt-3 d-flex gap-2 flex-wrap">
                <a href="guests.php" class="btn btn-outline-success btn-sm">
                    <i class="fas fa-user-friends me-1"></i> Manage Guests
                    <?php if ($guestCount > 0): ?>
                        <span class="badge bg-success ms-1"><?= $guestCount ?></span>
                    <?php endif; ?>
                </a>
                <button onclick="toggleAlertFeed()" class="btn btn-outline-danger btn-sm">
                    <i class="fas fa-bell me-1"></i> Live Alerts
                    <?php if (count($pendingAlerts) > 0): ?>
                        <span class="badge bg-danger ms-1"><?= count($pendingAlerts) ?></span>
                    <?php endif; ?>
                </button>
                <a href="alerts.php" class="btn btn-outline-warning btn-sm">
                    <i class="fas fa-shield-alt me-1"></i> Alert Center
                </a>
            </div>
            
            <?php if (isset($bookResult)): ?>
                <div class="book-result-card <?= empty($bookResult['borrowernumber']) ? 'border-danger' : '' ?>" 
                     style="background: <?= empty($bookResult['borrowernumber']) ? '#fff5f5' : '#f8f9fa' ?>; 
                            border-radius: 16px; padding: 20px; 
                            border: 2px solid <?= empty($bookResult['borrowernumber']) ? '#dc3545' : '#e9ecef' ?>; 
                            margin-top: 16px;">
                    
                    <?php if (empty($bookResult['borrowernumber'])): ?>
                        <div class="alert alert-danger mb-3">
                            <i class="fas fa-exclamation-triangle me-2"></i>
                            <strong>WARNING:</strong> This book is NOT issued. Exit will be logged as UNAUTHORIZED!
                        </div>
                    <?php endif; ?>
                    
                    <div class="row align-items-center">
                        <div class="col-12 col-md-8">
                            <h5 class="mb-1"><?= htmlspecialchars($bookResult['title']) ?></h5>
                            <div class="text-muted"><?= htmlspecialchars($bookResult['author'] ?? 'Unknown Author') ?></div>
                            <div class="mt-2">
                                <span class="badge bg-secondary">
                                    <i class="fas fa-barcode me-1"></i> <?= htmlspecialchars($bookResult['barcode']) ?>
                                </span>
                                <span class="badge <?= $bookResult['borrowernumber'] ? 'bg-warning text-dark' : 'bg-danger' ?>">
                                    <?= $bookResult['borrowernumber'] ? '📖 Issued' : '⚠️ NOT ISSUED' ?>
                                </span>
                                <?php if (!empty($bookResult['member_name']) && strpos($bookResult['member_name'], 'Guest') !== false): ?>
                                    <span class="badge bg-success">Guest</span>
                                <?php endif; ?>
                            </div>
                            <?php if ($bookResult['borrowernumber']): ?>
                                <div class="mt-1">
                                    <i class="fas fa-user me-1"></i> <strong>Issued to:</strong> 
                                    <?= htmlspecialchars($bookResult['member_name'] ?? $bookResult['member_cardnumber']) ?>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="col-12 col-md-4 text-center text-md-end mt-3 mt-md-0">
                            <form method="POST" id="bookExitForm">
                                <input type="hidden" name="barcode" value="<?= htmlspecialchars($bookResult['barcode']) ?>">
                                <input type="hidden" name="is_authorized" value="<?= $bookResult['borrowernumber'] ? 1 : 0 ?>">
                                <input type="hidden" name="member_admno" value="<?= htmlspecialchars($bookResult['member_cardnumber'] ?? '') ?>">
                                <input type="hidden" name="member_name" value="<?= htmlspecialchars($bookResult['member_name'] ?? '') ?>">
                                <input type="hidden" name="photo_data" id="photoData" value="">
                                <input type="hidden" name="is_guest" id="isGuest" value="0">
                                <input type="hidden" name="gate_number" value="MAIN">
                                
                                <?php if (!$bookResult['borrowernumber'] && ($settings['book_exit_photo'] ?? 1) && $cameraEnabled): ?>
                                    <button type="button" class="btn btn-outline-danger btn-sm mb-2" onclick="toggleCamera()">
                                        <i class="fas fa-camera me-1"></i> Capture Photo (Required)
                                    </button>
                                    <div id="photoPreviewContainer"></div>
                                <?php endif; ?>
                                
                                <button type="submit" name="record_book_exit" 
                                        class="btn <?= $bookResult['borrowernumber'] ? 'btn-success' : 'btn-danger' ?> btn-lg w-100" 
                                        id="recordBtn"
                                        <?= (!$bookResult['borrowernumber'] && ($settings['book_exit_photo'] ?? 1) && $cameraEnabled) ? 'disabled' : '' ?>>
                                    <i class="fas <?= $bookResult['borrowernumber'] ? 'fa-check-circle' : 'fa-exclamation-triangle' ?> me-2"></i>
                                    <?= $bookResult['borrowernumber'] ? 'Authorized Exit' : 'LOG UNAUTHORIZED EXIT' ?>
                                </button>
                            </form>
                        </div>
                    </div>
                    
                    <?php if (!$bookResult['borrowernumber'] && ($settings['book_exit_photo'] ?? 1) && $cameraEnabled): ?>
                        <div class="camera-container mt-3" id="cameraContainer" style="display:none; max-width: 400px; margin: 10px auto;">
                            <video id="video" autoplay playsinline style="width:100%; border-radius:12px; border:2px solid #dc3545; background:#000;"></video>
                            <canvas id="canvas" style="display:none;"></canvas>
                            <div class="camera-controls" style="display:flex; gap:10px; justify-content:center; margin-top:10px;">
                                <button type="button" class="btn btn-danger" onclick="capturePhoto()">
                                    <i class="fas fa-camera"></i> Capture
                                </button>
                                <button type="button" class="btn btn-secondary" onclick="toggleCamera()">
                                    <i class="fas fa-times"></i> Close
                                </button>
                            </div>
                            <div id="photoPreview" class="mt-2 text-center" style="display:none;">
                                <img id="capturedImage" class="photo-preview" style="max-width:200px; border-radius:8px; border:3px solid #dc3545;">
                                <p class="text-danger mt-1"><i class="fas fa-check-circle"></i> Photo captured - Ready to log!</p>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Book Exit Logs Table -->
    <div class="card shadow-sm">
        <div class="card-header bg-white d-flex justify-content-between align-items-center flex-wrap gap-2">
            <h5 class="mb-0"><i class="fas fa-history me-2"></i>Book Exit Logs</h5>
            <div class="d-flex gap-2">
                <span class="badge bg-danger rounded-pill px-3 py-2">
                    <i class="fas fa-exclamation-triangle me-1"></i> <?= number_format($unauthorized) ?> Unauthorized
                </span>
                <?php if ($unauthorized > 0): ?>
                    <button onclick="clearUnauthorizedLogs()" class="btn btn-sm btn-outline-danger">
                        <i class="fas fa-trash me-1"></i> Clear Unauthorized
                    </button>
                <?php endif; ?>
            </div>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover mb-0" id="booksTable">
                    <thead class="table-light">
                        <tr>
                            <th>Barcode</th>
                            <th>Title</th>
                            <th>Member</th>
                            <th>Time</th>
                            <th>Status</th>
                            <th>Photo</th>
                            <th>Alert</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($logs)): ?>
                            <tr>
                                <td colspan="8" class="text-center py-4 text-muted">
                                    <i class="fas fa-check-circle text-success me-2"></i> No book exit logs
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($logs as $r): ?>
                                <tr class="<?= !$r['is_authorized'] ? 'table-danger-row' : '' ?>"
                                    id="bookRow-<?= $r['id'] ?>"
                                    data-id="<?= $r['id'] ?>"
                                    data-barcode="<?= htmlspecialchars($r['book_barcode']) ?>"
                                    data-title="<?= htmlspecialchars($r['book_title']) ?>"
                                    data-author="<?= htmlspecialchars($r['book_author'] ?? '') ?>"
                                    data-admno="<?= htmlspecialchars($r['member_admno'] ?? '') ?>"
                                    data-member="<?= htmlspecialchars($r['member_name'] ?? '') ?>"
                                    data-authorized="<?= (int)$r['is_authorized'] ?>"
                                    data-notes="<?= htmlspecialchars($r['notes'] ?? '') ?>"
                                    data-gate="<?= htmlspecialchars($r['gate_number'] ?? 'MAIN') ?>"
                                    data-alert-sent="<?= (int)($r['alert_sent'] ?? 0) ?>">
                                    <td><code><?= htmlspecialchars($r['book_barcode']) ?></code></td>
                                    <td>
                                        <div class="fw-semibold"><?= htmlspecialchars(substr($r['book_title'], 0, 40)) ?></div>
                                        <small class="text-muted"><?= htmlspecialchars($r['book_author'] ?? '—') ?></small>
                                    </td>
                                    <td>
                                        <?= htmlspecialchars($r['member_name'] ?? 'Not linked') ?>
                                        <?php if (!empty($r['notes']) && strpos($r['notes'], 'Guest') !== false): ?>
                                            <span class="badge bg-success">Guest</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div><?= date('d M Y', strtotime($r['created_at'] ?? $r['exit_time'])) ?></div>
                                        <small class="text-muted"><?= date('h:i A', strtotime($r['created_at'] ?? $r['exit_time'])) ?></small>
                                    </td>
                                    <td>
                                        <span class="badge <?= $r['is_authorized'] ? 'bg-success' : 'bg-danger' ?>">
                                            <?= $r['is_authorized'] ? '✅ Authorized' : '⚠️ UNAUTHORIZED' ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php 
                                        $photoPath = UPLOAD_PATH . '/book_exit_photos/' . $r['photo_path'];
                                        if (!empty($r['photo_path']) && file_exists($photoPath)): ?>
                                            <img src="data:image/jpeg;base64,<?= base64_encode(file_get_contents($photoPath)) ?>" 
                                                 class="book-photo-preview" 
                                                 style="max-width: 60px; max-height: 60px; border-radius: 8px; cursor: pointer;"
                                                 alt="Photo" 
                                                 onclick="showPhotoModal(this.src, '<?= htmlspecialchars($r['book_barcode']) ?>')">
                                        <?php else: ?>
                                            <span class="text-muted">—</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if (!$r['is_authorized'] && !empty($r['alert_sent'])): ?>
                                            <span class="badge bg-warning text-dark">
                                                <i class="fas fa-bell me-1"></i> Alert Sent
                                            </span>
                                        <?php elseif (!$r['is_authorized']): ?>
                                            <button class="btn btn-sm btn-outline-warning" 
                                                    onclick="sendManualAlert(<?= $r['id'] ?>)">
                                                <i class="fas fa-paper-plane me-1"></i> Send Alert
                                            </button>
                                        <?php else: ?>
                                            <span class="text-muted">—</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="btn-group btn-group-sm" role="group">
                                            <button type="button"
                                                    class="btn btn-outline-primary"
                                                    title="Edit this log"
                                                    onclick="openEditBookModal(<?= $r['id'] ?>)">
                                                <i class="fas fa-edit"></i>
                                            </button>
                                            <button type="button"
                                                    class="btn btn-outline-danger"
                                                    title="Delete this log"
                                                    onclick="deleteBookLog(<?= $r['id'] ?>)">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Live Alert Feed -->
<div class="alert-feed" id="alertFeed">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h6 class="mb-0"><i class="fas fa-bell text-danger me-2"></i>Live Security Alerts</h6>
        <button class="btn btn-sm btn-outline-secondary" onclick="toggleAlertFeed()">
            <i class="fas fa-times"></i>
        </button>
    </div>
    <div id="alertFeedContent">
        <?php if (empty($pendingAlerts)): ?>
            <div class="text-center text-muted py-4">
                <i class="fas fa-shield-alt fa-2x mb-2"></i>
                <p>No pending alerts</p>
            </div>
        <?php else: ?>
            <?php foreach ($pendingAlerts as $alert): ?>
                <div class="alert-feed-item" id="alert-<?= $alert['id'] ?>">
                    <div class="feed-header">
                        <span class="feed-title">
                            <i class="fas fa-exclamation-triangle me-1"></i> UNAUTHORIZED EXIT
                        </span>
                        <span class="feed-time"><?= timeAgo($alert['created_at']) ?></span>
                    </div>
                    <div class="feed-body">
                        <div><strong><?= htmlspecialchars($alert['book_title']) ?></strong></div>
                        <div class="text-muted small">Barcode: <?= htmlspecialchars($alert['book_barcode']) ?></div>
                        <?php if (!empty($alert['member_name'])): ?>
                            <div class="small">Member: <?= htmlspecialchars($alert['member_name']) ?></div>
                        <?php endif; ?>
                    </div>
                    <?php if (!empty($alert['photo_path'])): ?>
                        <?php $photoPath = UPLOAD_PATH . '/book_exit_photos/' . $alert['photo_path']; ?>
                        <?php if (file_exists($photoPath)): ?>
                            <img src="data:image/jpeg;base64,<?= base64_encode(file_get_contents($photoPath)) ?>" 
                                 class="feed-photo" alt="Photo"
                                 onclick="showPhotoModal(this.src, '<?= htmlspecialchars($alert['book_barcode']) ?>')">
                        <?php endif; ?>
                    <?php endif; ?>
                    <div class="feed-actions">
                        <button class="btn btn-sm btn-success" onclick="acknowledgeAlert(<?= $alert['id'] ?>)">
                            <i class="fas fa-check me-1"></i> Acknowledge
                        </button>
                        <button class="btn btn-sm btn-outline-danger" 
                                onclick="viewAlertDetails(<?= $alert['id'] ?>)">
                            <i class="fas fa-eye me-1"></i> Details
                        </button>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

<!-- Photo Modal -->
<div class="modal fade security-modal" id="photoModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="fas fa-camera me-2"></i> Security Photo
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body text-center">
                <img id="modalPhoto" src="" class="img-fluid rounded" style="max-height: 400px;">
                <p class="mt-3 text-muted" id="modalPhotoCaption"></p>
            </div>
        </div>
    </div>
</div>

<!-- ============================================================
     EDIT BOOK EXIT LOG MODAL
     ============================================================ -->
<div class="modal fade edit-modal" id="editBookModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="fas fa-edit me-2"></i> Edit Book Exit Log
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <input type="hidden" id="editLogId" value="">

                <div class="row g-3">
                    <div class="col-12 col-md-6">
                        <label class="form-label">Book Barcode <span class="text-danger">*</span></label>
                        <input type="text" id="editBookBarcode" class="form-control" required>
                    </div>
                    <div class="col-12 col-md-6">
                        <label class="form-label">Book Title <span class="text-danger">*</span></label>
                        <input type="text" id="editBookTitle" class="form-control" required>
                    </div>
                    <div class="col-12 col-md-6">
                        <label class="form-label">Book Author</label>
                        <input type="text" id="editBookAuthor" class="form-control">
                    </div>
                    <div class="col-12 col-md-6">
                        <label class="form-label">Section / Gate</label>
                        <input type="text" id="editGateNumber" class="form-control" placeholder="MAIN">
                    </div>

                    <div class="col-12 col-md-6">
                        <label class="form-label">Member ID (ADMNO)</label>
                        <input type="text" id="editMemberAdmno" class="form-control">
                    </div>
                    <div class="col-12 col-md-6">
                        <label class="form-label">Member Name</label>
                        <input type="text" id="editMemberName" class="form-control">
                    </div>

                    <div class="col-12 col-md-6">
                        <label class="form-label">Authorization Status</label>
                        <select id="editIsAuthorized" class="form-select">
                            <option value="0">⚠️ Unauthorized (default)</option>
                            <option value="1">✅ Authorized</option>
                        </select>
                        <small class="text-muted">Change to <strong>Authorized</strong> if the book was actually issued.</small>
                    </div>
                    <div class="col-12 col-md-6">
                        <label class="form-label">Alert Sent</label>
                        <select id="editAlertSent" class="form-select">
                            <option value="0">Not sent</option>
                            <option value="1">Sent</option>
                        </select>
                    </div>

                    <div class="col-12">
                        <label class="form-label">Notes</label>
                        <textarea id="editNotes" class="form-control" rows="3"
                                  placeholder="Add a note (e.g. corrected member info, resolution details…)"></textarea>
                    </div>
                </div>

                <div class="alert alert-info mt-3 mb-0 small">
                    <i class="fas fa-info-circle me-1"></i>
                    Saving updates the log row, keeps any linked alert in sync, and writes an
                    entry to the audit trail (<code>activity_log</code>).
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                    <i class="fas fa-times me-1"></i> Cancel
                </button>
                <button type="button" class="btn btn-primary" id="saveEditBookBtn" onclick="saveEditedBookLog()">
                    <i class="fas fa-save me-1"></i> Save Changes
                </button>
            </div>
        </div>
    </div>
</div>

<script>
// ============================================================
// ALERT SYSTEM
// ============================================================
let alertFeedOpen = false;
let lastAlertCheck = <?= time() ?>;
let soundEnabled = true;

function toggleAlertFeed() {
    const feed = document.getElementById('alertFeed');
    alertFeedOpen = !alertFeedOpen;
    feed.classList.toggle('show', alertFeedOpen);
    if (alertFeedOpen) {
        checkForNewAlerts();
    }
}

function playAlertSound() {
    if (!soundEnabled) return;
    const audio = document.getElementById('alertSound');
    if (audio) {
        audio.currentTime = 0;
        audio.play().catch(e => console.log('Audio play failed:', e));
    }
}

function showPhotoModal(src, caption) {
    document.getElementById('modalPhoto').src = src;
    document.getElementById('modalPhotoCaption').textContent = 'Book: ' + caption;
    new bootstrap.Modal(document.getElementById('photoModal')).show();
}

function acknowledgeAlert(alertId) {
    const note = prompt('Add a note (optional):');
    
    fetch('ajax.php?action=acknowledge_book_alert', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'alert_id=' + alertId + '&ack_note=' + encodeURIComponent(note || '') + '&csrf_token=' + getCsrfToken()
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            const item = document.getElementById('alert-' + alertId);
            if (item) {
                item.classList.add('acknowledged');
                item.querySelector('.feed-actions').innerHTML = 
                    '<span class="text-success"><i class="fas fa-check-circle me-1"></i> Acknowledged</span>';
            }
            showToast('Alert acknowledged', 'success');
        } else {
            showToast(data.message || 'Failed to acknowledge', 'danger');
        }
    })
    .catch(err => {
        showToast('Network error', 'danger');
    });
}

function viewAlertDetails(alertId) {
    window.location.href = 'alerts.php?id=' + alertId;
}

function sendManualAlert(logId) {
    if (!confirm('Send alert notification for this unauthorized exit?')) return;
    
    fetch('ajax.php?action=send_book_alert', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'log_id=' + logId + '&csrf_token=' + getCsrfToken()
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            showToast('Alert sent successfully', 'success');
            setTimeout(() => location.reload(), 1500);
        } else {
            showToast(data.message || 'Failed to send alert', 'danger');
        }
    });
}

// Real-time alert checking
function checkForNewAlerts() {
    fetch('ajax.php?action=get_pending_alerts&since=' + lastAlertCheck)
        .then(res => res.json())
        .then(data => {
            if (data.alerts && data.alerts.length > 0) {
                data.alerts.forEach(alert => {
                    addAlertToFeed(alert);
                });
                playAlertSound();
                showToast('🚨 New unauthorized book exit detected!', 'danger');
                lastAlertCheck = Math.floor(Date.now() / 1000);
                
                // Update banner count
                const badge = document.querySelector('.alert-banner .alert-badge');
                if (badge) {
                    badge.textContent = parseInt(badge.textContent) + data.alerts.length;
                }
            }
        })
        .catch(err => console.log('Alert check failed:', err));
}

function addAlertToFeed(alert) {
    const container = document.getElementById('alertFeedContent');
    const noAlerts = container.querySelector('.text-center');
    if (noAlerts) noAlerts.remove();
    
    const item = document.createElement('div');
    item.className = 'alert-feed-item';
    item.id = 'alert-' + alert.id;
    item.innerHTML = `
        <div class="feed-header">
            <span class="feed-title">
                <i class="fas fa-exclamation-triangle me-1"></i> UNAUTHORIZED EXIT
            </span>
            <span class="feed-time">Just now</span>
        </div>
        <div class="feed-body">
            <div><strong>${escapeHtml(alert.book_title)}</strong></div>
            <div class="text-muted small">Barcode: ${escapeHtml(alert.book_barcode)}</div>
        </div>
        <div class="feed-actions">
            <button class="btn btn-sm btn-success" onclick="acknowledgeAlert(${alert.id})">
                <i class="fas fa-check me-1"></i> Acknowledge
            </button>
        </div>
    `;
    container.insertBefore(item, container.firstChild);
}

function escapeHtml(str) {
    if (!str) return '';
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
}

function getCsrfToken() {
    return document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '';
}

function showToast(message, type) {
    const toast = document.createElement('div');
    toast.className = `toast-notification alert alert-${type} alert-dismissible fade show position-fixed`;
    toast.style.cssText = 'top: 20px; right: 20px; z-index: 99999; min-width: 300px;';
    toast.innerHTML = `
        <i class="fas fa-${type === 'danger' ? 'exclamation-triangle' : 'check-circle'} me-2"></i>
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 5000);
}

// ============================================================
// EDIT BOOK EXIT LOG
// ============================================================
function openEditBookModal(logId) {
    const row = document.getElementById('bookRow-' + logId);
    if (!row) {
        showToast('Row not found', 'danger');
        return;
    }

    document.getElementById('editLogId').value        = logId;
    document.getElementById('editBookBarcode').value  = row.dataset.barcode  || '';
    document.getElementById('editBookTitle').value    = row.dataset.title    || '';
    document.getElementById('editBookAuthor').value   = row.dataset.author   || '';
    document.getElementById('editGateNumber').value   = row.dataset.gate     || 'MAIN';
    document.getElementById('editMemberAdmno').value  = row.dataset.admno    || '';
    document.getElementById('editMemberName').value   = row.dataset.member   || '';
    document.getElementById('editIsAuthorized').value = row.dataset.authorized || '0';
    document.getElementById('editAlertSent').value    = row.dataset.alertSent  || '0';
    document.getElementById('editNotes').value        = row.dataset.notes    || '';

    new bootstrap.Modal(document.getElementById('editBookModal')).show();
}

function saveEditedBookLog() {
    const id = parseInt(document.getElementById('editLogId').value, 10);
    if (!id) return;

    const barcode = document.getElementById('editBookBarcode').value.trim();
    const title   = document.getElementById('editBookTitle').value.trim();
    if (!barcode || !title) {
        showToast('Barcode and Title are required.', 'warning');
        return;
    }

    const btn = document.getElementById('saveEditBookBtn');
    const originalHtml = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span> Saving...';

    const body = new URLSearchParams({
        id:             id,
        book_barcode:   barcode,
        book_title:     title,
        book_author:    document.getElementById('editBookAuthor').value.trim(),
        gate_number:    document.getElementById('editGateNumber').value.trim() || 'MAIN',
        member_admno:   document.getElementById('editMemberAdmno').value.trim(),
        member_name:    document.getElementById('editMemberName').value.trim(),
        is_authorized:  document.getElementById('editIsAuthorized').value,
        alert_sent:     document.getElementById('editAlertSent').value,
        notes:          document.getElementById('editNotes').value.trim(),
        csrf_token:     getCsrfToken()
    });

    fetch('ajax.php?action=update_book_log', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        credentials: 'same-origin',
        body: body.toString()
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            // Update the row in-place (no reload required)
            const row = document.getElementById('bookRow-' + id);
            if (row) {
                row.dataset.barcode     = barcode;
                row.dataset.title       = title;
                row.dataset.author      = document.getElementById('editBookAuthor').value.trim();
                row.dataset.gate        = document.getElementById('editGateNumber').value.trim() || 'MAIN';
                row.dataset.admno       = document.getElementById('editMemberAdmno').value.trim();
                row.dataset.member      = document.getElementById('editMemberName').value.trim();
                row.dataset.authorized  = document.getElementById('editIsAuthorized').value;
                row.dataset.alertSent   = document.getElementById('editAlertSent').value;
                row.dataset.notes       = document.getElementById('editNotes').value.trim();

                // Toggle row tint based on authorization status
                const isAuth = document.getElementById('editIsAuthorized').value === '1';
                row.classList.toggle('table-danger-row', !isAuth);

                // Update visible cells
                const cells = row.querySelectorAll('td');
                if (cells[0]) cells[0].innerHTML = '<code>' + escapeHtml(barcode) + '</code>';
                if (cells[1]) {
                    cells[1].innerHTML =
                        '<div class="fw-semibold">' + escapeHtml(title.substring(0, 40)) + '</div>' +
                        '<small class="text-muted">' + escapeHtml(document.getElementById('editBookAuthor').value.trim() || '—') + '</small>';
                }
                if (cells[2]) {
                    const memberName = document.getElementById('editMemberName').value.trim() || 'Not linked';
                    cells[2].innerHTML = escapeHtml(memberName);
                }
                if (cells[4]) {
                    cells[4].innerHTML = isAuth
                        ? '<span class="badge bg-success">✅ Authorized</span>'
                        : '<span class="badge bg-danger">⚠️ UNAUTHORIZED</span>';
                }
            }

            showToast(data.message || 'Book exit log updated', 'success');
            const modalEl = document.getElementById('editBookModal');
            const modal = bootstrap.Modal.getInstance(modalEl);
            if (modal) modal.hide();

            // If authorization changed, refresh the page after a short delay
            // so the top-level counters (unauthorized total, banners) update.
            setTimeout(() => location.reload(), 900);
        } else {
            showToast(data.message || 'Failed to update', 'danger');
        }
    })
    .catch(err => {
        console.error(err);
        showToast('Network error', 'danger');
    })
    .finally(() => {
        btn.disabled = false;
        btn.innerHTML = originalHtml;
    });
}

// ============================================================
// CAMERA FUNCTIONS
// ============================================================
let stream = null;
let photoCaptured = false;

function toggleCamera() {
    const container = document.getElementById('cameraContainer');
    const video = document.getElementById('video');
    const photoPreview = document.getElementById('photoPreview');
    const recordBtn = document.getElementById('recordBtn');
    
    if (container.style.display === 'none') {
        container.style.display = 'block';
        photoPreview.style.display = 'none';
        photoCaptured = false;
        document.getElementById('photoData').value = '';
        if (recordBtn) recordBtn.disabled = true;
        startCamera();
    } else {
        stopCamera();
        container.style.display = 'none';
    }
}

function startCamera() {
    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } })
            .then(function(s) { 
                stream = s; 
                document.getElementById('video').srcObject = s; 
            })
            .catch(function(err) { 
                alert('Camera access denied. Please allow camera access and try again.'); 
                document.getElementById('cameraContainer').style.display = 'none'; 
            });
    } else {
        alert('Camera not supported on this device.');
        document.getElementById('cameraContainer').style.display = 'none';
    }
}

function stopCamera() {
    if (stream) { 
        stream.getTracks().forEach(track => track.stop()); 
        stream = null; 
    }
    const video = document.getElementById('video');
    if (video) video.srcObject = null;
}

function capturePhoto() {
    const video = document.getElementById('video');
    const canvas = document.getElementById('canvas');
    const context = canvas.getContext('2d');
    
    if (!video.videoWidth || !video.videoHeight) { 
        alert('Please wait for camera to initialize.'); 
        return; 
    }
    
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    context.drawImage(video, 0, 0, canvas.width, canvas.height);
    
    const photoData = canvas.toDataURL('image/jpeg', 0.8);
    document.getElementById('photoData').value = photoData;
    document.getElementById('capturedImage').src = photoData;
    document.getElementById('photoPreview').style.display = 'block';
    photoCaptured = true;
    
    // Enable record button
    const recordBtn = document.getElementById('recordBtn');
    if (recordBtn) recordBtn.disabled = false;
    
    showToast('Photo captured! Ready to log exit.', 'success');
}

// ============================================================
// UTILITY FUNCTIONS
// ============================================================
function clearUnauthorizedLogs() {
    if (!confirm('⚠️ Are you sure you want to delete ALL unauthorized book exit logs?\n\nThis action cannot be undone!')) return;
    
    fetch('ajax.php?action=clear_unauthorized_logs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'csrf_token=' + encodeURIComponent(getCsrfToken())
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) { 
            showToast(data.message, 'success'); 
            setTimeout(() => location.reload(), 1500); 
        } else { 
            showToast(data.message, 'danger'); 
        }
    })
    .catch(err => showToast('Network error', 'danger'));
}

function deleteBookLog(id) {
    if (!confirm('Are you sure you want to delete this log?')) return;
    
    fetch('ajax.php?action=delete_book_log', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'id=' + encodeURIComponent(id) + '&csrf_token=' + encodeURIComponent(getCsrfToken())
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) { 
            showToast(data.message, 'success'); 
            setTimeout(() => location.reload(), 1500); 
        } else { 
            showToast(data.message, 'danger'); 
        }
    })
    .catch(err => showToast('Network error', 'danger'));
}

// ============================================================
// INITIALIZATION
// ============================================================
document.addEventListener('DOMContentLoaded', function() {
    // Table search
    const table = document.getElementById('booksTable');
    if (table) {
        const cardBody = table.closest('.card-body');
        if (cardBody) {
            const searchDiv = document.createElement('div');
            searchDiv.className = 'p-3 border-bottom';
            searchDiv.innerHTML = `
                <div class="d-flex gap-2">
                    <input type="text" id="tableSearch" class="form-control form-control-sm" 
                           placeholder="Search logs..." style="max-width:300px;">
                    <button class="btn btn-sm btn-outline-secondary" onclick="clearTableSearch()">
                        <i class="fas fa-times"></i>
                    </button>
                    <button class="btn btn-sm btn-outline-success" 
                            onclick="exportTableToCSV('booksTable', 'book_logs_<?= date('Y-m-d') ?>')">
                        <i class="fas fa-file-csv"></i> Export CSV
                    </button>
                </div>
            `;
            cardBody.insertBefore(searchDiv, table);
            
            document.getElementById('tableSearch').addEventListener('input', function() {
                const filter = this.value.toLowerCase();
                const rows = table.getElementsByTagName('tbody')[0]?.getElementsByTagName('tr') || [];
                for (let i = 0; i < rows.length; i++) {
                    const text = rows[i].textContent.toLowerCase();
                    rows[i].style.display = text.includes(filter) ? '' : 'none';
                }
            });
        }
    }
    
    // Check for new alerts every 10 seconds
    setInterval(checkForNewAlerts, 10000);
    
    // Initial alert check
    setTimeout(checkForNewAlerts, 2000);
    
    // Play sound on page load if there are unauthorized books
    <?php if ($unauthorized > 0): ?>
    setTimeout(playAlertSound, 1000);
    <?php endif; ?>
});

function clearTableSearch() {
    const input = document.getElementById('tableSearch');
    if (input) { 
        input.value = ''; 
        input.dispatchEvent(new Event('input')); 
        input.focus(); 
    }
}

function exportTableToCSV(tableId, filename) {
    const table = document.getElementById(tableId);
    if (!table) return;
    
    const rows = table.querySelectorAll('tr');
    const csv = [];
    
    rows.forEach(row => {
        const cells = row.querySelectorAll('th, td');
        const rowData = [];
        cells.forEach(cell => {
            let text = cell.textContent.trim();
            if (text.includes(',')) { text = '"' + text + '"'; }
            rowData.push(text);
        });
        csv.push(rowData.join(','));
    });
    
    const csvContent = csv.join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = (filename || 'export') + '.csv';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}
</script>

<?php include __DIR__ . '/footer.php'; ?>
