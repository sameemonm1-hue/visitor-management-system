<?php
/**
 * Visitor Management System - Admin Header
 * Version: 8.5 FINAL — HTML-entity fix + Complete Alert Integration
 *
 * Changelog v8.5 (from v8.4):
 *  - REMOVED: Stock Verification nav link (and its open-sessions badge).
 *  - REMOVED: Computer Terminals nav link (and its active-sessions badge).
 *  - REMOVED: $openStockSessions and $activeComputerSessions counters
 *             (no longer used anywhere in the header).
 *  - PRESERVED: All other counters, all nav sections, all alert UI,
 *               all responsive behaviour, all CSS.
 *
 * Changelog v8.4:
 *  - FIXED: Institution name / page title / user name were being rendered as
 *           "Library &amp; information" when the DB stored pre-encoded entities.
 *           Now all display text goes through vms_h() which decodes once and
 *           encodes once, matching index.php v8.7 and settings.php v7.7.
 *  - NEW:   vms_normalize_text() / vms_h() helpers declared locally with
 *           function_exists() guards so this file works even if
 *           functions.php is stale.
 *  - IMPROVED: $institutionName, $adminHeaderText, $adminHeaderSubtext,
 *              $pageTitle and $user['full_name'] are all normalised at the
 *              top of the file.
 *  - PRESERVED: All counters (alerts, today's entries), all nav links, all
 *               responsive behaviour, all alert UI (bell, dropdown, global
 *               banner, toast).
 *
 * Changelog v8.3:
 *  - ADDED: Subject Classification nav link
 *  - ADDED: Labels & Barcodes nav link
 *  - ADDED: ID Cards nav link
 *  - ADDED: ISBN Lookup nav link
 *  - IMPROVED: Alert counters — consolidated, all wrapped in try/catch
 *  - IMPROVED: Sidebar grouping (Management / Advanced / System)
 *  - SAFE: Missing tables never break the header render
 *
 * Changelog v8.2:
 *  - FIXED: All alert system issues
 *  - ADDED: Working sidebar alert banner
 *  - ADDED: Working topbar alert bell with dropdown
 *  - ADDED: Global alert banner for critical alerts
 *  - ADDED: Toast notification container
 *  - ADDED: Complete alert JavaScript (polling, sound, UI updates)
 *  - SAFE: Graceful fallback if alerts.php missing
 */

if (session_status() === PHP_SESSION_NONE) {
    session_name('CGISESSID');
    if (isset($_COOKIE['CGISESSID'])) {
        session_id($_COOKIE['CGISESSID']);
    }
    session_start();
}

require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/koha.php';
require_once __DIR__ . '/includes/auth.php';

// Load alerts.php only if it exists (safe)
if (file_exists(__DIR__ . '/includes/alerts.php')) {
    require_once __DIR__ . '/includes/alerts.php';
}

if (!isKohaLoggedIn()) {
    header('Location: ' . KOHA_INTRANET_URL . '/cgi-bin/koha/mainpage.pl');
    exit;
}

// ============================================================
// v8.4 — HTML ENTITY HELPERS (local fallbacks)
// ============================================================
if (!function_exists('vms_normalize_text')) {
    function vms_normalize_text($value) {
        if ($value === null) return '';
        return html_entity_decode((string)$value, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    }
}
if (!function_exists('vms_h')) {
    function vms_h($value) {
        return htmlspecialchars(
            vms_normalize_text($value),
            ENT_QUOTES | ENT_HTML5,
            'UTF-8'
        );
    }
}
if (!function_exists('vms_plain')) {
    function vms_plain($value) {
        return vms_normalize_text($value);
    }
}

// ============================================================
// USER + SETTINGS BOOTSTRAP
// ============================================================
$user        = getCurrentUser();
$settings    = getSettings();
$currentPage = basename($_SERVER['PHP_SELF'], '.php');
$csrfToken   = generateCSRFToken();

// ============================================================
// GET SETTINGS WITH FALLBACKS (normalised)
// ============================================================
$adminHeaderBg            = $settings['header_bg']              ?? '#1e3c72';
$adminHeaderTextColor     = $settings['header_text_color']      ?? '#ffffff';
$adminHeaderHeight        = $settings['header_height']          ?? '80px';
$adminHeaderText          = vms_normalize_text($settings['header_text']    ?? 'Visitor Management');
$adminHeaderSubtext       = vms_normalize_text($settings['header_subtext'] ?? '');
$showAdminHeaderLogo      = $settings['show_header_logo']       ?? 1;
$showAdminInstitutionName = $settings['show_institution_name']  ?? 1;
$primaryColor             = $settings['primary_color']          ?? '#1e3c72';
$fontFamily               = $settings['font_family']            ?? 'Inter';
$bodyBg                   = $settings['body_bg']                ?? '#f0f2f5';

// v8.4 — normalise institution name so "Library & information" renders correctly
$institutionName          = vms_normalize_text($settings['institution_name'] ?? 'Library');

// ============================================================
// ALERT SYSTEM SETTINGS
// ============================================================
$alertSoundEnabled    = $settings['alert_sound_enabled']    ?? 1;
$alertAutoRefresh     = (int)($settings['alert_auto_refresh'] ?? 10);
$unauthorizedAlertOn  = $settings['book_unauthorized_alert'] ?? 1;

// ============================================================
// SAFE COUNTERS (wrapped so missing tables never break the header)
// ============================================================
$alertsNeedingAttention = 0;
$unauthorizedBooks      = 0;
$recentAlerts           = [];
$todayEntries           = 0;
// v8.5 — $openStockSessions and $activeComputerSessions were removed
// because their nav links were removed.

try {
    $db = getDB();

    // --- Alerts needing attention ---
    if (function_exists('getAlertStatistics')) {
        $alertStats = getAlertStatistics();
        $alertsNeedingAttention = (int)($alertStats['pending'] ?? 0);
    } else {
        try {
            $alertsNeedingAttention = (int)$db->query(
                "SELECT COUNT(*) FROM book_alerts WHERE acknowledged = 0 AND resolved = 0"
            )->fetchColumn();
        } catch (PDOException $e) { $alertsNeedingAttention = 0; }
    }

    // --- Unauthorized books ---
    if (function_exists('getUnauthorizedBookCount')) {
        $unauthorizedBooks = (int)getUnauthorizedBookCount();
    } else {
        try {
            $unauthorizedBooks = (int)$db->query(
                "SELECT COUNT(*) FROM book_exit_logs WHERE is_authorized = 0"
            )->fetchColumn();
        } catch (PDOException $e) { $unauthorizedBooks = 0; }
    }

    // Fallback — if book_alerts missing but unauthorized books exist, use that count
    if ($alertsNeedingAttention === 0 && $unauthorizedBooks > 0) {
        $alertsNeedingAttention = $unauthorizedBooks;
    }

    // --- Recent alerts for dropdown ---
    if (function_exists('getPendingAlerts')) {
        $recentAlerts = getPendingAlerts(5);
    } else {
        try {
            $recentAlerts = $db->query("
                SELECT id, id AS log_id, book_barcode, book_title, book_author,
                       member_name, member_admno, photo_path, created_at
                FROM book_exit_logs
                WHERE is_authorized = 0
                ORDER BY created_at DESC
                LIMIT 5
            ")->fetchAll();
        } catch (PDOException $e) { $recentAlerts = []; }
    }

    // --- Today's entries (used by logs link badge) ---
    if (function_exists('getTodayEntries')) {
        $todayEntries = (int)getTodayEntries();
    } else {
        try {
            $todayEntries = (int)$db->query("
                SELECT COUNT(*) FROM entry_exit_logs WHERE entry_date = CURDATE()
            ")->fetchColumn();
        } catch (PDOException $e) { $todayEntries = 0; }
    }

} catch (Exception $e) {
    error_log("Header loading error: " . $e->getMessage());
}

// ============================================================
// GET ADMIN HEADER LOGO
// ============================================================
if (!function_exists('getAdminHeaderLogo')) {
    function getAdminHeaderLogo() {
        $settings  = getSettings();
        $logoPath  = $settings['institution_logo'] ?? '';
        $uploadDir = __DIR__ . '/uploads/logos/';
        if (!empty($logoPath) && file_exists($uploadDir . $logoPath)) {
            $data = @file_get_contents($uploadDir . $logoPath);
            if ($data !== false) {
                $finfo = finfo_open(FILEINFO_MIME_TYPE);
                $mime  = finfo_buffer($finfo, $data);
                finfo_close($finfo);
                return 'data:' . $mime . ';base64,' . base64_encode($data);
            }
        }
        return null;
    }
}

$adminLogo = getAdminHeaderLogo();

// ============================================================
// USER INITIALS + NORMALISED USER NAME
// ============================================================
$userFullName = vms_normalize_text($user['full_name'] ?? '');
$userUsername = vms_normalize_text($user['username']  ?? '');

$initials = '';
if (!empty($userFullName)) {
    $parts = explode(' ', $userFullName);
    foreach ($parts as $p) {
        if (!empty($p[0])) $initials .= strtoupper($p[0]);
    }
    $initials = substr($initials, 0, 2);
}
if (empty($initials) && !empty($userUsername)) {
    $initials = strtoupper(substr($userUsername, 0, 2));
}
if (empty($initials)) {
    $initials = 'U';
}

$pageTitle    = isset($pageTitle) ? vms_normalize_text($pageTitle) : 'Dashboard';
$appVersion   = defined('APP_VERSION') ? APP_VERSION : '8.5.0';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?= vms_h($csrfToken) ?>">
    <meta name="alert-auto-refresh" content="<?= (int)$alertAutoRefresh ?>">
    <meta name="alert-sound-enabled" content="<?= (int)$alertSoundEnabled ?>">
    <title><?= vms_h($pageTitle) ?> - <?= vms_h($institutionName) ?></title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=<?= urlencode($fontFamily) ?>:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/admin.css">

    <style>
        :root {
            --primary:       <?= $primaryColor ?>;
            --sidebar-bg:    <?= $adminHeaderBg ?>;
            --font-family:   '<?= $fontFamily ?>', sans-serif;
            --header-bg:     <?= $adminHeaderBg ?>;
            --header-text:   <?= $adminHeaderTextColor ?>;
            --header-height: <?= $adminHeaderHeight ?>;
            --footer-bg:     <?= $settings['footer_bg'] ?? '#1e3c72' ?>;
            --body-bg:       <?= $bodyBg ?>;
        }

        * { font-family: var(--font-family); }
        body { background: var(--body-bg); }

        .wrapper { display: flex; min-height: 100vh; }

        /* ============ SIDEBAR ============ */
        .sidebar {
            width: 260px;
            min-height: 100vh;
            background: var(--sidebar-bg);
            color: rgba(255,255,255,0.85);
            position: fixed;
            left: 0; top: 0; bottom: 0;
            z-index: 1000;
            transition: all .3s;
            overflow-y: auto;
            box-shadow: 2px 0 12px rgba(0,0,0,0.08);
        }
        .sidebar::-webkit-scrollbar { width: 4px; }
        .sidebar::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.2); border-radius: 4px; }

        .sidebar-brand {
            padding: 20px 20px 15px;
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.08);
        }
        .sidebar-brand img {
            max-height: 55px;
            margin-bottom: 8px;
            border-radius: 10px;
            background: white;
            padding: 4px 12px;
        }
        .sidebar-brand h5 {
            color: white;
            font-weight: 700;
            margin: 0;
            font-size: 1rem;
            letter-spacing: -0.5px;
            word-break: break-word;
        }
        .sidebar-brand small {
            color: rgba(255,255,255,0.5);
            font-size: 0.65rem;
            letter-spacing: 0.5px;
        }

        /* ============ SIDEBAR ALERT BANNER ============ */
        .sidebar-alert-banner {
            background: linear-gradient(135deg, #dc3545, #c82333);
            color: #fff !important;
            padding: 12px 16px;
            margin: 12px;
            border-radius: 12px;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            display: block;
            animation: alertPulse 2s infinite;
        }
        .sidebar-alert-banner:hover {
            transform: scale(1.02);
            box-shadow: 0 8px 25px rgba(220, 53, 69, 0.4);
            color: #fff !important;
        }
        .sidebar-alert-banner .alert-count {
            font-size: 1.6rem;
            font-weight: 800;
            line-height: 1;
        }
        .sidebar-alert-banner .alert-text {
            font-size: 0.7rem;
            opacity: 0.9;
            font-weight: 500;
        }
        .sidebar-alert-banner .alert-icon {
            font-size: 1.4rem;
            animation: blink 1s infinite;
        }

        @keyframes alertPulse {
            0%, 100% { box-shadow: 0 0 0 0 rgba(220, 53, 69, 0.7); }
            50%      { box-shadow: 0 0 0 8px rgba(220, 53, 69, 0); }
        }
        @keyframes blink {
            0%, 100% { opacity: 1; }
            50%      { opacity: 0.4; }
        }
        @keyframes badgePulse {
            0%, 100% { transform: scale(1); }
            50%      { transform: scale(1.15); }
        }
        @keyframes slideInRight {
            from { transform: translateX(100%); opacity: 0; }
            to   { transform: translateX(0); opacity: 1; }
        }

        /* ============ SIDEBAR NAV ============ */
        .sidebar-nav { padding: 12px 0 24px; }
        .sidebar-nav .nav-section {
            padding: 12px 22px 4px;
            font-size: 0.65rem;
            text-transform: uppercase;
            letter-spacing: 1.5px;
            color: rgba(255,255,255,0.35);
            font-weight: 600;
        }
        .sidebar-nav .nav-item { padding: 0 12px; margin-bottom: 2px; }
        .sidebar-nav .nav-link {
            color: rgba(255,255,255,0.7);
            padding: 9px 16px;
            border-radius: 10px;
            transition: all .25s;
            font-weight: 500;
            font-size: 0.85rem;
            display: flex;
            align-items: center;
            gap: 12px;
            text-decoration: none;
        }
        .sidebar-nav .nav-link:hover,
        .sidebar-nav .nav-link.active {
            background: rgba(255,255,255,0.12);
            color: white;
        }
        .sidebar-nav .nav-link i {
            width: 20px;
            text-align: center;
            font-size: 1rem;
        }
        .sidebar-nav .nav-link .badge {
            margin-left: auto;
            background: rgba(255,255,255,0.15);
            color: white;
            border-radius: 20px;
            padding: 1px 10px;
            font-size: 0.65rem;
        }
        .sidebar-nav .nav-link .badge-danger {
            background: #dc3545;
            animation: badgePulse 2s infinite;
        }
        .sidebar-nav .nav-link .badge-success { background: #28a745; }
        .sidebar-nav .nav-link .badge-info    { background: #17a2b8; }
        .sidebar-nav .nav-link.alert-nav-link { color: #ff9999; }
        .sidebar-nav .nav-link.alert-nav-link:hover,
        .sidebar-nav .nav-link.alert-nav-link.active {
            background: rgba(220, 53, 69, 0.2);
            color: #ff6b6b;
        }

        /* ============ MAIN CONTENT ============ */
        .main-content {
            margin-left: 260px;
            flex: 1;
            padding: 20px 28px 25px;
            min-height: 100vh;
        }

        /* ============ TOPBAR ============ */
        .topbar {
            background: white;
            border-radius: 16px;
            padding: 10px 22px;
            margin-bottom: 25px;
            box-shadow: 0 2px 12px rgba(0,0,0,0.04);
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 10px;
        }
        .topbar-left { display: flex; align-items: center; gap: 14px; }
        .topbar-left h4 {
            margin: 0;
            font-weight: 700;
            font-size: 1.15rem;
            color: var(--primary);
        }
        .topbar-left small { color: #6c757d; font-size: 0.8rem; }
        .sidebar-toggle {
            display: none;
            background: none;
            border: none;
            color: var(--primary);
            font-size: 1.3rem;
            padding: 4px 8px;
            cursor: pointer;
        }
        .topbar-right {
            display: flex;
            align-items: center;
            gap: 12px;
            flex-wrap: wrap;
        }

        /* ============ ALERT BELL ============ */
        .alert-bell {
            position: relative;
            width: 42px;
            height: 42px;
            border-radius: 50%;
            background: #f8f9fa;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.2s ease;
            border: 1px solid transparent;
            color: #6c757d;
            text-decoration: none;
        }
        .alert-bell:hover {
            background: #e9ecef;
            border-color: #dee2e6;
            color: var(--primary);
            text-decoration: none;
        }
        .alert-bell.has-alerts {
            background: #fff5f5;
            border-color: #dc3545;
            color: #dc3545;
            animation: alertPulse 2s infinite;
        }
        .alert-bell.has-alerts:hover { background: #ffe0e0; color: #c82333; }
        .alert-bell .bell-count {
            position: absolute;
            top: -4px;
            right: -4px;
            background: #dc3545;
            color: white;
            font-size: 0.65rem;
            font-weight: 700;
            min-width: 20px;
            height: 20px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 0 5px;
            border: 2px solid white;
            animation: badgePulse 2s infinite;
        }
        .alert-bell .bell-icon { font-size: 1.1rem; }
        .alert-bell.no-alerts .bell-icon { opacity: 0.5; }

        /* ============ ALERT DROPDOWN ============ */
        .alert-dropdown {
            width: 380px;
            max-width: calc(100vw - 40px);
            padding: 0;
            border-radius: 16px;
            overflow: hidden;
            box-shadow: 0 12px 40px rgba(0,0,0,0.15);
            border: none;
        }
        .alert-dropdown-header {
            background: linear-gradient(135deg, #dc3545, #c82333);
            color: white;
            padding: 15px 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        .alert-dropdown-header h6 {
            margin: 0;
            font-weight: 700;
            font-size: 0.9rem;
        }
        .alert-dropdown-header .badge {
            background: rgba(255,255,255,0.25);
            color: white;
            font-size: 0.7rem;
        }
        .alert-dropdown-body {
            max-height: 350px;
            overflow-y: auto;
            padding: 0;
        }
        .alert-dropdown-body::-webkit-scrollbar { width: 4px; }
        .alert-dropdown-body::-webkit-scrollbar-thumb {
            background: #dce4ed;
            border-radius: 4px;
        }
        .alert-dropdown-item {
            padding: 12px 18px;
            border-bottom: 1px solid #f0f0f0;
            cursor: pointer;
            transition: all 0.2s ease;
            display: block;
            text-decoration: none;
            color: inherit;
        }
        .alert-dropdown-item:hover { background: #f8f9fa; color: inherit; }
        .alert-dropdown-item:last-child { border-bottom: none; }
        .alert-dropdown-item .alert-title {
            font-weight: 600;
            font-size: 0.85rem;
            color: #dc3545;
            margin-bottom: 2px;
        }
        .alert-dropdown-item .alert-subtitle {
            font-size: 0.75rem;
            color: #6c757d;
        }
        .alert-dropdown-item .alert-time {
            font-size: 0.65rem;
            color: #adb5bd;
            margin-top: 4px;
        }
        .alert-dropdown-footer {
            padding: 10px 20px;
            background: #f8f9fa;
            text-align: center;
            border-top: 1px solid #e9ecef;
        }
        .alert-dropdown-footer a {
            font-size: 0.8rem;
            color: var(--primary);
            text-decoration: none;
            font-weight: 600;
        }
        .alert-dropdown-footer a:hover { text-decoration: underline; }

        /* ============ USER INFO ============ */
        .user-info {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 4px 14px 4px 4px;
            border-radius: 30px;
            background: #f8f9fa;
            cursor: pointer;
            transition: all .2s;
            border: 1px solid transparent;
            text-decoration: none;
        }
        .user-info:hover {
            background: #e9ecef;
            border-color: #dee2e6;
            text-decoration: none;
        }
        .user-info .avatar {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            background: var(--primary);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            font-size: 0.9rem;
            flex-shrink: 0;
            overflow: hidden;
        }
        .user-info .avatar img { width: 100%; height: 100%; object-fit: cover; }
        .user-info .name {
            font-weight: 600;
            font-size: 0.85rem;
            color: #2c3e50;
            line-height: 1.2;
        }
        .user-info .role { font-size: 0.65rem; color: #6c757d; line-height: 1.2; }

        /* ============ DROPDOWN MENU ============ */
        .dropdown-menu {
            border: none;
            border-radius: 14px;
            box-shadow: 0 8px 30px rgba(0,0,0,0.12);
            padding: 8px 0;
            min-width: 200px;
            margin-top: 6px;
        }
        .dropdown-menu .dropdown-item {
            padding: 8px 20px;
            font-size: 0.85rem;
            color: #2c3e50;
            transition: all .15s;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .dropdown-menu .dropdown-item:hover {
            background: #f0f2f5;
            color: var(--primary);
        }
        .dropdown-menu .dropdown-item i {
            width: 18px;
            text-align: center;
            color: #6c757d;
            font-size: 0.9rem;
        }
        .dropdown-menu .dropdown-item.text-danger i { color: #dc3545; }
        .dropdown-menu .dropdown-divider { margin: 6px 12px; border-color: #e9ecef; }

        /* ============ STAT CARDS ============ */
        .stat-card {
            background: white;
            border-radius: 16px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.04);
            text-align: center;
            transition: all .3s;
        }
        .stat-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 8px 30px rgba(0,0,0,0.08);
        }
        .stat-card .stat-icon { font-size: 2.2rem; opacity: 0.3; margin-bottom: 4px; }
        .stat-card .stat-number { font-size: 1.8rem; font-weight: 700; color: #1e3c72; }
        .stat-card .stat-label { color: #6c757d; font-size: 0.8rem; }
        .stat-card.primary .stat-number { color: #1e3c72; }
        .stat-card.success .stat-number { color: #28a745; }
        .stat-card.danger  .stat-number { color: #dc3545; }
        .stat-card.info    .stat-number { color: #17a2b8; }

        .greeting-card {
            background: white;
            border-radius: 16px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.04);
        }
        .avatar-lg {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            overflow: hidden;
            background: var(--primary);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.8rem;
            font-weight: 700;
            flex-shrink: 0;
        }
        .avatar-lg img { width: 100%; height: 100%; object-fit: cover; }

        .quick-actions {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(100px, 1fr));
            gap: 10px;
        }
        .quick-btn {
            background: white;
            border-radius: 12px;
            padding: 12px 10px;
            text-align: center;
            box-shadow: 0 2px 8px rgba(0,0,0,0.04);
            transition: all .3s;
            text-decoration: none;
            color: #2c3e50;
            border: 1px solid transparent;
        }
        .quick-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.08);
            border-color: var(--primary);
            color: var(--primary);
        }
        .quick-btn i {
            font-size: 1.4rem;
            display: block;
            margin-bottom: 4px;
            color: var(--primary);
        }
        .quick-btn span { font-size: 0.7rem; font-weight: 500; }

        .card {
            border: none;
            border-radius: 16px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.04);
        }
        .card-header {
            background: transparent;
            border-bottom: 1px solid #e9ecef;
            padding: 14px 20px;
        }
        .card-header .card-title {
            margin: 0;
            font-weight: 600;
            color: #2c3e50;
            font-size: 0.95rem;
        }

        /* ============ GLOBAL ALERT BANNER ============ */
        .global-alert-banner {
            background: linear-gradient(135deg, #dc3545, #c82333);
            color: #fff !important;
            padding: 16px 24px;
            border-radius: 16px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            flex-wrap: wrap;
            gap: 12px;
            animation: alertPulse 2s infinite;
        }
        .global-alert-banner:hover {
            transform: scale(1.01);
            box-shadow: 0 8px 30px rgba(220, 53, 69, 0.4);
            color: #fff !important;
        }
        .global-alert-banner .banner-left {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        .global-alert-banner .banner-icon {
            font-size: 2rem;
            animation: blink 1s infinite;
        }
        .global-alert-banner .banner-title {
            font-size: 1.1rem;
            font-weight: 700;
            margin-bottom: 2px;
        }
        .global-alert-banner .banner-subtitle {
            font-size: 0.85rem;
            opacity: 0.9;
        }
        .global-alert-banner .banner-badge {
            background: white;
            color: #dc3545;
            padding: 8px 20px;
            border-radius: 30px;
            font-weight: 800;
            font-size: 1.3rem;
            white-space: nowrap;
        }

        /* ============ TOAST ============ */
        .vms-toast-container {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 99999;
            display: flex;
            flex-direction: column;
            gap: 10px;
            max-width: 380px;
            pointer-events: none;
        }
        .vms-toast {
            background: white;
            border-radius: 14px;
            padding: 15px 20px;
            box-shadow: 0 12px 40px rgba(0,0,0,0.15);
            display: flex;
            align-items: flex-start;
            gap: 12px;
            animation: slideInRight 0.3s ease;
            border-left: 4px solid var(--primary);
            pointer-events: auto;
        }
        .vms-toast.danger  { border-left-color: #dc3545; }
        .vms-toast.success { border-left-color: #28a745; }
        .vms-toast.warning { border-left-color: #ffc107; }
        .vms-toast.info    { border-left-color: #17a2b8; }
        .vms-toast .toast-icon { font-size: 1.3rem; flex-shrink: 0; }
        .vms-toast.danger  .toast-icon { color: #dc3545; }
        .vms-toast.success .toast-icon { color: #28a745; }
        .vms-toast.warning .toast-icon { color: #ffc107; }
        .vms-toast.info    .toast-icon { color: #17a2b8; }
        .vms-toast .toast-content { flex: 1; }
        .vms-toast .toast-title {
            font-weight: 700;
            font-size: 0.9rem;
            margin-bottom: 2px;
        }
        .vms-toast .toast-message { font-size: 0.8rem; color: #6c757d; }
        .vms-toast .toast-close {
            background: none;
            border: none;
            color: #adb5bd;
            cursor: pointer;
            padding: 0;
            font-size: 1rem;
        }

        /* ============ SIDEBAR OVERLAY ============ */
        .sidebar-overlay {
            display: none;
            position: fixed;
            top: 0; left: 0; right: 0; bottom: 0;
            background: rgba(0,0,0,0.4);
            z-index: 999;
        }
        .sidebar-overlay.show { display: block; }

        /* ============ RESPONSIVE ============ */
        @media (max-width: 992px) {
            .sidebar { transform: translateX(-100%); width: 280px; }
            .sidebar.show { transform: translateX(0); }
            .main-content { margin-left: 0; }
            .sidebar-toggle { display: block; }
        }
        @media (max-width: 576px) {
            .topbar { flex-direction: column; align-items: stretch; }
            .topbar-right { justify-content: space-between; }
            .main-content { padding: 12px 14px 16px; }
            .stat-card .stat-number { font-size: 1.4rem; }
            .stat-card { padding: 14px; }
            .quick-actions {
                grid-template-columns: repeat(3, 1fr);
                gap: 6px;
            }
            .quick-btn { padding: 8px 6px; }
            .quick-btn i { font-size: 1rem; }
            .quick-btn span { font-size: 0.6rem; }
            .alert-dropdown { width: calc(100vw - 30px); }
            .global-alert-banner {
                flex-direction: column;
                text-align: center;
            }
            .global-alert-banner .banner-left {
                flex-direction: column;
                gap: 8px;
            }
            .vms-toast-container {
                left: 10px;
                right: 10px;
                max-width: none;
            }
        }
    </style>
</head>
<body>

<!-- SIDEBAR OVERLAY -->
<div class="sidebar-overlay" id="sidebarOverlay" onclick="toggleSidebar()"></div>

<!-- GLOBAL CONFIG FOR JS -->
<script>
window.VMS_CONFIG = {
    ajaxUrl:        'ajax.php',
    csrfToken:      '<?= vms_h($csrfToken) ?>',
    autoRefresh:    <?= (int)$alertAutoRefresh * 1000 ?>,
    soundEnabled:   <?= $alertSoundEnabled ? 'true' : 'false' ?>,
    initialAlerts:  <?= (int)$alertsNeedingAttention ?>,
    initialUnauth:  <?= (int)$unauthorizedBooks ?>
};
</script>

<!-- WRAPPER -->
<div class="wrapper">

    <!-- ============================================================
    SIDEBAR
    ============================================================ -->
    <nav class="sidebar" id="sidebar">
        <div class="sidebar-brand">
            <?php if ($adminLogo): ?>
                <img src="<?= vms_h($adminLogo) ?>" alt="Logo" loading="lazy">
            <?php else: ?>
                <i class="fas fa-door-open" style="font-size:2rem;color:white;display:block;margin-bottom:6px;"></i>
            <?php endif; ?>
            <h5><?= vms_h($institutionName) ?></h5>
            <small>v<?= vms_h($appVersion) ?></small>
        </div>

        <!-- SIDEBAR ALERT BANNER -->
        <?php if ($alertsNeedingAttention > 0 && $unauthorizedAlertOn): ?>
            <a href="alerts.php" class="sidebar-alert-banner" id="sidebarAlertBanner">
                <div class="d-flex align-items-center gap-2">
                    <div class="alert-icon">
                        <i class="fas fa-exclamation-triangle"></i>
                    </div>
                    <div class="flex-grow-1">
                        <div class="alert-count" id="sidebarAlertCount"><?= $alertsNeedingAttention ?></div>
                        <div class="alert-text" id="sidebarAlertText">
                            Unauthorized Alert<?= $alertsNeedingAttention > 1 ? 's' : '' ?>
                        </div>
                    </div>
                    <div><i class="fas fa-chevron-right"></i></div>
                </div>
            </a>
        <?php endif; ?>

        <div class="sidebar-nav">

            <!-- ==================== MAIN ==================== -->
            <div class="nav-section">Main</div>
            <div class="nav-item">
                <a href="dashboard.php" class="nav-link <?= in_array($currentPage, ['dashboard','index'], true) ? 'active' : '' ?>">
                    <i class="fas fa-chart-pie"></i> Dashboard
                </a>
            </div>
            <div class="nav-item">
                <a href="entries.php" class="nav-link <?= $currentPage=='entries'?'active':'' ?>">
                    <i class="fas fa-sign-in-alt"></i> Entry
                </a>
            </div>
            <div class="nav-item">
                <a href="exits.php" class="nav-link <?= $currentPage=='exits'?'active':'' ?>">
                    <i class="fas fa-sign-out-alt"></i> Exit
                </a>
            </div>
            <div class="nav-item">
                <a href="logs.php" class="nav-link <?= $currentPage=='logs'?'active':'' ?>">
                    <i class="fas fa-list"></i> Logs
                    <?php if ($todayEntries > 0): ?>
                        <span class="badge"><?= $todayEntries ?></span>
                    <?php endif; ?>
                </a>
            </div>

            <!-- ==================== MANAGEMENT ==================== -->
            <div class="nav-section">Management</div>
            <div class="nav-item">
                <a href="members.php" class="nav-link <?= $currentPage=='members'?'active':'' ?>">
                    <i class="fas fa-users"></i> Members
                </a>
            </div>
            <div class="nav-item">
                <a href="books.php" class="nav-link <?= $currentPage=='books'?'active':'' ?>">
                    <i class="fas fa-book"></i> Books
                    <?php if ($unauthorizedBooks > 0): ?>
                        <span class="badge badge-danger" id="booksBadge"><?= $unauthorizedBooks ?></span>
                    <?php endif; ?>
                </a>
            </div>
            <div class="nav-item">
                <a href="reports.php" class="nav-link <?= $currentPage=='reports'?'active':'' ?>">
                    <i class="fas fa-chart-line"></i> Reports
                </a>
            </div>

            <!-- ==================== SECURITY ==================== -->
            <div class="nav-section">Security &amp; Alerts</div>
            <div class="nav-item">
                <a href="alerts.php" class="nav-link alert-nav-link <?= $currentPage=='alerts'?'active':'' ?>">
                    <i class="fas fa-shield-alt"></i> Alert Center
                    <?php if ($alertsNeedingAttention > 0): ?>
                        <span class="badge badge-danger" id="sidebarAlertBadge"><?= $alertsNeedingAttention ?></span>
                    <?php endif; ?>
                </a>
            </div>

            <!-- ==================== ADVANCED ==================== -->
            <div class="nav-section">Advanced Features</div>
            <div class="nav-item">
                <a href="occupancy.php" class="nav-link <?= $currentPage=='occupancy'?'active':'' ?>">
                    <i class="fas fa-users"></i> Occupancy Monitor
                </a>
            </div>
            <div class="nav-item">
                <a href="appointments.php" class="nav-link <?= $currentPage=='appointments'?'active':'' ?>">
                    <i class="fas fa-calendar-check"></i> Appointments
                </a>
            </div>
            <div class="nav-item">
                <a href="guests.php" class="nav-link <?= $currentPage=='guests'?'active':'' ?>">
                    <i class="fas fa-user-friends"></i> Guest Management
                </a>
            </div>
            <div class="nav-item">
                <a href="evacuation.php" class="nav-link <?= $currentPage=='evacuation'?'active':'' ?>" style="color:#ff9999;">
                    <i class="fas fa-exclamation-triangle"></i> Evacuation List
                </a>
            </div>
            <div class="nav-item">
                <a href="feedback.php" class="nav-link <?= $currentPage=='feedback'?'active':'' ?>">
                    <i class="fas fa-star"></i> Feedback
                </a>
            </div>

            <!-- ==================== SYSTEM ==================== -->
            <div class="nav-section">System</div>
            <div class="nav-item">
                <a href="settings.php" class="nav-link <?= $currentPage=='settings'?'active':'' ?>">
                    <i class="fas fa-cog"></i> Settings
                </a>
            </div>
            <div class="nav-item">
                <a href="backup.php" class="nav-link <?= $currentPage=='backup'?'active':'' ?>">
                    <i class="fas fa-database"></i> Backup
                </a>
            </div>
            <div class="nav-item">
                <a href="diag.php" class="nav-link <?= $currentPage=='test'?'active':'' ?>">
                    <i class="fas fa-flask"></i> Diagnostic Test
                </a>
            </div>
            <div class="nav-item">
                <a href="profile.php" class="nav-link <?= $currentPage=='profile'?'active':'' ?>">
                    <i class="fas fa-user"></i> Profile
                </a>
            </div>
            <div class="nav-item">
                <a href="<?= htmlspecialchars(KOHA_OPAC_URL) ?>/visitor/" class="nav-link" target="_blank">
                    <i class="fas fa-door-open"></i> Public Kiosk
                </a>
            </div>
            <div class="nav-item">
                <a href="logout.php" class="nav-link">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </div>
        </div>
    </nav>

    <!-- ============================================================
    MAIN CONTENT
    ============================================================ -->
    <main class="main-content">

        <!-- ============================================================
        TOPBAR
        ============================================================ -->
        <div class="topbar">
            <div class="topbar-left">
                <button class="sidebar-toggle" onclick="toggleSidebar()">
                    <i class="fas fa-bars"></i>
                </button>
                <div>
                    <h4><?= vms_h($pageTitle) ?></h4>
                    <small><?= vms_h($institutionName) ?></small>
                </div>
            </div>
            <div class="topbar-right">

                <!-- ALERT BELL -->
                <div class="dropdown">
                    <a href="#"
                       class="alert-bell <?= $alertsNeedingAttention > 0 ? 'has-alerts' : 'no-alerts' ?>"
                       id="alertBell"
                       data-bs-toggle="dropdown"
                       data-bs-auto-close="outside"
                       aria-expanded="false"
                       title="<?= $alertsNeedingAttention > 0 ? $alertsNeedingAttention . ' pending alert(s)' : 'No pending alerts' ?>">
                        <i class="fas fa-bell bell-icon"></i>
                        <?php if ($alertsNeedingAttention > 0): ?>
                            <span class="bell-count" id="bellCount"><?= $alertsNeedingAttention ?></span>
                        <?php endif; ?>
                    </a>
                    <div class="dropdown-menu dropdown-menu-end alert-dropdown" id="alertDropdown">
                        <div class="alert-dropdown-header">
                            <h6><i class="fas fa-shield-alt me-2"></i>Security Alerts</h6>
                            <span class="badge" id="alertHeaderBadge"><?= $alertsNeedingAttention ?> pending</span>
                        </div>
                        <div class="alert-dropdown-body" id="alertDropdownBody">
                            <?php if (empty($recentAlerts)): ?>
                                <div class="text-center py-4 text-muted" id="alertEmptyState">
                                    <i class="fas fa-shield-alt fa-2x mb-2 d-block" style="opacity:0.3;"></i>
                                    <div style="font-size:0.85rem;">No pending alerts</div>
                                    <div style="font-size:0.75rem;">All clear!</div>
                                </div>
                            <?php else: ?>
                                <?php foreach ($recentAlerts as $alert): ?>
                                    <a href="alerts.php?id=<?= (int)$alert['id'] ?>" class="alert-dropdown-item">
                                        <div class="alert-title">
                                            <i class="fas fa-exclamation-triangle me-1"></i>
                                            <?= vms_h(substr($alert['book_title'] ?? 'Unknown', 0, 40)) ?>
                                        </div>
                                        <div class="alert-subtitle">
                                            <i class="fas fa-barcode me-1"></i>
                                            <?= vms_h($alert['book_barcode'] ?? '') ?>
                                            <?php if (!empty($alert['member_name'])): ?>
                                                · <i class="fas fa-user me-1"></i>
                                                <?= vms_h($alert['member_name']) ?>
                                            <?php endif; ?>
                                        </div>
                                        <div class="alert-time">
                                            <i class="fas fa-clock me-1"></i>
                                            <?= vms_h(function_exists('timeAgo') ? timeAgo($alert['created_at']) : $alert['created_at']) ?>
                                        </div>
                                    </a>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                        <div class="alert-dropdown-footer">
                            <a href="alerts.php">
                                <i class="fas fa-external-link-alt me-1"></i>
                                View All Alerts
                            </a>
                        </div>
                    </div>
                </div>

                <!-- USER INFO -->
                <div class="dropdown">
                    <a href="#" class="user-info" data-bs-toggle="dropdown" aria-expanded="false">
                        <div class="avatar">
                            <?php if (!empty($user['photo'])): ?>
                                <img src="<?= vms_h($user['photo']) ?>" alt="Avatar" loading="lazy">
                            <?php else: ?>
                                <?= vms_h($initials) ?>
                            <?php endif; ?>
                        </div>
                        <div>
                            <div class="name"><?= vms_h($userFullName ?: 'User') ?></div>
                            <div class="role"><i class="fas fa-user-tag"></i> <?= vms_h(ucfirst($user['role'] ?? 'Viewer')) ?></div>
                        </div>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item" href="profile.php"><i class="fas fa-user"></i> My Profile</a></li>
                        <li><a class="dropdown-item" href="settings.php"><i class="fas fa-cog"></i> Settings</a></li>
                        <li><a class="dropdown-item" href="diag.php"><i class="fas fa-flask"></i> System Test</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item text-danger" href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                    </ul>
                </div>
            </div>
        </div>

        <!-- ============================================================
        GLOBAL ALERT BANNER
        ============================================================ -->
        <?php if ($alertsNeedingAttention > 0 && $unauthorizedAlertOn): ?>
            <a href="alerts.php" class="global-alert-banner" id="globalAlertBanner">
                <div class="banner-left">
                    <div class="banner-icon">
                        <i class="fas fa-exclamation-triangle"></i>
                    </div>
                    <div>
                        <div class="banner-title">
                            🚨 UNAUTHORIZED BOOK EXIT<?= $alertsNeedingAttention > 1 ? 'S' : '' ?> DETECTED
                        </div>
                        <div class="banner-subtitle">
                            <?= $alertsNeedingAttention ?> pending alert<?= $alertsNeedingAttention > 1 ? 's' : '' ?> require your attention. Click to review and acknowledge.
                        </div>
                    </div>
                </div>
                <div class="banner-badge" id="globalBannerCount"><?= $alertsNeedingAttention ?></div>
            </a>
        <?php endif; ?>

        <!-- ============================================================
        TOAST CONTAINER
        ============================================================ -->
        <div class="vms-toast-container" id="toastContainer"></div>

        <!-- ============================================================
        CONTENT AREA (page content starts here)
        ============================================================ -->
        <div class="content-area">
