<?php
/**
 * ID Cards & Barcodes – Professional Edition
 * Version: 7.1 (Institution Name Entity Fix + v7.0 features)
 *
 * FIX (v7.1):
 *   • Aggressive institution-name normalization (multi-level entity decode).
 *   • Publishes clean plain string to JS as window.VMS_INSTITUTION_NAME.
 *   • Shared footer output buffered + post-processed to collapse &amp; chains.
 *   • Institution name in HTML uses ENT_QUOTES with double_encode=false.
 *
 * RETAINED from v7.0:
 *   • Toggle visibility of each info field (Name, Desig, Class/Dept, Div/Course, Contact, Year)
 *   • Custom label text for each field
 *   • Header text background color / box with padding, radius, opacity
 *   • Flexible info text alignment (left/center/right)
 *   • Full info position controls (top/bottom/left/right, negative allowed)
 *   • Header text transform (none/uppercase/lowercase/capitalize)
 *   • Info line-height control
 *   • Label/value separator selection
 *   • Font family selection
 *   • Field order (move up/down)
 *   • Persist preferences in localStorage
 *   • Koha integration with proper credentials
 *   • Footer matches isbn.php, class.php, labels.php, and OPAC (shared partial)
 */

// ============================================================
// BOOTSTRAP – Load main VMS config
// ============================================================
$configPaths = [
    __DIR__ . '/../includes/config.php',
    __DIR__ . '/includes/config.php',
    '/usr/share/koha/intranet/cgi-bin/visitor/includes/config.php',
];
$mainConfigLoaded = false;
foreach ($configPaths as $path) {
    if (file_exists($path)) {
        require_once $path;
        $mainConfigLoaded = true;
        break;
    }
}

// ============================================================
// LOAD SHARED FOOTER PARTIAL
// ============================================================
$footerPartialPaths = [
    __DIR__ . '/includes/footer_partial.php',
    __DIR__ . '/../includes/footer_partial.php',
    '/usr/share/koha/intranet/cgi-bin/visitor/includes/footer_partial.php',
    '/usr/share/koha/intranet/cgi-bin/koha/visitor/includes/footer_partial.php',
];
foreach ($footerPartialPaths as $p) {
    if (file_exists($p)) {
        require_once $p;
        break;
    }
}

// ============================================================
// HELPER FUNCTIONS - Only define if not already defined
// ============================================================
if (!function_exists('getInstitutionLogo')) {
    function getInstitutionLogo() {
        global $settings;
        return $settings['institution_logo'] ?? '';
    }
}

if (!function_exists('updateSettings')) {
    function updateSettings($data) {
        global $db;
        try {
            foreach ($data as $key => $value) {
                $stmt = $db->prepare("INSERT INTO settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = ?");
                $stmt->execute([$key, $value, $value]);
            }
            return true;
        } catch (PDOException $e) {
            error_log("updateSettings error: " . $e->getMessage());
            return false;
        }
    }
}

if ($mainConfigLoaded && function_exists('getDB') && function_exists('getSettings')) {
    $db = getDB();
    $settings = getSettings();
    $institutionName = $settings['institution_name'] ?? 'My Library';
    $institutionLogo = !empty($settings['institution_logo']) ? getInstitutionLogo() : '';

    try {
        $db->exec("
            CREATE TABLE IF NOT EXISTS members_extra (
                admno VARCHAR(50) PRIMARY KEY,
                designation TEXT,
                academic_year VARCHAR(10),
                photo_path TEXT
            )
        ");
    } catch (PDOException $e) {
        error_log("members_extra table check: " . $e->getMessage());
    }
} else {
    $institutionName = 'My Library';
    $institutionLogo = '';
    if (!isset($db)) {
        try {
            $db = new PDO("mysql:host=localhost;dbname=koha_library;charset=utf8mb4", 'koha_library', 'mysqlroot');
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            error_log("Fallback DB connection failed: " . $e->getMessage());
        }
    }
}

// ============================================================
// INSTITUTION NAME — deeply normalized to plain text  [CHANGED v7.1]
// ============================================================
/**
 * Aggressively normalize an institution name to plain text.
 *
 * "Library & information"          → "Library & information"
 * "Library &amp; information"       → "Library & information"
 * "Library &amp;amp; information"   → "Library & information"
 * "Library &amp;amp;amp; info"      → "Library & information"
 */
if (!function_exists('idcards_clean_institution')) {
    function idcards_clean_institution(string $raw): string {
        $raw = trim($raw);
        if ($raw === '') return 'My Library';

        if (!mb_check_encoding($raw, 'UTF-8')) {
            $fixed = @mb_convert_encoding($raw, 'UTF-8', 'ISO-8859-1');
            if ($fixed !== false && $fixed !== '') $raw = $fixed;
        }

        // Loop-decode until stable (max 5 passes)
        $prev = null; $out = $raw; $i = 0;
        while ($prev !== $out && $i < 5) {
            $prev = $out;
            $out  = html_entity_decode($out, ENT_QUOTES | ENT_HTML5, 'UTF-8');
            $i++;
        }

        // Defensive collapse of residual literal entity sequences
        $out = str_replace(
            ['&amp;amp;amp;', '&amp;amp;', '&amp;', '&AMP;', '&Amp;'],
            '&',
            $out
        );
        $out = str_replace(
            ['&quot;', '&#039;', '&#39;', '&apos;', '&lt;', '&gt;', '&nbsp;'],
            ['"',       "'",       "'",      "'",       '<',    '>',    ' '],
            $out
        );

        $out = preg_replace('/\s+/u', ' ', $out);
        $out = trim($out);

        return $out !== '' ? $out : 'My Library';
    }
}

// Normalize the name (whether it came from getSettings() or the fallback)
$institutionName = idcards_clean_institution((string)$institutionName);

// Also check if config.php defines a constant and prefer that (normalized)
if (defined('INSTITUTION_NAME') && trim((string)INSTITUTION_NAME) !== '') {
    $institutionName = idcards_clean_institution((string)INSTITUTION_NAME);
}

// Publish everywhere so any footer partial or JS can read it
$GLOBALS['institution_name'] = $institutionName;
$GLOBALS['institutionName']  = $institutionName;
$GLOBALS['INSTITUTION_NAME'] = $institutionName;

// ============================================================
// KOHA CONNECTION
// ============================================================
if (!defined('KOHA_DB_HOST')) {
    define('KOHA_DB_HOST', 'localhost');
    define('KOHA_DB_NAME', 'koha_library');
    define('KOHA_DB_USER', 'koha_library');
    define('KOHA_DB_PASS', 'mysqlroot');
}

$kohaConnected = false;
try {
    $koha = new PDO("mysql:host=".KOHA_DB_HOST.";dbname=".KOHA_DB_NAME.";charset=utf8mb4", KOHA_DB_USER, KOHA_DB_PASS);
    $koha->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $kohaConnected = true;
} catch (PDOException $e) {
    $kohaConnected = false;
    error_log("Koha connection failed: " . $e->getMessage());
}

// ============================================================
// HELPER FUNCTIONS - Database related
// ============================================================
if (!function_exists('getMemberExtra')) {
    function getMemberExtra($admno) {
        global $db;
        try {
            if (!$db) return [];
            $stmt = $db->prepare("SELECT * FROM members_extra WHERE admno = ?");
            $stmt->execute([$admno]);
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            return [];
        }
    }
}

if (!function_exists('setMemberExtra')) {
    function setMemberExtra($admno, $data) {
        global $db;
        try {
            if (!$db) return false;
            $stmt = $db->prepare("INSERT INTO members_extra (admno, designation, academic_year, photo_path) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE designation = VALUES(designation), academic_year = VALUES(academic_year), photo_path = VALUES(photo_path)");
            $stmt->execute([$admno, $data['designation'] ?? '', $data['academic_year'] ?? '', $data['photo_path'] ?? '']);
            return true;
        } catch (PDOException $e) {
            error_log("setMemberExtra error: " . $e->getMessage());
            return false;
        }
    }
}

// ============================================================
// AJAX ENDPOINTS
// ============================================================
if (isset($_GET['ajax_action']) || isset($_POST['ajax_action'])) {
    $action = $_GET['ajax_action'] ?? $_POST['ajax_action'] ?? '';
    header('Content-Type: application/json');

    if ($action === 'get_photo_base64') {
        $admno = $_GET['admno'] ?? '';
        if (empty($admno)) { echo json_encode(['success' => false, 'error' => 'No admno']); exit; }
        $extra = getMemberExtra($admno);
        if ($extra && !empty($extra['photo_path']) && file_exists($extra['photo_path'])) {
            $mime = mime_content_type($extra['photo_path']);
            $data = file_get_contents($extra['photo_path']);
            echo json_encode(['success' => true, 'base64' => 'data:' . $mime . ';base64,' . base64_encode($data)]);
            exit;
        }
        if ($kohaConnected) {
            try {
                $stmt = $koha->prepare("SELECT pi.imagefile FROM borrowers b JOIN patronimage pi ON b.borrowernumber = pi.borrowernumber WHERE b.cardnumber = ?");
                $stmt->execute([$admno]);
                $image = $stmt->fetchColumn();
                if ($image) {
                    echo json_encode(['success' => true, 'base64' => 'data:image/jpeg;base64,' . base64_encode($image)]);
                    exit;
                }
            } catch (PDOException $e) {
                error_log("get_photo_base64 error: " . $e->getMessage());
            }
        }
        echo json_encode(['success' => false, 'error' => 'No photo']);
        exit;
    }

    if ($action === 'all_books') {
        if ($kohaConnected) {
            try {
                $stmt = $koha->query("SELECT i.barcode, b.title, b.author FROM items i JOIN biblio b ON i.biblionumber = b.biblionumber WHERE i.notforloan = 0 ORDER BY b.title LIMIT 200");
                echo json_encode($stmt->fetchAll());
            } catch (PDOException $e) {
                echo json_encode([]);
            }
        } else {
            echo json_encode([
                ['barcode' => 'BK001', 'title' => 'The Great Gatsby', 'author' => 'F. Scott Fitzgerald'],
                ['barcode' => 'BK002', 'title' => '1984', 'author' => 'George Orwell'],
                ['barcode' => 'BK003', 'title' => 'To Kill a Mockingbird', 'author' => 'Harper Lee'],
                ['barcode' => 'BK004', 'title' => 'Pride and Prejudice', 'author' => 'Jane Austen']
            ]);
        }
        exit;
    }

    if ($action === 'books_by_date') {
        $from = $_GET['from'] ?? ''; $to = $_GET['to'] ?? '';
        if ($from && $to && $kohaConnected) {
            try {
                $stmt = $koha->prepare("SELECT i.barcode, b.title, b.author, i.itemcallnumber AS call_number, b.publishercode AS publisher, b.isbn FROM items i JOIN biblio b ON i.biblionumber = b.biblionumber WHERE b.datecreated BETWEEN ? AND ? ORDER BY b.datecreated DESC LIMIT 500");
                $stmt->execute([$from . ' 00:00:00', $to . ' 23:59:59']);
                echo json_encode(['success' => true, 'books' => $stmt->fetchAll()]);
            } catch (PDOException $e) {
                echo json_encode(['success' => false, 'error' => $e->getMessage()]);
            }
        } else {
            echo json_encode(['success' => false, 'error' => 'Invalid date range or Koha not connected']);
        }
        exit;
    }

    if ($action === 'books_by_barcodes') {
        $barcodes = json_decode($_POST['barcodes'] ?? '[]', true);
        if (!empty($barcodes) && $kohaConnected) {
            try {
                $placeholders = implode(',', array_fill(0, count($barcodes), '?'));
                $stmt = $koha->prepare("SELECT i.barcode, b.title, b.author, i.itemcallnumber AS call_number, b.publishercode AS publisher, b.isbn FROM items i JOIN biblio b ON i.biblionumber = b.biblionumber WHERE i.barcode IN ($placeholders)");
                $stmt->execute($barcodes);
                echo json_encode(['success' => true, 'books' => $stmt->fetchAll()]);
            } catch (PDOException $e) {
                echo json_encode(['success' => false, 'error' => $e->getMessage()]);
            }
        } else {
            echo json_encode(['success' => false, 'books' => []]);
        }
        exit;
    }

    if ($action === 'update_institution_settings') {
        $name = $_POST['institution_name'] ?? '';
        $logoData = $_POST['institution_logo'] ?? '';

        if (function_exists('updateSettings')) {
            $updateData = [];
            if ($name) $updateData['institution_name'] = $name;
            if ($logoData !== '') $updateData['institution_logo'] = $logoData;
            if (!empty($updateData)) {
                updateSettings($updateData);
                echo json_encode(['success' => true, 'message' => 'Settings updated successfully']);
            } else {
                echo json_encode(['success' => false, 'message' => 'No changes']);
            }
        } else {
            echo json_encode(['success' => false, 'message' => 'Update function not available']);
        }
        exit;
    }

    echo json_encode(['success' => false, 'error' => 'Invalid action']);
    exit;
}

// ============================================================
// FETCH MEMBERS FROM KOHA
// ============================================================
$members = [];

if ($kohaConnected) {
    try {
        $stmt = $koha->query("
            SELECT 
                b.cardnumber AS admno,
                CONCAT(b.firstname, ' ', b.surname) AS name,
                c.description AS member_category,
                b.sort1 AS class,
                b.sort2 AS division,
                b.phone,
                b.email,
                (SELECT imagefile FROM patronimage WHERE borrowernumber = b.borrowernumber LIMIT 1) AS photo_blob
            FROM borrowers b
            LEFT JOIN categories c ON b.categorycode = c.categorycode
            WHERE b.dateexpiry > CURDATE() 
              AND (b.gonenoaddress IS NULL OR b.gonenoaddress = 0)
              AND (b.lost IS NULL OR b.lost = 0)
            ORDER BY b.surname
            LIMIT 300
        ");
        $members = $stmt->fetchAll();
    } catch (PDOException $e) {
        error_log("Fetch members error: " . $e->getMessage());
    }
}

if (empty($members)) {
    $members = [
        ['admno' => 'S1001', 'name' => 'John Doe', 'member_category' => 'Student', 'class' => 'Science', 'division' => 'A', 'phone' => '1234567890', 'email' => 'john@example.com', 'photo_blob' => null],
        ['admno' => 'S1002', 'name' => 'Jane Smith', 'member_category' => 'Faculty', 'class' => 'Arts', 'division' => 'B', 'phone' => '0987654321', 'email' => 'jane@example.com', 'photo_blob' => null],
        ['admno' => 'S1003', 'name' => 'Robert Johnson', 'member_category' => 'Staff', 'class' => 'Admin', 'division' => 'C', 'phone' => '1122334455', 'email' => 'robert@example.com', 'photo_blob' => null],
        ['admno' => 'S1004', 'name' => 'Maria Garcia', 'member_category' => 'Student', 'class' => 'Engineering', 'division' => 'D', 'phone' => '5566778899', 'email' => 'maria@example.com', 'photo_blob' => null],
        ['admno' => 'S1005', 'name' => 'David Lee', 'member_category' => 'Faculty', 'class' => 'Business', 'division' => 'E', 'phone' => '6677889900', 'email' => 'david@example.com', 'photo_blob' => null],
        ['admno' => 'S1006', 'name' => 'Sarah Wilson', 'member_category' => 'Student', 'class' => 'Science', 'division' => 'F', 'phone' => '7788990011', 'email' => 'sarah@example.com', 'photo_blob' => null],
        ['admno' => 'S1007', 'name' => 'Michael Brown', 'member_category' => 'Staff', 'class' => 'Admin', 'division' => 'G', 'phone' => '8899001122', 'email' => 'michael@example.com', 'photo_blob' => null],
    ];
}

foreach ($members as &$m) {
    $extra = getMemberExtra($m['admno']);
    $m['designation'] = $extra['designation'] ?? $m['member_category'] ?? '';
    $m['academic_year'] = $extra['academic_year'] ?? '';
    $m['photo_path'] = $extra['photo_path'] ?? '';
    $m['photo_url'] = !empty($m['photo_path']) && file_exists($m['photo_path']) ? 'data:image/jpeg;base64,' . base64_encode(file_get_contents($m['photo_path'])) : (!empty($m['photo_blob']) ? 'data:image/jpeg;base64,' . base64_encode($m['photo_blob']) : '');
    unset($m['photo_blob']);
}

// ============================================================
// RENDER PAGE
// ============================================================
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ID Cards – Professional Edition v7.1</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Roboto:wght@300;400;500;700;900&family=Open+Sans:wght@300;400;600;700;800&family=Lato:wght@300;400;700;900&family=Montserrat:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #1a2a6c;
            --shadow-sm: 0 2px 12px rgba(0,0,0,0.06);
            --shadow-md: 0 8px 32px rgba(0,0,0,0.10);
            --shadow-lg: 0 16px 48px rgba(0,0,0,0.14);
            --radius-lg: 24px;
            --radius-md: 16px;
            --radius-sm: 12px;
            --transition: all 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94);
            --card-width: 350px;
            --card-height: 220px;
        }

        body {
            font-family: 'Inter', -apple-system, sans-serif;
            background: #eef2f7;
            padding: 20px;
            min-height: 100vh;
        }

        .app-header {
            background: linear-gradient(135deg, #1a2a6c 0%, #2a4a8a 50%, #3a6aaa 100%);
            padding: 20px 30px;
            border-radius: var(--radius-lg);
            margin-bottom: 28px;
            box-shadow: var(--shadow-lg);
        }
        .app-header .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
        }
        .app-header .header-left {
            display: flex;
            align-items: center;
            gap: 18px;
        }
        .app-header .header-left .icon-wrapper {
            width: 56px;
            height: 56px;
            border-radius: var(--radius-md);
            background: rgba(255,255,255,0.15);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 28px;
            color: #ffd700;
        }
        .app-header h1 {
            color: white;
            font-weight: 800;
            font-size: 1.8rem;
            margin: 0;
        }
        .app-header p {
            color: rgba(255,255,255,0.7);
            margin: 0;
            font-size: 0.85rem;
        }
        .app-header .badge-version {
            background: rgba(255,215,0,0.2);
            color: #ffd700;
            padding: 6px 16px;
            border-radius: 30px;
            font-size: 0.7rem;
            font-weight: 600;
            border: 1px solid rgba(255,215,0,0.15);
        }
        .koha-status {
            background: rgba(255,255,255,0.1);
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.7rem;
            color: rgba(255,255,255,0.8);
        }
        .koha-status .connected { color: #7dffb3; }
        .koha-status .disconnected { color: #ff7d7d; }

        .glass-settings {
            background: rgba(255,255,255,0.85);
            backdrop-filter: blur(20px);
            border-radius: var(--radius-lg);
            padding: 18px 24px;
            margin-bottom: 24px;
            border: 1px solid rgba(255,255,255,0.5);
            box-shadow: var(--shadow-sm);
        }
        .glass-settings .settings-grid {
            display: flex;
            flex-wrap: wrap;
            gap: 12px;
            align-items: flex-end;
        }
        .glass-settings .btn-save {
            background: linear-gradient(135deg, #1a2a6c, #2a4a8a);
            color: white;
            border: none;
            padding: 8px 28px;
            border-radius: var(--radius-sm);
            font-weight: 600;
            transition: var(--transition);
        }
        .glass-settings .btn-save:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(26,42,108,0.3);
        }

        .card-premium {
            background: rgba(255,255,255,0.85);
            backdrop-filter: blur(20px);
            border-radius: var(--radius-lg);
            border: 1px solid rgba(255,255,255,0.5);
            box-shadow: var(--shadow-sm);
            transition: var(--transition);
            overflow: hidden;
            margin-bottom: 20px;
        }
        .card-premium:hover {
            box-shadow: var(--shadow-md);
            transform: translateY(-2px);
        }
        .card-premium .card-header-premium {
            padding: 16px 24px;
            background: rgba(255,255,255,0.5);
            border-bottom: 1px solid rgba(0,0,0,0.04);
            font-weight: 700;
            font-size: 0.95rem;
            color: var(--primary);
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .card-premium .card-body-premium {
            padding: 20px 24px;
        }

        .member-list {
            max-height: 320px;
            overflow-y: auto;
            border-radius: var(--radius-sm);
            border: 1px solid #e9ecef;
            padding: 4px;
        }
        .member-list::-webkit-scrollbar { width: 4px; }
        .member-list::-webkit-scrollbar-thumb { background: #dce4ed; border-radius: 4px; }
        .member-item {
            padding: 10px 14px;
            border-radius: var(--radius-sm);
            cursor: pointer;
            transition: var(--transition);
            border-left: 3px solid transparent;
            margin-bottom: 2px;
        }
        .member-item:hover {
            background: rgba(26,42,108,0.04);
            transform: translateX(4px);
        }
        .member-item.selected {
            background: rgba(26,42,108,0.08);
            border-left-color: var(--primary);
        }
        .member-item .member-name { font-weight: 600; color: #2c3e50; }
        .member-item .member-detail { font-size: 0.75rem; color: #6c757d; margin-top: 2px; }

        .id-card-container {
            display: flex;
            flex-wrap: wrap;
            gap: 24px;
            justify-content: center;
        }

        .id-card {
            width: var(--card-width);
            height: var(--card-height);
            border-radius: 16px;
            padding: 16px;
            position: relative;
            overflow: hidden;
            transition: var(--transition);
            box-shadow: 0 8px 30px rgba(0,0,0,0.10);
            flex-shrink: 0;
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
        }
        .id-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 16px 48px rgba(0,0,0,0.18);
        }

        .id-card .card-bg-overlay {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            z-index: 0;
            background: inherit;
            opacity: var(--bg-opacity, 0.3);
        }

        .id-card .card-content {
            position: relative;
            z-index: 1;
            height: 100%;
            display: flex;
            flex-direction: column;
        }

        .id-card .card-logo {
            position: absolute;
            left: var(--logo-left, 14px);
            top: var(--logo-top, 14px);
            width: var(--logo-width, 42px);
            height: var(--logo-height, 42px);
            border-radius: 10px;
            background: rgba(255,255,255,0.9);
            padding: 4px;
            object-fit: contain;
            z-index: 2;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        }

        .id-card .card-photo {
            position: absolute;
            right: var(--photo-right, 14px);
            top: var(--photo-top, 14px);
            width: var(--photo-width, 80px);
            height: var(--photo-height, 95px);
            border-radius: var(--photo-radius, 10px);
            border: var(--photo-border-width, 2px) solid var(--photo-border-color, rgba(255,255,255,0.3));
            overflow: hidden;
            display: flex;
            align-items: center;
            justify-content: center;
            background: rgba(255,255,255,0.1);
            z-index: 2;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        .id-card .card-photo img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        .id-card .card-photo i {
            font-size: 32px;
            color: rgba(255,255,255,0.4);
        }

        /* ===== HEADER TEXT with optional background ===== */
        .id-card .card-header-text {
            text-align: var(--header-align, center);
            margin-bottom: 6px;
            z-index: 2;
            position: relative;
            margin-top: var(--header-top, 0px);
            padding: var(--header-padding, 0px) var(--header-padding-x, 0px);
            background: var(--header-bg, transparent);
            border-radius: var(--header-radius, 0px);
            opacity: var(--header-opacity, 1);
            font-family: var(--header-font-family, 'Inter'), sans-serif;
            text-transform: var(--header-transform, none);
            transition: all 0.2s ease;
        }
        .id-card .card-header-text .institution {
            font-size: var(--header-font-size, 16px);
            font-weight: var(--header-font-weight, 800);
            color: var(--header-color, inherit);
            letter-spacing: var(--header-letter-spacing, -0.3px);
            text-shadow: var(--header-text-shadow, none);
            line-height: var(--header-line-height, 1.2);
        }
        .id-card .card-header-text .tagline {
            font-size: var(--tagline-font-size, 8px);
            font-weight: var(--tagline-font-weight, 400);
            color: var(--tagline-color, rgba(255,255,255,0.7));
            letter-spacing: var(--tagline-letter-spacing, 0.5px);
            text-transform: var(--tagline-transform, uppercase);
            margin-top: var(--tagline-top, 0px);
            margin-bottom: var(--tagline-bottom, 0px);
            font-family: var(--tagline-font-family, 'Inter'), sans-serif;
        }

        /* ===== INFO BLOCK ===== */
        .id-card .card-info {
            margin-top: var(--info-top, 0px);
            margin-bottom: var(--info-bottom, 0px);
            padding-left: var(--info-left, 10px);
            padding-right: var(--info-right, 10px);
            font-size: var(--info-font-size, 10px);
            line-height: var(--info-line-height, 1.6);
            z-index: 2;
            position: relative;
            text-align: var(--info-align, left);
            font-family: var(--info-font-family, 'Inter'), sans-serif;
            color: var(--info-color, inherit);
        }
        .id-card .card-info .label {
            font-weight: var(--label-font-weight, 600);
            opacity: var(--label-opacity, 0.8);
            color: var(--label-color, inherit);
        }
        .id-card .card-info .value {
            font-weight: var(--value-font-weight, 400);
            color: var(--value-color, inherit);
        }
        .id-card .card-info .info-row {
            display: var(--info-row-display, flex);
            gap: 6px;
            margin-bottom: var(--info-row-gap, 0px);
            justify-content: var(--info-row-justify, flex-start);
            align-items: baseline;
        }
        .id-card .card-info .info-row.center { justify-content: center; }
        .id-card .card-info .info-row.right { justify-content: flex-end; }
        .id-card .card-info .info-row.hidden { display: none !important; }

        .id-card .card-id {
            position: absolute;
            right: var(--id-right, 14px);
            top: var(--id-top, 118px);
            font-size: var(--id-font-size, 8px);
            text-align: var(--id-align, center);
            opacity: var(--id-opacity, 0.8);
            z-index: 2;
            color: var(--id-color, inherit);
        }
        .id-card .card-id strong {
            font-weight: var(--id-font-weight, 700);
        }

        .id-card .card-year {
            position: absolute;
            bottom: var(--year-bottom, 10px);
            left: var(--year-left, 14px);
            font-size: var(--year-font-size, 9px);
            opacity: var(--year-opacity, 0.7);
            z-index: 2;
            font-weight: var(--year-font-weight, 400);
            color: var(--year-color, inherit);
        }
        .id-card .card-year.hidden { display: none !important; }

        .id-card .card-barcode {
            position: absolute;
            bottom: var(--barcode-bottom, 10px);
            left: 50%;
            transform: translateX(-50%);
            background: var(--barcode-bg, rgba(255,255,255,0.85));
            padding: var(--barcode-padding, 3px 10px);
            border-radius: var(--barcode-radius, 8px);
            z-index: 2;
        }
        .id-card .card-barcode svg {
            height: var(--barcode-height, 30px) !important;
        }

        .id-card .card-qrcode {
            position: absolute;
            bottom: var(--qrcode-bottom, 10px);
            left: 50%;
            transform: translateX(-50%);
            background: var(--qrcode-bg, rgba(255,255,255,0.85));
            padding: var(--qrcode-padding, 4px);
            border-radius: var(--qrcode-radius, 8px);
            z-index: 2;
        }
        .id-card .card-qrcode canvas {
            width: var(--qrcode-size, 50px);
            height: var(--qrcode-size, 50px);
        }

        .id-card.back {
            background: var(--back-bg, #f8f9fa);
            color: var(--back-text-color, #2c3e50);
            border: var(--back-border, 1px solid #e9ecef);
        }
        .id-card.back .card-back-content {
            padding: var(--back-padding, 12px);
            height: 100%;
            display: flex;
            flex-direction: column;
            position: relative;
            z-index: 1;
        }
        .id-card.back .card-back-content .rules-title {
            font-weight: var(--rules-title-weight, 700);
            font-size: var(--rules-title-size, 11px);
            color: var(--rules-title-color, var(--primary));
            margin-bottom: var(--rules-title-margin, 4px);
            text-align: var(--rules-title-align, left);
        }
        .id-card.back .card-back-content .rules-text {
            font-size: var(--rules-text-size, 8px);
            flex-grow: 1;
            opacity: var(--rules-text-opacity, 0.8);
            line-height: var(--rules-text-line-height, 1.5);
            color: var(--rules-text-color, inherit);
            text-align: var(--rules-text-align, left);
        }
        .id-card.back .card-back-content .signature-area {
            text-align: var(--signature-align, center);
            margin-top: var(--signature-margin-top, auto);
            font-size: var(--signature-font-size, 8px);
            color: var(--signature-color, inherit);
        }
        .id-card.back .card-back-content .signature-area .signature-line {
            border-top: var(--signature-line-width, 1px) solid var(--signature-line-color, #999);
            width: var(--signature-line-width-px, 60px);
            margin: var(--signature-line-margin, 4px auto);
        }
        .id-card.back .card-back-content .signature-area .signature-image {
            max-height: var(--signature-image-height, 30px);
            margin-bottom: var(--signature-image-margin, 2px);
        }
        .id-card.back .card-back-bg-overlay {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            z-index: 0;
            background-size: cover;
            background-position: center;
            opacity: var(--back-bg-opacity, 0.1);
        }

        .card-pair {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            justify-content: center;
            position: relative;
            page-break-inside: avoid;
        }
        .card-pair .card-checkbox {
            position: absolute;
            top: -8px;
            left: -8px;
            z-index: 10;
            width: 20px;
            height: 20px;
            accent-color: var(--primary);
        }
        .card-pair.selected-for-export .id-card {
            outline: 3px solid #28a745;
            outline-offset: 4px;
        }

        .btn-premium {
            padding: 8px 20px;
            border-radius: var(--radius-sm);
            font-weight: 600;
            font-size: 0.85rem;
            transition: var(--transition);
            border: none;
        }
        .btn-premium-primary {
            background: linear-gradient(135deg, #1a2a6c, #2a4a8a);
            color: white;
        }
        .btn-premium-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(26,42,108,0.3);
            color: white;
        }
        .btn-premium-success {
            background: linear-gradient(135deg, #11998e, #38ef7d);
            color: white;
        }
        .btn-premium-success:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(17,153,142,0.3);
            color: white;
        }

        .stats-bar {
            background: linear-gradient(135deg, #1a2a6c, #2a4a8a);
            color: white;
            padding: 12px 24px;
            border-radius: var(--radius-md);
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 10px;
            margin-bottom: 20px;
        }
        .stats-bar .stats-count {
            font-weight: 700;
            font-size: 1.1rem;
        }

        .theme-btn {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            cursor: pointer;
            margin: 2px;
            border: 2px solid transparent;
            transition: var(--transition);
        }
        .theme-btn.active {
            border-color: #333;
            transform: scale(1.1);
            box-shadow: 0 0 0 2px white, 0 0 0 4px #333;
        }
        .theme-btn:hover {
            transform: scale(1.05);
        }

        .color-picker {
            width: 32px;
            height: 32px;
            border-radius: 8px;
            border: 1px solid #ddd;
            padding: 2px;
            cursor: pointer;
        }

        .style-controls-toggle {
            cursor: pointer;
            user-select: none;
            transition: var(--transition);
        }
        .style-controls-toggle:hover {
            color: var(--primary);
        }
        .style-controls-toggle .toggle-icon {
            transition: transform 0.3s ease;
        }
        .style-controls-toggle.collapsed .toggle-icon {
            transform: rotate(-90deg);
        }
        .style-controls-body {
            transition: all 0.3s ease;
            overflow: hidden;
        }
        .style-controls-body.collapsed {
            max-height: 0 !important;
            padding: 0 !important;
            margin: 0 !important;
            border: none !important;
        }

        .field-toggle-row {
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 4px 0;
            border-bottom: 1px solid #f0f0f0;
        }
        .field-toggle-row:last-child { border-bottom: none; }
        .field-toggle-row .field-label {
            flex: 1;
            font-size: 0.75rem;
            font-weight: 500;
        }
        .field-toggle-row .field-label-input {
            width: 90px;
            font-size: 0.7rem;
            padding: 2px 6px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        .field-toggle-row .field-order-btn {
            width: 22px;
            height: 22px;
            padding: 0;
            font-size: 0.6rem;
            line-height: 1;
            border-radius: 4px;
        }
        .field-toggle-row .form-check-input {
            width: 34px;
            height: 18px;
            cursor: pointer;
        }

        .barcode-header-text {
            font-size: var(--barcode-header-size, 14px);
            font-weight: var(--barcode-header-weight, 700);
            color: var(--barcode-header-color, #1a2a6c);
            text-align: var(--barcode-header-align, center);
            margin-bottom: var(--barcode-header-margin, 8px);
            letter-spacing: var(--barcode-header-spacing, 0px);
        }

        @media (max-width: 768px) {
            .app-header { padding: 16px 20px; }
            .app-header h1 { font-size: 1.3rem; }
            .app-header .header-left .icon-wrapper { width: 44px; height: 44px; font-size: 20px; }
            .glass-settings { padding: 14px 16px; }
            .card-premium .card-body-premium { padding: 14px 16px; }
            .id-card { width: 280px; height: 180px; padding: 12px; }
            .id-card .card-photo { width: 60px; height: 75px; right: 10px; top: 10px; }
            .id-card .card-logo { width: 32px; height: 32px; left: 10px; top: 10px; }
            .id-card .card-info { font-size: 8px; }
            .id-card .card-id { right: 10px; top: 95px; font-size: 7px; }
            .id-card .card-year { font-size: 7px; }
            .id-card .card-barcode svg { height: 24px !important; }
            .id-card .card-header-text .institution { font-size: 13px; }
            .stats-bar { padding: 10px 16px; font-size: 0.85rem; }
        }

        @media (max-width: 480px) {
            body { padding: 10px; }
            .id-card { width: 240px; height: 160px; padding: 10px; }
            .id-card .card-photo { width: 50px; height: 65px; right: 8px; top: 8px; }
            .id-card .card-info { font-size: 7px; }
            .id-card .card-id { right: 8px; top: 80px; font-size: 6px; }
            .id-card .card-header-text .institution { font-size: 11px; }
            .id-card .card-barcode svg { height: 20px !important; }
        }

        @media print {
            .no-print { display: none !important; }
            .app-header { background: white !important; color: black !important; box-shadow: none !important; }
            .app-header h1 { color: black !important; }
            .glass-settings { display: none !important; }
            .card-premium { box-shadow: none !important; border: 1px solid #ddd !important; backdrop-filter: none !important; }
            .id-card { box-shadow: none !important; border: 1px solid #ddd !important; }
            .id-card.front { background: #f8f9fa !important; color: #333 !important; }
            .id-card .card-barcode { background: white !important; }
            .id-card .card-qrcode { background: white !important; }
            .stats-bar { display: none !important; }
            .card-checkbox { display: none !important; }
            .selected-for-export .id-card { outline: none !important; }
            .card-pair { page-break-inside: avoid; }
        }
    </style>
</head>
<body>

<!-- ============================================================
HEADER
============================================================ -->
<div class="app-header no-print">
    <div class="header-content">
        <div class="header-left">
            <div class="icon-wrapper"><i class="fas fa-id-card"></i></div>
            <div>
                <h1>ID Cards &amp; Barcodes</h1>
                <p>Professional Library Identity Management — v7.1</p>
            </div>
        </div>
        <div class="d-flex align-items-center gap-3">
            <span class="badge-version"><i class="fas fa-code-branch me-1"></i> v7.1</span>
            <span class="koha-status">
                <i class="fas fa-database me-1"></i>
                Koha: <span class="<?= $kohaConnected ? 'connected' : 'disconnected' ?>">
                    <?= $kohaConnected ? '✓ Connected' : '✗ Offline' ?>
                </span>
            </span>
            <a href="../index.php" class="btn btn-light btn-sm" style="background:rgba(255,255,255,0.1);color:white;border-color:rgba(255,255,255,0.2);">
                <i class="fas fa-home me-1"></i> Home
            </a>
        </div>
    </div>
</div>

<!-- ============================================================
SETTINGS BAR
============================================================ -->
<div class="glass-settings no-print">
    <form class="settings-grid" id="settingsForm">
        <div style="flex:1;min-width:180px;">
            <label class="form-label fw-semibold mb-1" style="font-size:0.75rem;color:#6c757d;">INSTITUTION NAME</label>
            <input type="text" id="institutionNameInput" class="form-control form-control-sm"
                   value="<?= htmlspecialchars($institutionName, ENT_QUOTES, 'UTF-8', false) ?>">
        </div>
        <div style="flex:1;min-width:160px;">
            <label class="form-label fw-semibold mb-1" style="font-size:0.75rem;color:#6c757d;">INSTITUTION LOGO</label>
            <input type="file" id="institutionLogoFile" class="form-control form-control-sm" accept="image/*">
        </div>
        <div>
            <button type="button" class="btn-save btn-sm" onclick="saveInstitutionSettings()">
                <i class="fas fa-save me-1"></i> Save Settings
            </button>
        </div>
    </form>
    <?php if ($institutionLogo): ?>
    <div class="mt-2">
        <span style="font-size:0.7rem;color:#6c757d;">Current Logo:</span>
        <img src="<?= $institutionLogo ?>" style="max-height:35px; border-radius:6px; border:1px solid #e9ecef; padding:2px; margin-left:6px;" alt="Logo">
        <button class="btn btn-sm btn-outline-danger ms-2" onclick="removeInstitutionLogo()" style="font-size:0.7rem;padding:1px 8px;">
            <i class="fas fa-times"></i>
        </button>
    </div>
    <?php endif; ?>
</div>

<!-- ============================================================
TABS
============================================================ -->
<ul class="nav nav-tabs-modern no-print" role="tablist">
    <li class="nav-item">
        <button class="nav-link active" data-bs-toggle="tab" data-bs-target="#idcard">
            <i class="fas fa-id-card"></i> ID Cards
        </button>
    </li>
    <li class="nav-item">
        <button class="nav-link" data-bs-toggle="tab" data-bs-target="#barcode">
            <i class="fas fa-barcode"></i> Barcode &amp; Labels
        </button>
    </li>
</ul>

<!-- ============================================================
TAB CONTENT
============================================================ -->
<div class="tab-content">

    <!-- ============================================================
    ID CARDS TAB
    ============================================================ -->
    <div class="tab-pane fade show active" id="idcard">
        <div class="row g-4">

            <!-- LEFT COLUMN - CONTROLS -->
            <div class="col-lg-4">

                <!-- Card Design -->
                <div class="card-premium">
                    <div class="card-header-premium">
                        <i class="fas fa-palette"></i> Card Design
                        <span class="ms-auto" style="font-size:0.7rem;font-weight:400;color:#6c757d;">
                            <i class="fas fa-arrows-alt me-1"></i> Customize
                        </span>
                    </div>
                    <div class="card-body-premium">

                        <!-- Card Size -->
                        <label class="form-label" style="font-size:0.7rem;font-weight:600;">Card Size</label>
                        <div class="row g-1">
                            <div class="col-6">
                                <div class="input-group input-group-sm">
                                    <span class="input-group-text">W</span>
                                    <input type="number" id="cardWidth" class="form-control" step="5" value="350" onchange="resizeCards()">
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="input-group input-group-sm">
                                    <span class="input-group-text">H</span>
                                    <input type="number" id="cardHeight" class="form-control" step="5" value="220" onchange="resizeCards()">
                                </div>
                            </div>
                        </div>
                        <div class="d-flex gap-1 flex-wrap mt-1">
                            <span class="btn btn-sm btn-outline-primary size-preset active" onclick="setCardSize(350,220)">Standard</span>
                            <span class="btn btn-sm btn-outline-secondary size-preset" onclick="setCardSize(300,190)">Compact</span>
                            <span class="btn btn-sm btn-outline-secondary size-preset" onclick="setCardSize(400,250)">Large</span>
                            <span class="btn btn-sm btn-outline-secondary size-preset" onclick="setCardSize(480,300)">CR80</span>
                        </div>

                        <hr class="my-2">

                        <!-- FRONT DESIGN -->
                        <div class="style-controls-toggle" onclick="toggleStyleControls('frontStyle')">
                            <i class="fas fa-chevron-down toggle-icon me-1"></i>
                            <span style="font-weight:600;font-size:0.8rem;">Front Design</span>
                            <span class="badge bg-primary ms-1" style="font-size:0.6rem;">Customize</span>
                        </div>
                        <div id="frontStyle" class="style-controls-body" style="padding:10px 0;border-top:1px solid #e9ecef;margin-top:6px;">

                            <!-- Background Image -->
                            <label class="form-label" style="font-size:0.65rem;font-weight:600;">Background Image</label>
                            <input type="file" id="frontBgImage" class="form-control form-control-sm mb-2" accept="image/*" onchange="updateFrontBackground()">
                            <div id="frontBgPreview" class="mb-2" style="display:none;">
                                <img id="frontBgPreviewImg" style="max-height:60px;border-radius:6px;border:1px solid #ddd;padding:2px;">
                                <button class="btn btn-sm btn-outline-danger ms-1" onclick="removeFrontBackground()" style="font-size:0.6rem;padding:1px 6px;">×</button>
                            </div>

                            <!-- Background Settings -->
                            <div class="row g-1">
                                <div class="col-6">
                                    <label class="form-label" style="font-size:0.65rem;">Bg Opacity</label>
                                    <input type="range" id="bgOpacity" class="form-range" min="0" max="100" value="30" oninput="document.getElementById('bgOpacityVal').innerText=this.value; updateCardStyle()">
                                    <span id="bgOpacityVal" style="font-size:0.6rem;">30%</span>
                                </div>
                                <div class="col-6">
                                    <label class="form-label" style="font-size:0.65rem;">Bg Color</label>
                                    <input type="color" id="bgColor" class="form-control form-control-color" value="#1a2a6c" onchange="updateCardStyle()">
                                </div>
                            </div>

                            <!-- Theme Colors -->
                            <label class="form-label mt-1" style="font-size:0.65rem;font-weight:600;">Theme Colors</label>
                            <div class="d-flex gap-1 flex-wrap">
                                <div class="theme-btn active" style="background: linear-gradient(135deg, #1a2a6c, #2a4a8a);" onclick="applyTheme('#1a2a6c','#2a4a8a',this)"></div>
                                <div class="theme-btn" style="background: linear-gradient(135deg, #c0392b, #e74c3c);" onclick="applyTheme('#c0392b','#e74c3c',this)"></div>
                                <div class="theme-btn" style="background: linear-gradient(135deg, #27ae60, #2ecc71);" onclick="applyTheme('#27ae60','#2ecc71',this)"></div>
                                <div class="theme-btn" style="background: linear-gradient(135deg, #2980b9, #3498db);" onclick="applyTheme('#2980b9','#3498db',this)"></div>
                                <div class="theme-btn" style="background: linear-gradient(135deg, #8e44ad, #9b59b6);" onclick="applyTheme('#8e44ad','#9b59b6',this)"></div>
                                <div class="theme-btn" style="background: linear-gradient(135deg, #d35400, #e67e22);" onclick="applyTheme('#d35400','#e67e22',this)"></div>
                                <div class="theme-btn" style="background: linear-gradient(135deg, #2c3e50, #34495e);" onclick="applyTheme('#2c3e50','#34495e',this)"></div>
                                <div class="theme-btn" style="background: linear-gradient(135deg, #e91e63, #f06292);" onclick="applyTheme('#e91e63','#f06292',this)"></div>
                            </div>
                            <div class="row g-1 mt-1">
                                <div class="col-6">
                                    <input type="color" id="themeStartColor" class="color-picker" value="#1a2a6c">
                                </div>
                                <div class="col-6">
                                    <input type="color" id="themeEndColor" class="color-picker" value="#2a4a8a">
                                </div>
                                <div class="col-12">
                                    <button class="btn btn-sm btn-outline-primary w-100" onclick="applyCustomTheme()">Apply Custom Theme</button>
                                </div>
                            </div>

                            <hr class="my-1">

                            <!-- HEADER TEXT -->
                            <label class="form-label" style="font-size:0.65rem;font-weight:600;">Header Text</label>
                            <div class="row g-1">
                                <div class="col-7">
                                    <input type="text" id="schoolName" class="form-control form-control-sm"
                                           value="<?= htmlspecialchars($institutionName, ENT_QUOTES, 'UTF-8', false) ?>"
                                           oninput="updateCardStyle()">
                                </div>
                                <div class="col-5">
                                    <label style="font-size:0.6rem;">Top Pos</label>
                                    <input type="range" id="headerTop" class="form-range" min="-15" max="20" value="0" step="1" oninput="document.getElementById('headerTopVal').innerText=this.value; updateCardStyle()">
                                    <span id="headerTopVal" style="font-size:0.6rem;">0</span>
                                </div>
                            </div>
                            <div class="row g-1 mt-1">
                                <div class="col-4">
                                    <label style="font-size:0.6rem;">Font Size</label>
                                    <input type="range" id="headerFontSize" class="form-range" min="10" max="24" value="16" step="1" oninput="document.getElementById('headerFontSizeVal').innerText=this.value; updateCardStyle()">
                                    <span id="headerFontSizeVal" style="font-size:0.6rem;">16</span>
                                </div>
                                <div class="col-4">
                                    <select id="headerFontWeight" class="form-select form-select-sm" onchange="updateCardStyle()">
                                        <option value="400">Normal</option>
                                        <option value="600">Semi-bold</option>
                                        <option value="700" selected>Bold</option>
                                        <option value="800">Extra Bold</option>
                                        <option value="900">Black</option>
                                    </select>
                                </div>
                                <div class="col-4">
                                    <select id="headerAlign" class="form-select form-select-sm" onchange="updateCardStyle()">
                                        <option value="center" selected>Center</option>
                                        <option value="left">Left</option>
                                        <option value="right">Right</option>
                                    </select>
                                </div>
                            </div>
                            <div class="row g-1">
                                <div class="col-6">
                                    <label style="font-size:0.6rem;">Color</label>
                                    <input type="color" id="headerColor" class="form-control form-control-color" value="#ffffff" onchange="updateCardStyle()">
                                </div>
                                <div class="col-6">
                                    <label style="font-size:0.6rem;">Letter Spacing</label>
                                    <input type="range" id="headerLetterSpacing" class="form-range" min="-2" max="4" value="-0.3" step="0.1" oninput="document.getElementById('headerLetterSpacingVal').innerText=this.value; updateCardStyle()">
                                    <span id="headerLetterSpacingVal" style="font-size:0.6rem;">-0.3</span>
                                </div>
                            </div>
                            <div class="row g-1">
                                <div class="col-6">
                                    <label style="font-size:0.6rem;">Font Family</label>
                                    <select id="headerFontFamily" class="form-select form-select-sm" onchange="updateCardStyle()">
                                        <option value="Inter">Inter</option>
                                        <option value="Roboto">Roboto</option>
                                        <option value="Open Sans">Open Sans</option>
                                        <option value="Lato">Lato</option>
                                        <option value="Montserrat">Montserrat</option>
                                        <option value="Arial">Arial</option>
                                        <option value="Georgia">Georgia</option>
                                    </select>
                                </div>
                                <div class="col-6">
                                    <label style="font-size:0.6rem;">Text Transform</label>
                                    <select id="headerTransform" class="form-select form-select-sm" onchange="updateCardStyle()">
                                        <option value="none" selected>None</option>
                                        <option value="uppercase">UPPERCASE</option>
                                        <option value="lowercase">lowercase</option>
                                        <option value="capitalize">Capitalize</option>
                                    </select>
                                </div>
                            </div>

                            <!-- HEADER BACKGROUND -->
                            <label class="form-label mt-1" style="font-size:0.65rem;font-weight:600;">
                                <i class="fas fa-fill-drip me-1"></i> Header Background
                            </label>
                            <div class="row g-1">
                                <div class="col-4">
                                    <label style="font-size:0.6rem;">Bg Color</label>
                                    <input type="color" id="headerBgColor" class="form-control form-control-color" value="#1a2a6c" onchange="updateCardStyle()">
                                </div>
                                <div class="col-4">
                                    <label style="font-size:0.6rem;">Opacity</label>
                                    <input type="range" id="headerBgOpacity" class="form-range" min="0" max="100" value="0" step="5" oninput="document.getElementById('headerBgOpacityVal').innerText=this.value; updateCardStyle()">
                                    <span id="headerBgOpacityVal" style="font-size:0.6rem;">0%</span>
                                </div>
                                <div class="col-4">
                                    <div class="form-check form-switch mt-3">
                                        <input class="form-check-input" type="checkbox" id="headerBgEnable" onchange="updateCardStyle()">
                                        <label class="form-check-label" style="font-size:0.7rem;">Enable</label>
                                    </div>
                                </div>
                            </div>
                            <div class="row g-1">
                                <div class="col-4">
                                    <label style="font-size:0.6rem;">Padding</label>
                                    <input type="range" id="headerPadding" class="form-range" min="0" max="20" value="0" step="1" oninput="document.getElementById('headerPaddingVal').innerText=this.value; updateCardStyle()">
                                    <span id="headerPaddingVal" style="font-size:0.6rem;">0</span>
                                </div>
                                <div class="col-4">
                                    <label style="font-size:0.6rem;">Radius</label>
                                    <input type="range" id="headerRadius" class="form-range" min="0" max="20" value="0" step="1" oninput="document.getElementById('headerRadiusVal').innerText=this.value; updateCardStyle()">
                                    <span id="headerRadiusVal" style="font-size:0.6rem;">0</span>
                                </div>
                                <div class="col-4">
                                    <label style="font-size:0.6rem;">Width %</label>
                                    <input type="range" id="headerWidth" class="form-range" min="30" max="100" value="100" step="5" oninput="document.getElementById('headerWidthVal').innerText=this.value; updateCardStyle()">
                                    <span id="headerWidthVal" style="font-size:0.6rem;">100</span>
                                </div>
                            </div>

                            <hr class="my-1">

                            <!-- TAGLINE -->
                            <label class="form-label" style="font-size:0.65rem;font-weight:600;">Tagline</label>
                            <div class="row g-1">
                                <div class="col-5">
                                    <input type="text" id="tagline" class="form-control form-control-sm" value="Knowledge Hub" oninput="updateCardStyle()">
                                </div>
                                <div class="col-3">
                                    <label style="font-size:0.6rem;">Top</label>
                                    <input type="range" id="taglineTop" class="form-range" min="-10" max="10" value="0" step="1" oninput="document.getElementById('taglineTopVal').innerText=this.value; updateCardStyle()">
                                    <span id="taglineTopVal" style="font-size:0.6rem;">0</span>
                                </div>
                                <div class="col-4">
                                    <label style="font-size:0.6rem;">Bottom</label>
                                    <input type="range" id="taglineBottom" class="form-range" min="-10" max="10" value="0" step="1" oninput="document.getElementById('taglineBottomVal').innerText=this.value; updateCardStyle()">
                                    <span id="taglineBottomVal" style="font-size:0.6rem;">0</span>
                                </div>
                            </div>
                            <div class="row g-1">
                                <div class="col-4">
                                    <label style="font-size:0.6rem;">Font Size</label>
                                    <input type="range" id="taglineFontSize" class="form-range" min="6" max="14" value="8" step="1" oninput="document.getElementById('taglineFontSizeVal').innerText=this.value; updateCardStyle()">
                                    <span id="taglineFontSizeVal" style="font-size:0.6rem;">8</span>
                                </div>
                                <div class="col-4">
                                    <label style="font-size:0.6rem;">Color</label>
                                    <input type="color" id="taglineColor" class="form-control form-control-color" value="#ffffff" onchange="updateCardStyle()">
                                </div>
                                <div class="col-4">
                                    <select id="taglineTransform" class="form-select form-select-sm" onchange="updateCardStyle()">
                                        <option value="none">None</option>
                                        <option value="uppercase" selected>Uppercase</option>
                                        <option value="lowercase">Lowercase</option>
                                        <option value="capitalize">Capitalize</option>
                                    </select>
                                </div>
                            </div>
                            <div class="row g-1">
                                <div class="col-6">
                                    <label style="font-size:0.6rem;">Tagline Font Family</label>
                                    <select id="taglineFontFamily" class="form-select form-select-sm" onchange="updateCardStyle()">
                                        <option value="Inter">Inter</option>
                                        <option value="Roboto">Roboto</option>
                                        <option value="Open Sans">Open Sans</option>
                                        <option value="Lato">Lato</option>
                                        <option value="Montserrat">Montserrat</option>
                                        <option value="Arial">Arial</option>
                                    </select>
                                </div>
                                <div class="col-6">
                                    <label style="font-size:0.6rem;">Tagline Opacity</label>
                                    <input type="range" id="taglineOpacity" class="form-range" min="20" max="100" value="70" step="5" oninput="document.getElementById('taglineOpacityVal').innerText=this.value; updateCardStyle()">
                                    <span id="taglineOpacityVal" style="font-size:0.6rem;">70%</span>
                                </div>
                            </div>

                            <hr class="my-1">

                            <!-- INFO TEXT -->
                            <label class="form-label" style="font-size:0.65rem;font-weight:600;">
                                <i class="fas fa-list me-1"></i> Info Text
                            </label>

                            <div class="row g-1">
                                <div class="col-3">
                                    <label style="font-size:0.6rem;">Top</label>
                                    <input type="range" id="infoTop" class="form-range" min="-5" max="20" value="5" step="1" oninput="document.getElementById('infoTopVal').innerText=this.value; updateCardStyle()">
                                    <span id="infoTopVal" style="font-size:0.6rem;">5</span>
                                </div>
                                <div class="col-3">
                                    <label style="font-size:0.6rem;">Bottom</label>
                                    <input type="range" id="infoBottom" class="form-range" min="-5" max="20" value="5" step="1" oninput="document.getElementById('infoBottomVal').innerText=this.value; updateCardStyle()">
                                    <span id="infoBottomVal" style="font-size:0.6rem;">5</span>
                                </div>
                                <div class="col-3">
                                    <label style="font-size:0.6rem;">Left</label>
                                    <input type="range" id="infoLeft" class="form-range" min="-10" max="30" value="10" step="1" oninput="document.getElementById('infoLeftVal').innerText=this.value; updateCardStyle()">
                                    <span id="infoLeftVal" style="font-size:0.6rem;">10</span>
                                </div>
                                <div class="col-3">
                                    <label style="font-size:0.6rem;">Right</label>
                                    <input type="range" id="infoRight" class="form-range" min="-10" max="30" value="10" step="1" oninput="document.getElementById('infoRightVal').innerText=this.value; updateCardStyle()">
                                    <span id="infoRightVal" style="font-size:0.6rem;">10</span>
                                </div>
                            </div>

                            <div class="row g-1 mt-1">
                                <div class="col-4">
                                    <label style="font-size:0.6rem;">Font Size</label>
                                    <input type="range" id="infoFontSize" class="form-range" min="7" max="14" value="10" step="1" oninput="document.getElementById('infoFontSizeVal').innerText=this.value; updateCardStyle()">
                                    <span id="infoFontSizeVal" style="font-size:0.6rem;">10</span>
                                </div>
                                <div class="col-4">
                                    <label style="font-size:0.6rem;">Line Height</label>
                                    <input type="range" id="infoLineHeight" class="form-range" min="1" max="2.5" value="1.6" step="0.1" oninput="document.getElementById('infoLineHeightVal').innerText=this.value; updateCardStyle()">
                                    <span id="infoLineHeightVal" style="font-size:0.6rem;">1.6</span>
                                </div>
                                <div class="col-4">
                                    <label style="font-size:0.6rem;">Row Gap</label>
                                    <input type="range" id="infoRowGap" class="form-range" min="0" max="10" value="0" step="1" oninput="document.getElementById('infoRowGapVal').innerText=this.value; updateCardStyle()">
                                    <span id="infoRowGapVal" style="font-size:0.6rem;">0</span>
                                </div>
                            </div>
                            <div class="row g-1 mt-1">
                                <div class="col-4">
                                    <label style="font-size:0.6rem;">Color</label>
                                    <input type="color" id="infoColor" class="form-control form-control-color" value="#ffffff" onchange="updateCardStyle()">
                                </div>
                                <div class="col-4">
                                    <label style="font-size:0.6rem;">Align</label>
                                    <select id="infoAlign" class="form-select form-select-sm" onchange="updateCardStyle()">
                                        <option value="left" selected>Left</option>
                                        <option value="center">Center</option>
                                        <option value="right">Right</option>
                                    </select>
                                </div>
                                <div class="col-4">
                                    <label style="font-size:0.6rem;">Font Family</label>
                                    <select id="infoFontFamily" class="form-select form-select-sm" onchange="updateCardStyle()">
                                        <option value="Inter">Inter</option>
                                        <option value="Roboto">Roboto</option>
                                        <option value="Open Sans">Open Sans</option>
                                        <option value="Lato">Lato</option>
                                        <option value="Montserrat">Montserrat</option>
                                        <option value="Arial">Arial</option>
                                        <option value="Courier New">Courier New</option>
                                    </select>
                                </div>
                            </div>
                            <div class="row g-1 mt-1">
                                <div class="col-6">
                                    <label style="font-size:0.6rem;">Label Opacity</label>
                                    <input type="range" id="labelOpacity" class="form-range" min="30" max="100" value="80" step="5" oninput="document.getElementById('labelOpacityVal').innerText=this.value; updateCardStyle()">
                                    <span id="labelOpacityVal" style="font-size:0.6rem;">80%</span>
                                </div>
                                <div class="col-6">
                                    <label style="font-size:0.6rem;">Separator</label>
                                    <select id="infoSeparator" class="form-select form-select-sm" onchange="updateCardStyle()">
                                        <option value=":" selected>Colon ( : )</option>
                                        <option value="—">Dash ( — )</option>
                                        <option value="•">Bullet ( • )</option>
                                        <option value="">None</option>
                                    </select>
                                </div>
                            </div>

                            <!-- FIELD VISIBILITY & LABELS -->
                            <label class="form-label mt-2" style="font-size:0.65rem;font-weight:600;">
                                <i class="fas fa-eye me-1"></i> Fields &amp; Labels
                            </label>
                            <div id="fieldToggleContainer" style="max-height:260px;overflow-y:auto;border:1px solid #e9ecef;border-radius:6px;padding:6px 8px;">

                                <div class="field-toggle-row" data-field="name">
                                    <div class="form-check form-switch mb-0">
                                        <input class="form-check-input field-visible" type="checkbox" checked onchange="updateCardStyle()">
                                    </div>
                                    <span class="field-label">Name</span>
                                    <input type="text" class="field-label-input" value="Name" onchange="updateCardStyle()">
                                    <div class="d-flex flex-column">
                                        <button class="btn btn-sm btn-outline-secondary field-order-btn mb-1" onclick="moveField('name',-1)" title="Move up"><i class="fas fa-arrow-up"></i></button>
                                        <button class="btn btn-sm btn-outline-secondary field-order-btn" onclick="moveField('name',1)" title="Move down"><i class="fas fa-arrow-down"></i></button>
                                    </div>
                                </div>

                                <div class="field-toggle-row" data-field="designation">
                                    <div class="form-check form-switch mb-0">
                                        <input class="form-check-input field-visible" type="checkbox" checked onchange="updateCardStyle()">
                                    </div>
                                    <span class="field-label">Designation</span>
                                    <input type="text" class="field-label-input" value="Desig" onchange="updateCardStyle()">
                                    <div class="d-flex flex-column">
                                        <button class="btn btn-sm btn-outline-secondary field-order-btn mb-1" onclick="moveField('designation',-1)" title="Move up"><i class="fas fa-arrow-up"></i></button>
                                        <button class="btn btn-sm btn-outline-secondary field-order-btn" onclick="moveField('designation',1)" title="Move down"><i class="fas fa-arrow-down"></i></button>
                                    </div>
                                </div>

                                <div class="field-toggle-row" data-field="classDept">
                                    <div class="form-check form-switch mb-0">
                                        <input class="form-check-input field-visible" type="checkbox" checked onchange="updateCardStyle()">
                                    </div>
                                    <span class="field-label">Class / Dept</span>
                                    <input type="text" class="field-label-input" value="Class/Dept" onchange="updateCardStyle()">
                                    <div class="d-flex flex-column">
                                        <button class="btn btn-sm btn-outline-secondary field-order-btn mb-1" onclick="moveField('classDept',-1)" title="Move up"><i class="fas fa-arrow-up"></i></button>
                                        <button class="btn btn-sm btn-outline-secondary field-order-btn" onclick="moveField('classDept',1)" title="Move down"><i class="fas fa-arrow-down"></i></button>
                                    </div>
                                </div>

                                <div class="field-toggle-row" data-field="divisionCourse">
                                    <div class="form-check form-switch mb-0">
                                        <input class="form-check-input field-visible" type="checkbox" checked onchange="updateCardStyle()">
                                    </div>
                                    <span class="field-label">Div / Course</span>
                                    <input type="text" class="field-label-input" value="Div/Course" onchange="updateCardStyle()">
                                    <div class="d-flex flex-column">
                                        <button class="btn btn-sm btn-outline-secondary field-order-btn mb-1" onclick="moveField('divisionCourse',-1)" title="Move up"><i class="fas fa-arrow-up"></i></button>
                                        <button class="btn btn-sm btn-outline-secondary field-order-btn" onclick="moveField('divisionCourse',1)" title="Move down"><i class="fas fa-arrow-down"></i></button>
                                    </div>
                                </div>

                                <div class="field-toggle-row" data-field="phone">
                                    <div class="form-check form-switch mb-0">
                                        <input class="form-check-input field-visible" type="checkbox" checked onchange="updateCardStyle()">
                                    </div>
                                    <span class="field-label">Contact</span>
                                    <input type="text" class="field-label-input" value="Contact" onchange="updateCardStyle()">
                                    <div class="d-flex flex-column">
                                        <button class="btn btn-sm btn-outline-secondary field-order-btn mb-1" onclick="moveField('phone',-1)" title="Move up"><i class="fas fa-arrow-up"></i></button>
                                        <button class="btn btn-sm btn-outline-secondary field-order-btn" onclick="moveField('phone',1)" title="Move down"><i class="fas fa-arrow-down"></i></button>
                                    </div>
                                </div>

                                <div class="field-toggle-row" data-field="year">
                                    <div class="form-check form-switch mb-0">
                                        <input class="form-check-input field-visible" type="checkbox" checked onchange="updateCardStyle()">
                                    </div>
                                    <span class="field-label">Year</span>
                                    <input type="text" class="field-label-input" value="Year" onchange="updateCardStyle()">
                                    <div class="d-flex flex-column">
                                        <button class="btn btn-sm btn-outline-secondary field-order-btn mb-1" onclick="moveField('year',-1)" title="Move up"><i class="fas fa-arrow-up"></i></button>
                                        <button class="btn btn-sm btn-outline-secondary field-order-btn" onclick="moveField('year',1)" title="Move down"><i class="fas fa-arrow-down"></i></button>
                                    </div>
                                </div>

                                <div class="field-toggle-row" data-field="idNumber">
                                    <div class="form-check form-switch mb-0">
                                        <input class="form-check-input field-visible" type="checkbox" checked onchange="updateCardStyle()">
                                    </div>
                                    <span class="field-label">ID Number</span>
                                    <input type="text" class="field-label-input" value="ID No" onchange="updateCardStyle()">
                                    <div class="d-flex flex-column">
                                        <button class="btn btn-sm btn-outline-secondary field-order-btn mb-1" onclick="moveField('idNumber',-1)" title="Move up"><i class="fas fa-arrow-up"></i></button>
                                        <button class="btn btn-sm btn-outline-secondary field-order-btn" onclick="moveField('idNumber',1)" title="Move down"><i class="fas fa-arrow-down"></i></button>
                                    </div>
                                </div>

                            </div>

                            <div class="d-flex gap-1 mt-1">
                                <button class="btn btn-sm btn-outline-secondary w-100" onclick="resetFieldPreferences()">
                                    <i class="fas fa-undo me-1"></i> Reset Fields
                                </button>
                            </div>

                            <div class="form-check form-switch mt-1">
                                <input class="form-check-input" type="checkbox" id="headerBold" checked onchange="updateCardStyle()">
                                <label class="form-check-label" style="font-size:0.8rem;">Bold header</label>
                            </div>
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" id="showYear" checked onchange="updateCardStyle()">
                                <label class="form-check-label" style="font-size:0.8rem;">Show Year</label>
                            </div>

                            <hr class="my-1">

                            <!-- Photo Position -->
                            <label class="form-label" style="font-size:0.65rem;font-weight:600;">Photo</label>
                            <div class="row g-1">
                                <div class="col-6">
                                    <label style="font-size:0.6rem;">Width</label>
                                    <input type="range" id="photoWidth" class="form-range" min="50" max="100" value="80" step="2" oninput="document.getElementById('photoWidthVal').innerText=this.value; updateCardStyle()">
                                    <span id="photoWidthVal" style="font-size:0.6rem;">80</span>
                                </div>
                                <div class="col-6">
                                    <label style="font-size:0.6rem;">Height</label>
                                    <input type="range" id="photoHeight" class="form-range" min="60" max="110" value="95" step="2" oninput="document.getElementById('photoHeightVal').innerText=this.value; updateCardStyle()">
                                    <span id="photoHeightVal" style="font-size:0.6rem;">95</span>
                                </div>
                            </div>
                            <div class="row g-1">
                                <div class="col-6">
                                    <label style="font-size:0.6rem;">Top</label>
                                    <input type="range" id="photoTop" class="form-range" min="5" max="40" value="14" step="1" oninput="document.getElementById('photoTopVal').innerText=this.value; updateCardStyle()">
                                    <span id="photoTopVal" style="font-size:0.6rem;">14</span>
                                </div>
                                <div class="col-6">
                                    <label style="font-size:0.6rem;">Right</label>
                                    <input type="range" id="photoRight" class="form-range" min="5" max="30" value="14" step="1" oninput="document.getElementById('photoRightVal').innerText=this.value; updateCardStyle()">
                                    <span id="photoRightVal" style="font-size:0.6rem;">14</span>
                                </div>
                            </div>
                            <div class="row g-1">
                                <div class="col-6">
                                    <label style="font-size:0.6rem;">Border Color</label>
                                    <input type="color" id="photoBorderColor" class="form-control form-control-color" value="#ffffff" onchange="updateCardStyle()">
                                </div>
                                <div class="col-6">
                                    <label style="font-size:0.6rem;">Border Width</label>
                                    <input type="range" id="photoBorderWidth" class="form-range" min="0" max="4" value="2" step="0.5" oninput="document.getElementById('photoBorderWidthVal').innerText=this.value; updateCardStyle()">
                                    <span id="photoBorderWidthVal" style="font-size:0.6rem;">2</span>
                                </div>
                            </div>

                            <hr class="my-1">

                            <!-- Logo Position -->
                            <label class="form-label" style="font-size:0.65rem;font-weight:600;">Logo</label>
                            <div class="row g-1">
                                <div class="col-6">
                                    <label style="font-size:0.6rem;">Width</label>
                                    <input type="range" id="logoWidth" class="form-range" min="25" max="60" value="42" step="2" oninput="document.getElementById('logoWidthVal').innerText=this.value; updateCardStyle()">
                                    <span id="logoWidthVal" style="font-size:0.6rem;">42</span>
                                </div>
                                <div class="col-6">
                                    <label style="font-size:0.6rem;">Height</label>
                                    <input type="range" id="logoHeight" class="form-range" min="25" max="60" value="42" step="2" oninput="document.getElementById('logoHeightVal').innerText=this.value; updateCardStyle()">
                                    <span id="logoHeightVal" style="font-size:0.6rem;">42</span>
                                </div>
                            </div>
                            <div class="row g-1">
                                <div class="col-6">
                                    <label style="font-size:0.6rem;">Left (-15 to 20)</label>
                                    <input type="range" id="logoLeft" class="form-range" min="-15" max="20" value="14" step="1" oninput="document.getElementById('logoLeftVal').innerText=this.value; updateCardStyle()">
                                    <span id="logoLeftVal" style="font-size:0.6rem;">14</span>
                                </div>
                                <div class="col-6">
                                    <label style="font-size:0.6rem;">Top (-15 to 20)</label>
                                    <input type="range" id="logoTop" class="form-range" min="-15" max="20" value="14" step="1" oninput="document.getElementById('logoTopVal').innerText=this.value; updateCardStyle()">
                                    <span id="logoTopVal" style="font-size:0.6rem;">14</span>
                                </div>
                            </div>

                            <hr class="my-1">

                            <!-- Barcode Bottom Position -->
                            <label class="form-label" style="font-size:0.65rem;font-weight:600;">Barcode Bottom Pos</label>
                            <div class="row g-1">
                                <div class="col-6">
                                    <label style="font-size:0.6rem;">Bottom (-10 to 10)</label>
                                    <input type="range" id="barcodeBottom" class="form-range" min="-10" max="10" value="10" step="1" oninput="document.getElementById('barcodeBottomVal').innerText=this.value; updateCardStyle()">
                                    <span id="barcodeBottomVal" style="font-size:0.6rem;">10</span>
                                </div>
                                <div class="col-6">
                                    <label style="font-size:0.6rem;">Height</label>
                                    <input type="range" id="barcodeHeight" class="form-range" min="20" max="50" value="30" step="2" oninput="document.getElementById('barcodeHeightVal').innerText=this.value; updateCardStyle()">
                                    <span id="barcodeHeightVal" style="font-size:0.6rem;">30</span>
                                </div>
                            </div>

                            <hr class="my-1">

                            <!-- Year & ID -->
                            <div class="row g-1">
                                <div class="col-6">
                                    <label class="form-label" style="font-size:0.65rem;font-weight:600;">Year Font Size</label>
                                    <input type="range" id="yearFontSize" class="form-range" min="6" max="14" value="9" step="1" oninput="document.getElementById('yearFontSizeVal').innerText=this.value; updateCardStyle()">
                                    <span id="yearFontSizeVal" style="font-size:0.6rem;">9</span>
                                </div>
                                <div class="col-6">
                                    <label class="form-label" style="font-size:0.65rem;font-weight:600;">Year Color</label>
                                    <input type="color" id="yearColor" class="form-control form-control-color" value="#ffffff" onchange="updateCardStyle()">
                                </div>
                            </div>
                            <div class="row g-1">
                                <div class="col-6">
                                    <label class="form-label" style="font-size:0.65rem;font-weight:600;">ID Font Size</label>
                                    <input type="range" id="idFontSize" class="form-range" min="6" max="12" value="8" step="1" oninput="document.getElementById('idFontSizeVal').innerText=this.value; updateCardStyle()">
                                    <span id="idFontSizeVal" style="font-size:0.6rem;">8</span>
                                </div>
                                <div class="col-6">
                                    <label style="font-size:0.6rem;">ID Color</label>
                                    <input type="color" id="idColor" class="form-control form-control-color" value="#ffffff" onchange="updateCardStyle()">
                                </div>
                            </div>
                            <div class="row g-1">
                                <div class="col-6">
                                    <label style="font-size:0.6rem;">ID Top Pos</label>
                                    <input type="range" id="idTop" class="form-range" min="80" max="180" value="118" step="2" oninput="document.getElementById('idTopVal').innerText=this.value; updateCardStyle()">
                                    <span id="idTopVal" style="font-size:0.6rem;">118</span>
                                </div>
                                <div class="col-6">
                                    <label style="font-size:0.6rem;">ID Right Pos</label>
                                    <input type="range" id="idRight" class="form-range" min="-20" max="30" value="14" step="1" oninput="document.getElementById('idRightVal').innerText=this.value; updateCardStyle()">
                                    <span id="idRightVal" style="font-size:0.6rem;">14</span>
                                </div>
                            </div>

                        </div>

                        <hr class="my-2">

                        <!-- BACK DESIGN -->
                        <div class="style-controls-toggle" onclick="toggleStyleControls('backStyle')">
                            <i class="fas fa-chevron-right toggle-icon me-1"></i>
                            <span style="font-weight:600;font-size:0.8rem;">Back Design</span>
                            <span class="badge bg-secondary ms-1" style="font-size:0.6rem;">Customize</span>
                        </div>
                        <div id="backStyle" class="style-controls-body collapsed" style="padding:0;border-top:1px solid #e9ecef;margin-top:6px;max-height:0;">

                            <div style="padding:10px 0;">

                                <label class="form-label" style="font-size:0.65rem;font-weight:600;">Back Background Image</label>
                                <input type="file" id="backBgImage" class="form-control form-control-sm mb-2" accept="image/*" onchange="updateBackBackground()">
                                <div id="backBgPreview" class="mb-2" style="display:none;">
                                    <img id="backBgPreviewImg" style="max-height:60px;border-radius:6px;border:1px solid #ddd;padding:2px;">
                                    <button class="btn btn-sm btn-outline-danger ms-1" onclick="removeBackBackground()" style="font-size:0.6rem;padding:1px 6px;">×</button>
                                </div>

                                <div class="row g-1">
                                    <div class="col-6">
                                        <label class="form-label" style="font-size:0.65rem;">Back Bg Opacity</label>
                                        <input type="range" id="backBgOpacity" class="form-range" min="0" max="100" value="10" oninput="document.getElementById('backBgOpacityVal').innerText=this.value; updateCardStyle()">
                                        <span id="backBgOpacityVal" style="font-size:0.6rem;">10%</span>
                                    </div>
                                    <div class="col-6">
                                        <label class="form-label" style="font-size:0.65rem;">Back Color</label>
                                        <input type="color" id="backColor" class="form-control form-control-color" value="#f8f9fa" onchange="updateCardStyle()">
                                    </div>
                                </div>

                                <hr class="my-1">

                                <label class="form-label mt-1" style="font-size:0.65rem;font-weight:600;">Rules Text</label>
                                <textarea id="libraryRules" rows="2" class="form-control form-control-sm mb-1" oninput="updateCardStyle()">• Non-transferable
• Report loss immediately
• Show at entrance</textarea>

                                <div class="row g-1">
                                    <div class="col-6">
                                        <label style="font-size:0.6rem;">Rules Font Size</label>
                                        <input type="range" id="rulesFontSize" class="form-range" min="6" max="12" value="8" step="1" oninput="document.getElementById('rulesFontSizeVal').innerText=this.value; updateCardStyle()">
                                        <span id="rulesFontSizeVal" style="font-size:0.6rem;">8</span>
                                    </div>
                                    <div class="col-6">
                                        <label style="font-size:0.6rem;">Rules Color</label>
                                        <input type="color" id="rulesColor" class="form-control form-control-color" value="#2c3e50" onchange="updateCardStyle()">
                                    </div>
                                </div>
                                <div class="row g-1">
                                    <div class="col-6">
                                        <label style="font-size:0.6rem;">Rules Title Size</label>
                                        <input type="range" id="rulesTitleSize" class="form-range" min="8" max="14" value="11" step="1" oninput="document.getElementById('rulesTitleSizeVal').innerText=this.value; updateCardStyle()">
                                        <span id="rulesTitleSizeVal" style="font-size:0.6rem;">11</span>
                                    </div>
                                    <div class="col-6">
                                        <label style="font-size:0.6rem;">Rules Title Color</label>
                                        <input type="color" id="rulesTitleColor" class="form-control form-control-color" value="#1a2a6c" onchange="updateCardStyle()">
                                    </div>
                                </div>
                                <div class="row g-1">
                                    <div class="col-6">
                                        <label style="font-size:0.6rem;">Rules Text Align</label>
                                        <select id="rulesTextAlign" class="form-select form-select-sm" onchange="updateCardStyle()">
                                            <option value="left" selected>Left</option>
                                            <option value="center">Center</option>
                                            <option value="right">Right</option>
                                        </select>
                                    </div>
                                    <div class="col-6">
                                        <label style="font-size:0.6rem;">Rules Title Align</label>
                                        <select id="rulesTitleAlign" class="form-select form-select-sm" onchange="updateCardStyle()">
                                            <option value="left" selected>Left</option>
                                            <option value="center">Center</option>
                                            <option value="right">Right</option>
                                        </select>
                                    </div>
                                </div>

                                <hr class="my-1">

                                <label class="form-label mt-1" style="font-size:0.65rem;font-weight:600;">Signature</label>
                                <input type="text" id="signatureText" class="form-control form-control-sm" value="Authorized Signature" oninput="updateCardStyle()">

                                <div class="row g-1 mt-1">
                                    <div class="col-6">
                                        <label style="font-size:0.6rem;">Signature Size</label>
                                        <input type="range" id="signatureFontSize" class="form-range" min="6" max="12" value="8" step="1" oninput="document.getElementById('signatureFontSizeVal').innerText=this.value; updateCardStyle()">
                                        <span id="signatureFontSizeVal" style="font-size:0.6rem;">8</span>
                                    </div>
                                    <div class="col-6">
                                        <label style="font-size:0.6rem;">Signature Color</label>
                                        <input type="color" id="signatureColor" class="form-control form-control-color" value="#2c3e50" onchange="updateCardStyle()">
                                    </div>
                                </div>
                                <div class="row g-1">
                                    <div class="col-6">
                                        <label style="font-size:0.6rem;">Signature Image</label>
                                        <input type="file" id="signatureImage" class="form-control form-control-sm" accept="image/*" onchange="updateSignatureImage()">
                                    </div>
                                    <div class="col-6">
                                        <label style="font-size:0.6rem;">Signature Align</label>
                                        <select id="signatureAlign" class="form-select form-select-sm" onchange="updateCardStyle()">
                                            <option value="center" selected>Center</option>
                                            <option value="left">Left</option>
                                            <option value="right">Right</option>
                                        </select>
                                    </div>
                                </div>
                                <div id="signatureImagePreview" class="mt-1" style="display:none;">
                                    <img id="signatureImagePreviewImg" style="max-height:30px;border-radius:4px;border:1px solid #ddd;padding:2px;">
                                    <button class="btn btn-sm btn-outline-danger ms-1" onclick="removeSignatureImage()" style="font-size:0.6rem;padding:1px 6px;">×</button>
                                </div>

                            </div>
                        </div>

                        <hr class="my-2">

                        <label class="form-label" style="font-size:0.7rem;font-weight:600;">Custom Logo (session only)</label>
                        <div class="d-flex gap-2">
                            <input type="file" id="customLeftLogo" class="form-control form-control-sm" accept="image/*" style="flex:1;">
                            <button class="btn btn-sm btn-secondary" onclick="uploadCustomLogo()"><i class="fas fa-upload"></i></button>
                        </div>
                        <div id="customLogoPreview" class="mt-1"></div>

                    </div>
                </div>

                <!-- Member Selection -->
                <div class="card-premium">
                    <div class="card-header-premium">
                        <i class="fas fa-users"></i> Members
                        <span class="badge bg-primary rounded-pill ms-auto" style="font-size:0.7rem;"><?= count($members) ?></span>
                    </div>
                    <div class="card-body-premium">
                        <div class="input-group input-group-sm mb-2">
                            <input type="text" id="memberSearch" class="form-control form-control-sm" placeholder="Search members..." onkeyup="filterMembers()">
                            <button class="btn btn-outline-secondary btn-sm" onclick="filterMembers()"><i class="fas fa-search"></i></button>
                        </div>
                        <div class="member-list" id="memberList">
                            <?php foreach($members as $m): ?>
                            <div class="member-item" data-admno="<?= htmlspecialchars($m['admno']) ?>" data-name="<?= htmlspecialchars($m['name']) ?>" data-class="<?= htmlspecialchars($m['class']??'') ?>" data-division="<?= htmlspecialchars($m['division']??'') ?>" data-phone="<?= htmlspecialchars($m['phone']??'') ?>" data-photo-url="<?= htmlspecialchars($m['photo_url']) ?>" data-designation="<?= htmlspecialchars($m['designation']??'') ?>" data-year="<?= htmlspecialchars($m['academic_year']??'') ?>" onclick="selectMember(this)">
                                <div class="member-name"><?= htmlspecialchars($m['name']) ?></div>
                                <div class="member-detail"><?= $m['admno'] ?> <?= $m['member_category'] ? '| '.$m['member_category'] : '' ?></div>
                            </div>
                            <?php endforeach; ?>
                        </div>

                        <div class="d-grid gap-2 mt-3">
                            <button class="btn-premium btn-premium-success btn-sm" onclick="generateSelectedMembers()">
                                <i class="fas fa-user-plus me-1"></i> Generate Selected
                            </button>
                            <button class="btn-premium btn-premium-primary btn-sm" onclick="generateAllMembers()">
                                <i class="fas fa-users me-1"></i> Generate All
                            </button>
                        </div>

                        <div class="mt-2">
                            <label class="form-label" style="font-size:0.7rem;font-weight:600;">External Photo (card only)</label>
                            <div class="d-flex gap-2">
                                <input type="file" id="externalPhotoFile" class="form-control form-control-sm" accept="image/*" style="flex:1;">
                                <button class="btn btn-sm btn-secondary" onclick="applyExternalPhoto()"><i class="fas fa-camera"></i></button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Export Panel -->
                <div class="card-premium no-print">
                    <div class="card-header-premium">
                        <i class="fas fa-print"></i> Export
                    </div>
                    <div class="card-body-premium">
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" id="colorPrint" checked>
                            <label class="form-check-label" style="font-size:0.8rem;">Color output</label>
                        </div>
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" id="includeQR" onchange="toggleQR()">
                            <label class="form-check-label" style="font-size:0.8rem;">Use QR Code</label>
                        </div>

                        <label class="form-label mt-2" style="font-size:0.7rem;font-weight:600;">Cards per row</label>
                        <div class="d-flex gap-2">
                            <span class="btn btn-sm btn-outline-secondary layout-preset active" data-cols="2" onclick="setPrintLayout(2)">2</span>
                            <span class="btn btn-sm btn-outline-secondary layout-preset" data-cols="3" onclick="setPrintLayout(3)">3</span>
                            <span class="btn btn-sm btn-outline-secondary layout-preset" data-cols="4" onclick="setPrintLayout(4)">4</span>
                        </div>

                        <div class="row g-2 mt-2">
                            <div class="col-4">
                                <button class="btn btn-secondary btn-sm w-100" onclick="window.print()"><i class="fas fa-print"></i> Print</button>
                            </div>
                            <div class="col-4">
                                <button class="btn btn-danger btn-sm w-100" onclick="exportToPDF(false)"><i class="fas fa-file-pdf"></i> PDF</button>
                            </div>
                            <div class="col-4">
                                <button class="btn btn-success btn-sm w-100" onclick="exportToPDF(true)"><i class="fas fa-file-pdf"></i> PDF Sel</button>
                            </div>
                            <div class="col-6">
                                <button class="btn btn-info btn-sm w-100 text-white" onclick="exportToPNG()"><i class="fas fa-image"></i> PNG</button>
                            </div>
                            <div class="col-6">
                                <button class="btn btn-outline-danger btn-sm w-100" onclick="clearCards()"><i class="fas fa-trash"></i> Clear</button>
                            </div>
                        </div>

                        <hr class="my-2">

                        <div class="d-flex gap-2">
                            <button class="btn btn-sm btn-outline-primary" onclick="selectAllCards()"><i class="fas fa-check-double"></i> All</button>
                            <button class="btn btn-sm btn-outline-secondary" onclick="deselectAllCards()"><i class="fas fa-times"></i> None</button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- RIGHT COLUMN - PREVIEW -->
            <div class="col-lg-8">
                <div class="stats-bar no-print">
                    <span class="stats-count"><i class="fas fa-id-card"></i> <span id="cardCount">0</span> cards generated</span>
                    <span style="font-size:0.75rem;opacity:0.8;"><i class="fas fa-info-circle me-1"></i> Select a member and click Generate</span>
                </div>

                <div class="card-premium">
                    <div class="card-header-premium">
                        <i class="fas fa-eye"></i> Live Preview
                        <span class="ms-auto" style="font-size:0.7rem;font-weight:400;color:#6c757d;">
                            <i class="fas fa-arrows-left-right me-1"></i> Front &amp; Back
                        </span>
                    </div>
                    <div class="card-body-premium">
                        <div class="id-card-container" id="cardsContainer">
                            <div class="text-center text-muted py-5" style="width:100%;">
                                <i class="fas fa-id-card fa-3x mb-3 d-block" style="opacity:0.2;"></i>
                                Select a member from the left panel and click Generate
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ============================================================
    BARCODE & LABELS TAB
    ============================================================ -->
    <div class="tab-pane fade" id="barcode">
        <div class="row g-4">
            <div class="col-lg-4">
                <div class="card-premium">
                    <div class="card-header-premium">
                        <i class="fas fa-database"></i> Barcode Generator
                    </div>
                    <div class="card-body-premium">
                        <label class="form-label" style="font-size:0.7rem;font-weight:600;">Data Source</label>
                        <select id="barcodeMode" class="form-select form-select-sm mb-2" onchange="toggleBarcodeMode()">
                            <option value="manual">Manual Entry</option>
                            <option value="range">Number Range</option>
                            <option value="books">From Koha</option>
                            <option value="daterange">Date Range</option>
                        </select>

                        <div id="barcodeManualBox">
                            <label style="font-size:0.7rem;font-weight:600;">Values (one per line)</label>
                            <textarea id="barcodeManualInput" rows="4" class="form-control form-control-sm mb-2">ABC123
BOOK001</textarea>
                        </div>

                        <div id="barcodeRangeBox" style="display:none;">
                            <label style="font-size:0.7rem;font-weight:600;">Prefix</label>
                            <input type="text" id="barcodePrefix" class="form-control form-control-sm mb-1" value="LIB-">
                            <div class="row g-1">
                                <div class="col-6"><label style="font-size:0.65rem;">Start</label><input type="number" id="barcodeStart" class="form-control form-control-sm" value="1"></div>
                                <div class="col-6"><label style="font-size:0.65rem;">End</label><input type="number" id="barcodeEnd" class="form-control form-control-sm" value="50"></div>
                            </div>
                            <label style="font-size:0.7rem;font-weight:600;">Padding</label>
                            <input type="number" id="barcodePad" class="form-control form-control-sm mb-2" value="4">
                        </div>

                        <div id="barcodeBooksBox" style="display:none;">
                            <label style="font-size:0.7rem;font-weight:600;">Select Books</label>
                            <select id="bookBarcodeSelect" multiple class="form-select form-select-sm mb-2" size="5"></select>
                            <button class="btn btn-sm btn-secondary w-100" onclick="loadBooksForBarcode()"><i class="fas fa-sync me-1"></i> Load</button>
                        </div>

                        <div id="barcodeDateRangeBox" style="display:none;">
                            <label style="font-size:0.7rem;font-weight:600;">From Date</label>
                            <input type="date" id="barcodeDateFrom" class="form-control form-control-sm mb-1" value="<?= date('Y-m-01') ?>">
                            <label style="font-size:0.7rem;font-weight:600;">To Date</label>
                            <input type="date" id="barcodeDateTo" class="form-control form-control-sm mb-2" value="<?= date('Y-m-d') ?>">
                            <button class="btn btn-sm btn-secondary w-100" onclick="loadBarcodesByDateRange()"><i class="fas fa-search me-1"></i> Fetch</button>
                            <div id="barcodeFetchedList" class="mt-2 small text-muted"></div>
                        </div>

                        <hr class="my-2">

                        <h6 style="font-size:0.8rem;font-weight:700;"><i class="fas fa-heading me-1"></i> Barcode Header</h6>
                        <div class="row g-1">
                            <div class="col-12">
                                <input type="text" id="barcodeHeaderText" class="form-control form-control-sm" value="LIBRARY SYSTEM" placeholder="Header text" onchange="generateBarcodePreview()">
                            </div>
                            <div class="col-6">
                                <label style="font-size:0.6rem;">Font Size</label>
                                <input type="range" id="barcodeHeaderSize" class="form-range" min="8" max="24" value="14" step="1" oninput="document.getElementById('barcodeHeaderSizeVal').innerText=this.value; generateBarcodePreview()">
                                <span id="barcodeHeaderSizeVal" style="font-size:0.6rem;">14</span>
                            </div>
                            <div class="col-6">
                                <label style="font-size:0.6rem;">Font Weight</label>
                                <select id="barcodeHeaderWeight" class="form-select form-select-sm" onchange="generateBarcodePreview()">
                                    <option value="400">Normal</option>
                                    <option value="600">Semi-bold</option>
                                    <option value="700" selected>Bold</option>
                                    <option value="800">Extra Bold</option>
                                </select>
                            </div>
                            <div class="col-6">
                                <label style="font-size:0.6rem;">Color</label>
                                <input type="color" id="barcodeHeaderColor" class="form-control form-control-color" value="#1a2a6c" onchange="generateBarcodePreview()">
                            </div>
                            <div class="col-6">
                                <label style="font-size:0.6rem;">Alignment</label>
                                <select id="barcodeHeaderAlign" class="form-select form-select-sm" onchange="generateBarcodePreview()">
                                    <option value="center" selected>Center</option>
                                    <option value="left">Left</option>
                                    <option value="right">Right</option>
                                </select>
                            </div>
                            <div class="col-6">
                                <label style="font-size:0.6rem;">Margin Bottom</label>
                                <input type="range" id="barcodeHeaderMargin" class="form-range" min="0" max="20" value="8" step="1" oninput="document.getElementById('barcodeHeaderMarginVal').innerText=this.value; generateBarcodePreview()">
                                <span id="barcodeHeaderMarginVal" style="font-size:0.6rem;">8</span>
                            </div>
                            <div class="col-6">
                                <label style="font-size:0.6rem;">Letter Spacing</label>
                                <input type="range" id="barcodeHeaderSpacing" class="form-range" min="-1" max="4" value="0" step="0.5" oninput="document.getElementById('barcodeHeaderSpacingVal').innerText=this.value; generateBarcodePreview()">
                                <span id="barcodeHeaderSpacingVal" style="font-size:0.6rem;">0</span>
                            </div>
                        </div>

                        <hr class="my-2">

                        <h6 style="font-size:0.8rem;font-weight:700;"><i class="fas fa-print me-1"></i> Layout</h6>
                        <div class="row g-1">
                            <div class="col-6"><label style="font-size:0.65rem;">Rows</label><input type="number" id="barcodeRows" class="form-control form-control-sm" value="4"></div>
                            <div class="col-6"><label style="font-size:0.65rem;">Columns</label><input type="number" id="barcodeCols" class="form-control form-control-sm" value="3"></div>
                        </div>
                        <div class="row g-1 mt-1">
                            <div class="col-6"><label style="font-size:0.65rem;">Barcode Width</label><input type="number" id="barcodeWidth" class="form-control form-control-sm" value="2" step="0.5"></div>
                            <div class="col-6"><label style="font-size:0.65rem;">Height</label><input type="number" id="barcodeHeight" class="form-control form-control-sm" value="50" step="5"></div>
                        </div>
                        <label style="font-size:0.7rem;font-weight:600;margin-top:6px;">Show Value</label>
                        <select id="barcodeShowText" class="form-select form-select-sm mb-2">
                            <option value="true">Yes</option>
                            <option value="false">No</option>
                        </select>

                        <div class="d-grid gap-2 mt-2">
                            <button class="btn-premium btn-premium-primary btn-sm" onclick="generateBarcodePreview()"><i class="fas fa-eye me-1"></i> Preview</button>
                            <button class="btn-premium btn-premium-success btn-sm" onclick="downloadBarcodePDF()"><i class="fas fa-file-pdf me-1"></i> Download PDF</button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-8">
                <div class="card-premium">
                    <div class="card-header-premium">
                        <i class="fas fa-eye"></i> Barcode Preview
                        <span class="ms-auto" style="font-size:0.7rem;font-weight:400;color:#6c757d;">
                            <i class="fas fa-heading me-1"></i> Header enabled
                        </span>
                    </div>
                    <div class="card-body-premium">
                        <div class="barcode-sheet" id="barcodeSheet" style="background:white;padding:20px;border-radius:var(--radius-md);border:1px solid #e9ecef;min-height:300px;">
                            <div class="text-center text-muted py-4">
                                <i class="fas fa-barcode fa-3x mb-3 d-block" style="opacity:0.2;"></i>
                                Enter data and click Preview
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- ============================================================
SCRIPTS
============================================================ -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/jsbarcode@3.11.6/dist/JsBarcode.all.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>

<script>
// ============================================================
// INSTITUTION NAME — injected from PHP as a CLEAN plain string  [CHANGED v7.1]
// ============================================================
window.VMS_INSTITUTION_NAME = <?= json_encode($institutionName, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;

// ============================================================
// GLOBAL STATE
// ============================================================
let cards = [];
let selectedMemberElem = null;
let currentThemeStart = '#1a2a6c', currentThemeEnd = '#2a4a8a';
let useQR = false;
let currentLayoutCols = 2;
let customLeftLogoData = null;
let frontBgData = null;
let backBgData = null;
let signatureImageData = null;
let currentBarcodeValues = [];
const institutionLogo = "<?= $institutionLogo ? $institutionLogo : '' ?>";

// Field order state
let fieldOrder = ['name', 'designation', 'classDept', 'divisionCourse', 'phone', 'year', 'idNumber'];
const FIELD_STORAGE_KEY = 'idcards_field_prefs_v7';

// ============================================================
// FIELD PREFERENCES (localStorage)
// ============================================================
function saveFieldPreferences() {
    try {
        const prefs = {
            order: fieldOrder,
            fields: {}
        };
        document.querySelectorAll('#fieldToggleContainer .field-toggle-row').forEach(row => {
            const field = row.dataset.field;
            prefs.fields[field] = {
                visible: row.querySelector('.field-visible').checked,
                label: row.querySelector('.field-label-input').value
            };
        });
        localStorage.setItem(FIELD_STORAGE_KEY, JSON.stringify(prefs));
    } catch(e) { console.warn('Could not save field prefs', e); }
}

function loadFieldPreferences() {
    try {
        const raw = localStorage.getItem(FIELD_STORAGE_KEY);
        if (!raw) return;
        const prefs = JSON.parse(raw);
        if (prefs.order && Array.isArray(prefs.order)) {
            fieldOrder = prefs.order;
        }
        if (prefs.fields) {
            document.querySelectorAll('#fieldToggleContainer .field-toggle-row').forEach(row => {
                const field = row.dataset.field;
                if (prefs.fields[field]) {
                    row.querySelector('.field-visible').checked = !!prefs.fields[field].visible;
                    if (prefs.fields[field].label) {
                        row.querySelector('.field-label-input').value = prefs.fields[field].label;
                    }
                }
            });
        }
        reorderFieldRows();
    } catch(e) { console.warn('Could not load field prefs', e); }
}

function resetFieldPreferences() {
    if (!confirm('Reset all field visibility and labels to defaults?')) return;
    localStorage.removeItem(FIELD_STORAGE_KEY);
    fieldOrder = ['name', 'designation', 'classDept', 'divisionCourse', 'phone', 'year', 'idNumber'];
    const defaults = {
        name: 'Name',
        designation: 'Desig',
        classDept: 'Class/Dept',
        divisionCourse: 'Div/Course',
        phone: 'Contact',
        year: 'Year',
        idNumber: 'ID No'
    };
    document.querySelectorAll('#fieldToggleContainer .field-toggle-row').forEach(row => {
        const field = row.dataset.field;
        row.querySelector('.field-visible').checked = true;
        row.querySelector('.field-label-input').value = defaults[field] || field;
    });
    reorderFieldRows();
    updateCardStyle();
}

function moveField(field, direction) {
    const idx = fieldOrder.indexOf(field);
    if (idx === -1) return;
    const newIdx = idx + direction;
    if (newIdx < 0 || newIdx >= fieldOrder.length) return;
    [fieldOrder[idx], fieldOrder[newIdx]] = [fieldOrder[newIdx], fieldOrder[idx]];
    reorderFieldRows();
    saveFieldPreferences();
    updateCardStyle();
}

function reorderFieldRows() {
    const container = document.getElementById('fieldToggleContainer');
    if (!container) return;
    const rows = {};
    container.querySelectorAll('.field-toggle-row').forEach(row => {
        rows[row.dataset.field] = row;
    });
    fieldOrder.forEach(field => {
        if (rows[field]) container.appendChild(rows[field]);
    });
}

function getFieldConfig() {
    const config = {};
    document.querySelectorAll('#fieldToggleContainer .field-toggle-row').forEach(row => {
        const field = row.dataset.field;
        config[field] = {
            visible: row.querySelector('.field-visible').checked,
            label: row.querySelector('.field-label-input').value || field,
            order: fieldOrder.indexOf(field)
        };
    });
    return config;
}

// ============================================================
// SETTINGS
// ============================================================
async function saveInstitutionSettings() {
    const name = document.getElementById('institutionNameInput').value.trim();
    const fileInput = document.getElementById('institutionLogoFile');
    let logoData = '';

    if (fileInput.files.length > 0) {
        const file = fileInput.files[0];
        const reader = new FileReader();
        logoData = await new Promise((resolve) => {
            reader.onload = function(e) { resolve(e.target.result); };
            reader.readAsDataURL(file);
        });
    }

    const formData = new FormData();
    formData.append('ajax_action', 'update_institution_settings');
    formData.append('institution_name', name);
    if (logoData) formData.append('institution_logo', logoData);

    try {
        const resp = await fetch(window.location.href, { method: 'POST', body: formData });
        const data = await resp.json();
        if (data.success) {
            alert('✅ Settings saved! Refresh the page to see changes.');
            location.reload();
        } else {
            alert('❌ Failed to save settings: ' + (data.message || ''));
        }
    } catch (e) {
        alert('Error: ' + e.message);
    }
}

function removeInstitutionLogo() {
    if (confirm('Remove the institution logo?')) {
        const formData = new FormData();
        formData.append('ajax_action', 'update_institution_settings');
        formData.append('institution_name', document.getElementById('institutionNameInput').value.trim());
        formData.append('institution_logo', '');
        fetch(window.location.href, { method: 'POST', body: formData })
            .then(r => r.json())
            .then(data => {
                if (data.success) { location.reload(); }
                else { alert('Failed to remove logo.'); }
            });
    }
}

// ============================================================
// TOGGLE STYLE CONTROLS
// ============================================================
function toggleStyleControls(id) {
    const el = document.getElementById(id);
    const toggle = el.parentElement.querySelector('.style-controls-toggle');
    if (el.classList.contains('collapsed')) {
        el.classList.remove('collapsed');
        el.style.maxHeight = el.scrollHeight + 'px';
        toggle.querySelector('.toggle-icon').style.transform = 'rotate(0deg)';
    } else {
        el.classList.add('collapsed');
        el.style.maxHeight = '0';
        toggle.querySelector('.toggle-icon').style.transform = 'rotate(-90deg)';
    }
}

// ============================================================
// BACKGROUND / SIGNATURE IMAGE HANDLERS
// ============================================================
function updateFrontBackground() {
    const file = document.getElementById('frontBgImage').files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = function(e) {
        frontBgData = e.target.result;
        document.getElementById('frontBgPreview').style.display = 'block';
        document.getElementById('frontBgPreviewImg').src = frontBgData;
        updateCardStyle();
    };
    reader.readAsDataURL(file);
}

function removeFrontBackground() {
    frontBgData = null;
    document.getElementById('frontBgPreview').style.display = 'none';
    document.getElementById('frontBgImage').value = '';
    updateCardStyle();
}

function updateBackBackground() {
    const file = document.getElementById('backBgImage').files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = function(e) {
        backBgData = e.target.result;
        document.getElementById('backBgPreview').style.display = 'block';
        document.getElementById('backBgPreviewImg').src = backBgData;
        updateCardStyle();
    };
    reader.readAsDataURL(file);
}

function removeBackBackground() {
    backBgData = null;
    document.getElementById('backBgPreview').style.display = 'none';
    document.getElementById('backBgImage').value = '';
    updateCardStyle();
}

function updateSignatureImage() {
    const file = document.getElementById('signatureImage').files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = function(e) {
        signatureImageData = e.target.result;
        document.getElementById('signatureImagePreview').style.display = 'block';
        document.getElementById('signatureImagePreviewImg').src = signatureImageData;
        updateCardStyle();
    };
    reader.readAsDataURL(file);
}

function removeSignatureImage() {
    signatureImageData = null;
    document.getElementById('signatureImagePreview').style.display = 'none';
    document.getElementById('signatureImage').value = '';
    updateCardStyle();
}

function updateCardStyle() {
    saveFieldPreferences();
    regenerateAllCards();
}

// ============================================================
// ID CARDS - Core Functions
// ============================================================
function selectMember(el) {
    if(selectedMemberElem) selectedMemberElem.classList.remove('selected');
    selectedMemberElem = el;
    el.classList.add('selected');
}

function filterMembers() {
    let term = document.getElementById('memberSearch').value.toLowerCase();
    document.querySelectorAll('.member-item').forEach(m => {
        let t = (m.dataset.name + m.dataset.admno + (m.dataset.class||'') + (m.dataset.division||'')).toLowerCase();
        m.style.display = t.includes(term) ? '' : 'none';
    });
}

function uploadCustomLogo() {
    let file = document.getElementById('customLeftLogo').files[0];
    if(!file) return;
    let reader = new FileReader();
    reader.onload = function(e) {
        customLeftLogoData = e.target.result;
        document.getElementById('customLogoPreview').innerHTML = `<img src="${customLeftLogoData}" style="max-height:32px; border-radius:6px;">`;
        regenerateAllCards();
    };
    reader.readAsDataURL(file);
}

function applyExternalPhoto() {
    if(!selectedMemberElem) { alert('Select a member first.'); return; }
    let file = document.getElementById('externalPhotoFile').files[0];
    if(!file) return;
    let reader = new FileReader();
    reader.onload = function(e) {
        selectedMemberElem.dataset.tempPhoto = e.target.result;
        regenerateAllCards();
    };
    reader.readAsDataURL(file);
}

function getSelectedMemberData() {
    if(!selectedMemberElem) { alert('Select a member first.'); return null; }
    return {
        admno: selectedMemberElem.dataset.admno,
        name: selectedMemberElem.dataset.name,
        roll: selectedMemberElem.dataset.admno,
        classDept: selectedMemberElem.dataset.class || '',
        divisionCourse: selectedMemberElem.dataset.division || '',
        phone: selectedMemberElem.dataset.phone || '',
        designation: selectedMemberElem.dataset.designation || '',
        year: selectedMemberElem.dataset.year || '',
        photoUrl: selectedMemberElem.dataset.tempPhoto || selectedMemberElem.dataset.photoUrl || ''
    };
}

async function fetchPhotoBase64(admno) {
    let url = window.location.href + '?ajax_action=get_photo_base64&admno=' + encodeURIComponent(admno);
    try {
        let resp = await fetch(url);
        let data = await resp.json();
        if (data.success && data.base64) return data.base64;
    } catch(e) { console.error(e); }
    return '';
}

async function generateSelectedMembers() {
    let data = getSelectedMemberData();
    if(data) await generateCard(data);
}

async function generateAllMembers() {
    let members = document.querySelectorAll('.member-item');
    if(!members.length) return;
    if(confirm('Generate ' + members.length + ' cards?')) {
        for(let m of members) {
            await generateCard({
                admno: m.dataset.admno,
                name: m.dataset.name,
                roll: m.dataset.admno,
                classDept: m.dataset.class || '',
                divisionCourse: m.dataset.division || '',
                phone: m.dataset.phone || '',
                designation: m.dataset.designation || '',
                year: m.dataset.year || '',
                photoUrl: m.dataset.tempPhoto || m.dataset.photoUrl || ''
            });
        }
    }
}

async function generateCard(data) {
    const schoolName = document.getElementById('schoolName').value || 'Library';
    const tagline = document.getElementById('tagline').value;
    const rules = document.getElementById('libraryRules').value.replace(/\n/g, '<br>');
    const signature = document.getElementById('signatureText').value;

    // Header
    const headerTop = parseInt(document.getElementById('headerTop').value) || 0;
    const headerFontSize = document.getElementById('headerFontSize').value;
    const headerFontWeight = document.getElementById('headerFontWeight').value;
    const headerAlign = document.getElementById('headerAlign').value;
    const headerColor = document.getElementById('headerColor').value;
    const headerLetterSpacing = document.getElementById('headerLetterSpacing').value;
    const headerFontFamily = document.getElementById('headerFontFamily').value;
    const headerTransform = document.getElementById('headerTransform').value;

    // Header Background
    const headerBgEnable = document.getElementById('headerBgEnable').checked;
    const headerBgColor = document.getElementById('headerBgColor').value;
    const headerBgOpacity = document.getElementById('headerBgOpacity').value / 100;
    const headerPadding = document.getElementById('headerPadding').value;
    const headerRadius = document.getElementById('headerRadius').value;
    const headerWidth = document.getElementById('headerWidth').value;

    // Tagline
    const taglineTop = parseInt(document.getElementById('taglineTop').value) || 0;
    const taglineBottom = parseInt(document.getElementById('taglineBottom').value) || 0;
    const taglineFontSize = document.getElementById('taglineFontSize').value;
    const taglineColor = document.getElementById('taglineColor').value;
    const taglineTransform = document.getElementById('taglineTransform').value;
    const taglineFontFamily = document.getElementById('taglineFontFamily').value;
    const taglineOpacity = document.getElementById('taglineOpacity').value / 100;

    // Info
    const infoTop = parseInt(document.getElementById('infoTop').value) || 5;
    const infoBottom = parseInt(document.getElementById('infoBottom').value) || 5;
    const infoLeft = parseInt(document.getElementById('infoLeft').value) || 10;
    const infoRight = parseInt(document.getElementById('infoRight').value) || 10;
    const infoFontSize = document.getElementById('infoFontSize').value;
    const infoLineHeight = document.getElementById('infoLineHeight').value;
    const infoRowGap = document.getElementById('infoRowGap').value;
    const infoColor = document.getElementById('infoColor').value;
    const infoAlign = document.getElementById('infoAlign').value;
    const infoFontFamily = document.getElementById('infoFontFamily').value;
    const labelOpacity = document.getElementById('labelOpacity').value / 100;
    const infoSeparator = document.getElementById('infoSeparator').value;

    // Year & ID
    const yearFontSize = document.getElementById('yearFontSize').value;
    const yearColor = document.getElementById('yearColor').value;
    const idFontSize = document.getElementById('idFontSize').value;
    const idColor = document.getElementById('idColor').value;
    const idTop = document.getElementById('idTop').value;
    const idRight = document.getElementById('idRight').value;

    const headerBold = document.getElementById('headerBold').checked;
    const showYear = document.getElementById('showYear').checked;

    const bgOpacity = document.getElementById('bgOpacity').value / 100;
    const bgColor = document.getElementById('bgColor').value;

    // Back
    const backBgOpacity = document.getElementById('backBgOpacity').value / 100;
    const backColor = document.getElementById('backColor').value;
    const rulesFontSize = document.getElementById('rulesFontSize').value;
    const rulesColor = document.getElementById('rulesColor').value;
    const rulesTitleSize = document.getElementById('rulesTitleSize').value;
    const rulesTitleColor = document.getElementById('rulesTitleColor').value;
    const rulesTextAlign = document.getElementById('rulesTextAlign').value;
    const rulesTitleAlign = document.getElementById('rulesTitleAlign').value;
    const signatureFontSize = document.getElementById('signatureFontSize').value;
    const signatureColor = document.getElementById('signatureColor').value;
    const signatureAlign = document.getElementById('signatureAlign').value;

    // Photo / Logo / Barcode
    const photoWidth = document.getElementById('photoWidth').value;
    const photoHeight = document.getElementById('photoHeight').value;
    const photoTop = document.getElementById('photoTop').value;
    const photoRight = document.getElementById('photoRight').value;
    const photoBorderColor = document.getElementById('photoBorderColor').value;
    const photoBorderWidth = document.getElementById('photoBorderWidth').value;

    const logoWidth = document.getElementById('logoWidth').value;
    const logoHeight = document.getElementById('logoHeight').value;
    const logoLeft = parseInt(document.getElementById('logoLeft').value) || 14;
    const logoTop = parseInt(document.getElementById('logoTop').value) || 14;

    const barcodeBottom = parseInt(document.getElementById('barcodeBottom').value) || 10;
    const barcodeHeight = document.getElementById('barcodeHeight').value;

    // Field config
    const fieldConfig = getFieldConfig();

    // Header bg computation
    let headerBgValue = 'transparent';
    if (headerBgEnable && headerBgOpacity > 0) {
        const hex = headerBgColor.replace('#', '');
        const r = parseInt(hex.substring(0, 2), 16);
        const g = parseInt(hex.substring(2, 4), 16);
        const b = parseInt(hex.substring(4, 6), 16);
        headerBgValue = `rgba(${r},${g},${b},${headerBgOpacity})`;
    }

    let cardId = 'card_' + Date.now() + '_' + Math.random().toString(36).substr(2, 8);

    // Fetch photo
    let finalPhoto = '';
    if (data.photoUrl && (data.photoUrl.startsWith('blob:') || data.photoUrl.startsWith('data:'))) finalPhoto = data.photoUrl;
    else if (data.admno) finalPhoto = await fetchPhotoBase64(data.admno);

    let leftLogoUrl = customLeftLogoData ? customLeftLogoData : (institutionLogo ? institutionLogo : '');
    let displayYear = data.year || new Date().getFullYear().toString();

    // Build front style
    let frontStyle = `--card-width:${document.getElementById('cardWidth').value}px;--card-height:${document.getElementById('cardHeight').value}px;`;
    frontStyle += `--header-font-size:${headerFontSize}px;--header-font-weight:${headerBold ? '800' : headerFontWeight};--header-align:${headerAlign};--header-color:${headerColor};--header-letter-spacing:${headerLetterSpacing}px;`;
    frontStyle += `--header-top:${headerTop}px;--header-bg:${headerBgValue};--header-padding:${headerPadding}px;--header-padding-x:${headerPadding}px;--header-radius:${headerRadius}px;`;
    frontStyle += `--header-font-family:'${headerFontFamily}';--header-transform:${headerTransform};`;
    frontStyle += `--tagline-font-size:${taglineFontSize}px;--tagline-color:${taglineColor};--tagline-transform:${taglineTransform};--tagline-font-family:'${taglineFontFamily}';--tagline-opacity:${taglineOpacity};`;
    frontStyle += `--tagline-top:${taglineTop}px;--tagline-bottom:${taglineBottom}px;`;
    frontStyle += `--info-font-size:${infoFontSize}px;--info-top:${infoTop}px;--info-bottom:${infoBottom}px;--info-left:${infoLeft}px;--info-right:${infoRight}px;--info-color:${infoColor};--label-opacity:${labelOpacity};--info-line-height:${infoLineHeight};--info-row-gap:${infoRowGap}px;--info-align:${infoAlign};--info-font-family:'${infoFontFamily}';`;
    frontStyle += `--year-font-size:${yearFontSize}px;--year-color:${yearColor};--id-font-size:${idFontSize}px;--id-color:${idColor};--id-top:${idTop}px;--id-right:${idRight}px;`;
    frontStyle += `--barcode-height:${barcodeHeight}px;--barcode-bottom:${barcodeBottom}px;`;
    frontStyle += `--photo-width:${photoWidth}px;--photo-height:${photoHeight}px;--photo-top:${photoTop}px;--photo-right:${photoRight}px;--photo-border-color:${photoBorderColor};--photo-border-width:${photoBorderWidth}px;`;
    frontStyle += `--logo-width:${logoWidth}px;--logo-height:${logoHeight}px;--logo-left:${logoLeft}px;--logo-top:${logoTop}px;`;
    frontStyle += `--bg-opacity:${bgOpacity};`;
    frontStyle += `--header-width:${headerWidth}%;`;

    let frontBgStyle = frontBgData ? `background-image:url('${frontBgData}');background-size:cover;background-position:center;` : `background:${bgColor};`;

    // Build info rows
    const fieldValues = {
        name: data.name,
        designation: data.designation,
        classDept: data.classDept,
        divisionCourse: data.divisionCourse,
        phone: data.phone,
        year: displayYear,
        idNumber: data.roll
    };

    let infoRowsHtml = '';
    fieldOrder.forEach(field => {
        const cfg = fieldConfig[field];
        if (!cfg || !cfg.visible) return;
        const value = fieldValues[field] || '';
        if (!value && field !== 'year') return;
        if (field === 'year' && !showYear) return;

        const sep = infoSeparator ? ` ${infoSeparator} ` : ' ';
        const rowAlignClass = infoAlign === 'center' ? 'center' : (infoAlign === 'right' ? 'right' : '');
        infoRowsHtml += `<div class="info-row ${rowAlignClass}"><span class="label">${escapeHtml(cfg.label)}${sep}</span> <span class="value">${escapeHtml(value)}</span></div>`;
    });

    // Build front HTML
    let frontHtml = `<div class="id-card front" style="${frontStyle}${frontBgStyle}">`;
    frontHtml += `<div class="card-bg-overlay" style="background:${bgColor}; opacity:${bgOpacity};"></div>`;
    frontHtml += `<div class="card-content">`;
    frontHtml += leftLogoUrl ? `<img class="card-logo" src="${leftLogoUrl}" alt="Logo">` : '';
    frontHtml += `<div class="card-header-text" style="max-width:var(--header-width);${headerAlign === 'center' ? 'margin-left:auto;margin-right:auto;' : (headerAlign === 'right' ? 'margin-left:auto;' : '')}">`;
    frontHtml += `<div class="institution">${escapeHtml(schoolName)}</div>`;
    frontHtml += `<div class="tagline">${escapeHtml(tagline)}</div>`;
    frontHtml += `</div>`;
    frontHtml += `<div class="card-photo">${finalPhoto ? `<img src="${finalPhoto}" onerror="this.parentElement.innerHTML='<i class=\\'fas fa-user\\'></i>';">` : '<i class="fas fa-user"></i>'}</div>`;

    if (fieldConfig.idNumber && fieldConfig.idNumber.visible) {
        frontHtml += `<div class="card-id"><strong>${escapeHtml(fieldConfig.idNumber.label)}:</strong><br>${escapeHtml(data.roll)}</div>`;
    }

    frontHtml += `<div class="card-info">${infoRowsHtml}</div>`;

    if (showYear && fieldConfig.year && fieldConfig.year.visible) {
        frontHtml += `<div class="card-year"><strong>${escapeHtml(fieldConfig.year.label)}:</strong> ${escapeHtml(displayYear)}</div>`;
    }

    frontHtml += useQR ? `<div class="card-qrcode" id="qrcode-${cardId}"></div>` : `<div class="card-barcode"><svg id="barcode-${cardId}"></svg></div>`;
    frontHtml += `</div></div>`;

    // Build back
    let backStyle = `--back-bg:${backColor};--back-text-color:${backColor === '#f8f9fa' ? '#2c3e50' : '#ffffff'};`;
    backStyle += `--rules-title-size:${rulesTitleSize}px;--rules-text-size:${rulesFontSize}px;--rules-title-color:${rulesTitleColor};--rules-text-color:${rulesColor};`;
    backStyle += `--rules-title-align:${rulesTitleAlign};--rules-text-align:${rulesTextAlign};`;
    backStyle += `--signature-font-size:${signatureFontSize}px;--signature-color:${signatureColor};--signature-align:${signatureAlign};`;
    backStyle += `--back-bg-opacity:${backBgOpacity};`;

    let backBgStyle = backBgData ? `background-image:url('${backBgData}');background-size:cover;background-position:center;` : '';

    let backHtml = `<div class="id-card back" style="${backStyle}${backBgStyle}">`;
    if (backBgData) {
        backHtml += `<div class="card-back-bg-overlay" style="background:${backColor};opacity:${backBgOpacity};"></div>`;
    }
    backHtml += `<div class="card-back-content"><div class="rules-title">📋 Library Rules</div><div class="rules-text">${rules}</div><div class="signature-area">`;
    if (signatureImageData) {
        backHtml += `<div><img src="${signatureImageData}" class="signature-image"></div>`;
    }
    backHtml += `<div>${escapeHtml(signature)}</div><div class="signature-line"></div><div style="font-size:7px;opacity:0.6;">Issue: ${new Date().toLocaleDateString()}</div>`;
    backHtml += `</div></div></div>`;

    // Create pair
    let pair = document.createElement('div');
    pair.className = 'card-pair';
    pair.setAttribute('data-card-id', cardId);

    let frontDiv = document.createElement('div');
    frontDiv.innerHTML = frontHtml;
    let backDiv = document.createElement('div');
    backDiv.innerHTML = backHtml;

    pair.appendChild(frontDiv.firstChild);
    pair.appendChild(backDiv.firstChild);

    let cb = document.createElement('input');
    cb.type = 'checkbox';
    cb.className = 'card-checkbox';
    cb.checked = true;
    cb.onchange = function(e) { e.stopPropagation(); pair.classList.toggle('selected-for-export', this.checked); };
    pair.appendChild(cb);

    let container = document.getElementById('cardsContainer');
    if(container.querySelector('.text-muted.py-5')) container.innerHTML = '';
    container.appendChild(pair);

    if(useQR) {
        setTimeout(() => { 
            const el = document.getElementById(`qrcode-${cardId}`);
            if (el) new QRCode(el, { text: data.roll, width: 50, height: 50 });
        }, 50);
    } else {
        setTimeout(() => { 
            try {
                JsBarcode(`#barcode-${cardId}`, data.roll.toString(), { format: 'CODE128', width: 1.2, height: parseInt(barcodeHeight), displayValue: false, margin: 0 });
            } catch(e) { console.warn('Barcode error', e); }
        }, 50);
    }

    cards.push({ id: cardId, element: pair, data: data });
    updateCardCount();
}

function resizeCards() {
    let w = document.getElementById('cardWidth').value, h = document.getElementById('cardHeight').value;
    document.documentElement.style.setProperty('--card-width', w + 'px');
    document.documentElement.style.setProperty('--card-height', h + 'px');
    regenerateAllCards();
}

function setCardSize(w, h) {
    document.getElementById('cardWidth').value = w;
    document.getElementById('cardHeight').value = h;
    document.querySelectorAll('.size-preset').forEach(p => p.classList.remove('active'));
    event.target.classList.add('active');
    resizeCards();
}

function applyTheme(start, end, btn) {
    currentThemeStart = start; currentThemeEnd = end;
    document.querySelectorAll('.theme-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    document.getElementById('themeStartColor').value = start;
    document.getElementById('themeEndColor').value = end;
    document.getElementById('bgColor').value = start;
    regenerateAllCards();
}

function applyCustomTheme() {
    let start = document.getElementById('themeStartColor').value, end = document.getElementById('themeEndColor').value;
    currentThemeStart = start; currentThemeEnd = end;
    document.getElementById('bgColor').value = start;
    regenerateAllCards();
}

function regenerateAllCards() {
    if(!cards.length) return;
    let container = document.getElementById('cardsContainer');
    let oldCards = [...cards];
    container.innerHTML = '';
    cards = [];
    (async () => { 
        for(let card of oldCards) await generateCard(card.data); 
        setPrintLayout(currentLayoutCols);
    })();
}

function clearCards() {
    if(cards.length && confirm('Clear all generated cards?')) {
        document.getElementById('cardsContainer').innerHTML = '<div class="text-center text-muted py-5" style="width:100%;"><i class="fas fa-id-card fa-3x mb-3 d-block" style="opacity:0.2;"></i>Select a member from the left panel and click Generate</div>';
        cards = [];
        updateCardCount();
    }
}

function updateCardCount() { document.getElementById('cardCount').innerText = cards.length; }

function toggleQR() { useQR = document.getElementById('includeQR').checked; regenerateAllCards(); }

function setPrintLayout(cols) {
    currentLayoutCols = cols;
    document.querySelectorAll('.layout-preset').forEach(p => p.classList.remove('active'));
    const preset = document.querySelector(`.layout-preset[data-cols="${cols}"]`);
    if (preset) preset.classList.add('active');
    let container = document.getElementById('cardsContainer');
    let gap = 20;
    let widthPercent = 100 / cols;
    container.style.display = 'flex';
    container.style.flexWrap = 'wrap';
    container.style.gap = gap + 'px';
    container.style.justifyContent = 'center';
    document.querySelectorAll('.card-pair').forEach(pair => {
        pair.style.flex = `0 0 calc(${widthPercent}% - ${gap}px)`;
        pair.style.maxWidth = `calc(${widthPercent}% - ${gap}px)`;
    });
}

function selectAllCards() {
    document.querySelectorAll('.card-pair').forEach(p => { p.classList.add('selected-for-export'); let cb = p.querySelector('.card-checkbox'); if(cb) cb.checked = true; });
}

function deselectAllCards() {
    document.querySelectorAll('.card-pair').forEach(p => { p.classList.remove('selected-for-export'); let cb = p.querySelector('.card-checkbox'); if(cb) cb.checked = false; });
}

function getSelectedCards() {
    return Array.from(document.querySelectorAll('.card-pair')).filter(p => p.querySelector('.card-checkbox')?.checked);
}

async function exportToPDF(selectedOnly = false) {
    let cardsToExport = selectedOnly ? getSelectedCards() : document.querySelectorAll('.card-pair');
    if(cardsToExport.length === 0) { alert('No cards selected for export.'); return; }
    const isColor = document.getElementById('colorPrint').checked;
    const { jsPDF } = window.jspdf;
    const CARD_WIDTH_MM = 85.6, CARD_HEIGHT_MM = 54, PAGE_WIDTH_MM = 210, PAGE_HEIGHT_MM = 297, LEFT_MARGIN = 12, RIGHT_MARGIN = 12, TOP_MARGIN = 15, BOTTOM_MARGIN = 12, HORIZONTAL_GAP = 8, VERTICAL_GAP = 6;
    let cardWidth = CARD_WIDTH_MM, cardHeight = CARD_HEIGHT_MM, horizontalGap = HORIZONTAL_GAP;
    const availableWidth = PAGE_WIDTH_MM - LEFT_MARGIN - RIGHT_MARGIN;
    const twoCardsWidth = (cardWidth * 2) + horizontalGap;
    if (twoCardsWidth > availableWidth) {
        const scale = availableWidth / twoCardsWidth;
        cardWidth *= scale; cardHeight *= scale; horizontalGap *= scale;
    }
    let verticalGap = VERTICAL_GAP, cardsPerPage = 5;
    const totalHeightNeeded = (5 * cardHeight) + (4 * VERTICAL_GAP);
    const availableHeight = PAGE_HEIGHT_MM - TOP_MARGIN - BOTTOM_MARGIN;
    if (totalHeightNeeded > availableHeight) {
        cardsPerPage = 4;
        const fourCardsHeight = (4 * cardHeight) + (3 * VERTICAL_GAP);
        if (fourCardsHeight > availableHeight) {
            verticalGap = (availableHeight - (4 * cardHeight)) / 3;
            if (verticalGap < 2) verticalGap = 2;
        }
    }
    async function captureCardElement(el) {
        return new Promise((resolve) => {
            setTimeout(() => {
                html2canvas(el, { scale: 3, backgroundColor: isColor ? null : '#ffffff', useCORS: false, allowTaint: true, logging: false })
                    .then(canvas => resolve(canvas.toDataURL('image/png', 1.0)))
                    .catch(err => { console.error(err); resolve(null); });
            }, 100);
        });
    }
    let cardImages = [];
    for (let i = 0; i < cardsToExport.length; i++) {
        const pair = cardsToExport[i];
        const frontEl = pair.querySelector('.id-card.front');
        const backEl = pair.querySelector('.id-card.back');
        if (frontEl && backEl) {
            const frontImg = await captureCardElement(frontEl);
            const backImg = await captureCardElement(backEl);
            if (frontImg && backImg) cardImages.push({ front: frontImg, back: backImg });
        }
    }
    if (cardImages.length === 0) { alert('Could not generate card images.'); return; }
    const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
    let yPosition = TOP_MARGIN;
    let cardsOnCurrentPage = 0;
    for (let i = 0; i < cardImages.length; i++) {
        const card = cardImages[i];
        if (cardsOnCurrentPage >= cardsPerPage) { doc.addPage(); yPosition = TOP_MARGIN; cardsOnCurrentPage = 0; }
        const frontX = LEFT_MARGIN;
        const backX = LEFT_MARGIN + cardWidth + horizontalGap;
        doc.addImage(card.front, 'PNG', frontX, yPosition, cardWidth, cardHeight);
        doc.addImage(card.back, 'PNG', backX, yPosition, cardWidth, cardHeight);
        yPosition += cardHeight + verticalGap;
        cardsOnCurrentPage++;
    }
    doc.save(selectedOnly ? 'selected_id_cards.pdf' : 'all_id_cards.pdf');
}

async function exportToPNG() {
    let cardsToExport = getSelectedCards();
    if(cardsToExport.length === 0) { alert('Select at least one card first.'); return; }
    let tempContainer = document.createElement('div');
    tempContainer.style.position = 'absolute';
    tempContainer.style.top = '-10000px';
    tempContainer.style.background = 'white';
    tempContainer.style.padding = '20px';
    for(let pair of cardsToExport) { tempContainer.appendChild(pair.cloneNode(true)); }
    document.body.appendChild(tempContainer);
    await new Promise(r => setTimeout(r, 200));
    try {
        let canvas = await html2canvas(tempContainer, { scale: 3, backgroundColor: '#ffffff', useCORS: false });
        let link = document.createElement('a');
        link.download = 'id_cards.png';
        link.href = canvas.toDataURL();
        link.click();
    } catch(e) { alert('PNG export error'); }
    finally { document.body.removeChild(tempContainer); }
}

// ============================================================
// BARCODES
// ============================================================
function toggleBarcodeMode() {
    let mode = document.getElementById('barcodeMode').value;
    document.getElementById('barcodeManualBox').style.display = mode === 'manual' ? 'block' : 'none';
    document.getElementById('barcodeRangeBox').style.display = mode === 'range' ? 'block' : 'none';
    document.getElementById('barcodeBooksBox').style.display = mode === 'books' ? 'block' : 'none';
    document.getElementById('barcodeDateRangeBox').style.display = mode === 'daterange' ? 'block' : 'none';
    if (mode === 'books') loadBooksForBarcode();
}

function loadBooksForBarcode() {
    fetch(window.location.href + '?ajax_action=all_books')
        .then(r => r.json())
        .then(data => {
            let sel = document.getElementById('bookBarcodeSelect');
            sel.innerHTML = data.map(b => `<option value="${escapeHtml(b.barcode)}">${escapeHtml(b.barcode)} - ${escapeHtml(b.title)}</option>`).join('');
        })
        .catch(() => alert('Could not load books from Koha.'));
}

function loadBarcodesByDateRange() {
    let from = document.getElementById('barcodeDateFrom').value;
    let to = document.getElementById('barcodeDateTo').value;
    if(!from || !to) { alert('Please select a date range.'); return; }
    fetch(`${window.location.href}?ajax_action=books_by_date&from=${from}&to=${to}`)
        .then(r => r.json())
        .then(data => {
            let listDiv = document.getElementById('barcodeFetchedList');
            if(data.books && data.books.length) {
                currentBarcodeValues = data.books.map(b => b.barcode);
                listDiv.innerHTML = `<strong>${data.books.length}</strong> barcodes fetched from ${from} to ${to}`;
                generateBarcodePreview();
            } else {
                listDiv.innerHTML = 'No books found in this date range';
                currentBarcodeValues = [];
                document.getElementById('barcodeSheet').innerHTML = '<div class="text-center text-muted py-4"><i class="fas fa-book-open fa-2x mb-2 d-block" style="opacity:0.2;"></i>No books found</div>';
            }
        })
        .catch(() => alert('Error fetching books.'));
}

function getBarcodeValues() {
    let mode = document.getElementById('barcodeMode').value;
    if(mode==='manual') return document.getElementById('barcodeManualInput').value.split('\n').map(v=>v.trim()).filter(v=>v);
    if(mode==='range'){
        let p=document.getElementById('barcodePrefix').value,s=parseInt(document.getElementById('barcodeStart').value),e=parseInt(document.getElementById('barcodeEnd').value),pad=parseInt(document.getElementById('barcodePad').value);
        let arr=[]; for(let i=s;i<=e;i++) arr.push(p+String(i).padStart(pad,'0')); return arr;
    }
    if(mode==='books'){ let sel=document.getElementById('bookBarcodeSelect'); return Array.from(sel.selectedOptions).map(opt=>opt.value); }
    if(mode==='daterange') return currentBarcodeValues;
    return [];
}

function generateBarcodePreview() {
    let values = getBarcodeValues();
    if(!values.length){ alert('No data to generate barcodes.'); return; }
    let rows = parseInt(document.getElementById('barcodeRows').value) || 4;
    let cols = parseInt(document.getElementById('barcodeCols').value) || 3;
    let width = parseFloat(document.getElementById('barcodeWidth').value) || 2;
    let height = parseInt(document.getElementById('barcodeHeight').value) || 50;
    let showText = document.getElementById('barcodeShowText').value === 'true';
    let sheet = document.getElementById('barcodeSheet');

    let headerText = document.getElementById('barcodeHeaderText').value || 'LIBRARY SYSTEM';
    let headerSize = parseInt(document.getElementById('barcodeHeaderSize').value) || 14;
    let headerWeight = document.getElementById('barcodeHeaderWeight').value || '700';
    let headerColor = document.getElementById('barcodeHeaderColor').value || '#1a2a6c';
    let headerAlign = document.getElementById('barcodeHeaderAlign').value || 'center';
    let headerMargin = parseInt(document.getElementById('barcodeHeaderMargin').value) || 8;
    let headerSpacing = parseFloat(document.getElementById('barcodeHeaderSpacing').value) || 0;

    sheet.innerHTML = `<div style="display:grid;grid-template-columns:repeat(${cols},1fr);gap:10px;"></div>`;

    let grid = sheet.querySelector('div');

    for(let i = 0; i < rows * cols; i++){
        let code = values[i % values.length] || 'N/A';
        let box = document.createElement('div');
        box.style.border = '1px solid #eee';
        box.style.borderRadius = '8px';
        box.style.padding = '10px';
        box.style.background = '#fafafa';
        box.style.textAlign = 'center';

        let headerDiv = document.createElement('div');
        headerDiv.textContent = headerText;
        headerDiv.style.fontSize = headerSize + 'px';
        headerDiv.style.fontWeight = headerWeight;
        headerDiv.style.color = headerColor;
        headerDiv.style.textAlign = headerAlign;
        headerDiv.style.marginBottom = headerMargin + 'px';
        headerDiv.style.letterSpacing = headerSpacing + 'px';
        headerDiv.style.fontFamily = "'Inter', sans-serif";
        box.appendChild(headerDiv);

        let svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
        svg.style.width = '100%';
        svg.style.height = height + 'px';
        box.appendChild(svg);

        if(showText){
            let t = document.createElement('div');
            t.style.fontSize = '9px';
            t.style.color = '#666';
            t.style.marginTop = '4px';
            t.textContent = code;
            box.appendChild(t);
        }
        grid.appendChild(box);

        try {
            JsBarcode(svg, code, {
                format: 'CODE128',
                width: width,
                height: height,
                displayValue: false,
                margin: 0
            });
        } catch(e) {
            svg.innerHTML = `<text x="10" y="${height/2}" font-size="8" fill="#333">${escapeHtml(code)}</text>`;
        }
    }
}

async function downloadBarcodePDF() {
    const { jsPDF } = window.jspdf;
    let doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
    let values = getBarcodeValues();
    if (!values.length) { alert('No data to export.'); return; }

    let rows = parseInt(document.getElementById('barcodeRows').value) || 4;
    let cols = parseInt(document.getElementById('barcodeCols').value) || 3;
    let showText = document.getElementById('barcodeShowText').value === 'true';
    let width = parseFloat(document.getElementById('barcodeWidth').value) || 2;
    let height = parseInt(document.getElementById('barcodeHeight').value) || 50;

    let headerText = document.getElementById('barcodeHeaderText').value || 'LIBRARY SYSTEM';
    let headerSize = parseInt(document.getElementById('barcodeHeaderSize').value) || 14;
    let headerWeight = document.getElementById('barcodeHeaderWeight').value || '700';
    let headerColor = document.getElementById('barcodeHeaderColor').value || '#1a2a6c';
    let headerAlign = document.getElementById('barcodeHeaderAlign').value || 'center';
    let headerMargin = parseInt(document.getElementById('barcodeHeaderMargin').value) || 8;

    let pageW = doc.internal.pageSize.getWidth();
    let pageH = doc.internal.pageSize.getHeight();
    let marginX = 10, marginY = 10;
    let cellW = (pageW - 2 * marginX) / cols;
    let cellH = (pageH - 2 * marginY) / rows;
    let index = 0;

    for (let r = 0; r < rows; r++) {
        for (let c = 0; c < cols; c++) {
            let x = marginX + c * cellW;
            let y = marginY + r * cellH;
            let code = values[index % values.length] || 'N/A';

            doc.setFontSize(headerSize);
            doc.setFont('helvetica', headerWeight === '700' ? 'bold' : 'normal');
            doc.setTextColor(headerColor);
            let headerY = y + 3;
            if (headerAlign === 'center') {
                doc.text(headerText, x + cellW / 2, headerY, { align: 'center' });
            } else if (headerAlign === 'left') {
                doc.text(headerText, x + 2, headerY);
            } else {
                doc.text(headerText, x + cellW - 2, headerY, { align: 'right' });
            }

            let canvas = document.createElement('canvas');
            try {
                JsBarcode(canvas, code, {
                    format: 'CODE128',
                    width: width,
                    height: height,
                    displayValue: false,
                    margin: 0
                });
            } catch(e) {
                canvas = document.createElement('canvas');
                let ctx = canvas.getContext('2d');
                ctx.font = '10px Arial';
                ctx.fillText(code, 2, 20);
            }
            let img = canvas.toDataURL();
            let bcY = y + headerMargin + 3;
            let bcH = height * 0.6;
            doc.addImage(img, 'PNG', x + 2, bcY, cellW - 4, bcH);

            if (showText) {
                doc.setFontSize(7);
                doc.setTextColor('#333');
                doc.text(code, x + cellW / 2, bcY + bcH + 4, { align: 'center' });
            }
            index++;
        }
    }
    doc.save('barcode_labels.pdf');
}

function escapeHtml(s) {
    return String(s || '').replace(/[&<>"']/g, m => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[m]);
}

// ============================================================
// INIT
// ============================================================
document.addEventListener('DOMContentLoaded', function() {
    loadFieldPreferences();
    resizeCards();
    setPrintLayout(2);
    toggleBarcodeMode();

    document.querySelectorAll('.style-controls-body').forEach(el => {
        if (el.classList.contains('collapsed')) {
            el.style.maxHeight = '0';
        }
    });

    document.querySelectorAll('#fieldToggleContainer .field-visible, #fieldToggleContainer .field-label-input').forEach(el => {
        el.addEventListener('change', saveFieldPreferences);
    });
});
</script>

<!-- ============================================================
SHARED FOOTER — with entity-collapse post-processing  [CHANGED v7.1]
============================================================ -->
<?php
$__idcardsFooterOut = '';

ob_start();
try {
    if (function_exists('vms_footer_css')) { vms_footer_css(); }
    if (function_exists('vms_footer_js'))  { vms_footer_js();  }

    if (function_exists('vms_render_footer')) {
        vms_render_footer([
            'layout'           => 'compact',
            'institution_name' => $institutionName,
            'institutionName'  => $institutionName,
            'library_name'     => $institutionName,
            'site_name'        => $institutionName,
            'org_name'         => $institutionName,
            'no_escape'        => true,
        ]);
    }
} catch (Throwable $e) {
    error_log('[idcards.php] footer render: ' . $e->getMessage());
}
$__idcardsFooterOut = ob_get_clean();

if ($__idcardsFooterOut !== '') {
    // Collapse &amp;amp;amp; → &amp;amp; → &amp; (up to 5 passes)
    $prev = null;
    $out  = $__idcardsFooterOut;
    $i    = 0;
    while ($prev !== $out && $i < 5) {
        $prev = $out;
        $out  = str_replace('&amp;amp;', '&amp;', $out);
        $i++;
    }
    // Final collapse: "word &amp; word" → "word & word" (only between
    // alphanumerics, so we never touch &nbsp; &copy; &quot; etc.)
    $out = preg_replace_callback(
        '/(?<=[A-Za-z0-9])\s*&amp;\s*(?=[A-Za-z0-9])/',
        function () { return ' & '; },
        $out
    );
    echo $out;
}
?>

</body>
</html>
