<?php
/**
 * VMS + Koha Unified Backup
 * Version: 1.0 — Admin-only
 *
 * Provides 3 backup types:
 *   1. VMS only         (visitor_management)
 *   2. Koha only        (koha_library)
 *   3. Both combined    (single download with both schemas)
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

// Include path detection (same as your backup.php)
$possiblePaths = [
    __DIR__ . '/includes',
    dirname(__DIR__) . '/includes',
    '/usr/share/koha/intranet/cgi-bin/koha/visitor/includes',
];
$includePath = null;
foreach ($possiblePaths as $p) {
    if (file_exists($p . '/config.php')) { $includePath = $p; break; }
}
if (!$includePath) die('Could not find includes directory.');
define('VMS_INCLUDES', $includePath);

require_once VMS_INCLUDES . '/config.php';
require_once VMS_INCLUDES . '/functions.php';
require_once VMS_INCLUDES . '/auth.php';
require_once VMS_INCLUDES . '/backup_helper.php';

startSecureSession();
requireKohaLogin();

// -------- Admin guard --------
if (!function_exists('hasKohaRole') || !hasKohaRole('admin')) {
    http_response_code(403);
    die('Access denied. Admin role required for backup operations.');
}

$backupDirInfo = vms_backup_ensure_dir();
$backupDir     = $backupDirInfo['path'];
$db            = getDB();
$koha          = getKoha();
$user          = getCurrentUser();
$settings      = getSettings();

$message = '';
$error   = '';

// ============================================================
// CREATE BACKUP
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_backup'])) {
    try {
        if (!$backupDirInfo['writable']) {
            throw new Exception('Backup directory not writable: ' . $backupDir);
        }

        $type = $_POST['backup_type'] ?? 'vms';
        if (!in_array($type, ['vms', 'koha', 'both'], true)) {
            throw new Exception('Invalid backup type.');
        }

        $timestamp = date('Y-m-d_H-i-s');
        $pieces    = [];

        // ---------- VMS ----------
        if ($type === 'vms' || $type === 'both') {
            if (!$db) throw new Exception('VMS database not connected.');
            $pieces[] = vms_backup_dump_database($db, defined('DB_NAME') ? DB_NAME : 'visitor_management');
        }

        // ---------- Koha ----------
        if ($type === 'koha' || $type === 'both') {
            if (!$koha) throw new Exception('Koha database not connected. Check KOHA_* config.');
            $pieces[] = vms_backup_dump_database($koha, defined('KOHA_DB') ? KOHA_DB : 'koha_library');
        }

        $sql = implode("\n\n-- ==================== NEXT DATABASE ====================\n\n", $pieces);

        $filename = "backup_{$type}_{$timestamp}.sql";
        $filepath = rtrim($backupDir, '/') . '/' . $filename;

        $written = @file_put_contents($filepath, $sql);
        if ($written === false) {
            throw new Exception("Failed to write: $filepath");
        }
        @chmod($filepath, 0640);

        $size = filesize($filepath) ?: 0;
        logActivity($user['id'] ?? 0, 'BACKUP_CREATE',
            "Unified backup [$type]: $filename ($size bytes)");

        // ---------- Stream to browser ----------
        while (ob_get_level() > 0) ob_end_clean();
        header('Content-Type: application/sql; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Content-Length: ' . $size);
        header('Cache-Control: private, no-store');
        readfile($filepath);
        exit;

    } catch (Throwable $e) {
        $error = $e->getMessage();
    }
}

// ============================================================
// DELETE
// ============================================================
if (isset($_GET['delete'])) {
    $file = basename($_GET['delete']);
    $path = rtrim($backupDir, '/') . '/' . $file;
    if (file_exists($path)
        && preg_match('/^backup_(vms|koha|both)_[0-9_\-]+\.sql$/', $file)
    ) {
        @unlink($path);
        $message = 'Backup deleted.';
    } else {
        $error = 'Invalid file.';
    }
}

// ============================================================
// LIST
// ============================================================
$backups = vms_backup_list_files($backupDir, 'backup_');

// DB sizes
$vmsSize = 0;
$kohaSize = 0;
try {
    $stmt = $db->prepare("SELECT SUM(data_length + index_length) FROM information_schema.TABLES WHERE table_schema = ?");
    $stmt->execute([DB_NAME]);
    $vmsSize = (int)($stmt->fetchColumn() ?: 0);
} catch (PDOException $e) {}

if ($koha) {
    try {
        $stmt = $koha->prepare("SELECT SUM(data_length + index_length) FROM information_schema.TABLES WHERE table_schema = ?");
        $stmt->execute([KOHA_DB]);
        $kohaSize = (int)($stmt->fetchColumn() ?: 0);
    } catch (PDOException $e) {}
}

function fmtBytes($b) {
    if ($b >= 1073741824) return number_format($b / 1073741824, 2) . ' GB';
    if ($b >= 1048576)    return number_format($b / 1048576,    2) . ' MB';
    if ($b >= 1024)       return number_format($b / 1024,       1) . ' KB';
    return $b . ' B';
}

$pageTitle = 'Backup & Restore';
include __DIR__ . '/header.php';
?>

<style>
.bk-card { border-radius: 14px; border: 1px solid #e5e7eb; transition: .25s; }
.bk-card:hover { box-shadow: 0 8px 24px rgba(0,0,0,.08); transform: translateY(-2px); }
.bk-item {
    display: flex; justify-content: space-between; align-items: center;
    padding: 12px 16px; background: #f8fafc; border-radius: 10px;
    margin-bottom: 8px; border-left: 4px solid #1e3c72;
}
.bk-item:hover { background: #eef2ff; }
.bk-name { font-family: monospace; font-weight: 600; color: #1e3c72; word-break: break-all; }
.bk-meta { font-size: .75rem; color: #64748b; margin-top: 2px; }
.big-icon { font-size: 3.2rem; margin-bottom: 12px; }
.badge-dot { display: inline-block; width: 8px; height: 8px; border-radius: 50%; margin-right: 6px; }
.dot-ok { background: #10b981; }
.dot-err { background: #ef4444; }
</style>

<div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
    <h4 class="mb-0"><i class="fas fa-database me-2 text-primary"></i>Backup &amp; Restore</h4>
    <div class="d-flex gap-2">
        <span class="badge bg-secondary rounded-pill px-3 py-2">
            VMS: <?= fmtBytes($vmsSize) ?>
        </span>
        <span class="badge bg-dark rounded-pill px-3 py-2">
            <span class="badge-dot <?= $koha ? 'dot-ok' : 'dot-err' ?>"></span>
            Koha: <?= $koha ? fmtBytes($kohaSize) : 'Not connected' ?>
        </span>
    </div>
</div>

<?php if ($backupDirInfo['fallback']): ?>
    <div class="alert alert-warning">
        <i class="fas fa-exclamation-triangle me-2"></i>
        Primary backup directory is not writable — using fallback: <code><?= htmlspecialchars($backupDir) ?></code>
    </div>
<?php endif; ?>

<?php if ($message): ?>
    <div class="alert alert-success alert-dismissible fade show">
        <?= htmlspecialchars($message) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>
<?php if ($error): ?>
    <div class="alert alert-danger alert-dismissible fade show">
        <i class="fas fa-exclamation-circle me-2"></i><?= htmlspecialchars($error) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<div class="row g-4">
    <!-- ============ CREATE PANEL ============ -->
    <div class="col-lg-5">
        <div class="card bk-card shadow-sm">
            <div class="card-body text-center py-4">
                <i class="fas fa-download big-icon text-primary"></i>
                <h5>Create New Backup</h5>
                <p class="text-muted small mb-4">
                    Choose which database to back up. Files are stored server-side then streamed.
                </p>

                <form method="POST" id="backupForm">
                    <div class="btn-group w-100 mb-3" role="group">
                        <input type="radio" class="btn-check" name="backup_type" id="t_vms" value="vms" checked>
                        <label class="btn btn-outline-primary" for="t_vms">
                            <i class="fas fa-user-check d-block mb-1"></i>VMS
                        </label>

                        <input type="radio" class="btn-check" name="backup_type" id="t_koha" value="koha"
                               <?= $koha ? '' : 'disabled' ?>>
                        <label class="btn btn-outline-primary" for="t_koha">
                            <i class="fas fa-book d-block mb-1"></i>Koha
                        </label>

                        <input type="radio" class="btn-check" name="backup_type" id="t_both" value="both"
                               <?= $koha ? '' : 'disabled' ?>>
                        <label class="btn btn-outline-primary" for="t_both">
                            <i class="fas fa-layer-group d-block mb-1"></i>Both
                        </label>
                    </div>

                    <button type="submit" name="create_backup"
                            class="btn btn-primary btn-lg w-100"
                            <?= $backupDirInfo['writable'] ? '' : 'disabled' ?>>
                        <i class="fas fa-cloud-download-alt me-2"></i>Create &amp; Download
                    </button>
                </form>

                <div class="small text-muted mt-3">
                    Saved to: <code><?= htmlspecialchars($backupDir) ?></code>
                </div>
            </div>
        </div>

        <div class="card bk-card shadow-sm mt-3">
            <div class="card-header bg-white"><h6 class="mb-0"><i class="fas fa-info-circle me-2"></i>Restore Commands</h6></div>
            <div class="card-body">
                <p class="small mb-1"><strong>VMS:</strong></p>
                <pre class="small bg-light p-2 rounded mb-3">mysql -u koha_library -p visitor_management &lt; backup_vms_*.sql</pre>
                <p class="small mb-1"><strong>Koha:</strong></p>
                <pre class="small bg-light p-2 rounded mb-0">mysql -u koha_library -p koha_library &lt; backup_koha_*.sql</pre>
            </div>
        </div>
    </div>

    <!-- ============ HISTORY ============ -->
    <div class="col-lg-7">
        <div class="card bk-card shadow-sm">
            <div class="card-header bg-white d-flex justify-content-between align-items-center">
                <h6 class="mb-0"><i class="fas fa-history me-2"></i>Backup History</h6>
                <span class="badge bg-secondary"><?= count($backups) ?> files</span>
            </div>
            <div class="card-body">
                <?php if (empty($backups)): ?>
                    <div class="text-center text-muted py-5">
                        <i class="fas fa-archive fa-3x mb-3 d-block" style="opacity:.2;"></i>
                        <p>No backups yet.</p>
                    </div>
                <?php else: foreach ($backups as $b): ?>
                    <div class="bk-item">
                        <div style="flex:1;min-width:0;">
                            <div class="bk-name text-truncate">
                                <i class="fas fa-file-code me-1"></i><?= htmlspecialchars($b['name']) ?>
                            </div>
                            <div class="bk-meta">
                                <i class="fas fa-clock me-1"></i><?= date('d M Y, H:i:s', $b['date']) ?>
                                · <i class="fas fa-hdd me-1"></i><?= fmtBytes($b['size']) ?>
                            </div>
                        </div>
                        <div class="d-flex gap-2">
                            <a href="backup_unified_download.php?file=<?= urlencode($b['name']) ?>"
                               class="btn btn-sm btn-outline-primary" title="Download">
                                <i class="fas fa-download"></i>
                            </a>
                            <a href="?delete=<?= urlencode($b['name']) ?>"
                               class="btn btn-sm btn-outline-danger"
                               onclick="return confirm('Delete this backup?');" title="Delete">
                                <i class="fas fa-trash"></i>
                            </a>
                        </div>
                    </div>
                <?php endforeach; endif; ?>
            </div>
        </div>
    </div>
</div>

<?php include __DIR__ . '/footer.php'; ?>