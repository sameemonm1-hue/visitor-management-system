<?php
/**
 * Visitor Management System - Profile
 * Version: 7.4 FINAL - WORKING
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

// Auto-detect paths
$possiblePaths = [
    __DIR__ . '/includes',
    dirname(__DIR__) . '/includes',
    '/usr/share/koha/intranet/cgi-bin/koha/visitor/includes',
    '/usr/share/koha/intranet/cgi-bin/visitor/includes',
];

$includePath = null;
foreach ($possiblePaths as $path) {
    if (file_exists($path . '/config.php')) {
        $includePath = $path;
        break;
    }
}

if (!$includePath) {
    $testPath = __DIR__;
    for ($i = 0; $i < 5; $i++) {
        $testPath = dirname($testPath);
        if (file_exists($testPath . '/includes/config.php')) {
            $includePath = $testPath . '/includes';
            break;
        }
    }
}

if (!$includePath) {
    die('Could not find includes directory.');
}

define('VMS_INCLUDES', $includePath);
require_once VMS_INCLUDES . '/config.php';
require_once VMS_INCLUDES . '/functions.php';
require_once VMS_INCLUDES . '/koha.php';
require_once VMS_INCLUDES . '/auth.php';

startSecureSession();
requireKohaLogin();

$user = getCurrentUser();
$settings = getSettings();

if (!$user) {
    die('<div class="container mt-5"><div class="alert alert-danger">User not found. Your Koha session is valid, but we could not retrieve your user details.</div></div>');
}

$db = getDB();
$totalEntries = $db->query("SELECT COUNT(*) FROM entry_exit_logs WHERE staff_id = " . ($user['id'] ?? 0))->fetchColumn();
$activeGuests = $db->query("SELECT COUNT(*) FROM entry_exit_logs WHERE status = 'inside' AND entry_type = 'guest'")->fetchColumn();

$pageTitle = 'My Profile';
include __DIR__ . '/header.php';
?>

<style>
.profile-card {
    background: white;
    border-radius: 20px;
    padding: 30px;
    box-shadow: 0 4px 24px rgba(0, 0, 0, 0.06);
}
.profile-avatar {
    width: 120px;
    height: 120px;
    border-radius: 50%;
    object-fit: cover;
    border: 4px solid #1e3c72;
}
.profile-avatar-placeholder {
    width: 120px;
    height: 120px;
    border-radius: 50%;
    background: #1e3c72;
    color: white;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 3rem;
    font-weight: 700;
    margin: 0 auto;
}
.profile-info-item {
    padding: 10px 0;
    border-bottom: 1px solid #e9ecef;
}
.profile-info-item:last-child {
    border-bottom: none;
}
.profile-info-item .label {
    font-size: 0.75rem;
    color: #6c757d;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}
.profile-info-item .value {
    font-weight: 600;
    color: #2c3e50;
    font-size: 1rem;
}
.profile-stats {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
    gap: 12px;
    margin-top: 20px;
}
.profile-stat-item {
    background: #f8f9fa;
    border-radius: 12px;
    padding: 12px;
    text-align: center;
}
.profile-stat-item .number {
    font-size: 1.4rem;
    font-weight: 700;
    color: #1e3c72;
}
.profile-stat-item .label {
    font-size: 0.7rem;
    color: #6c757d;
}
.profile-stat-item.guest .number {
    color: #20c997;
}
@media (max-width: 768px) {
    .profile-card {
        padding: 20px;
    }
    .profile-avatar {
        width: 80px;
        height: 80px;
    }
}
</style>

<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-12 col-md-10 col-lg-8">
            <div class="profile-card">
                <div class="text-center mb-4">
                    <?php if (!empty($user['photo'])): ?>
                        <img src="<?= $user['photo'] ?>" class="profile-avatar" alt="Photo" loading="lazy">
                    <?php else: ?>
                        <div class="profile-avatar-placeholder">
                            <?= substr($user['full_name'] ?? 'U', 0, 1) ?>
                        </div>
                    <?php endif; ?>
                    <h3 class="mt-3 mb-0"><?= htmlspecialchars($user['full_name'] ?? 'User') ?></h3>
                    <p class="text-muted">
                        <i class="fas fa-user-tag me-1"></i> <?= ucfirst($user['role'] ?? 'Viewer') ?>
                        <?php if (!empty($user['branch_name'])): ?>
                            | <i class="fas fa-building me-1"></i> <?= htmlspecialchars($user['branch_name']) ?>
                        <?php endif; ?>
                    </p>
                </div>
                <div class="row">
                    <div class="col-12 col-md-6">
                        <div class="profile-info-item">
                            <div class="label"><i class="fas fa-id-card me-2"></i>Username</div>
                            <div class="value"><?= htmlspecialchars($user['username'] ?? 'N/A') ?></div>
                        </div>
                        <div class="profile-info-item">
                            <div class="label"><i class="fas fa-envelope me-2"></i>Email</div>
                            <div class="value"><?= htmlspecialchars($user['email'] ?? 'N/A') ?></div>
                        </div>
                        <div class="profile-info-item">
                            <div class="label"><i class="fas fa-phone me-2"></i>Mobile</div>
                            <div class="value"><?= htmlspecialchars($user['mobile'] ?? 'N/A') ?></div>
                        </div>
                    </div>
                    <div class="col-12 col-md-6">
                        <div class="profile-info-item">
                            <div class="label"><i class="fas fa-building me-2"></i>Branch</div>
                            <div class="value"><?= htmlspecialchars($user['branch_name'] ?? 'N/A') ?></div>
                        </div>
                        <div class="profile-info-item">
                            <div class="label"><i class="fas fa-tag me-2"></i>Category</div>
                            <div class="value"><?= htmlspecialchars($user['category_description'] ?? $user['category'] ?? 'N/A') ?></div>
                        </div>
                        <div class="profile-info-item">
                            <div class="label"><i class="fas fa-key me-2"></i>Permissions</div>
                            <div class="value">
                                <?php 
                                $perms = $user['permissions'] ?? [];
                                if (empty($perms)) { echo 'None'; } 
                                else { echo implode(', ', array_map('htmlspecialchars', $perms)); }
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="profile-stats">
                    <div class="profile-stat-item">
                        <div class="number"><?= number_format($totalEntries) ?></div>
                        <div class="label">Entries Recorded</div>
                    </div>
                    <div class="profile-stat-item guest">
                        <div class="number"><?= number_format($activeGuests) ?></div>
                        <div class="label">Active Guests</div>
                    </div>
                    <div class="profile-stat-item">
                        <div class="number"><?= number_format($db->query("SELECT COUNT(*) FROM entry_exit_logs WHERE staff_id = " . ($user['id'] ?? 0) . " AND status = 'inside'")->fetchColumn()) ?></div>
                        <div class="label">Currently Inside</div>
                    </div>
                </div>
                <hr>
                <div class="row text-muted small">
                    <div class="col-12 col-md-6">
                        <p><i class="fas fa-clock me-1"></i> Logged in since <?= date('d-m-Y H:i:s', $_SESSION['login_time'] ?? time()) ?></p>
                    </div>
                    <div class="col-12 col-md-6 text-md-end">
                        <p><i class="fas fa-database me-1"></i> System v<?= APP_VERSION ?></p>
                    </div>
                </div>
                <div class="text-center mt-3">
                    <a href="settings.php" class="btn btn-outline-primary">
                        <i class="fas fa-cog me-2"></i> System Settings
                    </a>
                    <a href="logout.php" class="btn btn-outline-danger">
                        <i class="fas fa-sign-out-alt me-2"></i> Logout
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include __DIR__ . '/footer.php'; ?>
