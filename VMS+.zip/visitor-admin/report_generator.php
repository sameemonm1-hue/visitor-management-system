<?php
/**
 * Visitor Management System - Report Generator
 * Version: 8.1 ADVANCED — Column selection, logo top-left, proper alignment
 *
 * New in v8.1 (from v8.0):
 *   ── HTML-entity fix: institution name, report titles, book titles,
 *      member names, categories, purposes, section names, notes — all pass
 *      through vms_h() so "Library & information" renders correctly in
 *      PDF and Excel exports (previously showed as "Library &amp; information").
 *   ── NEW: vms_normalize_text() / vms_h() local helpers with
 *           function_exists() guards, matching settings.php v7.7,
 *           index.php v8.7, header.php v8.4, reports.php v8.1.
 *   ── FIXED: <title> tag in Excel export now uses vms_h().
 *   ── FIXED: Footer in Excel + PDF uses vms_h().
 *   ── FIXED: Column header labels use vms_h() (safe for future custom labels).
 *   ── PRESERVED: All column logic, alignment, widths, badges, wkhtmltopdf,
 *                 Chromium fallback, and Excel styling.
 *
 * New in v8.0:
 *  - Column selector: user picks which columns appear in PDF/Excel
 *  - Logo at top-left corner of report header
 *  - 3-column header grid (logo | institution + title | metadata)
 *  - Auto column widths (relative weight per column)
 *  - Per-column alignment (text left, numeric right, badges centered)
 *  - Cell-type formatting (dates, times, codes, badges)
 *  - Zebra striping
 *  - wkhtmltopdf with repeated header + footer page numbers
 *  - Chromium fallback
 *  - Excel with UTF-8 BOM, autofilter-ready table, styled badges
 */

// ============================================================
// BOOTSTRAP — locate includes directory
// ============================================================
$possiblePaths = [
    __DIR__ . '/includes',
    dirname(__DIR__) . '/includes',
    '/usr/share/koha/intranet/cgi-bin/koha/visitor/includes',
    '/usr/share/koha/intranet/cgi-bin/visitor/includes',
];

$includePath = null;
foreach ($possiblePaths as $path) {
    if (file_exists($path . '/config.php')) {
        $includePath = $path;
        break;
    }
}
if (!$includePath) {
    $testPath = __DIR__;
    for ($i = 0; $i < 5; $i++) {
        $testPath = dirname($testPath);
        if (file_exists($testPath . '/includes/config.php')) {
            $includePath = $testPath . '/includes';
            break;
        }
    }
}
if (!$includePath) {
    die('Could not find includes directory.');
}

define('VMS_INCLUDES', $includePath);
require_once VMS_INCLUDES . '/config.php';
require_once VMS_INCLUDES . '/functions.php';
require_once VMS_INCLUDES . '/koha.php';
require_once VMS_INCLUDES . '/auth.php';

startSecureSession();
requireKohaLogin();

// ============================================================
// v8.1 — HTML ENTITY HELPERS (local fallbacks)
// ============================================================
if (!function_exists('vms_normalize_text')) {
    function vms_normalize_text($value) {
        if ($value === null) return '';
        return html_entity_decode((string)$value, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    }
}
if (!function_exists('vms_h')) {
    function vms_h($value) {
        return htmlspecialchars(
            vms_normalize_text($value),
            ENT_QUOTES | ENT_HTML5,
            'UTF-8'
        );
    }
}
if (!function_exists('vms_plain')) {
    function vms_plain($value) {
        return vms_normalize_text($value);
    }
}

// ============================================================
// INPUT PARAMETERS
// ============================================================
$format    = $_GET['format']      ?? 'pdf';
$from      = $_GET['from']        ?? date('Y-m-d', strtotime('-30 days'));
$to        = $_GET['to']          ?? date('Y-m-d');
$type      = $_GET['type']        ?? 'entries';
$section   = $_GET['section']     ?? 'all';
$category  = $_GET['category']    ?? 'all';
$entryType = $_GET['entry_type']  ?? 'all';

// Requested columns: JSON array, comma list, or 'all'
$columnsParam = $_GET['columns'] ?? 'all';
if ($columnsParam === 'all' || $columnsParam === '') {
    $requestedColumns = 'all';
} else {
    $decoded = json_decode($columnsParam, true);
    if (is_array($decoded)) {
        $requestedColumns = $decoded;
    } else {
        $requestedColumns = array_map('trim', explode(',', $columnsParam));
    }
}

// ============================================================
// SETTINGS (v8.1 — normalised)
// ============================================================
$db           = getDB();
$settings     = getSettings();
$institution  = vms_normalize_text($settings['institution_name'] ?? 'Library');
$logo         = getInstitutionLogo();
$primaryColor = $settings['primary_color']    ?? '#1e3c72';

// Also normalise the logo alt / any text coming out of settings that
// will land in the PDF/Excel header.
$footerText   = vms_normalize_text($settings['footer_text'] ?? '');

// ============================================================
// BUILD FILTER CONDITIONS
// ============================================================
$filterCond = "entry_date BETWEEN ? AND ?";
$params     = [$from, $to];

if ($section !== 'all') {
    $filterCond .= " AND gate_number = ?";
    $params[]    = $section;
}
if ($category !== 'all') {
    $filterCond .= " AND member_category = ?";
    $params[]    = $category;
}
if ($entryType !== 'all') {
    $filterCond .= " AND entry_type = ?";
    $params[]    = $entryType;
}

// ============================================================
// FETCH DATA
// ============================================================
if ($type === 'entries' || $type === 'guests') {

    $stmt = $db->prepare("
        SELECT
            entry_date,
            entry_time,
            exit_time,
            member_name,
            admno,
            member_category,
            purpose,
            status,
            entry_type,
            gate_number,
            TIMEDIFF(exit_time, entry_time) AS duration,
            created_at
        FROM entry_exit_logs
        WHERE $filterCond
        ORDER BY entry_date DESC, entry_time DESC
    ");
    $stmt->execute($params);
    $data = $stmt->fetchAll();

    $title = ($type === 'guests') ? 'Guest Report' : 'Entry/Exit Report';

    // ------------------------------------------------------------
    // COLUMN DEFINITIONS (for this report type)
    // ------------------------------------------------------------
    $ALL_COLUMNS = [
        'entry_date' => [
            'label' => 'Date', 'key' => 'entry_date',
            'width' => 12, 'align' => 'left', 'format' => 'date'
        ],
        'entry_time' => [
            'label' => 'Entry Time', 'key' => 'entry_time',
            'width' => 10, 'align' => 'center', 'format' => 'time'
        ],
        'exit_time' => [
            'label' => 'Exit Time', 'key' => 'exit_time',
            'width' => 10, 'align' => 'center', 'format' => 'time'
        ],
        'member_name' => [
            'label' => 'Member Name', 'key' => 'member_name',
            'width' => 24, 'align' => 'left', 'format' => 'text'
        ],
        'admno' => [
            'label' => 'ID', 'key' => 'admno',
            'width' => 14, 'align' => 'left', 'format' => 'code'
        ],
        'member_category' => [
            'label' => 'Category', 'key' => 'member_category',
            'width' => 14, 'align' => 'left', 'format' => 'text'
        ],
        'entry_type' => [
            'label' => 'Type', 'key' => 'entry_type',
            'width' => 9, 'align' => 'center', 'format' => 'badge-type'
        ],
        'purpose' => [
            'label' => 'Purpose', 'key' => 'purpose',
            'width' => 20, 'align' => 'left', 'format' => 'text'
        ],
        'status' => [
            'label' => 'Status', 'key' => 'status',
            'width' => 10, 'align' => 'center', 'format' => 'badge-status'
        ],
        'gate_number' => [
            'label' => 'Section', 'key' => 'gate_number',
            'width' => 10, 'align' => 'left', 'format' => 'text'
        ],
        'duration' => [
            'label' => 'Duration', 'key' => 'duration',
            'width' => 12, 'align' => 'right', 'format' => 'duration'
        ],
    ];

    $statuses  = array_column($data, 'status');
    $types     = array_column($data, 'entry_type');
    $statusCounts = array_count_values($statuses);
    $typeCounts   = array_count_values($types);

    $summary = [
        'total'   => count($data),
        'inside'  => $statusCounts['inside'] ?? 0,
        'exited'  => $statusCounts['exited'] ?? 0,
        'guests'  => $typeCounts['guest'] ?? 0,
        'members' => $typeCounts['member'] ?? 0,
    ];

    $categoryBreakdown = [];
    foreach ($data as $row) {
        $cat = $row['member_category'] ?? 'Unknown';
        if (!isset($categoryBreakdown[$cat])) {
            $categoryBreakdown[$cat] = 0;
        }
        $categoryBreakdown[$cat]++;
    }
    $summary['categories'] = $categoryBreakdown;

    if ($type === 'guests') {
        $guestOnly = array_filter($data, function ($r) {
            return $r['entry_type'] === 'guest';
        });
        $guestStatuses = array_count_values(array_column($guestOnly, 'status'));
        $summary['guest_inside'] = $guestStatuses['inside'] ?? 0;
        $summary['guest_exited'] = $guestStatuses['exited'] ?? 0;
    }

} else {

    // Book exit report
    $stmt = $db->prepare("
        SELECT
            book_barcode,
            book_title,
            book_author,
            member_name,
            member_admno,
            exit_time,
            is_authorized,
            notes,
            created_at
        FROM book_exit_logs
        WHERE DATE(exit_time) BETWEEN ? AND ?
        ORDER BY exit_time DESC
    ");
    $stmt->execute([$from, $to]);
    $data = $stmt->fetchAll();

    $title = 'Book Exit Report';

    $ALL_COLUMNS = [
        'book_barcode' => [
            'label' => 'Barcode', 'key' => 'book_barcode',
            'width' => 14, 'align' => 'left', 'format' => 'code'
        ],
        'book_title' => [
            'label' => 'Book Title', 'key' => 'book_title',
            'width' => 32, 'align' => 'left', 'format' => 'text'
        ],
        'book_author' => [
            'label' => 'Author', 'key' => 'book_author',
            'width' => 22, 'align' => 'left', 'format' => 'text'
        ],
        'member_name' => [
            'label' => 'Member Name', 'key' => 'member_name',
            'width' => 22, 'align' => 'left', 'format' => 'text'
        ],
        'member_admno' => [
            'label' => 'Member ID', 'key' => 'member_admno',
            'width' => 14, 'align' => 'left', 'format' => 'code'
        ],
        'exit_time' => [
            'label' => 'Exit Time', 'key' => 'exit_time',
            'width' => 18, 'align' => 'center', 'format' => 'datetime'
        ],
        'is_authorized' => [
            'label' => 'Status', 'key' => 'is_authorized',
            'width' => 12, 'align' => 'center', 'format' => 'badge-auth'
        ],
        'notes' => [
            'label' => 'Notes', 'key' => 'notes',
            'width' => 24, 'align' => 'left', 'format' => 'text'
        ],
    ];

    $authCounts = array_count_values(array_map('intval', array_column($data, 'is_authorized')));

    $summary = [
        'total'        => count($data),
        'authorized'   => $authCounts[1] ?? 0,
        'unauthorized' => $authCounts[0] ?? 0,
    ];
}

// ============================================================
// RESOLVE ACTIVE COLUMNS
// ============================================================
if ($requestedColumns === 'all') {
    $activeColumns = $ALL_COLUMNS;
} else {
    $activeColumns = [];
    foreach ($requestedColumns as $colKey) {
        if (isset($ALL_COLUMNS[$colKey])) {
            $activeColumns[$colKey] = $ALL_COLUMNS[$colKey];
        }
    }
    if (empty($activeColumns)) {
        $activeColumns = $ALL_COLUMNS;
    }
}

// ============================================================
// VALUE FORMATTER (unchanged)
// ============================================================
/**
 * Format a cell value based on its format type.
 *
 * @return array{text: string, class: string, is_badge: bool}
 */
function formatCellValue($value, $format)
{
    $val   = ($value === null || $value === '') ? null : $value;
    $text  = '—';
    $class = '';
    $isBadge = false;

    switch ($format) {
        case 'date':
            $text  = $val ? date('d-m-Y', strtotime($val)) : '—';
            $class = 'cell-date';
            break;

        case 'time':
            $text  = $val ? date('H:i:s', strtotime($val)) : '—';
            $class = 'cell-time';
            break;

        case 'datetime':
            $text  = $val ? date('d-m-Y H:i:s', strtotime($val)) : '—';
            $class = 'cell-time';
            break;

        case 'code':
            $text  = $val !== null ? $val : '—';
            $class = 'cell-code';
            break;

        case 'numeric':
            $text  = is_numeric($val) ? number_format((float)$val) : ($val !== null ? $val : '—');
            $class = 'cell-numeric';
            break;

        case 'duration':
            $text  = $val !== null ? $val : '—';
            $class = 'cell-numeric';
            break;

        case 'badge-status':
            if ($val === 'inside') {
                $text    = 'Inside';
                $class   = 'badge-inside';
            } elseif ($val === 'exited') {
                $text    = 'Exited';
                $class   = 'badge-exited';
            } else {
                $text    = $val ?: '—';
                $class   = 'badge-neutral';
            }
            $isBadge = true;
            break;

        case 'badge-type':
            if ($val === 'guest') {
                $text    = 'Guest';
                $class   = 'badge-guest';
            } elseif ($val === 'member') {
                $text    = 'Member';
                $class   = 'badge-member';
            } else {
                $text    = $val ?: '—';
                $class   = 'badge-neutral';
            }
            $isBadge = true;
            break;

        case 'badge-auth':
            if ((int)$val === 1) {
                $text    = 'Authorized';
                $class   = 'badge-authorized';
            } else {
                $text    = 'Unauthorized';
                $class   = 'badge-unauthorized';
            }
            $isBadge = true;
            break;

        case 'text':
        default:
            $text  = ($val !== null && $val !== '') ? $val : '—';
            $class = '';
            break;
    }

    return [
        'text'     => $text,
        'class'    => $class,
        'is_badge' => $isBadge,
    ];
}

// ============================================================
// NORMALIZE WIDTHS (0–100%)
// ============================================================
$totalWidth = 0;
foreach ($activeColumns as $col) {
    $totalWidth += $col['width'];
}
$colWidthPct = [];
foreach ($activeColumns as $key => $col) {
    $colWidthPct[$key] = $totalWidth > 0
        ? round(($col['width'] / $totalWidth) * 100, 3)
        : round(100 / count($activeColumns), 3);
}

// ============================================================
// EXPORT: EXCEL (.xls with HTML — universally opens in Excel/LibreOffice)
// ============================================================
if ($format === 'excel') {
    $filename = strtolower(str_replace(' ', '_', $title)) . '_' . date('Y-m-d') . '.xls';

    header('Content-Type: application/vnd.ms-excel; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Cache-Control: private, max-age=0');
    header('Pragma: public');
    header('Expires: 0');

    echo "\xEF\xBB\xBF"; // UTF-8 BOM
    ?>
<html>
<head>
<meta charset="UTF-8">
<title><?= vms_h($title) ?></title>
<style>
    body {
        font-family: Arial, Helvetica, sans-serif;
        font-size: 10px;
        color: #2c3e50;
        margin: 0;
        padding: 12px;
    }

    /* ---------- Header (3-column grid) ---------- */
    table.report-header {
        width: 100%;
        border-collapse: collapse;
        margin-bottom: 14px;
    }
    table.report-header td {
        border: none;
        padding: 0 8px;
        vertical-align: middle;
    }
    table.report-header .logo-cell {
        width: 100px;
        text-align: left;
    }
    table.report-header .logo-cell img {
        max-height: 54px;
        max-width: 96px;
        object-fit: contain;
    }
    table.report-header .title-cell {
        text-align: center;
    }
    table.report-header .title-cell h1 {
        margin: 0;
        color: <?= $primaryColor ?>;
        font-size: 18px;
        font-weight: bold;
        letter-spacing: -0.3px;
    }
    table.report-header .title-cell p {
        margin: 3px 0 0;
        color: #6c757d;
        font-size: 11px;
    }
    table.report-header .meta-cell {
        width: 240px;
        text-align: right;
        font-size: 9px;
        color: #6c757d;
        white-space: nowrap;
        line-height: 1.5;
    }
    table.report-header .meta-cell strong {
        color: #2c3e50;
    }

    /* ---------- Summary strip ---------- */
    table.summary-strip {
        width: 100%;
        border-collapse: separate;
        border-spacing: 4px 0;
        margin: 6px 0 12px;
    }
    table.summary-strip td {
        background: #f8f9fa;
        border: 1px solid #e9ecef;
        border-radius: 4px;
        padding: 6px 12px;
        text-align: center;
        white-space: nowrap;
    }
    table.summary-strip .num {
        display: block;
        font-size: 14px;
        font-weight: bold;
        color: <?= $primaryColor ?>;
        line-height: 1.2;
    }
    table.summary-strip .lbl {
        display: block;
        font-size: 8px;
        color: #6c757d;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        margin-top: 1px;
    }

    /* ---------- Data table ---------- */
    table.data {
        width: 100%;
        border-collapse: collapse;
        font-size: 9px;
    }
    table.data thead th {
        background: <?= $primaryColor ?>;
        color: #ffffff;
        font-weight: bold;
        padding: 6px 8px;
        border: 1px solid <?= $primaryColor ?>;
        text-transform: uppercase;
        font-size: 9px;
        letter-spacing: 0.3px;
        white-space: nowrap;
    }
    table.data tbody td {
        padding: 5px 8px;
        border: 1px solid #dee2e6;
        vertical-align: middle;
    }
    table.data tbody tr:nth-child(even) td { background: #f7f9fc; }
    table.data tbody tr:nth-child(odd)  td { background: #ffffff; }

    /* ---------- Alignment helpers ---------- */
    .align-left   { text-align: left; }
    .align-right  { text-align: right; }
    .align-center { text-align: center; }

    /* ---------- Cell types ---------- */
    .cell-date,
    .cell-time,
    .cell-code {
        font-family: "Courier New", Consolas, monospace;
        font-size: 9px;
    }
    .cell-numeric {
        font-family: "Courier New", Consolas, monospace;
        text-align: right;
    }

    /* ---------- Badges ---------- */
    .badge-inside        { background: #d4edda; color: #155724; font-weight: bold; padding: 2px 8px; }
    .badge-exited        { background: #e2e3e5; color: #383d41; font-weight: bold; padding: 2px 8px; }
    .badge-guest         { background: #d1ecf1; color: #0c5460; font-weight: bold; padding: 2px 8px; }
    .badge-member        { background: #e2e3e5; color: #383d41; font-weight: bold; padding: 2px 8px; }
    .badge-authorized    { background: #d4edda; color: #155724; font-weight: bold; padding: 2px 8px; }
    .badge-unauthorized  { background: #f8d7da; color: #721c24; font-weight: bold; padding: 2px 8px; }
    .badge-neutral       { background: #f8f9fa; color: #6c757d; font-weight: bold; padding: 2px 8px; }

    /* ---------- Footer ---------- */
    .footer {
        margin-top: 12px;
        padding-top: 6px;
        border-top: 1px solid #dee2e6;
        text-align: center;
        font-size: 8px;
        color: #6c757d;
    }
</style>
</head>
<body>

<!-- ============================================================
     Report header — logo left, title center, metadata right
     ============================================================ -->
<table class="report-header">
    <tr>
        <td class="logo-cell">
            <?php if ($logo): ?>
                <img src="<?= vms_h($logo) ?>" alt="<?= vms_h($institution) ?>">
            <?php endif; ?>
        </td>
        <td class="title-cell">
            <h1><?= vms_h($institution) ?></h1>
            <p><?= vms_h($title) ?></p>
        </td>
        <td class="meta-cell">
            <div><strong>Range:</strong> <?= vms_h($from) ?> &rarr; <?= vms_h($to) ?></div>
            <div><strong>Generated:</strong> <?= date('d-m-Y H:i:s') ?></div>
            <div><strong>Records:</strong> <?= number_format($summary['total']) ?></div>
            <?php if ($type === 'guests'): ?>
                <div><strong>Type:</strong> Guest Report</div>
            <?php endif; ?>
        </td>
    </tr>
</table>

<!-- ============================================================
     Summary strip
     ============================================================ -->
<table class="summary-strip">
    <tr>
        <td><span class="num"><?= number_format($summary['total']) ?></span><span class="lbl">Total Records</span></td>
        <?php if ($type === 'entries' || $type === 'guests'): ?>
            <td><span class="num" style="color:#28a745;"><?= number_format($summary['inside']) ?></span><span class="lbl">Inside</span></td>
            <td><span class="num" style="color:#dc3545;"><?= number_format($summary['exited']) ?></span><span class="lbl">Exited</span></td>
            <td><span class="num"><?= number_format($summary['members']) ?></span><span class="lbl">Members</span></td>
            <td><span class="num" style="color:#20c997;"><?= number_format($summary['guests']) ?></span><span class="lbl">Guests</span></td>
            <?php if ($type === 'guests'): ?>
                <td><span class="num" style="color:#28a745;"><?= number_format($summary['guest_inside'] ?? 0) ?></span><span class="lbl">Guest Inside</span></td>
                <td><span class="num" style="color:#6c757d;"><?= number_format($summary['guest_exited'] ?? 0) ?></span><span class="lbl">Guest Exited</span></td>
            <?php endif; ?>
        <?php else: ?>
            <td><span class="num" style="color:#28a745;"><?= number_format($summary['authorized']) ?></span><span class="lbl">Authorized</span></td>
            <td><span class="num" style="color:#dc3545;"><?= number_format($summary['unauthorized']) ?></span><span class="lbl">Unauthorized</span></td>
        <?php endif; ?>
    </tr>
</table>

<!-- ============================================================
     Data table
     ============================================================ -->
<table class="data">
    <colgroup>
        <?php foreach ($activeColumns as $key => $col): ?>
            <col style="width:<?= $colWidthPct[$key] ?>%;">
        <?php endforeach; ?>
    </colgroup>
    <thead>
        <tr>
            <?php foreach ($activeColumns as $col): ?>
                <th class="align-<?= $col['align'] ?>"><?= vms_h($col['label']) ?></th>
            <?php endforeach; ?>
        </tr>
    </thead>
    <tbody>
        <?php if (empty($data)): ?>
            <tr>
                <td colspan="<?= count($activeColumns) ?>" class="align-center" style="padding:20px;color:#6c757d;font-style:italic;">
                    No records found for the selected filters.
                </td>
            </tr>
        <?php else: ?>
            <?php foreach ($data as $row): ?>
                <tr>
                    <?php foreach ($activeColumns as $key => $col): ?>
                        <?php
                            $raw = $row[$col['key']] ?? null;
                            $f   = formatCellValue($raw, $col['format']);
                            $cls = 'align-' . $col['align'];
                            if ($f['class'] !== '' && !$f['is_badge']) {
                                $cls .= ' ' . $f['class'];
                            }
                        ?>
                        <td class="<?= $cls ?>">
                            <?php if ($f['is_badge']): ?>
                                <span class="<?= $f['class'] ?>"><?= vms_h($f['text']) ?></span>
                            <?php else: ?>
                                <?= vms_h($f['text']) ?>
                            <?php endif; ?>
                        </td>
                    <?php endforeach; ?>
                </tr>
            <?php endforeach; ?>
        <?php endif; ?>
    </tbody>
</table>

<div class="footer">
    <?= vms_h($institution) ?> &middot;
    Generated by Visitor Management System v<?= vms_h(APP_VERSION) ?> &middot;
    <?= date('Y') ?>
</div>

</body>
</html>
    <?php
    exit;
}

// ============================================================
// EXPORT: PDF
// ============================================================
if ($format === 'pdf') {
    $filename = strtolower(str_replace(' ', '_', $title)) . '_' . date('Y-m-d') . '.pdf';

    // ------------------------------------------------------------
    // Build the HTML for PDF rendering
    // ------------------------------------------------------------
    $html  = '<!DOCTYPE html>';
    $html .= '<html><head><meta charset="UTF-8">';
    $html .= '<title>' . vms_h($title) . '</title>';
    $html .= '<style>
        @page {
            size: A4 landscape;
            margin: 10mm 10mm 14mm 10mm;
        }
        * { box-sizing: border-box; }
        body {
            font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
            font-size: 8px;
            color: #2c3e50;
            line-height: 1.35;
            margin: 0;
            padding: 0;
        }

        /* ---------- Header (3-column grid) ---------- */
        table.report-header {
            width: 100%;
            border-collapse: collapse;
            border-bottom: 3px solid ' . $primaryColor . ';
            margin-bottom: 8px;
            page-break-inside: avoid;
        }
        table.report-header td {
            border: none;
            padding: 4px 6px;
            vertical-align: middle;
        }
        table.report-header .logo-cell {
            width: 90px;
            text-align: left;
        }
        table.report-header .logo-cell img {
            max-height: 50px;
            max-width: 88px;
            object-fit: contain;
        }
        table.report-header .title-cell {
            text-align: center;
        }
        table.report-header .title-cell h1 {
            margin: 0;
            color: ' . $primaryColor . ';
            font-size: 15px;
            font-weight: 700;
            letter-spacing: -0.3px;
        }
        table.report-header .title-cell p {
            margin: 2px 0 0;
            color: #6c757d;
            font-size: 10px;
        }
        table.report-header .meta-cell {
            width: 220px;
            text-align: right;
            font-size: 8px;
            color: #6c757d;
            line-height: 1.4;
            white-space: nowrap;
        }
        table.report-header .meta-cell strong { color: #2c3e50; }

        /* ---------- Summary strip ---------- */
        table.summary-strip {
            width: 100%;
            border-collapse: separate;
            border-spacing: 3px 0;
            margin: 4px 0 8px;
            page-break-inside: avoid;
        }
        table.summary-strip td {
            background: #f8f9fa;
            border: 1px solid #e9ecef;
            border-radius: 3px;
            padding: 5px 8px;
            text-align: center;
            white-space: nowrap;
        }
        table.summary-strip .num {
            display: block;
            font-size: 12px;
            font-weight: 700;
            color: ' . $primaryColor . ';
            line-height: 1.15;
        }
        table.summary-strip .lbl {
            display: block;
            font-size: 6.5px;
            color: #6c757d;
            text-transform: uppercase;
            letter-spacing: 0.4px;
            margin-top: 1px;
        }

        /* ---------- Data table ---------- */
        table.data {
            width: 100%;
            border-collapse: collapse;
            table-layout: fixed;
            font-size: 7px;
        }
        table.data thead th {
            background: ' . $primaryColor . ';
            color: #ffffff;
            padding: 5px 6px;
            font-weight: 600;
            font-size: 7.5px;
            text-transform: uppercase;
            letter-spacing: 0.3px;
            border: 1px solid ' . $primaryColor . ';
            white-space: nowrap;
            page-break-inside: avoid;
        }
        table.data tbody td {
            padding: 4px 6px;
            border: 1px solid #dee2e6;
            vertical-align: middle;
            word-wrap: break-word;
            overflow: hidden;
        }
        table.data tbody tr { page-break-inside: avoid; }
        table.data tbody tr:nth-child(even) td { background: #f7f9fc; }
        table.data tbody tr:nth-child(odd)  td { background: #ffffff; }

        /* ---------- Alignment ---------- */
        .align-left   { text-align: left; }
        .align-right  { text-align: right; }
        .align-center { text-align: center; }

        /* ---------- Cell types ---------- */
        .cell-date,
        .cell-time,
        .cell-code {
            font-family: "Courier New", "Consolas", monospace;
            font-size: 6.8px;
        }
        .cell-numeric {
            font-family: "Courier New", "Consolas", monospace;
            text-align: right;
        }

        /* ---------- Badges ---------- */
        .badge {
            display: inline-block;
            padding: 1px 5px;
            border-radius: 6px;
            font-size: 6.5px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.3px;
            white-space: nowrap;
        }
        .badge-inside        { background: #d4edda; color: #155724; }
        .badge-exited        { background: #e2e3e5; color: #383d41; }
        .badge-guest         { background: #d1ecf1; color: #0c5460; }
        .badge-member        { background: #e2e3e5; color: #383d41; }
        .badge-authorized    { background: #d4edda; color: #155724; }
        .badge-unauthorized  { background: #f8d7da; color: #721c24; }
        .badge-neutral       { background: #f8f9fa; color: #6c757d; }

        /* ---------- No data ---------- */
        .no-data {
            text-align: center;
            padding: 24px 0;
            color: #6c757d;
            font-size: 9px;
            font-style: italic;
        }

        /* ---------- Footer ---------- */
        .footer {
            margin-top: 10px;
            padding-top: 4px;
            border-top: 1px solid #dee2e6;
            text-align: center;
            font-size: 6.5px;
            color: #6c757d;
        }
    </style></head><body>';

    // ---------- Header ----------
    $html .= '<table class="report-header"><tr>';
    $html .= '<td class="logo-cell">';
    if ($logo) {
        $html .= '<img src="' . vms_h($logo) . '" alt="' . vms_h($institution) . '">';
    }
    $html .= '</td>';
    $html .= '<td class="title-cell">';
    $html .= '<h1>' . vms_h($institution) . '</h1>';
    $html .= '<p>' . vms_h($title) . '</p>';
    $html .= '</td>';
    $html .= '<td class="meta-cell">';
    $html .= '<div><strong>Range:</strong> ' . vms_h($from) . ' &rarr; ' . vms_h($to) . '</div>';
    $html .= '<div><strong>Generated:</strong> ' . date('d-m-Y H:i:s') . '</div>';
    $html .= '<div><strong>Records:</strong> ' . number_format($summary['total']) . '</div>';
    if ($type === 'guests') {
        $html .= '<div><strong>Type:</strong> Guest Report</div>';
    }
    $html .= '</td>';
    $html .= '</tr></table>';

    // ---------- Summary ----------
    $html .= '<table class="summary-strip"><tr>';
    $html .= '<td><span class="num">' . number_format($summary['total']) . '</span><span class="lbl">Total</span></td>';

    if ($type === 'entries' || $type === 'guests') {
        $html .= '<td><span class="num" style="color:#28a745;">' . number_format($summary['inside']) . '</span><span class="lbl">Inside</span></td>';
        $html .= '<td><span class="num" style="color:#dc3545;">' . number_format($summary['exited']) . '</span><span class="lbl">Exited</span></td>';
        $html .= '<td><span class="num">' . number_format($summary['members']) . '</span><span class="lbl">Members</span></td>';
        $html .= '<td><span class="num" style="color:#20c997;">' . number_format($summary['guests']) . '</span><span class="lbl">Guests</span></td>';
        if ($type === 'guests') {
            $html .= '<td><span class="num" style="color:#28a745;">' . number_format($summary['guest_inside'] ?? 0) . '</span><span class="lbl">Guest Inside</span></td>';
            $html .= '<td><span class="num" style="color:#6c757d;">' . number_format($summary['guest_exited'] ?? 0) . '</span><span class="lbl">Guest Exited</span></td>';
        }
    } else {
        $html .= '<td><span class="num" style="color:#28a745;">' . number_format($summary['authorized']) . '</span><span class="lbl">Authorized</span></td>';
        $html .= '<td><span class="num" style="color:#dc3545;">' . number_format($summary['unauthorized']) . '</span><span class="lbl">Unauthorized</span></td>';
    }
    $html .= '</tr></table>';

    // ---------- Data table ----------
    $html .= '<table class="data">';
    $html .= '<colgroup>';
    foreach ($activeColumns as $key => $col) {
        $html .= '<col style="width:' . $colWidthPct[$key] . '%;">';
    }
    $html .= '</colgroup>';
    $html .= '<thead><tr>';
    foreach ($activeColumns as $col) {
        $html .= '<th class="align-' . $col['align'] . '">' . vms_h($col['label']) . '</th>';
    }
    $html .= '</tr></thead><tbody>';

    if (empty($data)) {
        $html .= '<tr><td colspan="' . count($activeColumns) . '" class="no-data">';
        $html .= 'No records found for the selected filters.';
        $html .= '</td></tr>';
    } else {
        foreach ($data as $row) {
            $html .= '<tr>';
            foreach ($activeColumns as $key => $col) {
                $raw = $row[$col['key']] ?? null;
                $f   = formatCellValue($raw, $col['format']);
                $cls = 'align-' . $col['align'];
                if ($f['class'] !== '' && !$f['is_badge']) {
                    $cls .= ' ' . $f['class'];
                }
                $html .= '<td class="' . $cls . '">';
                if ($f['is_badge']) {
                    $html .= '<span class="badge ' . $f['class'] . '">' . vms_h($f['text']) . '</span>';
                } else {
                    $html .= vms_h($f['text']);
                }
                $html .= '</td>';
            }
            $html .= '</tr>';
        }
    }
    $html .= '</tbody></table>';

    $html .= '<div class="footer">';
    $html .= vms_h($institution);
    $html .= ' &middot; Visitor Management System v' . vms_h(APP_VERSION);
    $html .= ' &middot; ' . date('Y');
    $html .= '</div>';

    $html .= '</body></html>';

    // ------------------------------------------------------------
    // Write temp HTML
    // ------------------------------------------------------------
    $tempHtml = tempnam(sys_get_temp_dir(), 'vms_report_') . '.html';
    file_put_contents($tempHtml, $html);

    // ------------------------------------------------------------
    // Try wkhtmltopdf
    // ------------------------------------------------------------
    $wkhtml = '/usr/bin/wkhtmltopdf';
    if (file_exists($wkhtml) && is_executable($wkhtml)) {
        $tempPdf = tempnam(sys_get_temp_dir(), 'vms_report_') . '.pdf';
        try {
            $footerLeft  = escapeshellarg('VMS v' . APP_VERSION);
            $footerRight = escapeshellarg('Page [page] / [topage]');

            $cmd = escapeshellcmd($wkhtml)
                 . ' --margin-top 10'
                 . ' --margin-bottom 14'
                 . ' --margin-left 10'
                 . ' --margin-right 10'
                 . ' --page-size A4'
                 . ' --orientation Landscape'
                 . ' --enable-local-file-access'
                 . ' --print-media-type'
                 . ' --disable-smart-shrinking'
                 . ' --dpi 300'
                 . ' --footer-left ' . $footerLeft
                 . ' --footer-right ' . $footerRight
                 . ' --footer-font-size 7'
                 . ' --footer-spacing 4'
                 . ' ' . escapeshellarg($tempHtml)
                 . ' ' . escapeshellarg($tempPdf)
                 . ' 2>&1';

            exec($cmd, $out, $rc);

            if ($rc === 0 && file_exists($tempPdf) && filesize($tempPdf) > 500) {
                header('Content-Type: application/pdf');
                header('Content-Disposition: attachment; filename="' . $filename . '"');
                header('Content-Length: ' . filesize($tempPdf));
                header('Cache-Control: private, max-age=0');
                header('Pragma: public');
                readfile($tempPdf);
                @unlink($tempHtml);
                @unlink($tempPdf);
                exit;
            }
        } catch (Throwable $e) {
            error_log('[VMS] wkhtmltopdf failed: ' . $e->getMessage());
        } finally {
            if (file_exists($tempPdf)) @unlink($tempPdf);
        }
    }

    // ------------------------------------------------------------
    // Try Chromium headless
    // ------------------------------------------------------------
    $chromePaths = [
        '/usr/bin/chromium-browser',
        '/usr/bin/google-chrome',
        '/usr/bin/chromium',
        '/usr/bin/chrome',
    ];
    foreach ($chromePaths as $chrome) {
        if (!file_exists($chrome) || !is_executable($chrome)) continue;

        $tempPdf = tempnam(sys_get_temp_dir(), 'vms_report_') . '.pdf';
        try {
            $cmd = escapeshellcmd($chrome)
                 . ' --headless=new'
                 . ' --disable-gpu'
                 . ' --no-sandbox'
                 . ' --disable-dev-shm-usage'
                 . ' --hide-scrollbars'
                 . ' --print-to-pdf-no-header'
                 . ' --print-to-pdf=' . escapeshellarg($tempPdf)
                 . ' --virtual-time-budget=5000'
                 . ' --run-all-compositor-stages-before-draw'
                 . ' file://' . $tempHtml
                 . ' 2>&1';

            exec($cmd, $out, $rc);

            if ($rc === 0 && file_exists($tempPdf) && filesize($tempPdf) > 500) {
                header('Content-Type: application/pdf');
                header('Content-Disposition: attachment; filename="' . $filename . '"');
                header('Content-Length: ' . filesize($tempPdf));
                header('Cache-Control: private, max-age=0');
                header('Pragma: public');
                readfile($tempPdf);
                @unlink($tempHtml);
                @unlink($tempPdf);
                exit;
            }
        } catch (Throwable $e) {
            error_log('[VMS] Chromium failed: ' . $e->getMessage());
        } finally {
            if (file_exists($tempPdf)) @unlink($tempPdf);
        }
    }

    // ------------------------------------------------------------
    // Fallback — output as HTML with .pdf filename hint
    // ------------------------------------------------------------
    @unlink($tempHtml);
    header('Content-Type: text/html; charset=utf-8');
    echo $html;
    exit;
}

// ============================================================
// FALLBACK — invalid format
// ============================================================
header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Invalid Format</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <div class="alert alert-danger">
            <h4><i class="fas fa-exclamation-triangle"></i> Invalid Format Requested</h4>
            <p>Please use <code>format=pdf</code> or <code>format=excel</code>.</p>
            <a href="reports.php" class="btn btn-primary mt-2">
                <i class="fas fa-arrow-left me-2"></i>Back to Reports
            </a>
        </div>
    </div>
</body>
</html>
<?php
exit;
