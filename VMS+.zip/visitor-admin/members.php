<?php
/**
 * Visitor Management System - Member Management
 * Version: 7.4 FINAL - WORKING
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

// Auto-detect paths
$possiblePaths = [
    __DIR__ . '/includes',
    dirname(__DIR__) . '/includes',
    '/usr/share/koha/intranet/cgi-bin/koha/visitor/includes',
    '/usr/share/koha/intranet/cgi-bin/visitor/includes',
];

$includePath = null;
foreach ($possiblePaths as $path) {
    if (file_exists($path . '/config.php')) {
        $includePath = $path;
        break;
    }
}

if (!$includePath) {
    $testPath = __DIR__;
    for ($i = 0; $i < 5; $i++) {
        $testPath = dirname($testPath);
        if (file_exists($testPath . '/includes/config.php')) {
            $includePath = $testPath . '/includes';
            break;
        }
    }
}

if (!$includePath) {
    die('Could not find includes directory.');
}

define('VMS_INCLUDES', $includePath);
require_once VMS_INCLUDES . '/config.php';
require_once VMS_INCLUDES . '/functions.php';
require_once VMS_INCLUDES . '/koha.php';
require_once VMS_INCLUDES . '/auth.php';

startSecureSession();
requireKohaLogin();
requireKohaRole('admin');

$db = getDB();
$message = '';
$search = $_GET['search'] ?? '';

// Sync members from Koha
if (isset($_POST['sync_members'])) {
    $koha = getKoha();
    if ($koha) {
        try {
            $stmt = $koha->query("
                SELECT 
                    cardnumber, 
                    CONCAT(title, ' ', firstname, ' ', surname) as name, 
                    categorycode, 
                    branchcode, 
                    email, 
                    mobile, 
                    sex as gender, 
                    sort1 as department, 
                    sort2 as course 
                FROM borrowers 
                WHERE dateexpiry > CURDATE()
                AND (gonenoaddress IS NULL OR gonenoaddress = 0)
                AND (lost IS NULL OR lost = 0)
                AND (debarred IS NULL OR debarred = 0)
            ");
            $members = $stmt->fetchAll();
            $count = 0;
            foreach ($members as $m) {
                $check = $db->prepare("SELECT id FROM members WHERE admno = ?");
                $check->execute([$m['cardnumber']]);
                if (!$check->fetch()) {
                    $insert = $db->prepare("INSERT INTO members (admno, name, member_category, branch, department, course, email, mobile, gender, status, koha_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'active', ?)");
                    $insert->execute([$m['cardnumber'], $m['name'], $m['categorycode'], $m['branchcode'], $m['department'], $m['course'], $m['email'] ?? '', $m['mobile'] ?? '', $m['gender'] ?? '', $m['cardnumber']]);
                    $count++;
                } else {
                    $update = $db->prepare("UPDATE members SET name = ?, member_category = ?, branch = ?, department = ?, course = ?, email = ?, mobile = ?, gender = ?, updated_at = NOW() WHERE admno = ?");
                    $update->execute([$m['name'], $m['categorycode'], $m['branchcode'], $m['department'], $m['course'], $m['email'] ?? '', $m['mobile'] ?? '', $m['gender'] ?? '', $m['cardnumber']]);
                }
            }
            logActivity($user['id'] ?? 0, 'SYNC_MEMBERS', "Synced $count new members from Koha");
            $message = "✅ Synced $count new members from Koha";
            clearCache('members');
        } catch (PDOException $e) {
            $message = '⚠️ Koha sync error: ' . $e->getMessage();
        }
    } else {
        $message = '⚠️ Koha not connected';
    }
}

// Get members
if ($search) {
    $stmt = $db->prepare("SELECT * FROM members WHERE name LIKE ? OR admno LIKE ? ORDER BY name LIMIT 100");
    $searchTerm = '%' . $search . '%';
    $stmt->execute([$searchTerm, $searchTerm]);
    $members = $stmt->fetchAll();
} else {
    $members = $db->query("SELECT * FROM members ORDER BY name LIMIT 100")->fetchAll();
}

$totalMembers = $db->query("SELECT COUNT(*) FROM members")->fetchColumn();
$activeGuests = $db->query("SELECT COUNT(*) FROM entry_exit_logs WHERE status = 'inside' AND entry_type = 'guest'")->fetchColumn();

$pageTitle = 'Members';
include __DIR__ . '/header.php';
?>

<style>
.member-stats {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
    gap: 10px;
    margin-bottom: 16px;
}
.member-stat-item {
    background: white;
    border-radius: 12px;
    padding: 12px;
    text-align: center;
    border: 1px solid #e9ecef;
}
.member-stat-item .number {
    font-size: 1.2rem;
    font-weight: 700;
    color: #1e3c72;
}
.member-stat-item .label {
    font-size: 0.65rem;
    color: #6c757d;
}
.member-stat-item.guest .number {
    color: #20c997;
}
@media (max-width: 768px) {
    .member-stats {
        grid-template-columns: repeat(2, 1fr);
    }
}
</style>

<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
        <h4 class="mb-0"><i class="fas fa-users me-2 text-primary"></i>Member Management</h4>
        <span class="badge bg-primary rounded-pill px-3 py-2">
            <i class="fas fa-users me-1"></i> <?= number_format($totalMembers) ?> Total
        </span>
    </div>
    
    <?php if ($message): ?>
        <div class="alert alert-<?= strpos($message, '⚠️') !== false ? 'warning' : 'success' ?> alert-dismissible fade show">
            <?= htmlspecialchars($message) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <div class="member-stats">
        <div class="member-stat-item"><div class="number"><?= number_format($totalMembers) ?></div><div class="label">Total Members</div></div>
        <div class="member-stat-item"><div class="number"><?= number_format($db->query("SELECT COUNT(*) FROM members WHERE status = 'active'")->fetchColumn()) ?></div><div class="label">Active</div></div>
        <div class="member-stat-item"><div class="number"><?= number_format($db->query("SELECT COUNT(DISTINCT member_category) FROM members")->fetchColumn()) ?></div><div class="label">Categories</div></div>
        <div class="member-stat-item guest"><div class="number"><?= number_format($activeGuests) ?></div><div class="label">Active Guests</div></div>
    </div>

    <div class="card mb-4 shadow-sm">
        <div class="card-body">
            <div class="row g-3 align-items-center">
                <div class="col-12 col-md-6">
                    <form method="GET" class="d-flex gap-2">
                        <input type="text" name="search" class="form-control" placeholder="Search by name or ID..." value="<?= htmlspecialchars($search) ?>">
                        <button type="submit" class="btn btn-primary"><i class="fas fa-search"></i></button>
                    </form>
                </div>
                <div class="col-12 col-md-6 text-center text-md-end">
                    <form method="POST" class="d-inline">
                        <button type="submit" name="sync_members" class="btn btn-success">
                            <i class="fas fa-sync me-2"></i> Sync from Koha
                        </button>
                    </form>
                    <a href="guests.php" class="btn btn-outline-success">
                        <i class="fas fa-user-friends me-2"></i> Manage Guests
                    </a>
                    <?php if ($search): ?>
                        <a href="members.php" class="btn btn-secondary">
                            <i class="fas fa-times me-2"></i> Clear
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    
    <div class="card shadow-sm">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover mb-0" id="membersTable">
                    <thead class="table-light">
                        <tr><th>ID</th><th>Name</th><th>Category</th><th>Department</th><th>Email</th><th>Status</th></tr>
                    </thead>
                    <tbody>
                        <?php if (empty($members)): ?>
                            <tr><td colspan="6" class="text-center py-4 text-muted"><i class="fas fa-info-circle me-2"></i> No members found</td></tr>
                        <?php else: ?>
                            <?php foreach ($members as $m): ?>
                                <tr>
                                    <td><code><strong><?= htmlspecialchars($m['admno']) ?></strong></code></td>
                                    <td><?= htmlspecialchars($m['name']) ?></td>
                                    <td><span class="badge bg-primary"><?= htmlspecialchars($m['member_category'] ?? 'N/A') ?></span></td>
                                    <td><?= htmlspecialchars($m['department'] ?? 'N/A') ?></td>
                                    <td><?= htmlspecialchars($m['email'] ?? 'N/A') ?></td>
                                    <td><span class="badge <?= ($m['status'] ?? 'active') === 'active' ? 'bg-success' : 'bg-secondary' ?>"><?= ucfirst($m['status'] ?? 'Active') ?></span></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php if (count($members) == 100 && $totalMembers > 100): ?>
            <div class="card-footer bg-white text-center text-muted small">Showing first 100 members. Use search to find specific members.</div>
        <?php endif; ?>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const table = document.getElementById('membersTable');
    if (!table) return;
    const cardBody = table.closest('.card-body');
    if (cardBody) {
        const searchDiv = document.createElement('div');
        searchDiv.className = 'p-3 border-bottom';
        searchDiv.innerHTML = `
            <div class="d-flex gap-2">
                <input type="text" id="tableSearch" class="form-control form-control-sm" 
                       placeholder="Search in table..." style="max-width:300px;">
                <button class="btn btn-sm btn-outline-secondary" onclick="clearTableSearch()">
                    <i class="fas fa-times"></i>
                </button>
                <button class="btn btn-sm btn-outline-success" onclick="exportTableToCSV('membersTable', 'members_<?= date('Y-m-d') ?>')">
                    <i class="fas fa-file-csv"></i> Export CSV
                </button>
            </div>
        `;
        cardBody.insertBefore(searchDiv, table);
        document.getElementById('tableSearch').addEventListener('input', function() {
            const filter = this.value.toLowerCase();
            const rows = table.getElementsByTagName('tbody')[0]?.getElementsByTagName('tr') || [];
            for (let i = 0; i < rows.length; i++) {
                const text = rows[i].textContent.toLowerCase();
                rows[i].style.display = text.includes(filter) ? '' : 'none';
            }
        });
    }
});
function clearTableSearch() {
    const input = document.getElementById('tableSearch');
    if (input) { input.value = ''; input.dispatchEvent(new Event('input')); input.focus(); }
}
function exportTableToCSV(tableId, filename) {
    const table = document.getElementById(tableId);
    if (!table) return;
    const rows = table.querySelectorAll('tr');
    const csv = [];
    rows.forEach(row => {
        const cells = row.querySelectorAll('th, td');
        const rowData = [];
        cells.forEach(cell => {
            let text = cell.textContent.trim();
            if (text.includes(',')) { text = '"' + text + '"'; }
            rowData.push(text);
        });
        csv.push(rowData.join(','));
    });
    const csvContent = csv.join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = (filename || 'export') + '.csv';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}
</script>

<?php include __DIR__ . '/footer.php'; ?>
