<?php
/**
 * Visitor Management System — System Test / Health Check
 * Version: 8.6 FINAL
 *
 * Covers:
 *   • PHP version + extensions
 *   • VMS DB connection + critical tables
 *   • Koha DB connection + key tables
 *   • Runtime directories (5 @ chmod 777)
 *   • Trigger safety (only trg_purpose_stats)
 *   • book_exit_logs columns (v8.6 additions)
 *   • Purpose list integrity (Computer Uses present)
 *   • settings.migrations history
 *   • Live INSERT test on book_exit_logs (rolled back)
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

$possiblePaths = [
    __DIR__ . '/includes',
    dirname(__DIR__) . '/includes',
    '/usr/share/koha/intranet/cgi-bin/koha/visitor/includes',
];
$includePath = null;
foreach ($possiblePaths as $path) {
    if (file_exists($path . '/config.php')) { $includePath = $path; break; }
}
if (!$includePath) die('Could not find includes directory.');

define('VMS_INCLUDES', $includePath);
require_once VMS_INCLUDES . '/config.php';
require_once VMS_INCLUDES . '/db.php';
require_once VMS_INCLUDES . '/functions.php';
require_once VMS_INCLUDES . '/koha.php';

$results = [];
function check(&$results, string $label, bool $ok, string $detail = '', string $level = 'pass') {
    $results[] = [
        'label'  => $label,
        'ok'     => $ok,
        'detail' => $detail,
        'level'  => $ok ? 'pass' : $level,
    ];
}

// ============================================================
// 1. PHP
// ============================================================
check($results, 'PHP ≥ 7.4', version_compare(PHP_VERSION, '7.4.0', '>='), PHP_VERSION);
foreach (['pdo_mysql','gd','json','zip','mbstring','curl','intl','apcu'] as $ext) {
    check($results, "Extension: $ext", extension_loaded($ext), extension_loaded($ext) ? 'loaded' : 'missing', 'fail');
}

// ============================================================
// 2. VMS DATABASE
// ============================================================
$db = null;
try {
    $db = getDB();
    check($results, 'VMS DB connection', (bool)$db, (string)DB_NAME);
} catch (Exception $e) {
    check($results, 'VMS DB connection', false, $e->getMessage(), 'fail');
}

if ($db) {
    // Critical tables
    $criticalTables = [
        'settings','entry_exit_logs','book_exit_logs','book_alerts',
        'activity_log','purpose_stats','notifications_queue',
        'occupancy_snapshots','appointments','feedback',
        'computers','computer_sessions','computer_policies',
        'computer_attendance','system_users','system_user_logins',
        'schema_migrations','quotes','quick_actions','institutions',
        'members','users','session_logs','notification_logs',
        'module_permissions','user_preferences','login_cards',
        'staff_profiles','api_keys','visitor_goals','badge_queue',
        'audit_trail','lost_found','recommendations','notices',
        'ebooks','book_metadata_cache','classification_data'
    ];

    $missing = [];
    foreach ($criticalTables as $t) {
        try {
            $exists = $db->query("SHOW TABLES LIKE " . $db->quote($t))->rowCount() > 0;
            if (!$exists) $missing[] = $t;
        } catch (PDOException $e) { $missing[] = $t; }
    }
    check($results, 'VMS critical tables present',
          empty($missing),
          empty($missing) ? 'all present' : 'missing: ' . implode(', ', $missing),
          'warning');

    // Total table count
    try {
        $count = (int)$db->query("
            SELECT COUNT(*) FROM information_schema.TABLES
            WHERE table_schema = DATABASE() AND table_type = 'BASE TABLE'
        ")->fetchColumn();
        check($results, 'Total base tables ≥ 41', $count >= 41, "$count tables");
    } catch (PDOException $e) {}

    // ============================================================
    // 3. TRIGGERS (v8.6: only trg_purpose_stats)
    // ============================================================
    try {
        $triggers = $db->query("
            SELECT TRIGGER_NAME FROM information_schema.TRIGGERS
            WHERE TRIGGER_SCHEMA = DATABASE()
        ")->fetchAll(PDO::FETCH_COLUMN);

        $buggy = array_diff($triggers, ['trg_purpose_stats']);
        check($results, 'Only trg_purpose_stats trigger',
              empty($buggy),
              empty($triggers)
                  ? 'no triggers'
                  : 'found: ' . implode(', ', $triggers) . (empty($buggy) ? '' : ' — DROP: ' . implode(', ', $buggy)),
              'fail');
    } catch (PDOException $e) {}

    // ============================================================
    // 4. book_exit_logs v8.6 columns
    // ============================================================
    try {
        $cols = $db->query("SHOW COLUMNS FROM book_exit_logs")->fetchAll(PDO::FETCH_COLUMN);
        $want = ['book_barcode','book_title','book_author','book_isbn','is_authorized',
                 'photo_path','gate_number','staff_id','alert_sent','alert_sent_at',
                 'acknowledged','notes','exit_time','created_at'];
        $missingCols = array_diff($want, $cols);
        check($results, 'book_exit_logs v8.6 columns',
              empty($missingCols),
              empty($missingCols) ? 'all present' : 'missing: ' . implode(', ', $missingCols),
              'fail');
    } catch (PDOException $e) {}

    // ============================================================
    // 5. Live INSERT test on book_exit_logs (rolled back)
    // ============================================================
    try {
        $db->beginTransaction();
        $db->exec("
            INSERT INTO book_exit_logs (book_barcode, book_title, is_authorized)
            VALUES ('__TEST_V86__', 'Test', 0)
        ");
        $id = $db->lastInsertId();
        $db->rollBack();
        check($results, 'Trigger-safe INSERT (no 1442)', true, "would be id $id");
    } catch (PDOException $e) {
        try { $db->rollBack(); } catch (Exception $x) {}
        $is1442 = strpos($e->getMessage(), '1442') !== false;
        check($results, 'Trigger-safe INSERT (no 1442)', false,
              $e->getMessage() . ($is1442 ? ' → run fix_trigger.php' : ''),
              'fail');
    }

    // ============================================================
    // 6. Purpose list integrity
    // ============================================================
    if (function_exists('getPurposeOptions')) {
        $purposes = getPurposeOptions();
        $hasComputer = array_key_exists('Computer Uses', $purposes);
        check($results, 'Purpose list has "Computer Uses"', $hasComputer,
              $hasComputer ? 'present' : 'MISSING',
              'fail');
        check($results, 'Purpose list has 7 options',
              count($purposes) === 7,
              count($purposes) . ' options');
    }

    // ============================================================
    // 7. Migrations
    // ============================================================
    try {
        $versions = $db->query("SELECT version FROM schema_migrations ORDER BY id")->fetchAll(PDO::FETCH_COLUMN);
        $hasV86 = in_array('8.6.0', $versions, true);
        check($results, 'Migration v8.6.0 recorded', $hasV86,
              $versions ? implode(' → ', $versions) : 'none',
              'warning');
    } catch (PDOException $e) {}

    // ============================================================
    // 8. Settings row + seed data
    // ============================================================
    try {
        $settingsRow = $db->query("SELECT COUNT(*) FROM settings")->fetchColumn();
        check($results, 'settings row exists', (int)$settingsRow >= 1, "$settingsRow row(s)");
    } catch (PDOException $e) {}

    try {
        $quotes = (int)$db->query("SELECT COUNT(*) FROM quotes")->fetchColumn();
        $actions = (int)$db->query("SELECT COUNT(*) FROM quick_actions")->fetchColumn();
        $policies = (int)$db->query("SELECT COUNT(*) FROM computer_policies")->fetchColumn();
        check($results, 'Seed data (quotes ≥ 8, quick_actions ≥ 10, policies ≥ 4)',
              $quotes >= 8 && $actions >= 10 && $policies >= 4,
              "quotes=$quotes actions=$actions policies=$policies");
    } catch (PDOException $e) {}
}

// ============================================================
// 9. Koha
// ============================================================
$koha = null;
try {
    $koha = getKoha();
    check($results, 'Koha DB connection', (bool)$koha,
          $koha ? (defined('KOHA_DB') ? KOHA_DB : 'connected') : 'offline',
          'warning');
} catch (Exception $e) {
    check($results, 'Koha DB connection', false, $e->getMessage(), 'warning');
}

if ($koha) {
    foreach (['borrowers','items','biblio','issues','categories','branches'] as $t) {
        try {
            $exists = $koha->query("SHOW TABLES LIKE " . $koha->quote($t))->rowCount() > 0;
            check($results, "Koha table: $t", $exists, $exists ? 'ok' : 'missing', 'warning');
        } catch (PDOException $e) {}
    }
    try {
        $exists = $koha->query("SHOW TABLES LIKE 'sessions'")->rowCount() > 0;
        check($results, 'Koha sessions table', $exists,
              $exists ? 'ok' : 'add <sessions>mysql</sessions> to koha-conf.xml',
              'warning');
    } catch (PDOException $e) {}
}

// ============================================================
// 10. Directories
// ============================================================
$runtimeDirs = [
    'uploads', 'uploads/book_exit_photos', 'uploads/logos', 'logs', 'cache'
];
foreach ($runtimeDirs as $dir) {
    $path = (defined('ROOT_PATH') ? ROOT_PATH : __DIR__) . '/' . $dir;
    $exists = is_dir($path);
    $writable = $exists && is_writable($path);
    $perms = $exists ? substr(sprintf('%o', fileperms($path)), -3) : '—';
    check($results, "Dir: $dir",
          $exists && $writable,
          $exists ? "perms $perms" : 'missing — mkdir + chmod 777',
          $exists ? 'warning' : 'fail');
}

// ============================================================
// 11. config.php uses localhost (not 127.0.1.1)
// ============================================================
$configUrl = defined('KOHA_INTRANET_URL') ? KOHA_INTRANET_URL : '';
$usesBadHost = strpos($configUrl, '127.0.1.1') !== false;
check($results, 'KOHA_INTRANET_URL uses localhost', !$usesBadHost,
      $configUrl . ($usesBadHost ? ' — fix config.php' : ''),
      'fail');

// ============================================================
// RENDER
// ============================================================
$total   = count($results);
$passes  = count(array_filter($results, fn($r) => $r['level'] === 'pass'));
$warns   = count(array_filter($results, fn($r) => $r['level'] === 'warning'));
$fails   = count(array_filter($results, fn($r) => $r['level'] === 'fail'));
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>System Test — Visitor Management v8.6</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
body { background:#f0f2f5; padding:30px; font-family:'Inter',sans-serif; }
.test-card { background:white; border-radius:20px; padding:30px; max-width:900px; margin:0 auto; box-shadow:0 8px 30px rgba(0,0,0,0.08); }
.test-header { border-bottom:2px solid #1e3c72; padding-bottom:15px; margin-bottom:20px; }
.test-item { padding:12px 16px; border-radius:10px; margin-bottom:6px; display:flex; justify-content:space-between; align-items:center; font-size:0.9rem; }
.test-item.pass    { background:#d4edda; color:#155724; }
.test-item.fail    { background:#f8d7da; color:#721c24; }
.test-item.warning { background:#fff3cd; color:#856404; }
.test-item .detail { font-size:0.75rem; opacity:0.8; margin-top:2px; }
.summary { display:grid; grid-template-columns:repeat(3,1fr); gap:12px; margin-bottom:20px; }
.summary .box { text-align:center; padding:16px; border-radius:12px; }
.summary .box.pass    { background:#d4edda; }
.summary .box.warning { background:#fff3cd; }
.summary .box.fail    { background:#f8d7da; }
.summary .num { font-size:2rem; font-weight:800; }
.summary .lbl { font-size:0.75rem; text-transform:uppercase; opacity:0.8; }
</style>
</head>
<body>
<div class="test-card">
    <div class="test-header">
        <h2><i class="fas fa-flask me-2 text-primary"></i>System Test</h2>
        <p class="text-muted mb-0">Visitor Management System v<?= defined('APP_VERSION') ? APP_VERSION : '8.6.0' ?></p>
    </div>

    <div class="summary">
        <div class="box pass">   <div class="num"><?= $passes ?></div><div class="lbl">Passed</div></div>
        <div class="box warning"><div class="num"><?= $warns  ?></div><div class="lbl">Warnings</div></div>
        <div class="box fail">   <div class="num"><?= $fails  ?></div><div class="lbl">Failed</div></div>
    </div>

    <?php foreach ($results as $r): ?>
        <div class="test-item <?= $r['level'] ?>">
            <div>
                <strong><?= htmlspecialchars($r['label']) ?></strong>
                <?php if (!empty($r['detail'])): ?>
                    <div class="detail"><?= htmlspecialchars($r['detail']) ?></div>
                <?php endif; ?>
            </div>
            <span>
                <?php if ($r['level'] === 'pass'): ?>✅
                <?php elseif ($r['level'] === 'warning'): ?>⚠️
                <?php else: ?>❌<?php endif; ?>
            </span>
        </div>
    <?php endforeach; ?>

    <div class="mt-4 text-center">
        <a href="dashboard.php"    class="btn btn-primary"><i class="fas fa-chart-pie me-2"></i>Dashboard</a>
        <a href="fix_trigger.php"  class="btn btn-outline-danger"><i class="fas fa-wrench me-2"></i>Fix Triggers</a>
        <a href="settings.php"     class="btn btn-outline-secondary"><i class="fas fa-cog me-2"></i>Settings</a>
        <button onclick="location.reload()" class="btn btn-outline-primary"><i class="fas fa-sync me-2"></i>Re-run</button>
    </div>
</div>
</body>
</html>
