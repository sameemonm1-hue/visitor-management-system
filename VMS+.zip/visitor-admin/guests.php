<?php
/**
 * Visitor Management System - Guest Management
 * Version: 7.8 FINAL — Institution Name Entity Fix
 *
 * FIX (v7.8):
 *   • Aggressive institution-name normalization (multi-level entity decode).
 *   • Publishes clean plain value to $GLOBALS for the shared footer.
 *   • Shared footer output buffered + post-processed to collapse &amp; chains.
 *   • Publishes window.VMS_INSTITUTION_NAME to JS via json_encode.
 *
 * CHANGELOG v7.7 (from v7.5):
 *   ── NEW: Guest Name is now OPTIONAL in the "New Guest Entry" panel.
 *      If left blank, the system auto-generates "Guest N" so the
 *      visitor is never blocked at the admin panel.
 *   ── NEW: Inline rename — a pencil button on every active guest card
 *      and on every row of the history table opens a small modal to
 *      add, edit, or clear the guest's name.
 *   ── NEW: Rename writes an entry to activity_log (GUEST_RENAME) with
 *      old → new so nothing is lost.
 *   ── NEW: Guest name field shows "(optional)" hint; validation was
 *      removed from both client and server side.
 *   ── PRESERVED: Webcam capture (VMSBookCapture), photo thumbnail,
 *      guest_photo column migration, force-exit-all, stats strip,
 *      active guests grid, history table, search, CSV export.
 *
 * CHANGELOG v7.5:
 *   ── NEW: "New Guest Entry" panel with photo capture.
 *   ── NEW: guest_photo column auto-added (idempotent).
 *   ── NEW: Photo displayed on active cards + history.
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

// ============================================================
// AUTO-DETECT INCLUDES PATH
// ============================================================
$possiblePaths = [
    __DIR__ . '/includes',
    dirname(__DIR__) . '/includes',
    '/usr/share/koha/intranet/cgi-bin/koha/visitor/includes',
    '/usr/share/koha/intranet/cgi-bin/visitor/includes',
];

$includePath = null;
foreach ($possiblePaths as $path) {
    if (file_exists($path . '/config.php')) {
        $includePath = $path;
        break;
    }
}

if (!$includePath) {
    $testPath = __DIR__;
    for ($i = 0; $i < 5; $i++) {
        $testPath = dirname($testPath);
        if (file_exists($testPath . '/includes/config.php')) {
            $includePath = $testPath . '/includes';
            break;
        }
    }
}

if (!$includePath) {
    die('Could not find includes directory.');
}

define('VMS_INCLUDES', $includePath);
require_once VMS_INCLUDES . '/config.php';
require_once VMS_INCLUDES . '/functions.php';
require_once VMS_INCLUDES . '/koha.php';
require_once VMS_INCLUDES . '/auth.php';

startSecureSession();
requireKohaLogin();

$db       = getDB();
$user     = getCurrentUser();
$settings = getSettings();
$message  = '';
$error    = '';

// ============================================================
// INSTITUTION NAME — deeply normalized to plain text  [CHANGED v7.8]
// ============================================================
if (!function_exists('guests_clean_institution')) {
    /**
     * Aggressively normalize an institution name to plain text.
     *
     * "Library & information"          → "Library & information"
     * "Library &amp; information"       → "Library & information"
     * "Library &amp;amp; information"   → "Library & information"
     * "Library &amp;amp;amp; info"      → "Library & information"
     */
    function guests_clean_institution(string $raw): string {
        $raw = trim($raw);
        if ($raw === '') return 'My Library';

        if (!mb_check_encoding($raw, 'UTF-8')) {
            $fixed = @mb_convert_encoding($raw, 'UTF-8', 'ISO-8859-1');
            if ($fixed !== false && $fixed !== '') $raw = $fixed;
        }

        // Loop-decode until stable (max 5 passes)
        $prev = null; $out = $raw; $i = 0;
        while ($prev !== $out && $i < 5) {
            $prev = $out;
            $out  = html_entity_decode($out, ENT_QUOTES | ENT_HTML5, 'UTF-8');
            $i++;
        }

        // Defensive collapse of residual literal entity sequences
        $out = str_replace(
            ['&amp;amp;amp;', '&amp;amp;', '&amp;', '&AMP;', '&Amp;'],
            '&',
            $out
        );
        $out = str_replace(
            ['&quot;', '&#039;', '&#39;', '&apos;', '&lt;', '&gt;', '&nbsp;'],
            ['"',       "'",       "'",      "'",       '<',    '>',    ' '],
            $out
        );

        $out = preg_replace('/\s+/u', ' ', $out);
        $out = trim($out);

        return $out !== '' ? $out : 'My Library';
    }
}

$institutionName = 'My Library';
if (is_array($settings) && !empty($settings['institution_name'])) {
    $institutionName = guests_clean_institution((string)$settings['institution_name']);
} elseif (defined('INSTITUTION_NAME') && trim((string)INSTITUTION_NAME) !== '') {
    $institutionName = guests_clean_institution((string)INSTITUTION_NAME);
}

// Publish everywhere so the shared header/footer can read whichever key they use
$GLOBALS['institution_name'] = $institutionName;
$GLOBALS['institutionName']  = $institutionName;
$GLOBALS['INSTITUTION_NAME'] = $institutionName;

// Keep $settings['institution_name'] clean too in case the footer reads
// from the settings array (very common in VMS).
if (is_array($settings)) {
    $settings['institution_name'] = $institutionName;
}

// ============================================================
// v7.6 — ENSURE guest_photo COLUMN (idempotent migration)
// ============================================================
$hasGuestPhotoCol = false;
try {
    $cols = $db->query("SHOW COLUMNS FROM entry_exit_logs")->fetchAll(PDO::FETCH_COLUMN);
    $hasGuestPhotoCol = in_array('guest_photo', $cols, true);

    if (!$hasGuestPhotoCol) {
        $db->exec("ALTER TABLE entry_exit_logs
                   ADD COLUMN guest_photo VARCHAR(255) NULL
                   AFTER member_category");
        $hasGuestPhotoCol = true;
    }
} catch (PDOException $e) {
    error_log('[guests.php] guest_photo migration failed: ' . $e->getMessage());
}

// ============================================================
// PHOTO HELPER
// ============================================================
if (!function_exists('vms_save_guest_photo')) {
    function vms_save_guest_photo(?string $dataUrl): ?string
    {
        if (empty($dataUrl) || !is_string($dataUrl)) return null;

        if (!preg_match('#^data:image/(jpeg|jpg|png|webp);base64,#i', $dataUrl, $m)) {
            return null;
        }
        $ext = strtolower($m[1]);
        if ($ext === 'jpeg') $ext = 'jpg';

        $raw = base64_decode(substr($dataUrl, strlen($m[0])), true);
        if ($raw === false || strlen($raw) < 200) return null;
        if (strlen($raw) > 3 * 1024 * 1024) return null;

        $baseDir = defined('UPLOAD_PATH') ? UPLOAD_PATH : (__DIR__ . '/../uploads');
        $dir     = rtrim($baseDir, '/') . '/guest_photos/';
        if (!is_dir($dir)) {
            @mkdir($dir, 0777, true);
            @chmod($dir, 0777);
        }
        if (!is_dir($dir) || !is_writable($dir)) {
            error_log('[guests.php] photo dir not writable: ' . $dir);
            return null;
        }

        $filename = 'guest_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
        $target   = $dir . $filename;

        if (@file_put_contents($target, $raw) === false) {
            error_log('[guests.php] failed to write photo: ' . $target);
            return null;
        }
        @chmod($target, 0644);
        return $filename;
    }
}

// ============================================================
// HELPER: resolve photo URL for a row
// ============================================================
if (!function_exists('vms_guest_photo_url')) {
    function vms_guest_photo_url(array $row): string
    {
        $file = trim((string)($row['guest_photo'] ?? ''));
        if ($file === '') return '';
        $baseDir = defined('UPLOAD_PATH') ? UPLOAD_PATH : (__DIR__ . '/../uploads');
        $path    = rtrim($baseDir, '/') . '/guest_photos/' . $file;
        if (!file_exists($path)) return '';
        return 'guest_photo.php?f=' . urlencode($file);
    }
}

// ============================================================
// HELPER: generate next guest ID
// ============================================================
if (!function_exists('vms_next_guest_id')) {
    function vms_next_guest_id(PDO $db, array $settings): array
    {
        $guestNum = (int)($db->query("SELECT guest_daily_counter FROM settings LIMIT 1")->fetchColumn() ?: 1);
        $prefix   = $settings['guest_prefix']  ?? 'GUEST-';
        $padding  = (int)($settings['guest_padding'] ?? 4);
        $admno    = $prefix . str_pad($guestNum, $padding, '0', STR_PAD_LEFT);
        return ['num' => $guestNum, 'admno' => $admno];
    }
}

// ============================================================
// v7.7 — HANDLE MANUAL GUEST ENTRY (guest name is OPTIONAL)
// ============================================================
if (isset($_POST['guest_in_manual'])) {
    $guestName  = trim($_POST['guest_name'] ?? '');
    $guestPhoto = trim($_POST['guest_photo_data'] ?? '');
    $purpose    = trim($_POST['guest_purpose'] ?? ($settings['default_purpose'] ?? 'Other'));

    if ($guestName !== '') {
        if (function_exists('mb_substr')) {
            $guestName = mb_substr($guestName, 0, 120, 'UTF-8');
        } else {
            $guestName = substr($guestName, 0, 120);
        }
    }

    $photoFilename = null;
    if ($guestPhoto !== '' && $hasGuestPhotoCol) {
        $photoFilename = vms_save_guest_photo($guestPhoto);
    }

    $next     = vms_next_guest_id($db, $settings);
    $guestNum = $next['num'];
    $admno    = $next['admno'];

    $autoNamed = false;
    if ($guestName === '') {
        $guestName = 'Guest ' . $guestNum;
        $autoNamed = true;
    }

    try {
        if ($hasGuestPhotoCol) {
            $db->prepare("
                INSERT INTO entry_exit_logs
                    (admno, member_name, member_category, guest_photo,
                     entry_date, entry_time, purpose, status, entry_type)
                VALUES (?, ?, 'Guest', ?, CURDATE(), CURTIME(), ?, 'inside', 'guest')
            ")->execute([$admno, $guestName, $photoFilename, $purpose]);
        } else {
            $db->prepare("
                INSERT INTO entry_exit_logs
                    (admno, member_name, member_category,
                     entry_date, entry_time, purpose, status, entry_type)
                VALUES (?, ?, 'Guest', CURDATE(), CURTIME(), ?, 'inside', 'guest')
            ")->execute([$admno, $guestName, $purpose]);
        }

        $db->query("UPDATE settings SET guest_daily_counter = guest_daily_counter + 1");

        logActivity(
            $user['id'] ?? 0,
            'GUEST_ENTRY',
            "Guest '{$guestName}' entered ({$admno})" .
            ($autoNamed ? ' [auto-named]' : '')
        );

        $message = "Guest \"{$guestName}\" entered as {$admno}";
        if ($autoNamed) {
            $message .= ' — you can rename them below.';
        }

        clearCache('settings_all');
        clearCache('stats');

        $settings = getSettings();
        // Re-normalize after settings reload
        if (is_array($settings) && !empty($settings['institution_name'])) {
            $institutionName = guests_clean_institution((string)$settings['institution_name']);
            $settings['institution_name'] = $institutionName;
            $GLOBALS['institution_name'] = $institutionName;
            $GLOBALS['institutionName']  = $institutionName;
            $GLOBALS['INSTITUTION_NAME'] = $institutionName;
        }
    } catch (PDOException $e) {
        error_log('[guests.php] insert: ' . $e->getMessage());
        $error = 'Failed to record guest entry. Please try again.';
    }
}

// ============================================================
// v7.7 — HANDLE GUEST RENAME (add / edit / delete)
// ============================================================
if (isset($_POST['rename_guest'])) {
    $guestId = (int)($_POST['guest_id'] ?? 0);
    $newName = trim($_POST['new_name'] ?? '');

    if ($guestId <= 0) {
        $error = 'Invalid guest ID.';
    } else {
        if ($newName === '') {
            $newName = 'Guest (unnamed)';
        }

        if (function_exists('mb_substr')) {
            $newName = mb_substr($newName, 0, 120, 'UTF-8');
        } else {
            $newName = substr($newName, 0, 120);
        }

        try {
            $stmt = $db->prepare("SELECT member_name FROM entry_exit_logs WHERE id = ? AND entry_type = 'guest' LIMIT 1");
            $stmt->execute([$guestId]);
            $old = $stmt->fetch();

            if (!$old) {
                $error = 'Guest not found.';
            } else {
                $db->prepare("UPDATE entry_exit_logs SET member_name = ? WHERE id = ?")
                   ->execute([$newName, $guestId]);

                logActivity(
                    $user['id'] ?? 0,
                    'GUEST_RENAME',
                    "Renamed guest #{$guestId}: '{$old['member_name']}' → '{$newName}'"
                );

                $message = "Guest renamed to \"{$newName}\".";
                clearCache('stats');
            }
        } catch (PDOException $e) {
            error_log('[guests.php] rename: ' . $e->getMessage());
            $error = 'Failed to rename guest.';
        }
    }
}

// ============================================================
// HANDLE GUEST EXIT (single)
// ============================================================
if (isset($_POST['exit_guest'])) {
    $guestId = (int)$_POST['guest_id'];
    $stmt = $db->prepare("UPDATE entry_exit_logs SET exit_time = NOW(), status = 'exited' WHERE id = ? AND status = 'inside' AND entry_type = 'guest'");
    $stmt->execute([$guestId]);
    if ($stmt->rowCount() > 0) {
        logActivity($user['id'] ?? 0, 'GUEST_EXIT', "Guest exited ID: $guestId");
        $message = 'Guest exited successfully.';
        clearCache('stats');
    } else {
        $error = 'Guest not found or already exited.';
    }
}

// ============================================================
// FORCE EXIT ALL GUESTS
// ============================================================
if (isset($_POST['force_exit_all_guests'])) {
    $stmt = $db->prepare("
        UPDATE entry_exit_logs
           SET exit_time = NOW(),
               status = 'exited',
               notes = CONCAT(IFNULL(notes, ''), ' [Force exited all guests at ', NOW(), ']')
         WHERE status = 'inside' AND entry_type = 'guest'
    ");
    $stmt->execute();
    $count = $stmt->rowCount();
    if ($count > 0) {
        logActivity($user['id'] ?? 0, 'FORCE_EXIT_ALL_GUESTS', "Force exited $count guests");
        $message = "Force exited {$count} guest" . ($count === 1 ? '' : "s") . ".";
        clearCache('stats');
    } else {
        $error = 'No active guests to exit.';
    }
}

// ============================================================
// FETCH STATS + LISTS
// ============================================================
$activeGuests = (int)$db->query("SELECT COUNT(*) FROM entry_exit_logs WHERE status = 'inside' AND entry_type = 'guest'")->fetchColumn();
$todayGuests  = (int)$db->query("SELECT COUNT(*) FROM entry_exit_logs WHERE entry_date = CURDATE() AND entry_type = 'guest'")->fetchColumn();
$totalGuests  = (int)$db->query("SELECT COUNT(*) FROM entry_exit_logs WHERE entry_type = 'guest'")->fetchColumn();

$guests = $db->query("
    SELECT * FROM entry_exit_logs
     WHERE status = 'inside' AND entry_type = 'guest'
     ORDER BY entry_time DESC
")->fetchAll();

$guestHistory = $db->query("
    SELECT * FROM entry_exit_logs
     WHERE entry_type = 'guest'
     ORDER BY entry_date DESC, entry_time DESC
     LIMIT 100
")->fetchAll();

$pageTitle = 'Guest Management';
include __DIR__ . '/header.php';
?>

<style>
/* ---------------- Stats strip ---------------- */
.guest-stats {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
    gap: 12px;
    margin-bottom: 20px;
}
.guest-stat-item {
    background: #fff;
    border-radius: 16px;
    padding: 16px 20px;
    text-align: center;
    border: 1px solid #e9ecef;
    box-shadow: 0 2px 8px rgba(0,0,0,0.04);
}
.guest-stat-item .number {
    font-size: 1.8rem;
    font-weight: 700;
    color: #1e3c72;
}
.guest-stat-item .label {
    font-size: 0.75rem;
    color: #6c757d;
}
.guest-stat-item.guest .number { color: #20c997; }

/* ---------------- Guest cards ---------------- */
.guest-card {
    background: #fff;
    border-radius: 16px;
    padding: 16px 20px;
    border: 1px solid #e9ecef;
    transition: all 0.3s;
    height: 100%;
}
.guest-card:hover {
    box-shadow: 0 4px 20px rgba(0,0,0,0.06);
    transform: translateY(-2px);
}
.guest-card .guest-id {
    font-family: monospace;
    font-size: 1rem;
    font-weight: 600;
    color: #1e3c72;
}
.guest-card .guest-time {
    font-size: 0.8rem;
    color: #6c757d;
}
.guest-photo-thumb {
    width: 64px;
    height: 64px;
    border-radius: 12px;
    object-fit: cover;
    border: 2px solid #e9ecef;
    background: #f8f9fa;
    flex-shrink: 0;
}
.guest-photo-thumb.sm {
    width: 40px;
    height: 40px;
    border-radius: 8px;
}
.guest-photo-thumb.placeholder {
    display: flex;
    align-items: center;
    justify-content: center;
    color: #adb5bd;
}

/* ---------------- Manual entry panel ---------------- */
.guest-in-panel {
    background: #f8f9fa;
    border-radius: 16px;
    padding: 22px;
    border: 1px solid #e9ecef;
    margin-bottom: 20px;
}
.guest-in-panel h5 {
    color: #1e3c72;
    font-weight: 700;
}
.guest-in-panel .form-label {
    font-weight: 600;
    font-size: 0.85rem;
    color: #2c3e50;
}
.guest-in-panel .form-label .opt-hint {
    font-weight: 500;
    color: #6c757d;
    font-size: 0.78rem;
}
.guest-in-panel .form-control,
.guest-in-panel .form-select {
    border-radius: 10px;
}

/* ---------------- Webcam ---------------- */
.webcam-preview {
    width: 100%;
    max-width: 320px;
    aspect-ratio: 4 / 3;
    background: #000;
    border-radius: 12px;
    object-fit: cover;
    border: 3px solid #dee2e6;
    display: none;
}
.webcam-placeholder {
    width: 100%;
    max-width: 320px;
    aspect-ratio: 4 / 3;
    background: #f0f2f5;
    border-radius: 12px;
    border: 3px dashed #dee2e6;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #adb5bd;
    flex-direction: column;
    gap: 8px;
    font-size: 0.85rem;
    text-align: center;
    padding: 10px;
}
.camera-status {
    font-size: 0.78rem;
    color: #6c757d;
    min-height: 18px;
}

/* ---------------- Rename button ---------------- */
.rename-guest-btn {
    width: 32px;
    height: 32px;
    padding: 0;
    display: inline-flex;
    align-items: center;
    justify-content: center;
}

/* ---------------- Responsive ---------------- */
@media (max-width: 768px) {
    .guest-stats { grid-template-columns: repeat(2, 1fr); }
    .guest-stat-item .number { font-size: 1.3rem; }
    .guest-in-panel { padding: 16px; }
}
</style>

<script>
// Institution name is exposed to JS as a CLEAN plain string (raw "&",
// not "&amp;") so any client-side references stay correct.
window.VMS_INSTITUTION_NAME = <?= json_encode($institutionName, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
</script>

<div class="container-fluid">

    <!-- ============================================================
         PAGE HEADER
         ============================================================ -->
    <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
        <h4 class="mb-0">
            <i class="fas fa-user-friends me-2 text-success"></i>Guest Management
        </h4>
        <div class="d-flex gap-2">
            <span class="badge bg-success rounded-pill px-3 py-2">
                <i class="fas fa-users me-1"></i> <?= number_format($activeGuests) ?> Active
            </span>
            <span class="badge bg-primary rounded-pill px-3 py-2">
                <i class="fas fa-calendar-day me-1"></i> <?= number_format($todayGuests) ?> Today
            </span>
        </div>
    </div>

    <!-- ============================================================
         FLASH MESSAGES
         ============================================================ -->
    <?php if ($message): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <i class="fas fa-check-circle me-2"></i> <?= htmlspecialchars($message) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <i class="fas fa-exclamation-circle me-2"></i> <?= htmlspecialchars($error) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- ============================================================
         STATS STRIP
         ============================================================ -->
    <div class="guest-stats">
        <div class="guest-stat-item">
            <div class="number"><?= number_format($activeGuests) ?></div>
            <div class="label">Active Guests Inside</div>
        </div>
        <div class="guest-stat-item">
            <div class="number"><?= number_format($todayGuests) ?></div>
            <div class="label">Today's Guests</div>
        </div>
        <div class="guest-stat-item">
            <div class="number"><?= number_format($totalGuests) ?></div>
            <div class="label">Total Guests All Time</div>
        </div>
    </div>

    <!-- ============================================================
         v7.7 — NEW GUEST ENTRY PANEL (name optional)
         ============================================================ -->
    <div class="guest-in-panel">
        <h5 class="mb-3">
            <i class="fas fa-user-plus me-2 text-success"></i>New Guest Entry
        </h5>

        <form method="POST" id="guestInForm" autocomplete="off">
            <div class="row g-3">

                <!-- Name + Purpose -->
                <div class="col-12 col-md-5">
                    <label class="form-label" for="guestNameInput">
                        Guest Name
                        <span class="opt-hint">(optional — leave blank to auto-name)</span>
                    </label>
                    <input type="text"
                           name="guest_name"
                           id="guestNameInput"
                           class="form-control form-control-lg"
                           placeholder="Enter guest's full name (optional)"
                           maxlength="120"
                           autocomplete="off">

                    <label class="form-label mt-3" for="guestPurposeSelect">Purpose of Visit</label>
                    <select name="guest_purpose" id="guestPurposeSelect" class="form-select">
                        <?php
                        $defaultPurpose = $settings['default_purpose'] ?? 'Other';
                        if (function_exists('renderPurposeOptions')) {
                            echo renderPurposeOptions($defaultPurpose);
                        } else {
                            $purposes = ['Reading/Study','Computer Uses','Book Issue/Return','Research','Meeting','Event','Other'];
                            foreach ($purposes as $p) {
                                $sel = ($defaultPurpose === $p) ? ' selected' : '';
                                echo '<option value="' . htmlspecialchars($p, ENT_QUOTES) . '"' . $sel . '>'
                                   . htmlspecialchars($p) . '</option>';
                            }
                        }
                        ?>
                    </select>
                </div>

                <!-- Photo -->
                <div class="col-12 col-md-4">
                    <label class="form-label">
                        Photo <span class="text-muted small">(optional — auto-captured)</span>
                    </label>

                    <video id="guestVideo"
                           class="webcam-preview"
                           autoplay playsinline muted></video>

                    <div id="guestVideoPlaceholder" class="webcam-placeholder">
                        <i class="fas fa-camera fa-2x"></i>
                        <span>Click "Take Photo" to activate camera</span>
                    </div>

                    <canvas id="guestCanvas" style="display:none;"></canvas>

                    <div class="d-flex gap-2 mt-2 flex-wrap">
                        <button type="button"
                                class="btn btn-sm btn-outline-primary"
                                id="btnStartCam">
                            <i class="fas fa-camera me-1"></i> Take Photo
                        </button>
                        <button type="button"
                                class="btn btn-sm btn-success"
                                id="btnCapture"
                                style="display:none;">
                            <i class="fas fa-circle me-1"></i> Capture
                        </button>
                        <button type="button"
                                class="btn btn-sm btn-outline-secondary"
                                id="btnStopCam"
                                style="display:none;">
                            <i class="fas fa-stop me-1"></i> Stop
                        </button>
                        <button type="button"
                                class="btn btn-sm btn-outline-danger"
                                id="btnClearPhoto"
                                style="display:none;">
                            <i class="fas fa-trash me-1"></i> Clear
                        </button>
                    </div>

                    <div class="camera-status mt-2" id="cameraStatus"></div>

                    <input type="hidden" name="guest_photo_data" id="guestPhotoData" value="">
                    <img id="guestPhotoPreview"
                         class="guest-photo-thumb mt-2"
                         style="display:none; width:96px; height:96px;"
                         alt="Captured photo">
                </div>

                <!-- Submit -->
                <div class="col-12 col-md-3 d-flex align-items-end">
                    <button type="submit"
                            name="guest_in_manual"
                            class="btn btn-success btn-lg w-100"
                            id="btnGuestIn">
                        <i class="fas fa-sign-in-alt me-2"></i> Guest In
                    </button>
                </div>

            </div>
        </form>
    </div>

    <!-- ============================================================
         QUICK ACTIONS
         ============================================================ -->
    <div class="card mb-4 shadow-sm">
        <div class="card-body">
            <div class="d-flex flex-wrap gap-2">
                <a href="<?= htmlspecialchars(KOHA_OPAC_URL) ?>/visitor/"
                   class="btn btn-primary"
                   target="_blank"
                   rel="noopener">
                    <i class="fas fa-door-open me-2"></i> Public Kiosk
                </a>
                <?php if ($activeGuests > 0): ?>
                    <form method="POST"
                          onsubmit="return confirm('Force exit ALL active guests? This cannot be undone.');"
                          class="d-inline">
                        <button type="submit" name="force_exit_all_guests" class="btn btn-danger">
                            <i class="fas fa-exclamation-triangle me-2"></i> Force Exit All Guests
                        </button>
                    </form>
                <?php endif; ?>
                <a href="reports.php?range=today&report_type=guests" class="btn btn-outline-primary">
                    <i class="fas fa-chart-bar me-2"></i> Guest Report
                </a>
            </div>
        </div>
    </div>

    <!-- ============================================================
         ACTIVE GUESTS
         ============================================================ -->
    <div class="card shadow-sm">
        <div class="card-header bg-white d-flex justify-content-between align-items-center flex-wrap gap-2">
            <h5 class="mb-0"><i class="fas fa-users me-2"></i>Active Guests</h5>
            <span class="badge bg-success rounded-pill px-3 py-2">
                <?= count($guests) ?> Inside
            </span>
        </div>
        <div class="card-body">
            <?php if (empty($guests)): ?>
                <div class="text-center py-4 text-muted">
                    <i class="fas fa-user-friends fa-3x mb-3 d-block" style="opacity:0.2;"></i>
                    <p class="mb-0">No active guests currently inside</p>
                </div>
            <?php else: ?>
                <div class="row g-3">
                    <?php foreach ($guests as $g):
                        $photoUrl = vms_guest_photo_url($g);
                    ?>
                        <div class="col-12 col-md-6 col-lg-4">
                            <div class="guest-card">
                                <div class="d-flex justify-content-between align-items-start gap-3">
                                    <div class="d-flex gap-3 align-items-start flex-grow-1 min-w-0">
                                        <?php if ($photoUrl): ?>
                                            <img src="<?= htmlspecialchars($photoUrl) ?>"
                                                 class="guest-photo-thumb"
                                                 alt="<?= htmlspecialchars($g['member_name']) ?>">
                                        <?php else: ?>
                                            <div class="guest-photo-thumb placeholder">
                                                <i class="fas fa-user"></i>
                                            </div>
                                        <?php endif; ?>
                                        <div class="min-w-0">
                                            <div class="fw-semibold text-truncate">
                                                <?= htmlspecialchars($g['member_name']) ?>
                                            </div>
                                            <div class="guest-id">
                                                <?= htmlspecialchars($g['admno']) ?>
                                            </div>
                                            <div class="guest-time">
                                                <i class="fas fa-clock me-1"></i>
                                                Entry: <?= htmlspecialchars($g['entry_time']) ?>
                                            </div>
                                            <div class="guest-time text-warning">
                                                <i class="fas fa-hourglass-half me-1"></i>
                                                <?= htmlspecialchars(timeAgo($g['entry_date'] . ' ' . $g['entry_time'])) ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="d-flex flex-column gap-2">
                                        <button type="button"
                                                class="btn btn-sm btn-outline-primary rename-guest-btn"
                                                data-guest-id="<?= (int)$g['id'] ?>"
                                                data-guest-name="<?= htmlspecialchars($g['member_name']) ?>"
                                                title="Rename this guest">
                                            <i class="fas fa-pen"></i>
                                        </button>
                                        <form method="POST" onsubmit="return confirm('Exit this guest?');">
                                            <input type="hidden" name="guest_id" value="<?= (int)$g['id'] ?>">
                                            <button type="submit" name="exit_guest" class="btn btn-sm btn-success">
                                                <i class="fas fa-sign-out-alt"></i>
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- ============================================================
         GUEST HISTORY
         ============================================================ -->
    <div class="card shadow-sm mt-4">
        <div class="card-header bg-white d-flex justify-content-between align-items-center flex-wrap gap-2">
            <h5 class="mb-0"><i class="fas fa-history me-2"></i>Guest History</h5>
            <span class="badge bg-secondary rounded-pill px-3 py-2">
                <?= count($guestHistory) ?> Records
            </span>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover mb-0" id="guestHistoryTable">
                    <thead class="table-light">
                        <tr>
                            <th style="width:60px;">Photo</th>
                            <th>ID</th>
                            <th>Guest Name</th>
                            <th>Entry Date</th>
                            <th>Entry Time</th>
                            <th>Exit Time</th>
                            <th>Purpose</th>
                            <th>Status</th>
                            <th style="width:60px;">Edit</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($guestHistory)): ?>
                            <tr>
                                <td colspan="9" class="text-center py-4 text-muted">
                                    No guest history found
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($guestHistory as $g):
                                $photoUrl = vms_guest_photo_url($g);
                            ?>
                                <tr>
                                    <td>
                                        <?php if ($photoUrl): ?>
                                            <img src="<?= htmlspecialchars($photoUrl) ?>"
                                                 class="guest-photo-thumb sm"
                                                 alt="">
                                        <?php else: ?>
                                            <span class="text-muted small">—</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><code><?= htmlspecialchars($g['admno']) ?></code></td>
                                    <td><?= htmlspecialchars($g['member_name']) ?></td>
                                    <td><?= htmlspecialchars($g['entry_date']) ?></td>
                                    <td><?= htmlspecialchars($g['entry_time']) ?></td>
                                    <td>
                                        <?php if (!empty($g['exit_time'])): ?>
                                            <?= htmlspecialchars($g['exit_time']) ?>
                                        <?php else: ?>
                                            <span class="badge bg-success">Inside</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?= htmlspecialchars($g['purpose'] ?? 'N/A') ?></td>
                                    <td>
                                        <span class="badge <?= ($g['status'] ?? '') === 'inside' ? 'bg-success' : 'bg-secondary' ?>">
                                            <?= htmlspecialchars(strtoupper($g['status'] ?? 'Unknown')) ?>
                                        </span>
                                    </td>
                                    <td class="text-center">
                                        <button type="button"
                                                class="btn btn-sm btn-outline-primary rename-guest-btn"
                                                data-guest-id="<?= (int)$g['id'] ?>"
                                                data-guest-name="<?= htmlspecialchars($g['member_name']) ?>"
                                                title="Rename this guest">
                                            <i class="fas fa-pen"></i>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div><!-- /.container-fluid -->

<!-- ============================================================
     v7.7 — RENAME GUEST MODAL
     ============================================================ -->
<div class="modal fade" id="renameGuestModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <form method="POST" class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="fas fa-pen me-2"></i>Rename Guest
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <input type="hidden" name="guest_id" id="renameGuestId" value="">

                <label class="form-label fw-semibold">Current name</label>
                <div class="mb-3">
                    <code id="renameGuestCurrent" class="text-muted">—</code>
                </div>

                <label class="form-label fw-semibold" for="renameGuestInput">
                    New name <span class="text-muted small">(leave blank to clear)</span>
                </label>
                <input type="text" name="new_name" id="renameGuestInput"
                       class="form-control form-control-lg"
                       maxlength="120" autocomplete="off"
                       placeholder="Enter new name or leave blank">

                <div class="small text-muted mt-2">
                    <i class="fas fa-info-circle me-1"></i>
                    Changes are applied immediately and logged in the activity trail.
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" name="rename_guest" class="btn btn-primary">
                    <i class="fas fa-save me-1"></i> Save Name
                </button>
            </div>
        </form>
    </div>
</div>

<!-- ============================================================
     SCRIPTS
     ============================================================ -->
<script src="assets/js/book_capture.js"></script>
<script>
/* ============================================================
   v7.7 — Guest Entry: webcam capture (name optional)
   ============================================================ */
(function () {
    'use strict';

    var videoEl      = document.getElementById('guestVideo');
    var placeholder  = document.getElementById('guestVideoPlaceholder');
    var canvas       = document.getElementById('guestCanvas');
    var photoData    = document.getElementById('guestPhotoData');
    var photoPrev    = document.getElementById('guestPhotoPreview');
    var btnStart     = document.getElementById('btnStartCam');
    var btnCapture   = document.getElementById('btnCapture');
    var btnStop      = document.getElementById('btnStopCam');
    var btnClear     = document.getElementById('btnClearPhoto');
    var statusEl     = document.getElementById('cameraStatus');

    function setStatus(msg) {
        if (statusEl) statusEl.textContent = msg || '';
    }

    function showCaptured(dataUrl) {
        if (!dataUrl) return;
        photoData.value = dataUrl;
        photoPrev.src = dataUrl;
        photoPrev.style.display = 'block';
        if (btnClear) btnClear.style.display = '';
    }

    function clearCaptured() {
        photoData.value = '';
        photoPrev.src = '';
        photoPrev.style.display = 'none';
        if (btnClear) btnClear.style.display = 'none';
    }

    function resetCameraUI() {
        if (videoEl) videoEl.style.display = 'none';
        if (placeholder) placeholder.style.display = 'flex';
        if (btnStart) btnStart.style.display   = '';
        if (btnCapture) btnCapture.style.display = 'none';
        if (btnStop) btnStop.style.display    = 'none';
    }

    if (btnStart) {
        btnStart.addEventListener('click', function () {
            var cap = window.VMSBookCapture;
            if (!cap || !cap.start) {
                setStatus('Camera module not loaded. Check assets/js/book_capture.js');
                return;
            }
            setStatus('Starting camera…');
            cap.start('guestVideo').then(function (ok) {
                if (!ok) {
                    setStatus('Camera unavailable — you can still enter the guest.');
                    resetCameraUI();
                    return;
                }
                videoEl.style.display = 'block';
                placeholder.style.display = 'none';
                btnStart.style.display   = 'none';
                btnCapture.style.display = '';
                btnStop.style.display    = '';
                setStatus('Camera ready — click Capture.');
            });
        });
    }

    if (btnCapture) {
        btnCapture.addEventListener('click', function () {
            var cap = window.VMSBookCapture;
            if (!cap || !cap.capture) return;
            setStatus('Capturing…');
            cap.capture('guestVideo').then(function (dataUrl) {
                if (!dataUrl) {
                    setStatus('Capture failed — please try again.');
                    return;
                }
                showCaptured(dataUrl);
                setStatus('Photo captured.');
                if (cap.stop) cap.stop();
                resetCameraUI();
            });
        });
    }

    if (btnStop) {
        btnStop.addEventListener('click', function () {
            if (window.VMSBookCapture && window.VMSBookCapture.stop) {
                window.VMSBookCapture.stop();
            }
            resetCameraUI();
            setStatus('');
        });
    }

    if (btnClear) {
        btnClear.addEventListener('click', function () {
            clearCaptured();
            setStatus('Photo removed.');
        });
    }
})();

/* ============================================================
   v7.7 — Rename guest modal
   ============================================================ */
function openRenameModal(guestId, currentName) {
    var idEl      = document.getElementById('renameGuestId');
    var curEl     = document.getElementById('renameGuestCurrent');
    var input     = document.getElementById('renameGuestInput');
    var modalEl   = document.getElementById('renameGuestModal');
    if (!idEl || !input || !modalEl) return;

    idEl.value = guestId;
    if (curEl) curEl.textContent = currentName || '—';
    input.value = (currentName && currentName !== 'Guest (unnamed)') ? currentName : '';
    new bootstrap.Modal(modalEl).show();

    modalEl.addEventListener('shown.bs.modal', function () {
        input.focus();
        input.select();
    }, { once: true });
}

document.addEventListener('click', function (e) {
    var btn = e.target.closest('.rename-guest-btn');
    if (!btn) return;
    e.preventDefault();
    var id   = btn.dataset.guestId;
    var name = btn.dataset.guestName || '';
    if (id) openRenameModal(id, name);
});

/* ============================================================
   History table: search + CSV export
   ============================================================ */
document.addEventListener('DOMContentLoaded', function () {
    var table = document.getElementById('guestHistoryTable');
    if (!table) return;
    var cardBody = table.closest('.card-body');
    if (cardBody) {
        var searchDiv = document.createElement('div');
        searchDiv.className = 'p-3 border-bottom';
        searchDiv.innerHTML =
            '<div class="d-flex gap-2 flex-wrap">' +
                '<input type="text" id="tableSearch" class="form-control form-control-sm" ' +
                       'placeholder="Search guest history..." style="max-width:300px;">' +
                '<button class="btn btn-sm btn-outline-secondary" onclick="clearTableSearch()">' +
                    '<i class="fas fa-times"></i>' +
                '</button>' +
                '<button class="btn btn-sm btn-outline-success" ' +
                        'onclick="exportTableToCSV(\'guestHistoryTable\', \'guest_history_<?= date('Y-m-d') ?>\')">' +
                    '<i class="fas fa-file-csv"></i> Export CSV' +
                '</button>' +
            '</div>';
        cardBody.insertBefore(searchDiv, table);

        var searchInput = document.getElementById('tableSearch');
        if (searchInput) {
            searchInput.addEventListener('input', function () {
                var filter = this.value.toLowerCase();
                var tbody = table.getElementsByTagName('tbody')[0];
                if (!tbody) return;
                var rows = tbody.getElementsByTagName('tr');
                for (var i = 0; i < rows.length; i++) {
                    var text = rows[i].textContent.toLowerCase();
                    rows[i].style.display = text.indexOf(filter) !== -1 ? '' : 'none';
                }
            });
        }
    }
});

function clearTableSearch() {
    var input = document.getElementById('tableSearch');
    if (input) {
        input.value = '';
        input.dispatchEvent(new Event('input'));
        input.focus();
    }
}

function exportTableToCSV(tableId, filename) {
    var table = document.getElementById(tableId);
    if (!table) return;
    var rows = table.querySelectorAll('tr');
    var csv = [];
    rows.forEach(function (row) {
        var cells = row.querySelectorAll('th, td');
        var rowData = [];
        cells.forEach(function (cell) {
            var text = cell.textContent.trim().replace(/\s+/g, ' ');
            if (text.indexOf(',') !== -1 || text.indexOf('"') !== -1) {
                text = '"' + text.replace(/"/g, '""') + '"';
            }
            rowData.push(text);
        });
        csv.push(rowData.join(','));
    });
    var csvContent = csv.join('\n');
    var blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    var link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = (filename || 'export') + '.csv';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}
</script>

<?php
// ============================================================
// FOOTER — with entity-collapse post-processing  [CHANGED v7.8]
// ============================================================
// The shared footer.php may re-encode the institution name, producing
// literal "&amp;" in the HTML. We buffer it and collapse any over-encoded
// entities so the browser shows the name exactly as typed.

$__guestsFooterOut = '';

ob_start();
try {
    include __DIR__ . '/footer.php';
} catch (Throwable $e) {
    error_log('[guests.php] footer include: ' . $e->getMessage());
}
$__guestsFooterOut = ob_get_clean();

if ($__guestsFooterOut !== '') {
    // Collapse &amp;amp;amp; → &amp;amp; → &amp; (up to 5 passes)
    $prev = null;
    $out  = $__guestsFooterOut;
    $i    = 0;
    while ($prev !== $out && $i < 5) {
        $prev = $out;
        $out  = str_replace('&amp;amp;', '&amp;', $out);
        $i++;
    }
    // Final collapse: "word &amp; word" → "word & word" (only between
    // alphanumerics, so we never touch &nbsp; &copy; &quot; etc.)
    $out = preg_replace_callback(
        '/(?<=[A-Za-z0-9])\s*&amp;\s*(?=[A-Za-z0-9])/',
        function () { return ' & '; },
        $out
    );
    echo $out;
}
?>
