<?php
/**
 * Footer Configuration API
 * Version: 1.1
 *
 * Purpose:
 *   Returns the current footer configuration (as configured in admin Settings)
 *   as JSON so that the OPAC can render an identical footer.
 *
 * Endpoint: GET /cgi-bin/koha/visitor/footer_api.php
 * Returns:  application/json
 *
 * CHANGELOG v1.1:
 *   - Decode HTML entities before sending JSON, so "&amp;" becomes "&"
 *     and OPAC rendering matches admin footer exactly.
 *   - Added "logoUrl" fallback alongside "logoBase64".
 *   - Defensive JSON encoding with JSON_INVALID_UTF8_SUBSTITUTE.
 */

declare(strict_types=1);
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', sys_get_temp_dir() . '/footer_api_errors.log');

// ============================================================
// CORS — allow OPAC to fetch from the intranet host
// ============================================================
header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');

$allowedOrigins = [];
$configPaths = [
    __DIR__ . '/includes/config.php',
    dirname(__DIR__) . '/includes/config.php',
    '/usr/share/koha/intranet/cgi-bin/koha/visitor/includes/config.php',
];
$includePath = null;
foreach ($configPaths as $p) {
    if (file_exists($p)) { $includePath = dirname($p); break; }
}

if ($includePath) {
    require_once $includePath . '/config.php';
    if (defined('KOHA_OPAC_URL')) {
        $allowedOrigins[] = rtrim(KOHA_OPAC_URL, '/');
    }
    if (defined('KOHA_INTRANET_URL')) {
        $allowedOrigins[] = rtrim(KOHA_INTRANET_URL, '/');
    }
}

$origin = $_SERVER['HTTP_ORIGIN'] ?? '';
if ($origin && in_array(rtrim($origin, '/'), $allowedOrigins, true)) {
    header('Access-Control-Allow-Origin: ' . $origin);
    header('Access-Control-Allow-Methods: GET, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type');
    header('Vary: Origin');
}

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'OPTIONS') {
    http_response_code(204);
    exit;
}

// ============================================================
// LOAD SETTINGS
// ============================================================
if (!$includePath) {
    http_response_code(500);
    echo json_encode(['error' => 'Config not found']);
    exit;
}

require_once $includePath . '/db.php';
require_once $includePath . '/functions.php';
require_once $includePath . '/constants.php';

$settings = [];
try {
    if (function_exists('getSettings')) {
        $settings = getSettings();
    }
} catch (Throwable $e) {
    error_log("footer_api.php: " . $e->getMessage());
}

if (empty($settings)) {
    http_response_code(500);
    echo json_encode(['error' => 'Settings unavailable']);
    exit;
}

// ============================================================
// HELPERS
// ============================================================

/**
 * Decode any HTML entities that may have been stored in the DB
 * (e.g. "&amp;" or "&#39;") back to their raw characters, so the
 * OPAC can render them 1:1 the same way the admin footer does.
 */
function vms_decode(?string $value): string
{
    if ($value === null) return '';
    return html_entity_decode($value, ENT_QUOTES | ENT_HTML5, 'UTF-8');
}

/**
 * Try footer_logo first, then institution_logo.
 * Returns base64 data URI or null.
 */
function resolveLogoBase64(array $settings, string $baseDir): ?string
{
    $uploadDir = $baseDir . '/uploads/logos/';
    foreach (['footer_logo', 'institution_logo'] as $key) {
        $path = $settings[$key] ?? '';
        if (!empty($path) && file_exists($uploadDir . $path)) {
            $data = @file_get_contents($uploadDir . $path);
            if ($data !== false) {
                $finfo = finfo_open(FILEINFO_MIME_TYPE);
                $mime  = finfo_buffer($finfo, $data);
                finfo_close($finfo);
                return 'data:' . $mime . ';base64,' . base64_encode($data);
            }
        }
    }
    return null;
}

/**
 * Public relative URL to the logo file (used as fallback for OPAC).
 */
function resolveLogoUrl(array $settings, string $baseDir): ?string
{
    $uploadDir = $baseDir . '/uploads/logos/';
    foreach (['footer_logo', 'institution_logo'] as $key) {
        $path = $settings[$key] ?? '';
        if (!empty($path) && file_exists($uploadDir . $path)) {
            return 'uploads/logos/' . $path;
        }
    }
    return null;
}

// ============================================================
// BUILD RESPONSE
// ============================================================

$logoBase64 = null;
$logoUrl    = null;
if (($settings['show_footer_logo'] ?? 1)) {
    $logoBase64 = resolveLogoBase64($settings, $includePath . '/..');
    $logoUrl    = resolveLogoUrl($settings, $includePath . '/..');
}

$response = [
    'enabled'         => true,
    'institutionName' => vms_decode($settings['institution_name'] ?? 'Library'),
    'footerText'      => vms_decode($settings['footer_text'] ?? ''),
    'footerBg'        => vms_decode($settings['footer_bg'] ?? '#1e3c72'),
    'footerTextColor' => vms_decode($settings['footer_text_color'] ?? '#ffffff'),
    'footerAccent'    => vms_decode($settings['accent_color'] ?? '#ffd700'),
    'logoBase64'      => $logoBase64,
    'logoUrl'         => $logoUrl,
    'showLogo'        => (bool)($settings['show_footer_logo'] ?? 1),
    'designer' => [
        'name' => 'Sameermon M',
        'url'  => 'https://www.linkedin.com/in/sameermon-m-559692186',
    ],
    'version'         => defined('APP_VERSION') ? APP_VERSION : '7.5.1',
    'generatedAt'     => date('c'),
];

$json = json_encode(
    $response,
    JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE
);

if ($json === false) {
    http_response_code(500);
    echo json_encode(['error' => 'JSON encode failed: ' . json_last_error_msg()]);
    exit;
}

echo $json;
