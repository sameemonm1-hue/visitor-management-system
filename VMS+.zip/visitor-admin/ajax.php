<?php
/**
 * Visitor Management System - AJAX Handler
 * Version: 8.3 FINAL – Guest name + photo capture, hardened photo pipeline
 *
 * CHANGELOG v8.3 (from v8.2):
 *   ── HARDENED: guest_entry now probes the guest_photo column BEFORE
 *      attempting an INSERT that names it. If the column is missing,
 *      the insert falls back to a column-less version so the guest is
 *      still recorded (only the photo filename is dropped, with a
 *      warning surfaced to the client).
 *   ── IMPROVED: vms_save_guest_photo() returns a structured result
 *      with error details (dir-not-writable, size-too-large, bad-mime,
 *      write-failed) so the failure reason is visible in the JSON.
 *   ── NEW: guest_entry response includes `photo_saved` (bool) and
 *      `photo_warning` (string) — empty on full success.
 *   ── NEW: guest_photo_probe action — diagnostic endpoint that checks
 *      schema + directory + live test-save. Safe to call in production.
 *   ── NEW: guest_exit action — exit a specific guest by ID.
 *   ── IMPROVED: guest_exit_last now logs the guest name to
 *      activity_log so the audit trail shows who exited.
 *   ── PRESERVED: All v8.2 behavior — HTML-entity helpers, purpose
 *      whitelisting, alert system, monitoring, bulk ops, CSRF checks.
 *
 * CHANGELOG v8.2 (from v8.1):
 *   ── guest_entry now accepts a required `guest_name` and an optional
 *      `photo_data` (base64 data-URL).
 *   ── guest_exit_last now returns the guest's real name and photo flag.
 *   ── NEW: vms_save_guest_photo(), vms_ensure_guest_photo_column().
 *   ── NEW: vms_normalize_text() / vms_h() / vms_plain() helpers.
 *   ── IMPROVED: book-log update fields run through vms_prepare_text().
 */

error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

// ============================================================
// SESSION & INCLUDES
// ============================================================
if (session_status() === PHP_SESSION_NONE) {
    session_name('CGISESSID');
    if (isset($_COOKIE['CGISESSID'])) {
        session_id($_COOKIE['CGISESSID']);
    }
    session_start();
}

// Auto-detect includes path
$possiblePaths = [
    __DIR__ . '/includes',
    dirname(__DIR__) . '/includes',
    __DIR__ . '/../includes',
    '/usr/share/koha/intranet/cgi-bin/koha/visitor/includes',
    '/usr/share/koha/intranet/cgi-bin/visitor/includes',
];

$includePath = null;
foreach ($possiblePaths as $path) {
    if (file_exists($path . '/config.php')) {
        $includePath = $path;
        break;
    }
}

if (!$includePath) {
    header('Content-Type: application/json');
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Configuration not found']);
    exit;
}

require_once $includePath . '/config.php';
require_once $includePath . '/functions.php';
require_once $includePath . '/koha.php';
require_once $includePath . '/auth.php';

// Load alerts.php if available
$alertsFile = $includePath . '/alerts.php';
if (file_exists($alertsFile)) {
    require_once $alertsFile;
}

// ============================================================
// HTML ENTITY HELPERS (local fallbacks)
// ============================================================
if (!function_exists('vms_normalize_text')) {
    function vms_normalize_text($value) {
        if ($value === null) return '';
        return html_entity_decode((string)$value, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    }
}
if (!function_exists('vms_h')) {
    function vms_h($value) {
        return htmlspecialchars(
            vms_normalize_text($value),
            ENT_QUOTES | ENT_HTML5,
            'UTF-8'
        );
    }
}
if (!function_exists('vms_plain')) {
    function vms_plain($value) {
        return vms_normalize_text($value);
    }
}
if (!function_exists('vms_prepare_text')) {
    function vms_prepare_text($value) {
        $decoded = html_entity_decode((string)$value, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        if (function_exists('sanitizeInput')) {
            return sanitizeInput($decoded);
        }
        return htmlspecialchars($decoded, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    }
}

// ============================================================
// HELPER FUNCTIONS
// ============================================================
if (!function_exists('sendJson')) {
    function sendJson($data) {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }
}

if (!function_exists('getJsonBody')) {
    function getJsonBody() {
        static $body = null;
        if ($body === null) {
            $raw = file_get_contents('php://input');
            $body = json_decode($raw, true) ?: [];
        }
        return $body;
    }
}

if (!function_exists('getPatronImageBase64')) {
    function getPatronImageBase64($borrowernumber) {
        $koha = getKoha();
        if (!$koha || empty($borrowernumber)) return null;
        try {
            $stmt = $koha->prepare("SELECT imagefile FROM patronimage WHERE borrowernumber = ? LIMIT 1");
            $stmt->execute([$borrowernumber]);
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($row && !empty($row['imagefile'])) {
                return base64_encode($row['imagefile']);
            }
        } catch (Exception $e) {
            error_log("getPatronImageBase64: " . $e->getMessage());
        }
        return null;
    }
}

// ============================================================
// v8.3 — GUEST PHOTO SAVER + MIGRATION
// ============================================================

if (!function_exists('vms_guest_photo_dir')) {
    /**
     * Resolve + ensure the guest photo directory.
     * Returns [path, writable, error].
     */
    function vms_guest_photo_dir(): array
    {
        $baseDir = defined('UPLOAD_PATH') ? UPLOAD_PATH : (__DIR__ . '/../uploads');
        $dir     = rtrim($baseDir, '/') . '/guest_photos/';

        if (!is_dir($dir)) {
            @mkdir($dir, 0777, true);
            @chmod($dir, 0777);
        }
        if (!is_dir($dir)) {
            return ['path' => $dir, 'writable' => false, 'error' => 'directory could not be created'];
        }
        if (!is_writable($dir)) {
            return ['path' => $dir, 'writable' => false, 'error' => 'directory is not writable'];
        }
        return ['path' => $dir, 'writable' => true, 'error' => ''];
    }
}

if (!function_exists('vms_save_guest_photo')) {
    /**
     * Save a base64 data-URL photo to /uploads/guest_photos/.
     *
     * Returns a structured result:
     *   ['ok' => bool, 'filename' => string, 'error' => string]
     *
     * Preserves the v8.2 signature contract (accepts ?string), but
     * callers should switch to reading ['ok'] and ['filename'].
     */
    function vms_save_guest_photo(?string $dataUrl): array
    {
        if (empty($dataUrl) || !is_string($dataUrl)) {
            return ['ok' => false, 'filename' => '', 'error' => 'no photo data'];
        }

        if (!preg_match('#^data:image/(jpeg|jpg|png|webp);base64,#i', $dataUrl, $m)) {
            return ['ok' => false, 'filename' => '', 'error' => 'invalid image prefix (expected data:image/jpeg;base64,…)'];
        }
        $ext = strtolower($m[1]);
        if ($ext === 'jpeg') $ext = 'jpg';

        $raw = base64_decode(substr($dataUrl, strlen($m[0])), true);
        if ($raw === false) {
            return ['ok' => false, 'filename' => '', 'error' => 'base64 decode failed'];
        }
        if (strlen($raw) < 200) {
            return ['ok' => false, 'filename' => '', 'error' => 'image too small (< 200 bytes)'];
        }
        if (strlen($raw) > 3 * 1024 * 1024) {
            return ['ok' => false, 'filename' => '', 'error' => 'image exceeds 3 MB limit'];
        }

        $info = vms_guest_photo_dir();
        if (!$info['writable']) {
            error_log('[ajax] guest photo dir not writable: ' . $info['path'] . ' (' . $info['error'] . ')');
            return ['ok' => false, 'filename' => '', 'error' => 'photo directory not writable: ' . $info['path']];
        }

        $filename = 'guest_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
        $target   = $info['path'] . $filename;

        if (@file_put_contents($target, $raw) === false) {
            error_log('[ajax] failed to write guest photo: ' . $target);
            return ['ok' => false, 'filename' => '', 'error' => 'failed to write file to disk'];
        }
        @chmod($target, 0644);

        return ['ok' => true, 'filename' => $filename, 'error' => ''];
    }
}

if (!function_exists('vms_guest_photo_column_exists')) {
    /**
     * Cached per-request check: does entry_exit_logs have a guest_photo column?
     */
    function vms_guest_photo_column_exists(PDO $db): bool
    {
        static $exists = null;
        if ($exists !== null) return $exists;
        try {
            $cols = $db->query("SHOW COLUMNS FROM entry_exit_logs")->fetchAll(PDO::FETCH_COLUMN);
            $exists = in_array('guest_photo', $cols, true);
        } catch (PDOException $e) {
            error_log('[ajax] guest_photo probe: ' . $e->getMessage());
            $exists = false;
        }
        return $exists;
    }
}

if (!function_exists('vms_ensure_guest_photo_column')) {
    function vms_ensure_guest_photo_column(PDO $db): bool
    {
        if (vms_guest_photo_column_exists($db)) return true;
        try {
            $db->exec("ALTER TABLE entry_exit_logs
                       ADD COLUMN guest_photo VARCHAR(255) NULL
                       AFTER member_category");
            // The static cache in vms_guest_photo_column_exists will still
            // return false for the rest of this request (it's per-process).
            // We return true here so callers know the ALTER succeeded.
            return true;
        } catch (PDOException $e) {
            error_log('[ajax] guest_photo migration failed: ' . $e->getMessage());
            return false;
        }
    }
}

// ============================================================
// REQUEST ROUTING
// ============================================================
$action   = $_GET['action'] ?? $_POST['action'] ?? '';
$jsonBody = getJsonBody();

if (empty($action) && isset($_GET['ajax'])) {
    $action = $_GET['ajax'];
}

if (empty($action)) {
    sendJson(['success' => false, 'error' => 'No action specified']);
}

// ============================================================
// HANDLE ACTIONS
// ============================================================
try {
    switch ($action) {

        // ====================================================
        // CHECK BOOK
        // ====================================================
        case 'check_book':
            $barcode = trim($_GET['barcode'] ?? ($jsonBody['barcode'] ?? ''));
            $book = getKohaBook($barcode);

            if (!$book) {
                sendJson(['is_book' => false, 'message' => 'Not a book barcode']);
            }

            $isAuthorized = !empty($book['borrowernumber']);
            $member = null;

            if ($isAuthorized && !empty($book['member_cardnumber'])) {
                $member = getKohaMember($book['member_cardnumber']);
                if ($member && empty($member['photo_base64']) && !empty($member['borrowernumber'])) {
                    $imageData = getPatronImageBase64($member['borrowernumber']);
                    if ($imageData) {
                        $member['photo_base64'] = 'data:image/jpeg;base64,' . $imageData;
                    }
                }
            }

            sendJson([
                'is_book'       => true,
                'book'          => $book,
                'is_authorized' => $isAuthorized,
                'member'        => $member,
            ]);
            break;

        // ====================================================
        // GET MEMBER
        // ====================================================
        case 'get_member':
            $admno = trim($_GET['admno'] ?? ($jsonBody['admno'] ?? ''));

            if (strlen($admno) < 2) {
                sendJson(['error' => 'Please enter a valid ID']);
            }

            $member = getKohaMember($admno);

            if (!$member) {
                sendJson(['error' => 'Member not found: ' . vms_h($admno)]);
            }

            // Enrich with photo
            if (empty($member['photo_base64']) && !empty($member['borrowernumber'])) {
                $imageData = getPatronImageBase64($member['borrowernumber']);
                if ($imageData) {
                    $member['photo_base64'] = 'data:image/jpeg;base64,' . $imageData;
                }
            }

            // Check if inside
            $db = getDB();
            $check = $db->prepare("SELECT id FROM entry_exit_logs WHERE admno = ? AND status = 'inside'");
            $check->execute([$member['cardnumber']]);
            $member['is_inside'] = (bool)$check->fetch();

            sendJson([
                'member'    => $member,
                'is_inside' => $member['is_inside']
            ]);
            break;

        // ====================================================
        // TOGGLE ENTRY/EXIT
        // ====================================================
        case 'toggle':
            $admno   = trim($_POST['admno']   ?? ($jsonBody['admno']   ?? ''));
            $purpose = vms_valid_purpose(trim($_POST['purpose'] ?? ($jsonBody['purpose'] ?? 'Reading/Study')));

            if (strlen($admno) < 2) {
                sendJson(['error' => 'Please enter a valid ID']);
            }

            $member = getKohaMember($admno);
            if (!$member) {
                sendJson(['error' => 'Member not found']);
            }

            $db = getDB();
            $check = $db->prepare("SELECT id FROM entry_exit_logs WHERE admno = ? AND status = 'inside'");
            $check->execute([$member['cardnumber']]);
            $existing = $check->fetch();

            if ($existing) {
                // EXIT
                $update = $db->prepare("UPDATE entry_exit_logs SET exit_time = NOW(), status = 'exited' WHERE id = ?");
                $update->execute([$existing['id']]);

                logActivity($_SESSION['koha_user_id'] ?? 0, 'MEMBER_EXIT', "Exit: {$member['cardnumber']}");
                clearCache('stats');

                sendJson([
                    'success' => true,
                    'action'  => 'exit',
                    'message' => 'Exit recorded successfully'
                ]);
            } else {
                // ENTRY
                $insert = $db->prepare("
                    INSERT INTO entry_exit_logs
                    (admno, member_name, member_category, entry_date, entry_time, purpose, status, entry_type)
                    VALUES (?, ?, ?, CURDATE(), CURTIME(), ?, 'inside', 'member')
                ");
                $insert->execute([
                    $member['cardnumber'],
                    $member['full_name'],
                    $member['category_description'] ?? $member['categorycode'] ?? 'Member',
                    $purpose
                ]);

                logActivity($_SESSION['koha_user_id'] ?? 0, 'MEMBER_ENTRY', "Entry: {$member['cardnumber']}");
                clearCache('stats');

                sendJson([
                    'success' => true,
                    'action'  => 'entry',
                    'message' => 'Entry recorded successfully'
                ]);
            }
            break;

        // ====================================================
        // STATS
        // ====================================================
        case 'stats':
            $db = getDB();

            $stats = [
                'insideCount'    => 0,
                'todayVisitors'  => 0,
                'maleCount'      => 0,
                'femaleCount'    => 0,
                'otherCount'     => 0,
                'categoryStats'  => []
            ];

            try {
                $stats['insideCount'] = (int)$db->query(
                    "SELECT COUNT(*) FROM entry_exit_logs WHERE status = 'inside'"
                )->fetchColumn();

                $stats['todayVisitors'] = (int)$db->query(
                    "SELECT COUNT(*) FROM entry_exit_logs WHERE entry_date = CURDATE()"
                )->fetchColumn();

                $gender = $db->query("
                    SELECT
                        SUM(CASE WHEN member_category LIKE '%Male%' AND member_category NOT LIKE '%Female%' THEN 1 ELSE 0 END) as male,
                        SUM(CASE WHEN member_category LIKE '%Female%' THEN 1 ELSE 0 END) as female,
                        SUM(CASE WHEN member_category NOT LIKE '%Male%' AND member_category NOT LIKE '%Female%' THEN 1 ELSE 0 END) as other
                    FROM entry_exit_logs WHERE status = 'inside'
                ")->fetch();

                $stats['maleCount']   = (int)($gender['male']   ?? 0);
                $stats['femaleCount'] = (int)($gender['female'] ?? 0);
                $stats['otherCount']  = (int)($gender['other']  ?? 0);

                $catStats = $db->query("
                    SELECT member_category, COUNT(*) as count
                    FROM entry_exit_logs
                    WHERE status = 'inside'
                    GROUP BY member_category
                ")->fetchAll(PDO::FETCH_KEY_PAIR);

                $stats['categoryStats'] = $catStats ?: [];
            } catch (PDOException $e) {
                error_log("Stats error: " . $e->getMessage());
            }

            sendJson($stats);
            break;

        // ====================================================
        // GET PURPOSE STATS
        // ====================================================
        case 'get_purpose_stats':
            $db = getDB();
            try {
                $purposes = $db->query("
                    SELECT purpose, COUNT(*) as count
                    FROM entry_exit_logs
                    WHERE entry_date = CURDATE()
                    GROUP BY purpose
                    ORDER BY count DESC
                ")->fetchAll();

                sendJson(['success' => true, 'purposes' => $purposes]);
            } catch (PDOException $e) {
                sendJson(['success' => false, 'purposes' => []]);
            }
            break;

        // ====================================================
        // v8.3 — GUEST PHOTO PROBE (diagnostic)
        // ====================================================
        case 'guest_photo_probe':
            $db = getDB();
            $report = [
                'column_exists'     => vms_guest_photo_column_exists($db),
                'column_name'       => 'entry_exit_logs.guest_photo',
                'dir_info'          => vms_guest_photo_dir(),
                'upload_path_defined' => defined('UPLOAD_PATH'),
                'upload_path'       => defined('UPLOAD_PATH') ? UPLOAD_PATH : '(not defined)',
                'php_sapi'          => PHP_SAPI,
                'writable_cwd'      => is_writable(__DIR__) ? 'yes' : 'no',
                'test_save'         => null,
            ];

            // Live test: build a 1×1 transparent PNG data-URL, save, then delete.
            $pngBytes = base64_decode(
                'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg=='
            );
            if ($pngBytes !== false) {
                $testDataUrl = 'data:image/png;base64,' . base64_encode($pngBytes);
                $saveResult  = vms_save_guest_photo($testDataUrl);
                $report['test_save'] = $saveResult;

                // Clean up
                if (!empty($saveResult['ok']) && !empty($saveResult['filename'])) {
                    $dir = vms_guest_photo_dir()['path'];
                    @unlink($dir . $saveResult['filename']);
                    $report['test_save']['cleaned_up'] = true;
                }
            }

            sendJson(['success' => true, 'report' => $report]);
            break;

        case 'guest_entry':
    $db       = getDB();
    $settings = getSettings();

    if (!($settings['guest_enabled'] ?? 1)) {
        sendJson(['error' => 'Guest mode disabled']);
    }

    // v8.4 — name is OPTIONAL
    $guestName = trim(
        $_POST['guest_name']
        ?? $jsonBody['guest_name']
        ?? ''
    );
    $photoData = trim(
        $_POST['photo_data']
        ?? $jsonBody['photo_data']
        ?? ''
    );
    $guestPurpose = vms_valid_purpose(
        trim(
            $_POST['purpose']
            ?? $jsonBody['purpose']
            ?? ($settings['default_purpose'] ?? 'Reading/Study')
        )
    );

    // Bound the name length (only if user provided one)
    if ($guestName !== '') {
        if (function_exists('mb_substr')) {
            $guestName = mb_substr($guestName, 0, 120, 'UTF-8');
        } else {
            $guestName = substr($guestName, 0, 120);
        }
    }

    // ---- 1. Ensure the column exists ----
    $hasPhotoCol = vms_ensure_guest_photo_column($db);
    if (!$hasPhotoCol) {
        $hasPhotoCol = vms_guest_photo_column_exists($db);
    }

    // ---- 2. Save the photo (only if column available) ----
    $photoFilename = '';
    $photoWarning  = '';
    $photoSaved    = false;

    if ($photoData !== '') {
        if (!$hasPhotoCol) {
            $photoWarning = 'guest_photo column missing — photo not saved. Run schema.sql to enable photo storage.';
            error_log('[ajax] guest entry: photo captured but guest_photo column is missing');
        } else {
            $saveResult = vms_save_guest_photo($photoData);
            if (!empty($saveResult['ok'])) {
                $photoFilename = $saveResult['filename'];
                $photoSaved    = true;
            } else {
                $photoWarning = 'Photo save failed: ' . ($saveResult['error'] ?? 'unknown error');
                error_log('[ajax] guest entry: photo save failed — ' . ($saveResult['error'] ?? 'unknown'));
            }
        }
    }

    // ---- 3. Generate the guest ID and (if needed) auto-name ----
    $guestNum = (int)($db->query("SELECT guest_daily_counter FROM settings LIMIT 1")->fetchColumn() ?: 1);

    // v8.4 — auto-generate a placeholder name when user skipped
    $autoNamed = false;
    if ($guestName === '') {
        $guestName = 'Guest ' . $guestNum;
        $autoNamed = true;
    }

    $prefix   = $settings['guest_prefix']  ?? 'GUEST-';
    $padding  = (int)($settings['guest_padding'] ?? 4);
    $admno    = $prefix . str_pad($guestNum, $padding, '0', STR_PAD_LEFT);

    // ---- 4. Insert the guest row ----
    try {
        if ($hasPhotoCol) {
            $insert = $db->prepare("
                INSERT INTO entry_exit_logs
                    (admno, member_name, member_category, guest_photo,
                     entry_date, entry_time, purpose, status, entry_type)
                VALUES (?, ?, 'Guest', ?, CURDATE(), CURTIME(), ?, 'inside', 'guest')
            ");
            $insert->execute([
                $admno,
                $guestName,
                $photoFilename !== '' ? $photoFilename : null,
                $guestPurpose
            ]);
        } else {
            $insert = $db->prepare("
                INSERT INTO entry_exit_logs
                    (admno, member_name, member_category,
                     entry_date, entry_time, purpose, status, entry_type)
                VALUES (?, ?, 'Guest', CURDATE(), CURTIME(), ?, 'inside', 'guest')
            ");
            $insert->execute([$admno, $guestName, $guestPurpose]);
        }

        $db->query("UPDATE settings SET guest_daily_counter = guest_daily_counter + 1");
        clearCache('stats');
        clearCache('settings_all');

        logActivity(
            $_SESSION['koha_user_id'] ?? 0,
            'GUEST_ENTRY',
            "Guest '{$guestName}' entered ({$admno})" . ($photoSaved ? ' [photo]' : '')
        );

        sendJson([
            'success'       => true,
            'guest_number'  => $guestNum,
            'guest_id'      => $admno,
            'guest_name'    => $guestName,
            'auto_named'    => $autoNamed,       // v8.4 flag
            'had_photo'     => $photoSaved,
            'photo_saved'   => $photoSaved,
            'photo_warning' => $photoWarning,
            'message'       => 'Welcome ' . $guestName . ' — entered as ' . $admno,
        ]);
    } catch (PDOException $e) {
        error_log('[ajax] guest insert: ' . $e->getMessage());
        sendJson([
            'error'   => 'Failed to add guest',
            'details' => $e->getMessage(),
        ]);
    }
    break;

        // ====================================================
        // v8.3 — GUEST EXIT (last active, personalised)
        // ====================================================
        case 'guest_exit_last':
            $db       = getDB();
            $settings = getSettings();

            if (!($settings['guest_enabled'] ?? 1)) {
                sendJson(['error' => 'Guest mode disabled']);
            }

            try {
                // Try with guest_photo column first, fall back without
                $guest = null;
                try {
                    $guest = $db->query("
                        SELECT id, admno, member_name, guest_photo
                        FROM entry_exit_logs
                        WHERE status = 'inside' AND (entry_type = 'guest' OR member_category = 'Guest')
                        ORDER BY entry_time DESC
                        LIMIT 1
                    ")->fetch();
                } catch (PDOException $e) {
                    $guest = $db->query("
                        SELECT id, admno, member_name
                        FROM entry_exit_logs
                        WHERE status = 'inside' AND (entry_type = 'guest' OR member_category = 'Guest')
                        ORDER BY entry_time DESC
                        LIMIT 1
                    ")->fetch();
                }

                if (!$guest) {
                    sendJson(['error' => 'No active guests to exit']);
                }

                $db->prepare("UPDATE entry_exit_logs SET exit_time = NOW(), status = 'exited' WHERE id = ?")
                   ->execute([$guest['id']]);

                clearCache('stats');

                $name = trim((string)($guest['member_name'] ?? ''));
                $msg  = $name !== ''
                    ? 'Goodbye ' . $name . ' — exit recorded.'
                    : 'Guest exited successfully';

                logActivity(
                    $_SESSION['koha_user_id'] ?? 0,
                    'GUEST_EXIT',
                    "Guest '{$name}' exited ({$guest['admno']})"
                );

                sendJson([
                    'success'     => true,
                    'guest_name'  => $name,
                    'guest_id'    => $guest['admno'] ?? '',
                    'guest_photo' => $guest['guest_photo'] ?? '',
                    'message'     => $msg,
                ]);
            } catch (PDOException $e) {
                error_log('[ajax] guest exit: ' . $e->getMessage());
                sendJson(['error' => 'Failed to exit guest', 'details' => $e->getMessage()]);
            }
            break;

        // ====================================================
        // v8.3 — GUEST EXIT (by ID)
        // ====================================================
        case 'guest_exit':
            $guestId = (int)($_POST['guest_id'] ?? ($jsonBody['guest_id'] ?? 0));

            if ($guestId <= 0) {
                sendJson(['error' => 'Invalid guest ID']);
            }

            $db = getDB();
            try {
                $guest = $db->prepare("
                    SELECT id, admno, member_name
                    FROM entry_exit_logs
                    WHERE id = ? AND status = 'inside' AND (entry_type = 'guest' OR member_category = 'Guest')
                    LIMIT 1
                ");
                $guest->execute([$guestId]);
                $row = $guest->fetch();

                if (!$row) {
                    sendJson(['error' => 'Guest not found or already exited']);
                }

                $db->prepare("UPDATE entry_exit_logs SET exit_time = NOW(), status = 'exited' WHERE id = ?")
                   ->execute([$guestId]);

                clearCache('stats');

                logActivity(
                    $_SESSION['koha_user_id'] ?? 0,
                    'GUEST_EXIT',
                    "Guest '{$row['member_name']}' exited ({$row['admno']})"
                );

                sendJson([
                    'success'    => true,
                    'guest_name' => $row['member_name'],
                    'guest_id'   => $row['admno'],
                    'message'    => 'Goodbye ' . $row['member_name'] . ' — exit recorded.',
                ]);
            } catch (PDOException $e) {
                error_log('[ajax] guest exit by id: ' . $e->getMessage());
                sendJson(['error' => 'Failed to exit guest']);
            }
            break;

        // ====================================================
        // ALERT SYSTEM — Get Pending Alerts
        // ====================================================
        case 'get_pending_alerts':
            $since = (int)($_GET['since'] ?? 0);
            $db = getDB();
            $alerts = [];

            try {
                $tableCheck = $db->query("SHOW TABLES LIKE 'book_alerts'");
                $hasTable = $tableCheck->rowCount() > 0;

                if ($hasTable) {
                    if ($since > 0) {
                        $stmt = $db->prepare("
                            SELECT ba.*, bel.book_barcode, bel.book_title, bel.book_author,
                                   bel.member_name, bel.member_admno, bel.photo_path
                            FROM book_alerts ba
                            LEFT JOIN book_exit_logs bel ON ba.log_id = bel.id
                            WHERE ba.created_at > FROM_UNIXTIME(?)
                              AND ba.acknowledged = 0
                              AND ba.resolved = 0
                            ORDER BY ba.created_at DESC
                            LIMIT 20
                        ");
                        $stmt->execute([$since]);
                    } else {
                        $stmt = $db->prepare("
                            SELECT ba.*, bel.book_barcode, bel.book_title, bel.book_author,
                                   bel.member_name, bel.member_admno, bel.photo_path
                            FROM book_alerts ba
                            LEFT JOIN book_exit_logs bel ON ba.log_id = bel.id
                            WHERE ba.acknowledged = 0 AND ba.resolved = 0
                            ORDER BY ba.created_at DESC
                            LIMIT 20
                        ");
                        $stmt->execute();
                    }
                    $alerts = $stmt->fetchAll();
                } else {
                    if ($since > 0) {
                        $stmt = $db->prepare("
                            SELECT id, id as log_id, book_barcode, book_title, book_author,
                                   member_name, member_admno, photo_path, created_at, 0 as acknowledged
                            FROM book_exit_logs
                            WHERE is_authorized = 0 AND created_at > FROM_UNIXTIME(?)
                            ORDER BY created_at DESC
                            LIMIT 20
                        ");
                        $stmt->execute([$since]);
                    } else {
                        $stmt = $db->prepare("
                            SELECT id, id as log_id, book_barcode, book_title, book_author,
                                   member_name, member_admno, photo_path, created_at, 0 as acknowledged
                            FROM book_exit_logs
                            WHERE is_authorized = 0
                            ORDER BY created_at DESC
                            LIMIT 20
                        ");
                        $stmt->execute();
                    }
                    $alerts = $stmt->fetchAll();
                }
            } catch (PDOException $e) {
                error_log("get_pending_alerts error: " . $e->getMessage());
            }

            sendJson(['success' => true, 'alerts' => $alerts]);
            break;

        // ====================================================
        // ALERT SYSTEM — Get Alert Statistics
        // ====================================================
        case 'get_alert_stats':
            $db = getDB();
            $stats = [
                'pending'      => 0,
                'acknowledged' => 0,
                'resolved'     => 0,
                'today'        => 0
            ];

            try {
                $tableCheck = $db->query("SHOW TABLES LIKE 'book_alerts'");
                if ($tableCheck->rowCount() > 0) {
                    $stats['pending']      = (int)$db->query("SELECT COUNT(*) FROM book_alerts WHERE acknowledged = 0 AND resolved = 0")->fetchColumn();
                    $stats['acknowledged'] = (int)$db->query("SELECT COUNT(*) FROM book_alerts WHERE acknowledged = 1 AND resolved = 0")->fetchColumn();
                    $stats['resolved']     = (int)$db->query("SELECT COUNT(*) FROM book_alerts WHERE resolved = 1")->fetchColumn();
                    $stats['today']        = (int)$db->query("SELECT COUNT(*) FROM book_alerts WHERE DATE(created_at) = CURDATE()")->fetchColumn();
                } else {
                    $stats['pending'] = (int)$db->query("SELECT COUNT(*) FROM book_exit_logs WHERE is_authorized = 0")->fetchColumn();
                    $stats['today']   = (int)$db->query("SELECT COUNT(*) FROM book_exit_logs WHERE is_authorized = 0 AND DATE(created_at) = CURDATE()")->fetchColumn();
                }
            } catch (PDOException $e) {
                error_log("get_alert_stats error: " . $e->getMessage());
            }

            sendJson($stats);
            break;

        // ====================================================
        // ALERT SYSTEM — Acknowledge Alert
        // ====================================================
        case 'acknowledge_book_alert':
        case 'acknowledge_alert':
            $alertId = (int)($_POST['alert_id'] ?? ($jsonBody['alert_id'] ?? 0));
            $note    = vms_prepare_text($_POST['ack_note'] ?? $_POST['note'] ?? ($jsonBody['ack_note'] ?? ''));
            $userId  = $_SESSION['koha_user_id'] ?? 0;

            if ($alertId <= 0) {
                sendJson(['success' => false, 'message' => 'Invalid alert ID']);
            }

            $db = getDB();
            $done = false;

            try {
                $tableCheck = $db->query("SHOW TABLES LIKE 'book_alerts'");
                if ($tableCheck->rowCount() > 0) {
                    $stmt = $db->prepare("
                        UPDATE book_alerts
                        SET acknowledged = 1, acknowledged_by = ?, acknowledged_at = NOW(), ack_note = ?
                        WHERE id = ?
                    ");
                    $stmt->execute([$userId, $note, $alertId]);
                    $done = $stmt->rowCount() > 0;
                } else {
                    try {
                        $stmt = $db->prepare("UPDATE book_exit_logs SET acknowledged = 1, acknowledged_by = ?, acknowledged_at = NOW() WHERE id = ?");
                        $stmt->execute([$userId, $alertId]);
                        $done = $stmt->rowCount() > 0;
                    } catch (PDOException $e) {
                        $done = false;
                    }
                }

                if ($done) {
                    logActivity($userId, 'ALERT_ACK', "Acknowledged alert #$alertId");
                    clearCache('stats');
                    sendJson(['success' => true, 'message' => 'Alert acknowledged']);
                } else {
                    sendJson(['success' => false, 'message' => 'Alert not found or already acknowledged']);
                }
            } catch (PDOException $e) {
                sendJson(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
            }
            break;

        // ====================================================
        // ALERT SYSTEM — Resolve Alert
        // ====================================================
        case 'resolve_book_alert':
        case 'resolve_alert':
            $alertId    = (int)($_POST['alert_id'] ?? ($jsonBody['alert_id'] ?? 0));
            $resolution = vms_prepare_text($_POST['resolution'] ?? ($jsonBody['resolution'] ?? ''));
            $userId     = $_SESSION['koha_user_id'] ?? 0;

            if ($alertId <= 0) {
                sendJson(['success' => false, 'message' => 'Invalid alert ID']);
            }

            $db = getDB();
            $done = false;

            try {
                $tableCheck = $db->query("SHOW TABLES LIKE 'book_alerts'");
                if ($tableCheck->rowCount() > 0) {
                    $stmt = $db->prepare("
                        UPDATE book_alerts
                        SET resolved = 1, resolved_by = ?, resolved_at = NOW(), resolution = ?
                        WHERE id = ?
                    ");
                    $stmt->execute([$userId, $resolution, $alertId]);
                    $done = $stmt->rowCount() > 0;
                }

                if ($done) {
                    logActivity($userId, 'ALERT_RESOLVE', "Resolved alert #$alertId");
                    clearCache('stats');
                    sendJson(['success' => true, 'message' => 'Alert resolved']);
                } else {
                    sendJson(['success' => false, 'message' => 'Alert not found']);
                }
            } catch (PDOException $e) {
                sendJson(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
            }
            break;

        // ====================================================
        // ALERT SYSTEM — Send Manual Alert
        // ====================================================
        case 'send_book_alert':
            $logId  = (int)($_POST['log_id'] ?? ($jsonBody['log_id'] ?? 0));
            $userId = $_SESSION['koha_user_id'] ?? 0;

            if ($logId <= 0) {
                sendJson(['success' => false, 'message' => 'Invalid log ID']);
            }

            $db = getDB();
            try {
                $stmt = $db->prepare("SELECT * FROM book_exit_logs WHERE id = ?");
                $stmt->execute([$logId]);
                $logData = $stmt->fetch();

                if (!$logData) {
                    sendJson(['success' => false, 'message' => 'Log not found']);
                }

                $alertSent = false;

                if (function_exists('sendUnauthorizedBookAlert')) {
                    $alertSent = sendUnauthorizedBookAlert([
                        'barcode'      => $logData['book_barcode'],
                        'title'        => $logData['book_title'],
                        'author'       => $logData['book_author'] ?? '',
                        'member_name'  => $logData['member_name'] ?? '',
                        'member_id'    => $logData['member_admno'] ?? '',
                        'photo_path'   => $logData['photo_path'] ?? '',
                        'staff_name'   => $_SESSION['koha_full_name'] ?? 'System',
                        'gate_number'  => $logData['gate_number'] ?? 'MAIN',
                        'timestamp'    => $logData['created_at']
                    ]);
                } else {
                    error_log("[MANUAL ALERT] Unauthorized book: {$logData['book_barcode']}");
                    $alertSent = true;
                }

                if ($alertSent) {
                    try {
                        $db->prepare("UPDATE book_exit_logs SET alert_sent = 1, alert_sent_at = NOW() WHERE id = ?")
                           ->execute([$logId]);
                    } catch (PDOException $e) {
                        // Column may not exist
                    }
                    logActivity($userId, 'MANUAL_ALERT', "Sent alert for book: {$logData['book_barcode']}");
                    sendJson(['success' => true, 'message' => 'Alert sent successfully']);
                } else {
                    sendJson(['success' => false, 'message' => 'Failed to send alert']);
                }
            } catch (PDOException $e) {
                sendJson(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
            }
            break;

        // ====================================================
        // ALERT SYSTEM — Clear Unauthorized Logs
        // ====================================================
        case 'clear_unauthorized_logs':
            $csrfToken = $_POST['csrf_token'] ?? ($jsonBody['csrf_token'] ?? '');
            $userId = $_SESSION['koha_user_id'] ?? 0;

            if (function_exists('verifyCSRFToken') && !empty($csrfToken)) {
                if (!verifyCSRFToken($csrfToken)) {
                    sendJson(['success' => false, 'message' => 'Invalid CSRF token']);
                }
            }

            $db = getDB();
            try {
                try {
                    $db->exec("DELETE FROM book_alerts WHERE acknowledged = 0 AND resolved = 0");
                } catch (PDOException $e) {
                    // Table doesn't exist - skip
                }

                $stmt = $db->prepare("DELETE FROM book_exit_logs WHERE is_authorized = 0");
                $stmt->execute();
                $deleted = $stmt->rowCount();

                logActivity($userId, 'CLEAR_UNAUTHORIZED', "Cleared $deleted unauthorized book exit logs");
                clearCache('stats');

                sendJson([
                    'success' => true,
                    'message' => "Cleared $deleted unauthorized log(s)"
                ]);
            } catch (PDOException $e) {
                sendJson(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
            }
            break;

        // ====================================================
        // DELETE BOOK LOG
        // ====================================================
        case 'delete_book_log':
            $id = (int)($_POST['id'] ?? ($jsonBody['id'] ?? 0));
            $csrfToken = $_POST['csrf_token'] ?? ($jsonBody['csrf_token'] ?? '');
            $userId = $_SESSION['koha_user_id'] ?? 0;

            if ($id <= 0) {
                sendJson(['success' => false, 'message' => 'Invalid ID']);
            }

            if (function_exists('verifyCSRFToken') && !empty($csrfToken)) {
                if (!verifyCSRFToken($csrfToken)) {
                    sendJson(['success' => false, 'message' => 'Invalid CSRF token']);
                }
            }

            $db = getDB();
            try {
                try {
                    $db->prepare("DELETE FROM book_alerts WHERE log_id = ?")->execute([$id]);
                } catch (PDOException $e) {
                    // Table may not exist
                }

                $stmt = $db->prepare("DELETE FROM book_exit_logs WHERE id = ?");
                $stmt->execute([$id]);

                if ($stmt->rowCount() > 0) {
                    logActivity($userId, 'DELETE_BOOK_LOG', "Deleted book exit log #$id");
                    clearCache('stats');
                    sendJson(['success' => true, 'message' => 'Log deleted successfully']);
                } else {
                    sendJson(['success' => false, 'message' => 'Log not found']);
                }
            } catch (PDOException $e) {
                sendJson(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
            }
            break;

        // ====================================================
        // EDIT / UPDATE BOOK LOG (entity-safe)
        // ====================================================
        case 'update_book_log':
            $id = (int)($_POST['id'] ?? ($jsonBody['id'] ?? 0));
            if ($id <= 0) {
                sendJson(['success' => false, 'message' => 'Invalid log ID']);
            }

            $csrfToken = $_POST['csrf_token'] ?? ($jsonBody['csrf_token'] ?? '');
            if (function_exists('verifyCSRFToken') && !empty($csrfToken)) {
                if (!verifyCSRFToken($csrfToken)) {
                    sendJson(['success' => false, 'message' => 'Invalid CSRF token']);
                }
            }

            // Entity-safe input decoding
            $bookBarcode  = trim(vms_plain($_POST['book_barcode']  ?? ($jsonBody['book_barcode']  ?? '')));
            $bookTitle    = trim(vms_plain($_POST['book_title']    ?? ($jsonBody['book_title']    ?? '')));
            $bookAuthor   = trim(vms_plain($_POST['book_author']   ?? ($jsonBody['book_author']   ?? '')));
            $memberAdmno  = trim(vms_plain($_POST['member_admno']  ?? ($jsonBody['member_admno']  ?? '')));
            $memberName   = trim(vms_plain($_POST['member_name']   ?? ($jsonBody['member_name']   ?? '')));
            $isAuthorized = (int)($_POST['is_authorized'] ?? ($jsonBody['is_authorized'] ?? 0));
            $notes        = trim(vms_plain($_POST['notes']         ?? ($jsonBody['notes']         ?? '')));
            $gateNumber   = trim(vms_plain($_POST['gate_number']   ?? ($jsonBody['gate_number']   ?? 'MAIN')));
            $alertSent    = (int)($_POST['alert_sent']   ?? ($jsonBody['alert_sent']   ?? 0));

            if ($bookBarcode === '' || $bookTitle === '') {
                sendJson(['success' => false, 'message' => 'Barcode and title are required']);
            }

            $db = getDB();
            try {
                // Verify the log exists
                $check = $db->prepare("SELECT id, photo_path FROM book_exit_logs WHERE id = ? LIMIT 1");
                $check->execute([$id]);
                $existing = $check->fetch();
                if (!$existing) {
                    sendJson(['success' => false, 'message' => 'Book exit log not found']);
                }

                $stmt = $db->prepare("
                    UPDATE book_exit_logs
                       SET book_barcode  = ?,
                           book_title    = ?,
                           book_author   = ?,
                           member_admno  = ?,
                           member_name   = ?,
                           is_authorized = ?,
                           notes         = ?,
                           gate_number   = ?,
                           alert_sent    = ?
                     WHERE id = ?
                ");
                $stmt->execute([
                    $bookBarcode,
                    $bookTitle,
                    $bookAuthor,
                    $memberAdmno,
                    $memberName,
                    $isAuthorized,
                    $notes,
                    $gateNumber,
                    $alertSent,
                    $id
                ]);

                // Keep the linked alert row in sync (if it exists)
                try {
                    $db->prepare("
                        UPDATE book_alerts
                           SET book_barcode = ?,
                               book_title   = ?
                         WHERE log_id = ?
                    ")->execute([$bookBarcode, $bookTitle, $id]);
                } catch (PDOException $e) {
                    // book_alerts table may not exist — ignore
                }

                $userId = $_SESSION['koha_user_id'] ?? 0;
                logActivity($userId, 'BOOK_LOG_EDIT', "Edited book exit log #$id ({$bookBarcode})");
                clearCache('stats');

                sendJson([
                    'success' => true,
                    'message' => 'Book exit log updated successfully',
                    'data'    => [
                        'id'             => $id,
                        'book_barcode'   => $bookBarcode,
                        'book_title'     => $bookTitle,
                        'book_author'    => $bookAuthor,
                        'member_admno'   => $memberAdmno,
                        'member_name'    => $memberName,
                        'is_authorized'  => $isAuthorized,
                        'notes'          => $notes,
                        'gate_number'    => $gateNumber,
                        'alert_sent'     => $alertSent,
                    ]
                ]);
            } catch (PDOException $e) {
                sendJson(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
            }
            break;

        // ====================================================
        // GET MONITORING DATA
        // ====================================================
        case 'get_monitoring_data':
            $db = getDB();
            $data = [
                'unauthorized_today'      => 0,
                'unauthorized_week'       => 0,
                'total_book_exits_today'  => 0,
                'pending_alerts'          => 0,
                'last_unauthorized'       => null,
                'hourly_breakdown'        => [],
                'top_members'             => []
            ];

            try {
                $data['unauthorized_today'] = (int)$db->query("
                    SELECT COUNT(*) FROM book_exit_logs
                    WHERE is_authorized = 0 AND DATE(created_at) = CURDATE()
                ")->fetchColumn();

                $data['unauthorized_week'] = (int)$db->query("
                    SELECT COUNT(*) FROM book_exit_logs
                    WHERE is_authorized = 0 AND created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
                ")->fetchColumn();

                $data['total_book_exits_today'] = (int)$db->query("
                    SELECT COUNT(*) FROM book_exit_logs WHERE DATE(created_at) = CURDATE()
                ")->fetchColumn();

                $data['last_unauthorized'] = $db->query("
                    SELECT book_barcode, book_title, created_at
                    FROM book_exit_logs
                    WHERE is_authorized = 0
                    ORDER BY created_at DESC LIMIT 1
                ")->fetch();

                $data['hourly_breakdown'] = $db->query("
                    SELECT HOUR(created_at) as hour, COUNT(*) as count
                    FROM book_exit_logs
                    WHERE is_authorized = 0 AND DATE(created_at) = CURDATE()
                    GROUP BY hour ORDER BY hour
                ")->fetchAll();

                $data['top_members'] = $db->query("
                    SELECT member_name, COUNT(*) as count
                    FROM book_exit_logs
                    WHERE is_authorized = 0 AND member_name IS NOT NULL AND member_name != ''
                    GROUP BY member_name ORDER BY count DESC LIMIT 5
                ")->fetchAll();

                try {
                    $data['pending_alerts'] = (int)$db->query("
                        SELECT COUNT(*) FROM book_alerts WHERE acknowledged = 0 AND resolved = 0
                    ")->fetchColumn();
                } catch (PDOException $e) {
                    $data['pending_alerts'] = $data['unauthorized_today'];
                }
            } catch (PDOException $e) {
                error_log("get_monitoring_data error: " . $e->getMessage());
            }

            sendJson($data);
            break;

        // ====================================================
        // BULK ACKNOWLEDGE ALERTS
        // ====================================================
        case 'bulk_acknowledge_alerts':
            $ids     = $_POST['alert_ids'] ?? ($jsonBody['alert_ids'] ?? []);
            $userId  = $_SESSION['koha_user_id'] ?? 0;
            $count   = 0;

            if (empty($ids) || !is_array($ids)) {
                sendJson(['success' => false, 'message' => 'No alerts selected']);
            }

            $db = getDB();
            try {
                $tableCheck = $db->query("SHOW TABLES LIKE 'book_alerts'");
                if ($tableCheck->rowCount() > 0) {
                    $placeholders = implode(',', array_fill(0, count($ids), '?'));
                    $stmt = $db->prepare("
                        UPDATE book_alerts
                        SET acknowledged = 1, acknowledged_by = ?, acknowledged_at = NOW(), ack_note = 'Bulk acknowledged'
                        WHERE id IN ($placeholders) AND acknowledged = 0
                    ");
                    $params = array_merge([$userId], array_map('intval', $ids));
                    $stmt->execute($params);
                    $count = $stmt->rowCount();
                }

                logActivity($userId, 'BULK_ALERT_ACK', "Acknowledged $count alerts");
                clearCache('stats');

                sendJson([
                    'success' => true,
                    'message' => "Acknowledged $count alert(s)"
                ]);
            } catch (PDOException $e) {
                sendJson(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
            }
            break;

        // ====================================================
        // DEFAULT - Unknown action
        // ====================================================
        default:
            sendJson(['success' => false, 'error' => 'Invalid action: ' . vms_h($action)]);
    }

} catch (Exception $e) {
    error_log("AJAX error [{$action}]: " . $e->getMessage());
    sendJson([
        'success' => false,
        'error'   => 'Server error: ' . $e->getMessage()
    ]);
} catch (Error $e) {
    error_log("AJAX fatal [{$action}]: " . $e->getMessage());
    sendJson([
        'success' => false,
        'error'   => 'Fatal error: ' . $e->getMessage()
    ]);
}
