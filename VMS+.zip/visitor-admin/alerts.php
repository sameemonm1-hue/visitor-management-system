<?php
/**
 * Visitor Management System - Security Alert Center
 * Version: 8.2 FIXED – All columns properly qualified
 *
 * CHANGELOG v8.2:
 *  - FIXED: Ambiguous 'acknowledged' column (both tables have it now)
 *  - FIXED: Ambiguous 'resolved' column (both tables have it now)
 *  - All WHERE/ORDER columns now use table aliases (ba. or bel.)
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

// ============================================================
// INCLUDE PATH DETECTION
// ============================================================
$possiblePaths = [
    __DIR__ . '/includes',
    dirname(__DIR__) . '/includes',
    '/usr/share/koha/intranet/cgi-bin/koha/visitor/includes',
    '/usr/share/koha/intranet/cgi-bin/visitor/includes',
];

$includePath = null;
foreach ($possiblePaths as $path) {
    if (file_exists($path . '/config.php')) {
        $includePath = $path;
        break;
    }
}

if (!$includePath) {
    die('Could not find includes directory.');
}

define('VMS_INCLUDES', $includePath);
require_once VMS_INCLUDES . '/config.php';
require_once VMS_INCLUDES . '/functions.php';
require_once VMS_INCLUDES . '/koha.php';
require_once VMS_INCLUDES . '/auth.php';

if (file_exists(VMS_INCLUDES . '/alerts.php')) {
    require_once VMS_INCLUDES . '/alerts.php';
}

startSecureSession();
requireKohaLogin();

$db = getDB();
$user = getCurrentUser();
$settings = getSettings();
$message = '';
$error = '';

// ============================================================
// AUTO-CREATE book_alerts TABLE IF MISSING
// ============================================================
function ensureAlertTables($db) {
    try {
        $db->exec("
            CREATE TABLE IF NOT EXISTS book_alerts (
                id INT PRIMARY KEY AUTO_INCREMENT,
                log_id INT NOT NULL,
                book_barcode VARCHAR(50) NOT NULL,
                book_title VARCHAR(200) NOT NULL,
                photo_path VARCHAR(255),
                acknowledged TINYINT(1) DEFAULT 0,
                acknowledged_by INT DEFAULT NULL,
                acknowledged_at DATETIME DEFAULT NULL,
                ack_note TEXT,
                resolved TINYINT(1) DEFAULT 0,
                resolved_by INT DEFAULT NULL,
                resolved_at DATETIME DEFAULT NULL,
                resolution TEXT,
                email_sent TINYINT(1) DEFAULT 0,
                sms_sent TINYINT(1) DEFAULT 0,
                webhook_sent TINYINT(1) DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_acknowledged (acknowledged),
                INDEX idx_resolved (resolved),
                INDEX idx_created (created_at),
                INDEX idx_log (log_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");
        return true;
    } catch (PDOException $e) {
        error_log("ensureAlertTables error: " . $e->getMessage());
        return false;
    }
}

ensureAlertTables($db);

// ============================================================
// HANDLE ACTIONS
// ============================================================
if (isset($_POST['acknowledge'])) {
    $alertId = (int)$_POST['alert_id'];
    $note = trim($_POST['note'] ?? '');
    try {
        $stmt = $db->prepare("
            UPDATE book_alerts 
            SET acknowledged = 1, acknowledged_by = ?, acknowledged_at = NOW(), ack_note = ?
            WHERE id = ?
        ");
        $stmt->execute([$user['id'], $note, $alertId]);
        $message = 'Alert acknowledged successfully.';
    } catch (PDOException $e) {
        $error = 'Failed to acknowledge: ' . $e->getMessage();
    }
}

if (isset($_POST['resolve'])) {
    $alertId = (int)$_POST['alert_id'];
    $resolution = trim($_POST['resolution'] ?? '');
    try {
        $stmt = $db->prepare("
            UPDATE book_alerts 
            SET resolved = 1, resolved_by = ?, resolved_at = NOW(), resolution = ?
            WHERE id = ?
        ");
        $stmt->execute([$user['id'], $resolution, $alertId]);
        $message = 'Alert resolved.';
    } catch (PDOException $e) {
        $error = 'Failed to resolve: ' . $e->getMessage();
    }
}

if (isset($_POST['bulk_acknowledge'])) {
    $ids = $_POST['alert_ids'] ?? [];
    $count = 0;
    foreach ($ids as $id) {
        try {
            $stmt = $db->prepare("
                UPDATE book_alerts 
                SET acknowledged = 1, acknowledged_by = ?, acknowledged_at = NOW(), ack_note = 'Bulk acknowledged'
                WHERE id = ? AND acknowledged = 0
            ");
            $stmt->execute([$user['id'], (int)$id]);
            $count += $stmt->rowCount();
        } catch (PDOException $e) {
            // Skip
        }
    }
    $message = "$count alert(s) acknowledged.";
}

// ============================================================
// FILTERS & PAGINATION
// ============================================================
$filter = $_GET['filter'] ?? 'pending';
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 20;
$offset = ($page - 1) * $perPage;

// ============================================================
// BUILD WHERE CLAUSE WITH TABLE ALIAS (fixes ambiguous columns)
// ============================================================
$whereClause = '';
switch ($filter) {
    case 'pending':
        $whereClause = "WHERE ba.acknowledged = 0 AND ba.resolved = 0";
        break;
    case 'acknowledged':
        $whereClause = "WHERE ba.acknowledged = 1 AND ba.resolved = 0";
        break;
    case 'resolved':
        $whereClause = "WHERE ba.resolved = 1";
        break;
    case 'all':
    default:
        $whereClause = "";
        break;
}

// ============================================================
// FETCH STATISTICS
// ============================================================
$stats = [
    'pending'      => 0,
    'acknowledged' => 0,
    'resolved'     => 0,
    'today'        => 0
];

try {
    $stats['pending']      = (int)$db->query("SELECT COUNT(*) FROM book_alerts WHERE acknowledged = 0 AND resolved = 0")->fetchColumn();
    $stats['acknowledged'] = (int)$db->query("SELECT COUNT(*) FROM book_alerts WHERE acknowledged = 1 AND resolved = 0")->fetchColumn();
    $stats['resolved']     = (int)$db->query("SELECT COUNT(*) FROM book_alerts WHERE resolved = 1")->fetchColumn();
    $stats['today']        = (int)$db->query("SELECT COUNT(*) FROM book_alerts WHERE DATE(created_at) = CURDATE()")->fetchColumn();
} catch (PDOException $e) {
    error_log("Stats error: " . $e->getMessage());
}

// ============================================================
// FETCH ALERTS (with aliased columns)
// ============================================================
$alerts = [];
$totalAlerts = 0;

try {
    // Count — uses same WHERE clause with ba. prefix
    $countSql = "SELECT COUNT(*) FROM book_alerts ba $whereClause";
    $stmt = $db->prepare($countSql);
    $stmt->execute();
    $totalAlerts = (int)$stmt->fetchColumn();

    // Fetch — aliases all columns with ba. or bel. prefix
    $sql = "
        SELECT 
            ba.id,
            ba.log_id,
            ba.book_barcode,
            ba.book_title,
            ba.photo_path,
            ba.acknowledged,
            ba.acknowledged_by,
            ba.acknowledged_at,
            ba.ack_note,
            ba.resolved,
            ba.resolved_by,
            ba.resolved_at,
            ba.resolution,
            ba.created_at,
            bel.book_author,
            bel.member_name,
            bel.member_admno
        FROM book_alerts ba
        LEFT JOIN book_exit_logs bel ON ba.log_id = bel.id
        $whereClause
        ORDER BY ba.created_at DESC
        LIMIT $perPage OFFSET $offset
    ";
    $stmt = $db->prepare($sql);
    $stmt->execute();
    $alerts = $stmt->fetchAll();

} catch (PDOException $e) {
    error_log("Fetch alerts error: " . $e->getMessage());
    $error = 'Failed to load alerts: ' . $e->getMessage();

    // FALLBACK: pull from book_exit_logs only
    try {
        $alerts = $db->query("
            SELECT 
                bel.id,
                bel.id AS log_id,
                bel.book_barcode,
                bel.book_title,
                bel.book_author,
                bel.member_name,
                bel.member_admno,
                bel.photo_path,
                bel.created_at,
                0 AS acknowledged,
                0 AS resolved,
                '' AS ack_note,
                '' AS resolution
            FROM book_exit_logs bel
            WHERE bel.is_authorized = 0
            ORDER BY bel.created_at DESC
            LIMIT $perPage OFFSET $offset
        ")->fetchAll();
        $totalAlerts = count($alerts);
    } catch (PDOException $e2) {
        error_log("Fallback error: " . $e2->getMessage());
    }
}

$totalPages = $totalAlerts > 0 ? ceil($totalAlerts / $perPage) : 1;

$pageTitle = 'Security Alerts';
include __DIR__ . '/header.php';
?>

<style>
.alert-card {
    background: white;
    border-radius: 16px;
    padding: 20px;
    margin-bottom: 16px;
    box-shadow: 0 4px 20px rgba(0,0,0,0.08);
    border-left: 4px solid #dc3545;
    transition: all 0.3s ease;
}
.alert-card:hover {
    box-shadow: 0 8px 30px rgba(0,0,0,0.12);
    transform: translateY(-2px);
}
.alert-card.acknowledged { border-left-color: #ffc107; }
.alert-card.resolved { border-left-color: #28a745; opacity: 0.8; }
.alert-card .alert-photo {
    width: 120px;
    height: 120px;
    border-radius: 12px;
    object-fit: cover;
    border: 2px solid #dee2e6;
    cursor: pointer;
}
.filter-tabs {
    display: flex;
    gap: 10px;
    margin-bottom: 20px;
    flex-wrap: wrap;
}
.filter-tab {
    padding: 8px 20px;
    border-radius: 30px;
    background: white;
    border: 1px solid #dee2e6;
    color: #6c757d;
    text-decoration: none;
    font-weight: 500;
    transition: all 0.2s ease;
    font-size: 0.85rem;
}
.filter-tab:hover { background: #f8f9fa; color: #1e3c72; }
.filter-tab.active { background: #1e3c72; color: white; border-color: #1e3c72; }
.filter-tab .badge { margin-left: 5px; }
.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
    gap: 15px;
    margin-bottom: 25px;
}
.stat-box {
    background: white;
    border-radius: 16px;
    padding: 20px;
    text-align: center;
    box-shadow: 0 4px 20px rgba(0,0,0,0.06);
}
.stat-box .value { font-size: 2rem; font-weight: 800; }
.stat-box .label { font-size: 0.8rem; color: #6c757d; }
.stat-box.danger .value { color: #dc3545; }
.stat-box.warning .value { color: #ffc107; }
.stat-box.success .value { color: #28a745; }
.stat-box.primary .value { color: #1e3c72; }
</style>

<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
        <h4 class="mb-0">
            <i class="fas fa-shield-alt me-2 text-danger"></i>Security Alert Center
        </h4>
        <div class="d-flex gap-2">
            <a href="books.php" class="btn btn-outline-primary">
                <i class="fas fa-book me-1"></i> Book Management
            </a>
            <button onclick="location.reload()" class="btn btn-outline-secondary">
                <i class="fas fa-sync-alt me-1"></i> Refresh
            </button>
        </div>
    </div>
    
    <?php if ($message): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <i class="fas fa-check-circle me-2"></i><?= htmlspecialchars($message) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <?php if ($error): ?>
        <div class="alert alert-warning alert-dismissible fade show">
            <i class="fas fa-exclamation-circle me-2"></i><?= htmlspecialchars($error) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <!-- Statistics -->
    <div class="stats-grid">
        <div class="stat-box danger">
            <div class="value"><?= $stats['pending'] ?></div>
            <div class="label">Pending Alerts</div>
        </div>
        <div class="stat-box warning">
            <div class="value"><?= $stats['acknowledged'] ?></div>
            <div class="label">Acknowledged</div>
        </div>
        <div class="stat-box success">
            <div class="value"><?= $stats['resolved'] ?></div>
            <div class="label">Resolved</div>
        </div>
        <div class="stat-box primary">
            <div class="value"><?= $stats['today'] ?></div>
            <div class="label">Today's Alerts</div>
        </div>
    </div>
    
    <!-- Filter Tabs -->
    <div class="filter-tabs">
        <a href="?filter=pending" class="filter-tab <?= $filter === 'pending' ? 'active' : '' ?>">
            <i class="fas fa-clock me-1"></i> Pending
            <?php if ($stats['pending'] > 0): ?>
                <span class="badge bg-danger"><?= $stats['pending'] ?></span>
            <?php endif; ?>
        </a>
        <a href="?filter=acknowledged" class="filter-tab <?= $filter === 'acknowledged' ? 'active' : '' ?>">
            <i class="fas fa-check me-1"></i> Acknowledged
        </a>
        <a href="?filter=resolved" class="filter-tab <?= $filter === 'resolved' ? 'active' : '' ?>">
            <i class="fas fa-check-double me-1"></i> Resolved
        </a>
        <a href="?filter=all" class="filter-tab <?= $filter === 'all' ? 'active' : '' ?>">
            <i class="fas fa-list me-1"></i> All Alerts
        </a>
    </div>
    
    <!-- Bulk Actions -->
    <?php if (!empty($alerts) && $filter === 'pending'): ?>
        <div class="mb-3">
            <form method="POST" id="bulkForm">
                <button type="button" class="btn btn-outline-success btn-sm" onclick="bulkAcknowledge()">
                    <i class="fas fa-check-double me-1"></i> Acknowledge Selected
                </button>
                <button type="button" class="btn btn-outline-secondary btn-sm" onclick="selectAllAlerts()">
                    <i class="fas fa-check-square me-1"></i> Select All
                </button>
            </form>
        </div>
    <?php endif; ?>
    
    <!-- Alerts List -->
    <?php if (empty($alerts)): ?>
        <div class="text-center py-5">
            <i class="fas fa-shield-alt fa-4x text-success mb-3"></i>
            <h5>No alerts found</h5>
            <p class="text-muted">All clear! No security alerts in this category.</p>
        </div>
    <?php else: ?>
        <?php foreach ($alerts as $alert): 
            $isAck = !empty($alert['acknowledged']);
            $isRes = !empty($alert['resolved']);
            $cardClass = $isRes ? 'resolved' : ($isAck ? 'acknowledged' : '');
        ?>
            <div class="alert-card <?= $cardClass ?>">
                <div class="row">
                    <div class="col-12 col-md-8">
                        <div class="d-flex align-items-start gap-3">
                            <?php if ($filter === 'pending' && !$isRes): ?>
                                <input type="checkbox" class="form-check-input mt-1 alert-checkbox" 
                                       value="<?= $alert['id'] ?>" form="bulkForm">
                            <?php endif; ?>
                            
                            <div class="flex-grow-1">
                                <div class="d-flex align-items-center gap-2 mb-2">
                                    <span class="badge bg-danger">
                                        <i class="fas fa-exclamation-triangle me-1"></i> UNAUTHORIZED EXIT
                                    </span>
                                    <small class="text-muted">
                                        <?= function_exists('timeAgo') ? timeAgo($alert['created_at']) : $alert['created_at'] ?>
                                    </small>
                                </div>
                                
                                <h6 class="mb-1"><?= htmlspecialchars($alert['book_title']) ?></h6>
                                <div class="text-muted small mb-2">
                                    <i class="fas fa-barcode me-1"></i> <?= htmlspecialchars($alert['book_barcode']) ?>
                                    <?php if (!empty($alert['book_author'])): ?>
                                        | <i class="fas fa-user-edit me-1"></i> <?= htmlspecialchars($alert['book_author']) ?>
                                    <?php endif; ?>
                                </div>
                                
                                <?php if (!empty($alert['member_name'])): ?>
                                    <div class="small">
                                        <i class="fas fa-user me-1"></i> 
                                        <strong><?= htmlspecialchars($alert['member_name']) ?></strong>
                                        <?php if (!empty($alert['member_admno'])): ?>
                                            (<?= htmlspecialchars($alert['member_admno']) ?>)
                                        <?php endif; ?>
                                    </div>
                                <?php endif; ?>
                                
                                <?php if (!empty($alert['ack_note'])): ?>
                                    <div class="mt-2 p-2 bg-light rounded small">
                                        <i class="fas fa-sticky-note me-1 text-warning"></i>
                                        <strong>Note:</strong> <?= htmlspecialchars($alert['ack_note']) ?>
                                    </div>
                                <?php endif; ?>
                                
                                <?php if (!empty($alert['resolution'])): ?>
                                    <div class="mt-2 p-2 bg-light rounded small">
                                        <i class="fas fa-check-double me-1 text-success"></i>
                                        <strong>Resolution:</strong> <?= htmlspecialchars($alert['resolution']) ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-12 col-md-4 text-center text-md-end mt-3 mt-md-0">
                        <?php if (!empty($alert['photo_path'])): ?>
                            <?php $photoPath = UPLOAD_PATH . '/book_exit_photos/' . $alert['photo_path']; ?>
                            <?php if (file_exists($photoPath)): ?>
                                <img src="data:image/jpeg;base64,<?= base64_encode(file_get_contents($photoPath)) ?>" 
                                     class="alert-photo mb-2" alt="Security Photo"
                                     onclick="showPhotoModal(this.src)">
                            <?php endif; ?>
                        <?php endif; ?>
                        
                        <div class="d-flex gap-2 justify-content-center justify-content-md-end flex-wrap">
                            <?php if (!$isAck): ?>
                                <button class="btn btn-sm btn-success" 
                                        onclick="acknowledgeAlert(<?= $alert['id'] ?>)">
                                    <i class="fas fa-check me-1"></i> Acknowledge
                                </button>
                            <?php endif; ?>
                            
                            <?php if ($isAck && !$isRes): ?>
                                <button class="btn btn-sm btn-primary" 
                                        onclick="resolveAlert(<?= $alert['id'] ?>)">
                                    <i class="fas fa-check-double me-1"></i> Resolve
                                </button>
                            <?php endif; ?>
                            
                            <?php if ($isRes): ?>
                                <span class="badge bg-success py-2">
                                    <i class="fas fa-check-circle me-1"></i> Resolved
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
        
        <!-- Pagination -->
        <?php if ($totalPages > 1): ?>
            <nav>
                <ul class="pagination justify-content-center">
                    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                        <li class="page-item <?= $i === $page ? 'active' : '' ?>">
                            <a class="page-link" href="?filter=<?= $filter ?>&page=<?= $i ?>"><?= $i ?></a>
                        </li>
                    <?php endfor; ?>
                </ul>
            </nav>
        <?php endif; ?>
    <?php endif; ?>
</div>

<!-- Photo Modal -->
<div class="modal fade" id="photoModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title"><i class="fas fa-camera me-2"></i> Security Photo</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body text-center">
                <img id="modalPhoto" src="" class="img-fluid rounded" style="max-height: 500px;">
            </div>
        </div>
    </div>
</div>

<script>
function showPhotoModal(src) {
    document.getElementById('modalPhoto').src = src;
    new bootstrap.Modal(document.getElementById('photoModal')).show();
}

function acknowledgeAlert(alertId) {
    const note = prompt('Add a note (optional):');
    if (note === null) return;
    
    const form = document.createElement('form');
    form.method = 'POST';
    form.innerHTML = `
        <input type="hidden" name="acknowledge" value="1">
        <input type="hidden" name="alert_id" value="${alertId}">
        <input type="hidden" name="note" value="${escapeHtml(note)}">
    `;
    document.body.appendChild(form);
    form.submit();
}

function resolveAlert(alertId) {
    const resolution = prompt('Resolution notes:');
    if (resolution === null) return;
    
    const form = document.createElement('form');
    form.method = 'POST';
    form.innerHTML = `
        <input type="hidden" name="resolve" value="1">
        <input type="hidden" name="alert_id" value="${alertId}">
        <input type="hidden" name="resolution" value="${escapeHtml(resolution)}">
    `;
    document.body.appendChild(form);
    form.submit();
}

function selectAllAlerts() {
    const checkboxes = document.querySelectorAll('.alert-checkbox');
    const allChecked = Array.from(checkboxes).every(cb => cb.checked);
    checkboxes.forEach(cb => cb.checked = !allChecked);
}

function bulkAcknowledge() {
    const selected = document.querySelectorAll('.alert-checkbox:checked');
    if (selected.length === 0) {
        alert('Please select at least one alert');
        return;
    }
    
    if (!confirm(`Acknowledge ${selected.length} alert(s)?`)) return;
    
    const form = document.getElementById('bulkForm');
    form.innerHTML = '<input type="hidden" name="bulk_acknowledge" value="1">';
    selected.forEach(cb => {
        const input = document.createElement('input');
        input.type = 'hidden';
        input.name = 'alert_ids[]';
        input.value = cb.value;
        form.appendChild(input);
    });
    form.submit();
}

function escapeHtml(str) {
    if (!str) return '';
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
}
</script>

<?php include __DIR__ . '/footer.php'; ?>
