<?php
/**
 * Visitor Management System — System User Setup (CLI)
 * Version: 8.6 FINAL
 *
 * Manage non-interactive service accounts used by cron, webhooks,
 * the REST API, and one-shot installers. Each account has its own
 * bcrypt-hashed API key, an auditable trail in `system_user_logins`,
 * and optional binding to a Koha borrower for role inheritance.
 *
 * USAGE (command line only):
 *   sudo -u www-data php system_user_setup.php --list
 *   sudo -u www-data php system_user_setup.php --reset-default
 *   sudo -u www-data php system_user_setup.php --create=vms-cron   --role=cron  --name="VMS Cron Worker"
 *   sudo -u www-data php system_user_setup.php --create=vms-mobile --role=api   --name="Mobile Client"
 *   sudo -u www-data php system_user_setup.php --rotate=1
 *   sudo -u www-data php system_user_setup.php --disable=vms-cron
 *   sudo -u www-data php system_user_setup.php --enable=vms-cron
 *   sudo -u www-data php system_user_setup.php --delete=vms-cron
 *   sudo -u www-data php system_user_setup.php --logins=1 --limit=20
 *
 * WEB ACCESS IS BLOCKED — the script dies if PHP_SAPI !== 'cli'.
 */

// ============================================================
// WEB-GUARD: refuse to run from HTTP
// ============================================================
if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    header('Content-Type: text/plain; charset=utf-8');
    echo "Access denied: this script must be run from the command line.\n";
    exit(1);
}

// ============================================================
// ERROR REPORTING (verbose on CLI)
// ============================================================
error_reporting(E_ALL);
ini_set('display_errors', '1');
ini_set('log_errors', '1');

// ============================================================
// LOCATE config.php
// ============================================================
$possiblePaths = [
    __DIR__ . '/includes',
    __DIR__ . '/../includes',
    dirname(__DIR__) . '/includes',
    '/usr/share/koha/intranet/cgi-bin/koha/visitor/includes',
    '/usr/share/koha/intranet/cgi-bin/visitor/includes',
];
$includePath = null;
foreach ($possiblePaths as $p) {
    if (file_exists($p . '/config.php')) { $includePath = $p; break; }
}
if (!$includePath) {
    fwrite(STDERR, "❌ Could not find includes/config.php\n");
    exit(1);
}

require_once $includePath . '/config.php';
require_once $includePath . '/db.php';
require_once $includePath . '/functions.php';

$db = getDB();
if (!$db) {
    fwrite(STDERR, "❌ Database connection failed\n");
    exit(1);
}

// ============================================================
// HELPERS — Output
// ============================================================
function out(string $msg, string $color = ''): void {
    $colors = [
        'green'  => "\033[32m",
        'red'    => "\033[31m",
        'yellow' => "\033[33m",
        'blue'   => "\033[34m",
        'cyan'   => "\033[36m",
        'bold'   => "\033[1m",
        'dim'    => "\033[2m",
        'reset'  => "\033[0m",
    ];
    $c = $colors[$color] ?? '';
    $r = $colors['reset'];
    echo ($c ? $c : '') . $msg . ($c ? $r : '') . PHP_EOL;
}

function box(string $title, array $lines): void {
    $width = max(array_map('strlen', $lines));
    $width = max($width, strlen($title)) + 4;
    $bar = str_repeat('─', $width);
    out("┌{$bar}┐", 'dim');
    out("│ " . str_pad($title, $width - 1) . "│", 'bold');
    out("├{$bar}┤", 'dim');
    foreach ($lines as $line) {
        out("│ " . str_pad($line, $width - 1) . "│");
    }
    out("└{$bar}┘", 'dim');
}

// ============================================================
// HELPERS — API key generation
// ============================================================
/**
 * Generate a fresh API key in the format:
 *   vms_<48 hex chars>
 * 52 chars total. Enough entropy (192 bits) to be unguessable.
 */
function generateApiKey(): string {
    return 'vms_' . bin2hex(random_bytes(24));
}

/**
 * Extract a prefix (first 8 chars after `vms_`) for display and
 * efficient lookups. Never stored in plaintext alongside the hash.
 */
function apiKeyPrefix(string $key): string {
    // Example: vms_2b8c4d8f4a1e... → "vms_2b8c4d8f"
    return substr($key, 0, 12);
}

// ============================================================
// HELPERS — Table bootstrap (idempotent)
// ============================================================
function ensureSystemTables(PDO $db): void {
    $db->exec("
        CREATE TABLE IF NOT EXISTS system_users (
            id INT PRIMARY KEY AUTO_INCREMENT,
            username VARCHAR(64) NOT NULL,
            display_name VARCHAR(200) NOT NULL,
            api_key_hash VARCHAR(255) NOT NULL,
            api_key_prefix VARCHAR(12) NOT NULL,
            role ENUM('system','admin','cron','api') DEFAULT 'system',
            bound_borrowernumber INT NULL,
            enabled TINYINT(1) DEFAULT 1,
            last_used_at DATETIME NULL,
            last_ip VARCHAR(45) NULL,
            notes TEXT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE KEY uniq_username (username),
            INDEX idx_enabled (enabled),
            INDEX idx_prefix  (api_key_prefix),
            INDEX idx_role    (role)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");

    $db->exec("
        CREATE TABLE IF NOT EXISTS system_user_logins (
            id INT PRIMARY KEY AUTO_INCREMENT,
            system_user_id INT NOT NULL,
            source ENUM('cron','webhook','api','installer','cli') NOT NULL,
            action VARCHAR(100) NOT NULL,
            ip_address VARCHAR(45) NULL,
            user_agent TEXT NULL,
            success TINYINT(1) DEFAULT 1,
            details TEXT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_user     (system_user_id),
            INDEX idx_source   (source),
            INDEX idx_action   (action),
            INDEX idx_created  (created_at),
            INDEX idx_success  (success)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
}

// ============================================================
// HELPERS — Audit log
// ============================================================
function logCliAction(PDO $db, ?int $userId, string $action, string $details = ''): void {
    try {
        if ($userId !== null) {
            $db->prepare("
                INSERT INTO system_user_logins
                    (system_user_id, source, action, success, details)
                VALUES (?, 'cli', ?, 1, ?)
            ")->execute([$userId, $action, $details]);
        }
        // Also log to the main activity_log for admin visibility
        if (function_exists('logActivity')) {
            logActivity(0, 'SYSUSER_' . $action, $details);
        }
    } catch (PDOException $e) {
        // Non-fatal
    }
}

// ============================================================
// HELPERS — Lookup
// ============================================================
function findUserById(PDO $db, int $id): ?array {
    $s = $db->prepare("SELECT * FROM system_users WHERE id = ? LIMIT 1");
    $s->execute([$id]);
    $row = $s->fetch(PDO::FETCH_ASSOC);
    return $row ?: null;
}

function findUserByUsername(PDO $db, string $username): ?array {
    $s = $db->prepare("SELECT * FROM system_users WHERE username = ? LIMIT 1");
    $s->execute([$username]);
    $row = $s->fetch(PDO::FETCH_ASSOC);
    return $row ?: null;
}

// ============================================================
// COMMANDS
// ============================================================

/**
 * --list : show all system users
 */
function cmdList(PDO $db): int {
    $rows = $db->query("
        SELECT id, username, display_name, role, enabled,
               api_key_prefix, last_used_at, last_ip, created_at
          FROM system_users
         ORDER BY id
    ")->fetchAll(PDO::FETCH_ASSOC);

    if (empty($rows)) {
        out("No system users found.", 'yellow');
        return 0;
    }

    out('');
    out('System Users', 'bold');
    out(str_repeat('─', 118), 'dim');
    printf("%-4s %-16s %-28s %-10s %-8s %-14s %-19s\n",
        'ID', 'Username', 'Display Name', 'Role', 'Enabled', 'Prefix', 'Last Used');
    out(str_repeat('─', 118), 'dim');

    foreach ($rows as $r) {
        printf("%-4d %-16s %-28s %-10s %-8s %-14s %-19s\n",
            (int)$r['id'],
            substr($r['username'], 0, 16),
            substr($r['display_name'], 0, 28),
            $r['role'],
            $r['enabled'] ? 'yes' : 'no',
            $r['api_key_prefix'],
            $r['last_used_at'] ?: '—'
        );
    }
    out(str_repeat('─', 118), 'dim');
    out("Total: " . count($rows) . " user(s)", 'dim');
    out('');

    return 0;
}

/**
 * --reset-default : rotate the default `vms-system` key
 *                   (creates the row if missing)
 */
function cmdResetDefault(PDO $db): int {
    $username = 'vms-system';
    $key      = generateApiKey();
    $hash     = password_hash($key, PASSWORD_BCRYPT);
    $prefix   = apiKeyPrefix($key);

    $existing = findUserByUsername($db, $username);

    if ($existing) {
        $db->prepare("
            UPDATE system_users
               SET api_key_hash = ?, api_key_prefix = ?, updated_at = NOW()
             WHERE id = ?
        ")->execute([$hash, $prefix, $existing['id']]);

        logCliAction($db, (int)$existing['id'], 'KEY_ROTATE', 'reset-default');

        box('Rotated default system user key', [
            "Username:  $username",
            "ID:        {$existing['id']}",
            "Prefix:    $prefix",
        ]);
    } else {
        $db->prepare("
            INSERT INTO system_users
                (username, display_name, api_key_hash, api_key_prefix, role, enabled, notes)
            VALUES (?, 'VMS Service Account', ?, ?, 'system', 1,
                    'Primary service account for cron, webhook, and API.')
        ")->execute([$username, $hash, $prefix]);

        $id = (int)$db->lastInsertId();
        logCliAction($db, $id, 'CREATE', 'reset-default');

        box('Created default system user', [
            "Username:  $username",
            "ID:        $id",
            "Prefix:    $prefix",
        ]);
    }

    out('');
    out('API KEY: ' . $key, 'green');
    out('STORE THIS KEY — it cannot be shown again.', 'yellow');
    out('', 'dim');
    out('Example usage in a cron or API client:', 'dim');
    out('  export VMS_SYSTEM_KEY="' . $key . '"', 'cyan');
    out('', 'dim');

    return 0;
}

/**
 * --create=USERNAME --role=ROLE --name="NAME" [--borrower=N] [--note="..."]
 */
function cmdCreate(PDO $db, array $opts): int {
    $username = $opts['create']  ?? '';
    $role     = $opts['role']    ?? 'system';
    $name     = $opts['name']    ?? '';
    $borrower = isset($opts['borrower']) ? (int)$opts['borrower'] : null;
    $note     = $opts['note']    ?? '';

    if ($username === '') {
        fwrite(STDERR, "❌ --create requires a username\n");
        return 1;
    }
    if (!preg_match('/^[a-z0-9\-_]{3,64}$/i', $username)) {
        fwrite(STDERR, "❌ Username must be 3–64 chars: letters, digits, - or _\n");
        return 1;
    }
    if (!in_array($role, ['system','admin','cron','api'], true)) {
        fwrite(STDERR, "❌ --role must be one of: system, admin, cron, api\n");
        return 1;
    }
    if ($name === '') {
        $name = $username; // fallback display name
    }

    if (findUserByUsername($db, $username)) {
        fwrite(STDERR, "❌ User '{$username}' already exists. Use --rotate or --reset-default.\n");
        return 1;
    }

    $key    = generateApiKey();
    $hash   = password_hash($key, PASSWORD_BCRYPT);
    $prefix = apiKeyPrefix($key);

    $db->prepare("
        INSERT INTO system_users
            (username, display_name, api_key_hash, api_key_prefix, role,
             bound_borrowernumber, enabled, notes)
        VALUES (?, ?, ?, ?, ?, ?, 1, ?)
    ")->execute([$username, $name, $hash, $prefix, $role, $borrower, $note]);

    $id = (int)$db->lastInsertId();
    logCliAction($db, $id, 'CREATE', "created $username ($role)");

    box("Created system user #$id", [
        "Username:  $username",
        "Role:      $role",
        "Name:      $name",
        "Prefix:    $prefix",
        "Borrower:  " . ($borrower ?: '—'),
    ]);

    out('');
    out('API KEY: ' . $key, 'green');
    out('STORE THIS KEY — it cannot be shown again.', 'yellow');
    out('', 'dim');

    return 0;
}

/**
 * --rotate=ID : generate a new key for the given user id
 */
function cmdRotate(PDO $db, array $opts): int {
    $id = (int)($opts['rotate'] ?? 0);
    if ($id <= 0) {
        fwrite(STDERR, "❌ --rotate requires a numeric user id\n");
        return 1;
    }

    $user = findUserById($db, $id);
    if (!$user) {
        fwrite(STDERR, "❌ No user with id $id\n");
        return 1;
    }

    $key    = generateApiKey();
    $hash   = password_hash($key, PASSWORD_BCRYPT);
    $prefix = apiKeyPrefix($key);

    $db->prepare("
        UPDATE system_users
           SET api_key_hash = ?, api_key_prefix = ?, updated_at = NOW()
         WHERE id = ?
    ")->execute([$hash, $prefix, $id]);

    logCliAction($db, $id, 'KEY_ROTATE', "rotated key for {$user['username']}");

    box("Rotated key for #$id ({$user['username']})", [
        "Prefix:  $prefix",
    ]);

    out('');
    out('API KEY: ' . $key, 'green');
    out('STORE THIS KEY — it cannot be shown again.', 'yellow');
    out('', 'dim');

    return 0;
}

/**
 * --disable=USERNAME / --enable=USERNAME
 */
function cmdEnableDisable(PDO $db, string $username, bool $enable): int {
    $user = findUserByUsername($db, $username);
    if (!$user) {
        fwrite(STDERR, "❌ No user '{$username}'\n");
        return 1;
    }

    $db->prepare("UPDATE system_users SET enabled = ?, updated_at = NOW() WHERE id = ?")
       ->execute([$enable ? 1 : 0, $user['id']]);

    logCliAction($db, (int)$user['id'],
        $enable ? 'ENABLE' : 'DISABLE',
        ($enable ? 'enabled' : 'disabled') . " $username");

    out(($enable ? "✅ Enabled" : "✅ Disabled") . " '{$username}' (id {$user['id']})", 'green');
    return 0;
}

/**
 * --delete=USERNAME
 */
function cmdDelete(PDO $db, string $username): int {
    $user = findUserByUsername($db, $username);
    if (!$user) {
        fwrite(STDERR, "❌ No user '{$username}'\n");
        return 1;
    }

    // Safety: never delete the last enabled 'system' user
    if ($user['role'] === 'system') {
        $count = (int)$db->query("
            SELECT COUNT(*) FROM system_users
             WHERE role = 'system' AND enabled = 1
        ")->fetchColumn();
        if ($count <= 1) {
            fwrite(STDERR, "❌ Refusing to delete the last enabled system user.\n");
            return 1;
        }
    }

    $db->prepare("DELETE FROM system_users WHERE id = ?")->execute([$user['id']]);
    logCliAction($db, null, 'DELETE', "deleted $username");

    out("✅ Deleted '{$username}' (id {$user['id']})", 'green');
    return 0;
}

/**
 * --logins=ID [--limit=N]
 */
function cmdLogins(PDO $db, array $opts): int {
    $id    = (int)($opts['logins'] ?? 0);
    $limit = max(1, min(200, (int)($opts['limit'] ?? 20)));

    $user = findUserById($db, $id);
    if (!$user) {
        fwrite(STDERR, "❌ No user with id $id\n");
        return 1;
    }

    $s = $db->prepare("
        SELECT source, action, success, ip_address, details, created_at
          FROM system_user_logins
         WHERE system_user_id = ?
         ORDER BY id DESC
         LIMIT $limit
    ");
    $s->execute([$id]);
    $rows = $s->fetchAll(PDO::FETCH_ASSOC);

    box("Recent logins for #$id ({$user['username']})", [
        "Showing last " . count($rows) . " of up to $limit",
    ]);

    if (empty($rows)) {
        out('  (no login history)', 'dim');
        return 0;
    }

    out('');
    out(str_repeat('─', 100), 'dim');
    printf("%-10s %-24s %-8s %-16s %-19s\n",
        'Source', 'Action', 'OK', 'IP', 'When');
    out(str_repeat('─', 100), 'dim');

    foreach ($rows as $r) {
        printf("%-10s %-24s %-8s %-16s %-19s\n",
            $r['source'],
            substr($r['action'], 0, 24),
            $r['success'] ? 'yes' : 'no',
            $r['ip_address'] ?: '—',
            $r['created_at']
        );
    }
    out(str_repeat('─', 100), 'dim');
    out('');

    return 0;
}

/**
 * --verify=USERNAME --key=KEY : test whether an API key is valid
 */
function cmdVerify(PDO $db, array $opts): int {
    $username = $opts['verify'] ?? '';
    $key      = $opts['key']    ?? '';
    if ($username === '' || $key === '') {
        fwrite(STDERR, "❌ --verify requires --verify=USERNAME --key=KEY\n");
        return 1;
    }

    $user = findUserByUsername($db, $username);
    if (!$user) {
        out("❌ User '{$username}' not found", 'red');
        return 1;
    }
    if (!$user['enabled']) {
        out("❌ User '{$username}' is disabled", 'red');
        return 1;
    }
    if (!password_verify($key, $user['api_key_hash'])) {
        out("❌ API key does NOT match", 'red');
        return 1;
    }
    out("✅ API key is VALID for '{$username}'", 'green');
    return 0;
}

// ============================================================
// ARGUMENT PARSER
// ============================================================
function parseArgs(array $argv): array {
    $opts = [];
    foreach (array_slice($argv, 1) as $arg) {
        if (strpos($arg, '--') === 0) {
            $arg = substr($arg, 2);
            if (strpos($arg, '=') !== false) {
                [$k, $v] = explode('=', $arg, 2);
                $opts[$k] = $v;
            } else {
                $opts[$arg] = true;
            }
        }
    }
    return $opts;
}

// ============================================================
// HELP
// ============================================================
function showHelp(): void {
    out('');
    out('VMS System User Setup — v8.6', 'bold');
    out(str_repeat('─', 70), 'dim');
    out('Manage service accounts for cron, webhook, and API access.', 'dim');
    out('');
    out('COMMANDS:', 'bold');
    out('');
    out('  --list', 'cyan');
    out('      Show every system user with role, prefix, and last use.');
    out('');
    out('  --reset-default', 'cyan');
    out('      Rotate the default `vms-system` API key (creates it if missing).');
    out('');
    out('  --create=USERNAME --role=ROLE --name="DISPLAY NAME"', 'cyan');
    out('      Create a new service account. ROLE ∈ {system, admin, cron, api}.');
    out('      Optional: --borrower=N  --note="..."');
    out('');
    out('  --rotate=ID', 'cyan');
    out('      Generate a fresh API key for the user with the given numeric ID.');
    out('');
    out('  --enable=USERNAME   /   --disable=USERNAME', 'cyan');
    out('      Toggle whether an account can authenticate.');
    out('');
    out('  --delete=USERNAME', 'cyan');
    out('      Permanently remove an account (refuses to delete the last system).');
    out('');
    out('  --logins=ID [--limit=N]', 'cyan');
    out('      Show recent login history for the given user ID.');
    out('');
    out('  --verify=USERNAME --key=KEY', 'cyan');
    out('      Test whether an API key matches the stored hash.');
    out('');
    out('EXAMPLES:', 'bold');
    out('  sudo -u www-data php system_user_setup.php --list', 'green');
    out('  sudo -u www-data php system_user_setup.php --reset-default', 'green');
    out('  sudo -u www-data php system_user_setup.php \\', 'green');
    out('       --create=vms-cron --role=cron --name="VMS Cron Worker"', 'green');
    out('  sudo -u www-data php system_user_setup.php --rotate=1', 'green');
    out('');
    out('NOTE: API keys are shown ONLY at creation/rotation time. Store them', 'yellow');
    out('      in a password manager. They cannot be retrieved later.', 'yellow');
    out('');
}

// ============================================================
// MAIN
// ============================================================
ensureSystemTables($db);

$opts = parseArgs($argv);

if (empty($opts) || isset($opts['help']) || isset($opts['h'])) {
    showHelp();
    exit(0);
}

try {
    if (isset($opts['list'])) {
        exit(cmdList($db));
    }
    if (isset($opts['reset-default'])) {
        exit(cmdResetDefault($db));
    }
    if (isset($opts['create'])) {
        exit(cmdCreate($db, $opts));
    }
    if (isset($opts['rotate'])) {
        exit(cmdRotate($db, $opts));
    }
    if (isset($opts['enable']) && is_string($opts['enable'])) {
        exit(cmdEnableDisable($db, $opts['enable'], true));
    }
    if (isset($opts['disable']) && is_string($opts['disable'])) {
        exit(cmdEnableDisable($db, $opts['disable'], false));
    }
    if (isset($opts['delete']) && is_string($opts['delete'])) {
        exit(cmdDelete($db, $opts['delete']));
    }
    if (isset($opts['logins'])) {
        exit(cmdLogins($db, $opts));
    }
    if (isset($opts['verify'])) {
        exit(cmdVerify($db, $opts));
    }

    fwrite(STDERR, "❌ Unknown command. Run with --help.\n");
    exit(1);

} catch (PDOException $e) {
    fwrite(STDERR, "❌ DB error: " . $e->getMessage() . "\n");
    exit(1);
} catch (Throwable $e) {
    fwrite(STDERR, "❌ Error: " . $e->getMessage() . "\n");
    exit(1);
}