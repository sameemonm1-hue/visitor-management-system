<?php
/**
 * VMS + Koha Unified Backup — Download Endpoint
 * Version: 1.0
 */

require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/backup_helper.php';

startSecureSession();
requireKohaLogin();

// Admin-only
if (!function_exists('hasKohaRole') || !hasKohaRole('admin')) {
    http_response_code(403);
    die('Access denied.');
}

$file = basename($_GET['file'] ?? '');

// Strict filename validation
if (!preg_match('/^backup_(vms|koha|both)_[0-9_\-]+\.sql$/', $file)) {
    http_response_code(400);
    die('Invalid file name.');
}

$backupDirInfo = vms_backup_ensure_dir();
$path = rtrim($backupDirInfo['path'], '/') . '/' . $file;

if (!is_file($path) || !is_readable($path)) {
    http_response_code(404);
    die('File not found.');
}

// Log the download
if (function_exists('logActivity')) {
    $u = function_exists('getCurrentUser') ? getCurrentUser() : null;
    logActivity($u['id'] ?? 0, 'BACKUP_DOWNLOAD', "Downloaded: $file");
}

// Headers
while (ob_get_level() > 0) ob_end_clean();
header('Content-Type: application/sql; charset=utf-8');
header('Content-Disposition: attachment; filename="' . $file . '"');
header('Content-Length: ' . filesize($path));
header('Cache-Control: private, no-store, must-revalidate');
header('Pragma: no-cache');
header('X-Content-Type-Options: nosniff');

readfile($path);
exit;