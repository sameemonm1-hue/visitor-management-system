<?php
/**
 * Visitor Management System - Entry Point (index.php)
 * Version: 7.3 FINAL
 *
 * Purpose:
 *   - Serve as the single entry point for /cgi-bin/koha/visitor/
 *   - Detect Koha login status
 *   - Redirect logged-in users straight to dashboard.php
 *   - Redirect non-logged-in users to Koha login, then back to dashboard.php
 *
 * IMPORTANT:
 *   - The return URL after Koha login points to dashboard.php (NOT mainpage.pl)
 *   - Avoids infinite redirect loops
 */

// ------------------------------------------------------------
// Bootstrap
// ------------------------------------------------------------
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/koha.php';
require_once __DIR__ . '/includes/auth.php';

startSecureSession();

// ------------------------------------------------------------
// If the user is already authenticated with Koha → go to dashboard
// ------------------------------------------------------------
if (isKohaLoggedIn()) {
    header('Location: dashboard.php');
    exit;
}

// ------------------------------------------------------------
// Not logged in → send to Koha login, with return URL pointing
// directly at dashboard.php (not the visitor index).
// ------------------------------------------------------------
$returnUrl = urlencode(
    'http://' . $_SERVER['HTTP_HOST'] . '/cgi-bin/koha/visitor/dashboard.php'
);

$kohaLoginUrl = KOHA_INTRANET_URL . '/cgi-bin/koha/mainpage.pl?return=' . $returnUrl;

header("Location: $kohaLoginUrl");
exit;
