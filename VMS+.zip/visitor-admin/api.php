<?php
/**
 * Visitor Management System - REST API
 * Version: 7.5 Advanced Edition
 * 
 * Endpoints for mobile apps and external integrations
 * 
 * Usage:
 *   GET  /api.php?endpoint=stats
 *   GET  /api.php?endpoint=member&id=CARD123
 *   POST /api.php?endpoint=entry   { "id": "CARD123", "purpose": "Study" }
 *   POST /api.php?endpoint=exit    { "id": "CARD123" }
 *   GET  /api.php?endpoint=books&search=python
 *   GET  /api.php?endpoint=occupancy
 * 
 * Authentication: X-API-Key header or api_key parameter
 */

// CORS
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, X-API-Key, Authorization');
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

$possiblePaths = [__DIR__ . '/includes', '/usr/share/koha/intranet/cgi-bin/koha/visitor/includes'];
$includePath = null;
foreach ($possiblePaths as $p) { if (file_exists($p . '/config.php')) { $includePath = $p; break; } }
if (!$includePath) { http_response_code(500); die(json_encode(['error' => 'Config not found'])); }

define('VMS_INCLUDES', $includePath);
require_once VMS_INCLUDES . '/config.php';

$db = getDB();
$settings = getSettings();

// ============================================================
// API KEY AUTHENTICATION (optional)
// ============================================================
$apiKey = $_SERVER['HTTP_X_API_KEY'] ?? $_GET['api_key'] ?? null;
$validKey = $settings['api_key'] ?? null;

// If API key configured, validate it
if (!empty($validKey) && $apiKey !== $validKey) {
    http_response_code(401);
    echo json_encode(['error' => 'Invalid API key']);
    exit;
}

// ============================================================
// ROUTER
// ============================================================
$endpoint = $_GET['endpoint'] ?? '';
$method = $_SERVER['REQUEST_METHOD'];

// Parse JSON body for POST/PUT
$input = [];
if (in_array($method, ['POST', 'PUT'])) {
    $body = file_get_contents('php://input');
    $input = json_decode($body, true) ?: $_POST;
}

try {
    switch ($endpoint) {
        
        case 'stats':
            $stats = getCurrentStats();
            echo json_encode([
                'success' => true,
                'data' => [
                    'inside' => $stats['inside'] ?? 0,
                    'today' => $stats['today'] ?? 0,
                    'members' => ($stats['inside'] ?? 0) - ($stats['guests'] ?? 0),
                    'guests' => $stats['guests'] ?? 0,
                    'male' => $stats['male'] ?? 0,
                    'female' => $stats['female'] ?? 0,
                    'unauthorized' => $stats['unauthorized'] ?? 0,
                ],
                'timestamp' => date('c')
            ]);
            break;
        
        case 'occupancy':
            $inside = (int)$db->query("SELECT COUNT(*) FROM entry_exit_logs WHERE status = 'inside'")->fetchColumn();
            $capacity = (int)($settings['max_capacity'] ?? 100);
            echo json_encode([
                'success' => true,
                'data' => [
                    'current' => $inside,
                    'capacity' => $capacity,
                    'percent' => $capacity > 0 ? round(($inside / $capacity) * 100, 1) : 0,
                    'status' => $inside >= $capacity * 0.95 ? 'critical' : ($inside >= $capacity * 0.8 ? 'warning' : 'normal')
                ]
            ]);
            break;
        
        case 'member':
            $id = $_GET['id'] ?? '';
            if (empty($id)) throw new Exception('Member ID required');
            $member = getKohaMember($id);
            if (!$member) throw new Exception('Member not found');
            echo json_encode(['success' => true, 'data' => $member]);
            break;
        
        case 'entry':
            $id = $input['id'] ?? '';
            $purpose = $input['purpose'] ?? 'Reading/Study';
            if (empty($id)) throw new Exception('Member ID required');
            
            $member = getKohaMember($id);
            if (!$member) throw new Exception('Member not found');
            
            $check = $db->prepare("SELECT id FROM entry_exit_logs WHERE admno = ? AND status = 'inside'");
            $check->execute([$member['cardnumber']]);
            if ($check->fetch()) throw new Exception('Member already inside');
            
            $insert = $db->prepare("
                INSERT INTO entry_exit_logs 
                (admno, member_name, member_category, entry_date, entry_time, purpose, status, entry_type) 
                VALUES (?, ?, ?, CURDATE(), CURTIME(), ?, 'inside', 'member')
            ");
            $insert->execute([
                $member['cardnumber'],
                $member['full_name'],
                $member['category_description'] ?? $member['categorycode'],
                $purpose
            ]);
            
            logActivity(0, 'API_ENTRY', "API entry: {$member['full_name']}");
            
            echo json_encode([
                'success' => true,
                'message' => 'Entry recorded',
                'data' => ['member' => $member['full_name'], 'time' => date('H:i:s')]
            ]);
            break;
        
        case 'exit':
            $id = $input['id'] ?? '';
            if (empty($id)) throw new Exception('Member ID required');
            
            $member = getKohaMember($id);
            if (!$member) throw new Exception('Member not found');
            
            $update = $db->prepare("UPDATE entry_exit_logs SET exit_time = NOW(), status = 'exited' WHERE admno = ? AND status = 'inside'");
            $update->execute([$member['cardnumber']]);
            
            if ($update->rowCount() === 0) throw new Exception('Member not inside');
            
            logActivity(0, 'API_EXIT', "API exit: {$member['full_name']}");
            
            echo json_encode([
                'success' => true,
                'message' => 'Exit recorded',
                'data' => ['member' => $member['full_name'], 'time' => date('H:i:s')]
            ]);
            break;
        
        case 'books':
            $search = $_GET['search'] ?? '';
            $limit = min((int)($_GET['limit'] ?? 20), 100);
            
            $koha = getKoha();
            if (!$koha) throw new Exception('Koha not available');
            
            $stmt = $koha->prepare("
                SELECT b.biblionumber, b.title, b.author, b.isbn,
                    (SELECT COUNT(*) FROM items WHERE biblionumber = b.biblionumber AND notforloan = 0) as available
                FROM biblio b
                WHERE b.title LIKE ? OR b.author LIKE ? OR b.isbn LIKE ?
                ORDER BY b.title
                LIMIT ?
            ");
            $term = "%$search%";
            $stmt->execute([$term, $term, $term, $limit]);
            $books = $stmt->fetchAll();
            
            echo json_encode(['success' => true, 'data' => $books]);
            break;
        
        case 'logs':
            $limit = min((int)($_GET['limit'] ?? 50), 200);
            $type = $_GET['type'] ?? 'all';
            
            $where = "1=1";
            $params = [];
            if ($type === 'member' || $type === 'guest') {
                $where = "entry_type = ?";
                $params[] = $type;
            }
            
            $stmt = $db->prepare("SELECT * FROM entry_exit_logs WHERE $where ORDER BY created_at DESC LIMIT ?");
            $stmt->execute(array_merge($params, [$limit]));
            echo json_encode(['success' => true, 'data' => $stmt->fetchAll()]);
            break;
        
        case 'guest_entry':
            $settings = getSettings();
            if (!($settings['guest_enabled'] ?? 1)) throw new Exception('Guest mode disabled');
            
            $guestNum = (int)($db->query("SELECT guest_daily_counter FROM settings LIMIT 1")->fetchColumn() ?: 1);
            $prefix = $settings['guest_prefix'] ?? 'GUEST-';
            $padding = (int)($settings['guest_padding'] ?? 4);
            $admno = $prefix . str_pad($guestNum, $padding, '0', STR_PAD_LEFT);
            
            $insert = $db->prepare("
                INSERT INTO entry_exit_logs 
                (admno, member_name, member_category, entry_date, entry_time, purpose, status, entry_type) 
                VALUES (?, ?, 'Guest', CURDATE(), CURTIME(), ?, 'inside', 'guest')
            ");
            $insert->execute([$admno, "Guest $guestNum", 'Reading/Study']);
            
            $db->query("UPDATE settings SET guest_daily_counter = guest_daily_counter + 1");
            
            echo json_encode([
                'success' => true,
                'message' => "Guest $guestNum entered",
                'data' => ['guest_number' => $guestNum, 'guest_id' => $admno]
            ]);
            break;
        
        case 'health':
            echo json_encode([
                'success' => true,
                'data' => [
                    'status' => 'healthy',
                    'database' => $db !== null,
                    'koha' => isKohaAvailable(),
                    'version' => APP_VERSION,
                    'time' => date('c')
                ]
            ]);
            break;
        
        case '':
            echo json_encode([
                'success' => true,
                'name' => 'Visitor Management System API',
                'version' => APP_VERSION,
                'endpoints' => [
                    'GET  ?endpoint=health',
                    'GET  ?endpoint=stats',
                    'GET  ?endpoint=occupancy',
                    'GET  ?endpoint=member&id=XXX',
                    'GET  ?endpoint=books&search=XXX',
                    'GET  ?endpoint=logs&limit=50&type=member|guest',
                    'POST ?endpoint=entry     { id, purpose }',
                    'POST ?endpoint=exit      { id }',
                    'POST ?endpoint=guest_entry',
                ]
            ]);
            break;
        
        default:
            http_response_code(404);
            echo json_encode(['error' => 'Unknown endpoint: ' . $endpoint]);
    }
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>