<?php
/**
 * Koha Stock Verification Tool
 * Version: 1.2 FINAL — Standalone Koha-integrated physical inventory tool
 *
 * CHANGELOG v1.2
 *   • Institution name is now deeply normalized so the shared VMS
 *     footer renders "Library & information" exactly as typed —
 *     no double-encoded "&amp;" leaking through.
 *   • Publishes window.VMS_INSTITUTION_NAME for JS-side references.
 *   • Footer output buffered + post-processed to collapse &amp; chains.
 *
 * CHANGELOG v1.1
 *   • Added shared VMS footer partial (same as isbn.php / class.php /
 *     labels.php / idcards.php / system.php / OPAC)
 *
 * FEATURES
 *   • Direct DB access to koha_library (no VMS dependency)
 *   • Session-based verification campaigns
 *   • Live barcode scanning with status tracking
 *   • Discrepancy reports, CSV/Excel export, print view
 *
 * Location:
 *   /usr/share/koha/intranet/cgi-bin/visitor/stock_verify.php
 *
 * URL:
 *   http://localhost:8081/cgi-bin/koha/visitor/stock_verify.php
 */

// ============================================================
// 1. CONFIG — locate Koha DB config
// ============================================================
$configCandidates = [
    '/etc/koha/sites/library/koha-conf.xml',
    '/etc/koha/koha-conf.xml',
];

$kohaConf = null;
foreach ($configCandidates as $c) {
    if (is_readable($c)) { $kohaConf = $c; break; }
}

if (!$kohaConf) {
    die('Could not locate koha-conf.xml. Check /etc/koha/sites/<instance>/koha-conf.xml');
}

// Parse koha-conf.xml
$xml = @simplexml_load_file($kohaConf);
if (!$xml) {
    die('Could not parse ' . htmlspecialchars($kohaConf));
}

$dbConfig = [
    'host' => (string)($xml->config->hostname ?? 'localhost'),
    'port' => (string)($xml->config->port ?? '3306'),
    'name' => (string)($xml->config->database ?? 'koha_library'),
    'user' => (string)($xml->config->user ?? 'koha_library'),
    'pass' => (string)($xml->config->pass ?? ''),
];

// ============================================================
// 1a. LOAD SHARED FOOTER PARTIAL (VMS family — same as all siblings)
// ============================================================
$footerPartialPaths = [
    __DIR__ . '/includes/footer_partial.php',
    __DIR__ . '/../includes/footer_partial.php',
    dirname(__DIR__) . '/includes/footer_partial.php',
    '/usr/share/koha/intranet/cgi-bin/koha/visitor/includes/footer_partial.php',
    '/usr/share/koha/intranet/cgi-bin/visitor/includes/footer_partial.php',
];
foreach ($footerPartialPaths as $p) {
    if (file_exists($p)) { require_once $p; break; }
}

// ============================================================
// 1b. INSTITUTION NAME — deeply normalized to plain text  [CHANGED v1.2]
// ============================================================
if (!function_exists('sv_clean_institution')) {
    /**
     * Aggressively normalize an institution name to plain text.
     *
     * "Library & information"          → "Library & information"
     * "Library &amp; information"       → "Library & information"
     * "Library &amp;amp; information"   → "Library & information"
     * "Library &amp;amp;amp; info"      → "Library & information"
     */
    function sv_clean_institution(string $raw): string {
        $raw = trim($raw);
        if ($raw === '') return 'My Library';

        if (!mb_check_encoding($raw, 'UTF-8')) {
            $fixed = @mb_convert_encoding($raw, 'UTF-8', 'ISO-8859-1');
            if ($fixed !== false && $fixed !== '') $raw = $fixed;
        }

        // Loop-decode until stable (max 5 passes)
        $prev = null; $out = $raw; $i = 0;
        while ($prev !== $out && $i < 5) {
            $prev = $out;
            $out  = html_entity_decode($out, ENT_QUOTES | ENT_HTML5, 'UTF-8');
            $i++;
        }

        // Defensive collapse of residual literal entity sequences
        $out = str_replace(
            ['&amp;amp;amp;', '&amp;amp;', '&amp;', '&AMP;', '&Amp;'],
            '&',
            $out
        );
        $out = str_replace(
            ['&quot;', '&#039;', '&#39;', '&apos;', '&lt;', '&gt;', '&nbsp;'],
            ['"',       "'",       "'",      "'",       '<',    '>',    ' '],
            $out
        );

        $out = preg_replace('/\s+/u', ' ', $out);
        $out = trim($out);

        return $out !== '' ? $out : 'My Library';
    }
}

// Try to read institution name from the VMS settings table (best-effort)
$institutionName = 'My Library';
$vmsSettingsPaths = [
    __DIR__ . '/includes/config.php',
    __DIR__ . '/../includes/config.php',
    '/usr/share/koha/intranet/cgi-bin/visitor/includes/config.php',
    '/usr/share/koha/intranet/cgi-bin/koha/visitor/includes/config.php',
];
foreach ($vmsSettingsPaths as $cfg) {
    if (file_exists($cfg)) {
        // Don't require — config.php already loaded by footer_partial in
        // most setups. Only require if getSettings() isn't already present.
        if (!function_exists('getSettings')) {
            @require_once $cfg;
        }
        break;
    }
}

if (function_exists('getSettings')) {
    try {
        $vmsSettings = getSettings();
        if (is_array($vmsSettings) && !empty($vmsSettings['institution_name'])) {
            $institutionName = sv_clean_institution((string)$vmsSettings['institution_name']);
        }
    } catch (Throwable $e) {
        // ignore — fall back to constant or default
    }
}

// Fallback: constant
if ($institutionName === 'My Library'
    && defined('INSTITUTION_NAME')
    && trim((string)INSTITUTION_NAME) !== '') {
    $institutionName = sv_clean_institution((string)INSTITUTION_NAME);
}

// Publish everywhere so any footer partial or JS can read it
$GLOBALS['institution_name'] = $institutionName;
$GLOBALS['institutionName']  = $institutionName;
$GLOBALS['INSTITUTION_NAME'] = $institutionName;
if (isset($GLOBALS['settings']) && is_array($GLOBALS['settings'])) {
    $GLOBALS['settings']['institution_name'] = $institutionName;
}

// ============================================================
// 2. SESSION
// ============================================================
if (session_status() === PHP_SESSION_NONE) {
    session_name('CGISESSID');
    if (isset($_COOKIE['CGISESSID'])) session_id($_COOKIE['CGISESSID']);
    session_start();
}

// ============================================================
// 3. DB CONNECTION
// ============================================================
try {
    $dsn = "mysql:host={$dbConfig['host']};port={$dbConfig['port']};dbname={$dbConfig['name']};charset=utf8mb4";
    $db = new PDO($dsn, $dbConfig['user'], $dbConfig['pass'], [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
        PDO::ATTR_TIMEOUT            => 5,
    ]);
} catch (PDOException $e) {
    die('<div style="font-family:sans-serif;padding:20px;color:#c00;">'
      . '<h3>Koha database error</h3>'
      . '<p>' . htmlspecialchars($e->getMessage()) . '</p>'
      . '<p>Check user privileges on <code>' . htmlspecialchars($dbConfig['name']) . '</code>.</p>'
      . '</div>');
}

// ============================================================
// 4. AUTO-INSTALL SCHEMA (idempotent)
// ============================================================
function vms_sv_ensure_schema(PDO $db): void {
    $db->exec("
        CREATE TABLE IF NOT EXISTS vms_stock_verification_sessions (
            id              INT AUTO_INCREMENT PRIMARY KEY,
            session_code    VARCHAR(20)  NOT NULL UNIQUE,
            title           VARCHAR(200) NOT NULL,
            description     TEXT         NULL,
            branch_filter   VARCHAR(50)  NULL,
            itype_filter    VARCHAR(50)  NULL,
            ccode_filter    VARCHAR(50)  NULL,
            location_filter VARCHAR(50)  NULL,
            status          ENUM('open','paused','closed') NOT NULL DEFAULT 'open',
            started_by      INT          NULL,
            started_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
            closed_by       INT          NULL,
            closed_at       DATETIME     NULL,
            total_items     INT          NOT NULL DEFAULT 0,
            total_scanned   INT          NOT NULL DEFAULT 0,
            total_found     INT          NOT NULL DEFAULT 0,
            total_missing   INT          NOT NULL DEFAULT 0,
            total_misplaced INT          NOT NULL DEFAULT 0,
            total_damaged   INT          NOT NULL DEFAULT 0,
            notes           TEXT         NULL,
            created_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_status     (status),
            INDEX idx_started_at (started_at),
            INDEX idx_branch     (branch_filter)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");

    $db->exec("
        CREATE TABLE IF NOT EXISTS vms_stock_verification_scans (
            id                BIGINT AUTO_INCREMENT PRIMARY KEY,
            session_id        INT          NOT NULL,
            itemnumber        INT          NULL,
            barcode           VARCHAR(50)  NOT NULL,
            title             VARCHAR(255) NULL,
            author            VARCHAR(255) NULL,
            itemcallnumber    VARCHAR(100) NULL,
            homebranch        VARCHAR(50)  NULL,
            holdingbranch     VARCHAR(50)  NULL,
            location          VARCHAR(50)  NULL,
            itype             VARCHAR(50)  NULL,
            ccode             VARCHAR(50)  NULL,
            found_location    VARCHAR(100) NULL,
            status            ENUM('found','missing','damaged','misplaced','not_found','withdrawn') NOT NULL,
            notes             TEXT         NULL,
            scanned_by        INT          NULL,
            scanned_at        DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
            scan_duration_ms  INT          NULL,
            INDEX idx_session     (session_id),
            INDEX idx_itemnumber  (itemnumber),
            INDEX idx_barcode     (barcode),
            INDEX idx_status      (status),
            INDEX idx_scanned_at  (scanned_at),
            INDEX idx_uniq_scan   (session_id, itemnumber)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
}

vms_sv_ensure_schema($db);

// ============================================================
// 5. CURRENT USER (from Koha session, best-effort)
// ============================================================
$currentUserBn   = 0;
$currentUserName = 'Staff';

if (isset($_COOKIE['CGISESSID'])) {
    try {
        $cols = $db->query("SHOW COLUMNS FROM sessions")->fetchAll(PDO::FETCH_COLUMN);
        $sid  = $_COOKIE['CGISESSID'];
        $bn   = 0;

        if (in_array('a_session', $cols, true)) {
            $s = $db->prepare("SELECT a_session FROM sessions WHERE id = ?");
            $s->execute([$sid]);
            $row = (string)$s->fetchColumn();
            if ($row !== '' && preg_match('/"borrowernumber"\s*[:=]\s*"?(\d+)/', $row, $m)) {
                $bn = (int)$m[1];
            }
        } else {
            $s = $db->prepare("SELECT borrowernumber FROM sessions WHERE sessionid = ? AND lasttime > UNIX_TIMESTAMP() - 3600 LIMIT 1");
            $s->execute([$sid]);
            $bn = (int)$s->fetchColumn();
        }

        if ($bn) {
            $currentUserBn = $bn;
            $u = $db->prepare("
                SELECT CONCAT_WS(' ',
                    NULLIF(TRIM(title),''),
                    NULLIF(TRIM(firstname),''),
                    NULLIF(TRIM(surname),'')
                ) AS name
                FROM borrowers WHERE borrowernumber = ? LIMIT 1
            ");
            $u->execute([$bn]);
            $name = trim((string)$u->fetchColumn());
            if ($name !== '') $currentUserName = $name;
        }
    } catch (PDOException $e) {
        // Silent
    }
}

// ============================================================
// 6. HELPERS
// ============================================================
function sv_json(array $data, int $code = 200): void {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function sv_get_active_session(PDO $db, int $id): ?array {
    if ($id <= 0) return null;
    $s = $db->prepare("SELECT * FROM vms_stock_verification_sessions WHERE id = ? LIMIT 1");
    $s->execute([$id]);
    return $s->fetch() ?: null;
}

function sv_get_item_by_barcode(PDO $db, string $barcode): ?array {
    $s = $db->prepare("
        SELECT
            i.itemnumber, i.barcode, i.biblionumber, i.biblioitemnumber,
            i.itemcallnumber, i.homebranch, i.holdingbranch,
            i.location, i.itype, i.ccode, i.notforloan, i.damaged, i.itemlost, i.withdrawn,
            b.title, b.author,
            bi.isbn,
            br.branchname AS homebranch_name,
            hb.branchname AS holdingbranch_name,
            it.description AS itype_description,
            av.lib AS ccode_description
        FROM items i
        LEFT JOIN biblio      b  ON b.biblionumber      = i.biblionumber
        LEFT JOIN biblioitems bi ON bi.biblioitemnumber = i.biblioitemnumber
        LEFT JOIN branches    br ON br.branchcode       = i.homebranch
        LEFT JOIN branches    hb ON hb.branchcode       = i.holdingbranch
        LEFT JOIN itemtypes   it ON it.itemtype         = i.itype
        LEFT JOIN authorised_values av ON av.authorised_value = i.ccode
                                       AND av.category = 'CCODE'
        WHERE i.barcode = ?
        LIMIT 1
    ");
    $s->execute([$barcode]);
    $row = $s->fetch();
    return $row ?: null;
}

function sv_recount_session(PDO $db, int $sessionId): array {
    $s = $db->prepare("
        SELECT
            COUNT(*)                                AS scanned,
            SUM(status = 'found')                   AS found,
            SUM(status IN ('missing','not_found'))  AS missing,
            SUM(status = 'misplaced')               AS misplaced,
            SUM(status = 'damaged')                 AS damaged,
            SUM(status = 'withdrawn')               AS withdrawn
        FROM vms_stock_verification_scans
        WHERE session_id = ?
    ");
    $s->execute([$sessionId]);
    $counts = $s->fetch(PDO::FETCH_ASSOC);

    $u = $db->prepare("
        UPDATE vms_stock_verification_sessions SET
            total_scanned   = ?,
            total_found     = ?,
            total_missing   = ?,
            total_misplaced = ?,
            total_damaged   = ?
        WHERE id = ?
    ");
    $u->execute([
        (int)$counts['scanned'],
        (int)$counts['found'],
        (int)$counts['missing'],
        (int)$counts['misplaced'],
        (int)$counts['damaged'],
        $sessionId,
    ]);
    return $counts;
}

function sv_count_scope_items(PDO $db, array $sess): int {
    $where  = [];
    $params = [];

    if (!empty($sess['branch_filter'])) {
        $where[]  = "(i.homebranch = ? OR i.holdingbranch = ?)";
        $params[] = $sess['branch_filter'];
        $params[] = $sess['branch_filter'];
    }
    if (!empty($sess['itype_filter'])) {
        $where[]  = "i.itype = ?";
        $params[] = $sess['itype_filter'];
    }
    if (!empty($sess['ccode_filter'])) {
        $where[]  = "i.ccode = ?";
        $params[] = $sess['ccode_filter'];
    }
    if (!empty($sess['location_filter'])) {
        $where[]  = "i.location = ?";
        $params[] = $sess['location_filter'];
    }

    $where[] = "(i.withdrawn IS NULL OR i.withdrawn = 0)";

    $sql = "SELECT COUNT(*) FROM items i";
    if ($where) $sql .= " WHERE " . implode(' AND ', $where);

    $s = $db->prepare($sql);
    $s->execute($params);
    return (int)$s->fetchColumn();
}

// ============================================================
// 7. AJAX ROUTER
// ============================================================
if (isset($_GET['ajax']) || isset($_POST['ajax'])) {
    $action = $_GET['ajax'] ?? $_POST['ajax'];

    try {
        switch ($action) {

            case 'list_sessions': {
                $rows = $db->query("
                    SELECT * FROM vms_stock_verification_sessions
                    ORDER BY status = 'open' DESC, started_at DESC
                    LIMIT 100
                ")->fetchAll();

                foreach ($rows as &$r) {
                    $r['scope_total'] = sv_count_scope_items($db, $r);
                }
                unset($r);

                sv_json(['success' => true, 'sessions' => $rows]);
            }

            case 'get_session': {
                $id = (int)($_GET['id'] ?? 0);
                $sess = sv_get_active_session($db, $id);
                if (!$sess) sv_json(['success' => false, 'error' => 'Session not found'], 404);
                $sess['scope_total'] = sv_count_scope_items($db, $sess);
                sv_json(['success' => true, 'session' => $sess]);
            }

            case 'create_session': {
                $raw  = file_get_contents('php://input');
                $body = json_decode($raw, true) ?: $_POST;

                $title = trim((string)($body['title'] ?? ''));
                if ($title === '') sv_json(['success' => false, 'error' => 'Title is required'], 400);

                $code = 'SV-' . date('Ymd') . '-' . strtoupper(bin2hex(random_bytes(3)));

                $ins = $db->prepare("
                    INSERT INTO vms_stock_verification_sessions
                        (session_code, title, description, branch_filter, itype_filter, ccode_filter,
                         location_filter, status, started_by)
                    VALUES (?, ?, ?, ?, ?, ?, ?, 'open', ?)
                ");
                $ins->execute([
                    $code,
                    $title,
                    trim((string)($body['description'] ?? '')),
                    ($body['branch_filter'] ?? '') ?: null,
                    ($body['itype_filter'] ?? '') ?: null,
                    ($body['ccode_filter'] ?? '') ?: null,
                    ($body['location_filter'] ?? '') ?: null,
                    $currentUserBn,
                ]);
                $newId = (int)$db->lastInsertId();

                $sess = sv_get_active_session($db, $newId);
                $sess['scope_total'] = sv_count_scope_items($db, $sess);

                sv_json(['success' => true, 'session' => $sess]);
            }

            case 'close_session': {
                $id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
                $db->prepare("
                    UPDATE vms_stock_verification_sessions
                       SET status = 'closed', closed_by = ?, closed_at = NOW()
                     WHERE id = ?
                ")->execute([$currentUserBn, $id]);
                sv_json(['success' => true]);
            }

            case 'delete_session': {
                $id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
                $db->beginTransaction();
                $db->prepare("DELETE FROM vms_stock_verification_scans WHERE session_id = ?")->execute([$id]);
                $db->prepare("DELETE FROM vms_stock_verification_sessions WHERE id = ?")->execute([$id]);
                $db->commit();
                sv_json(['success' => true]);
            }

            case 'scan': {
                $raw  = file_get_contents('php://input');
                $body = json_decode($raw, true) ?: $_POST;

                $sessionId   = (int)($body['session_id'] ?? 0);
                $barcode     = trim((string)($body['barcode'] ?? ''));
                $status      = $body['status'] ?? 'found';
                $foundLoc    = trim((string)($body['found_location'] ?? ''));
                $notes       = trim((string)($body['notes'] ?? ''));

                $allowedStatuses = ['found','missing','damaged','misplaced','not_found','withdrawn'];
                if (!in_array($status, $allowedStatuses, true)) $status = 'found';

                if ($sessionId <= 0) sv_json(['success' => false, 'error' => 'No session'], 400);
                if ($barcode === '')  sv_json(['success' => false, 'error' => 'Empty barcode'], 400);

                $sess = sv_get_active_session($db, $sessionId);
                if (!$sess) sv_json(['success' => false, 'error' => 'Session not found'], 404);
                if ($sess['status'] === 'closed') sv_json(['success' => false, 'error' => 'Session is closed'], 400);

                $t0   = microtime(true);
                $item = sv_get_item_by_barcode($db, $barcode);

                if (!$item) {
                    $ins = $db->prepare("
                        INSERT INTO vms_stock_verification_scans
                            (session_id, itemnumber, barcode, status, found_location, notes, scanned_by)
                        VALUES (?, NULL, ?, 'not_found', ?, ?, ?)
                    ");
                    $ins->execute([$sessionId, $barcode, $foundLoc ?: null, $notes ?: 'Barcode not in catalog', $currentUserBn]);
                    sv_recount_session($db, $sessionId);

                    sv_json([
                        'success'    => true,
                        'outcome'    => 'unknown_barcode',
                        'barcode'    => $barcode,
                        'message'    => 'Barcode not found in catalog — logged as not_found.',
                    ]);
                }

                $itemnumber = (int)$item['itemnumber'];

                $chk = $db->prepare("
                    SELECT id, status, scanned_at
                      FROM vms_stock_verification_scans
                     WHERE session_id = ? AND itemnumber = ?
                     LIMIT 1
                ");
                $chk->execute([$sessionId, $itemnumber]);
                $existing = $chk->fetch();

                if ($existing) {
                    $db->prepare("
                        UPDATE vms_stock_verification_scans
                           SET status = ?, found_location = COALESCE(?, found_location),
                               notes = COALESCE(?, notes), scanned_at = NOW(),
                               scanned_by = ?
                         WHERE id = ?
                    ")->execute([
                        $status,
                        $foundLoc ?: null,
                        $notes    ?: null,
                        $currentUserBn,
                        $existing['id'],
                    ]);
                    sv_recount_session($db, $sessionId);

                    sv_json([
                        'success'  => true,
                        'outcome'  => 'duplicate_updated',
                        'barcode'  => $barcode,
                        'previous' => $existing['status'],
                        'new'      => $status,
                        'item'     => [
                            'itemnumber'    => $itemnumber,
                            'title'         => $item['title'],
                            'author'        => $item['author'],
                            'itemcallnumber'=> $item['itemcallnumber'],
                            'homebranch_name' => $item['homebranch_name'],
                            'location'      => $item['location'],
                        ],
                        'message'  => 'Item already scanned — status updated.',
                    ]);
                }

                $dur = (int)round((microtime(true) - $t0) * 1000);

                $ins = $db->prepare("
                    INSERT INTO vms_stock_verification_scans
                        (session_id, itemnumber, barcode,
                         title, author, itemcallnumber,
                         homebranch, holdingbranch, location, itype, ccode,
                         found_location, status, notes, scanned_by, scan_duration_ms)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ");
                $ins->execute([
                    $sessionId,
                    $itemnumber,
                    $barcode,
                    $item['title']  ?? '',
                    $item['author'] ?? '',
                    $item['itemcallnumber'] ?? '',
                    $item['homebranch'] ?? '',
                    $item['holdingbranch'] ?? '',
                    $item['location'] ?? '',
                    $item['itype'] ?? '',
                    $item['ccode'] ?? '',
                    $foundLoc ?: null,
                    $status,
                    $notes ?: null,
                    $currentUserBn,
                    $dur,
                ]);

                sv_recount_session($db, $sessionId);

                sv_json([
                    'success' => true,
                    'outcome' => 'new_scan',
                    'barcode' => $barcode,
                    'item'    => [
                        'itemnumber'      => $itemnumber,
                        'title'           => $item['title'],
                        'author'          => $item['author'],
                        'itemcallnumber'  => $item['itemcallnumber'],
                        'homebranch_name' => $item['homebranch_name'],
                        'holdingbranch_name' => $item['holdingbranch_name'],
                        'location'        => $item['location'],
                        'itype_description'  => $item['itype_description'],
                        'ccode_description'  => $item['ccode_description'],
                    ],
                    'status'  => $status,
                    'message' => 'Item recorded.',
                ]);
            }

            case 'session_rows': {
                $id   = (int)($_GET['id'] ?? 0);
                $page = max(1, (int)($_GET['page'] ?? 1));
                $per  = 50;
                $off  = ($page - 1) * $per;
                $filter = $_GET['filter'] ?? 'all';

                $where  = "session_id = ?";
                $params = [$id];

                if ($filter === 'found')     { $where .= " AND status = 'found'"; }
                if ($filter === 'missing')   { $where .= " AND status IN ('missing','not_found')"; }
                if ($filter === 'misplaced') { $where .= " AND status = 'misplaced'"; }
                if ($filter === 'damaged')   { $where .= " AND status = 'damaged'"; }

                $cnt = $db->prepare("SELECT COUNT(*) FROM vms_stock_verification_scans WHERE $where");
                $cnt->execute($params);
                $total = (int)$cnt->fetchColumn();

                $q = $db->prepare("
                    SELECT * FROM vms_stock_verification_scans
                     WHERE $where
                     ORDER BY scanned_at DESC
                     LIMIT $per OFFSET $off
                ");
                $q->execute($params);
                $rows = $q->fetchAll();

                sv_json([
                    'success' => true,
                    'rows'    => $rows,
                    'total'   => $total,
                    'page'    => $page,
                    'per_page'=> $per,
                    'pages'   => max(1, (int)ceil($total / $per)),
                ]);
            }

            case 'missing_items': {
                $id = (int)($_GET['id'] ?? 0);
                $sess = sv_get_active_session($db, $id);
                if (!$sess) sv_json(['success' => false, 'error' => 'Session not found'], 404);

                $where  = ["(i.withdrawn IS NULL OR i.withdrawn = 0)"];
                $params = [];

                if (!empty($sess['branch_filter'])) {
                    $where[]  = "(i.homebranch = ? OR i.holdingbranch = ?)";
                    $params[] = $sess['branch_filter'];
                    $params[] = $sess['branch_filter'];
                }
                if (!empty($sess['itype_filter'])) {
                    $where[]  = "i.itype = ?";
                    $params[] = $sess['itype_filter'];
                }
                if (!empty($sess['ccode_filter'])) {
                    $where[]  = "i.ccode = ?";
                    $params[] = $sess['ccode_filter'];
                }
                if (!empty($sess['location_filter'])) {
                    $where[]  = "i.location = ?";
                    $params[] = $sess['location_filter'];
                }

                $sql = "
                    SELECT
                        i.itemnumber, i.barcode, i.itemcallnumber,
                        i.homebranch, i.holdingbranch, i.location, i.itype, i.ccode,
                        b.title, b.author,
                        br.branchname AS homebranch_name
                    FROM items i
                    LEFT JOIN biblio b ON b.biblionumber = i.biblionumber
                    LEFT JOIN branches br ON br.branchcode = i.homebranch
                    WHERE " . implode(' AND ', $where) . "
                      AND i.itemnumber NOT IN (
                          SELECT itemnumber FROM vms_stock_verification_scans
                           WHERE session_id = ? AND itemnumber IS NOT NULL
                      )
                    ORDER BY i.homebranch, i.itemcallnumber, b.title
                    LIMIT 5000
                ";
                $params[] = $id;

                $q = $db->prepare($sql);
                $q->execute($params);
                $items = $q->fetchAll();

                sv_json(['success' => true, 'items' => $items, 'count' => count($items)]);
            }

            case 'misplaced_items': {
                $id = (int)($_GET['id'] ?? 0);
                $q = $db->prepare("
                    SELECT *
                      FROM vms_stock_verification_scans
                     WHERE session_id = ?
                       AND status = 'misplaced'
                     ORDER BY scanned_at DESC
                     LIMIT 5000
                ");
                $q->execute([$id]);
                sv_json(['success' => true, 'items' => $q->fetchAll()]);
            }

            case 'export_csv': {
                $id = (int)($_GET['id'] ?? 0);
                $sess = sv_get_active_session($db, $id);
                if (!$sess) sv_json(['success' => false, 'error' => 'Session not found'], 404);

                $q = $db->prepare("
                    SELECT
                        s.scanned_at, s.barcode, s.itemnumber, s.status,
                        s.title, s.author, s.itemcallnumber,
                        s.homebranch, s.holdingbranch, s.location, s.found_location,
                        s.itype, s.ccode, s.notes
                      FROM vms_stock_verification_scans s
                     WHERE s.session_id = ?
                     ORDER BY s.scanned_at
                ");
                $q->execute([$id]);
                $rows = $q->fetchAll();

                $filename = 'stock_verification_' . $sess['session_code'] . '.csv';

                header('Content-Type: text/csv; charset=utf-8');
                header('Content-Disposition: attachment; filename="' . $filename . '"');

                $out = fopen('php://output', 'w');
                fwrite($out, "\xEF\xBB\xBF");

                fputcsv($out, [
                    'Scanned At', 'Barcode', 'Item Number', 'Status',
                    'Title', 'Author', 'Call Number',
                    'Home Branch', 'Holding Branch', 'Expected Location', 'Found Location',
                    'Item Type', 'Collection', 'Notes',
                ]);

                foreach ($rows as $r) {
                    fputcsv($out, [
                        $r['scanned_at'], $r['barcode'], $r['itemnumber'], $r['status'],
                        $r['title'], $r['author'], $r['itemcallnumber'],
                        $r['homebranch'], $r['holdingbranch'], $r['location'], $r['found_location'],
                        $r['itype'], $r['ccode'], $r['notes'],
                    ]);
                }
                fclose($out);
                exit;
            }

            case 'filter_options': {
                $branches   = $db->query("SELECT branchcode, branchname FROM branches ORDER BY branchname")->fetchAll();
                $itemtypes  = $db->query("SELECT itemtype, description FROM itemtypes ORDER BY description")->fetchAll();
                $ccodes     = $db->query("
                    SELECT DISTINCT authorised_value, lib
                      FROM authorised_values
                     WHERE category = 'CCODE'
                     ORDER BY lib
                ")->fetchAll();
                $locations  = $db->query("
                    SELECT DISTINCT location
                      FROM items
                     WHERE location IS NOT NULL AND location != ''
                     ORDER BY location
                     LIMIT 200
                ")->fetchAll(PDO::FETCH_COLUMN);

                sv_json([
                    'success'    => true,
                    'branches'   => $branches,
                    'itemtypes'  => $itemtypes,
                    'ccodes'     => $ccodes,
                    'locations'  => $locations,
                ]);
            }

            case 'session_stats': {
                $id = (int)($_GET['id'] ?? 0);
                $sess = sv_get_active_session($db, $id);
                if (!$sess) sv_json(['success' => false, 'error' => 'Session not found'], 404);

                $scope = sv_count_scope_items($db, $sess);

                sv_json([
                    'success' => true,
                    'session' => $sess,
                    'scope'   => $scope,
                ]);
            }
        }

        sv_json(['success' => false, 'error' => 'Unknown ajax action: ' . $action], 400);

    } catch (Throwable $e) {
        sv_json(['success' => false, 'error' => $e->getMessage()], 500);
    }
}

// ============================================================
// 8. FIRST-RUN VALUES FOR PAGE
// ============================================================
$firstOptions = [
    'branches'  => $db->query("SELECT branchcode, branchname FROM branches ORDER BY branchname")->fetchAll(),
    'itemtypes' => $db->query("SELECT itemtype, description FROM itemtypes ORDER BY description")->fetchAll(),
    'ccodes'    => $db->query("SELECT DISTINCT authorised_value, lib FROM authorised_values WHERE category = 'CCODE' ORDER BY lib")->fetchAll(),
];

// ============================================================
// 9. RENDER HTML
// ============================================================
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Stock Verification — <?= htmlspecialchars($institutionName, ENT_QUOTES, 'UTF-8', false) ?></title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

<style>
:root {
    --sv-primary: #0c1960;
    --sv-secondary: #067b6b;
    --sv-danger: #dc3545;
    --sv-warning: #ffc107;
    --sv-success: #28a745;
    --sv-info: #0ea5e9;
    --sv-bg: #f4f6fa;
}
* { box-sizing: border-box; }
body {
    font-family: 'Inter', -apple-system, sans-serif;
    background: var(--sv-bg);
    color: #1e293b;
    margin: 0;
    padding: 20px;
    min-height: 100vh;
}

.sv-header {
    background: linear-gradient(135deg, var(--sv-primary), var(--sv-secondary));
    color: #fff;
    padding: 20px 28px;
    border-radius: 18px;
    margin-bottom: 22px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 14px;
    box-shadow: 0 12px 40px rgba(12, 25, 96, 0.15);
}
.sv-header h1 { margin: 0; font-size: 1.5rem; font-weight: 800; }
.sv-header p { margin: 2px 0 0; opacity: 0.85; font-size: 0.85rem; }
.sv-user { font-size: 0.85rem; opacity: 0.9; }

.sv-tabs {
    display: flex;
    gap: 8px;
    margin-bottom: 20px;
    flex-wrap: wrap;
}
.sv-tab {
    background: #fff;
    border: 2px solid transparent;
    color: var(--sv-primary);
    font-weight: 600;
    padding: 10px 18px;
    border-radius: 12px;
    cursor: pointer;
    font-size: 0.88rem;
    transition: all .2s;
}
.sv-tab:hover { background: #eef2f7; }
.sv-tab.active { background: var(--sv-primary); color: #fff; }
.sv-tab i { margin-right: 6px; }

.sv-card {
    background: #fff;
    border-radius: 16px;
    box-shadow: 0 2px 12px rgba(0,0,0,.05);
    margin-bottom: 20px;
    overflow: hidden;
}
.sv-card-head {
    padding: 14px 22px;
    background: #f8fafc;
    border-bottom: 1px solid #e9edf2;
    font-weight: 700;
    color: var(--sv-primary);
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 8px;
}
.sv-card-body { padding: 20px 22px; }

.sv-stat {
    background: #fff;
    border-radius: 14px;
    padding: 16px 18px;
    border-left: 4px solid var(--sv-primary);
    box-shadow: 0 2px 10px rgba(0,0,0,.04);
    transition: transform .25s;
    height: 100%;
}
.sv-stat:hover { transform: translateY(-3px); box-shadow: 0 8px 24px rgba(0,0,0,.08); }
.sv-stat .sv-num { font-size: 1.85rem; font-weight: 800; line-height: 1; color: var(--sv-primary); }
.sv-stat .sv-lbl { font-size: 0.72rem; color: #6c757d; text-transform: uppercase; margin-top: 4px; letter-spacing: 0.5px; }
.sv-stat.found { border-left-color: var(--sv-success); } .sv-stat.found .sv-num { color: var(--sv-success); }
.sv-stat.missing { border-left-color: var(--sv-danger); } .sv-stat.missing .sv-num { color: var(--sv-danger); }
.sv-stat.misplaced { border-left-color: var(--sv-warning); } .sv-stat.misplaced .sv-num { color: #b45309; }
.sv-stat.damaged { border-left-color: var(--sv-info); } .sv-stat.damaged .sv-num { color: var(--sv-info); }

.sv-scan-input {
    font-size: 1.6rem;
    font-weight: 600;
    text-align: center;
    height: 70px;
    border-radius: 14px;
    border: 3px solid var(--sv-primary);
    letter-spacing: 1px;
    transition: all .2s;
    padding: 0 20px;
}
.sv-scan-input:focus {
    outline: none;
    border-color: var(--sv-secondary);
    box-shadow: 0 0 0 5px rgba(6, 123, 107, 0.15);
}

.sv-status-btns {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(130px, 1fr));
    gap: 8px;
    margin-top: 12px;
}
.sv-status-btn {
    background: #fff;
    border: 2px solid #dee2e6;
    padding: 10px 14px;
    border-radius: 12px;
    font-weight: 600;
    font-size: 0.85rem;
    cursor: pointer;
    transition: all .15s;
    color: #4b5563;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 6px;
}
.sv-status-btn:hover { background: #f3f4f6; }
.sv-status-btn.active[data-status="found"]    { background: var(--sv-success); color: #fff; border-color: var(--sv-success); }
.sv-status-btn.active[data-status="missing"]  { background: var(--sv-danger); color: #fff; border-color: var(--sv-danger); }
.sv-status-btn.active[data-status="misplaced"]{ background: var(--sv-warning); color: #1f2937; border-color: var(--sv-warning); }
.sv-status-btn.active[data-status="damaged"]  { background: var(--sv-info); color: #fff; border-color: var(--sv-info); }

.sv-result {
    padding: 16px 20px;
    border-radius: 14px;
    margin-top: 14px;
    border-left: 5px solid transparent;
    animation: svSlideIn .3s;
}
.sv-result.ok      { background: #ecfdf5; border-left-color: var(--sv-success); color: #065f46; }
.sv-result.warn    { background: #fefce8; border-left-color: var(--sv-warning); color: #713f12; }
.sv-result.danger  { background: #fef2f2; border-left-color: var(--sv-danger); color: #991b1b; }
.sv-result.info    { background: #eff6ff; border-left-color: var(--sv-info); color: #1e3a8a; }
.sv-result h5 { margin: 0 0 4px; font-size: 1rem; font-weight: 700; }
.sv-result p  { margin: 0; font-size: 0.85rem; }
.sv-result .sv-meta { font-size: 0.75rem; opacity: 0.8; margin-top: 6px; }

@keyframes svSlideIn {
    from { opacity: 0; transform: translateY(-6px); }
    to   { opacity: 1; transform: translateY(0); }
}

.sv-table-wrap { overflow-x: auto; max-height: 560px; overflow-y: auto; }
.sv-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 0.82rem;
}
.sv-table th {
    background: var(--sv-primary);
    color: #fff;
    padding: 10px 12px;
    text-align: left;
    font-weight: 600;
    position: sticky;
    top: 0;
    z-index: 1;
    font-size: 0.72rem;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}
.sv-table td {
    padding: 9px 12px;
    border-bottom: 1px solid #e9edf2;
    vertical-align: top;
}
.sv-table tr:nth-child(even) td { background: #fbfcfd; }
.sv-table tr:hover td { background: #f0f4f8; }

.sv-pill {
    display: inline-block;
    padding: 2px 10px;
    border-radius: 20px;
    font-size: 0.7rem;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.3px;
}
.sv-pill.found     { background: #d4edda; color: #155724; }
.sv-pill.missing   { background: #f8d7da; color: #721c24; }
.sv-pill.not_found { background: #f8d7da; color: #721c24; }
.sv-pill.misplaced { background: #fff3cd; color: #856404; }
.sv-pill.damaged   { background: #d1ecf1; color: #0c5460; }
.sv-pill.withdrawn { background: #e2e3e5; color: #383d41; }

.sv-empty {
    text-align: center;
    padding: 40px 20px;
    color: #94a3b8;
}
.sv-empty i { font-size: 3rem; opacity: 0.3; display: block; margin-bottom: 12px; }

.sv-toast {
    position: fixed;
    bottom: 24px;
    right: 24px;
    background: var(--sv-primary);
    color: #fff;
    padding: 12px 22px;
    border-radius: 12px;
    box-shadow: 0 12px 40px rgba(0,0,0,.25);
    font-weight: 600;
    font-size: 0.88rem;
    transform: translateY(80px);
    opacity: 0;
    transition: all .3s;
    z-index: 99999;
    max-width: 360px;
}
.sv-toast.show { transform: translateY(0); opacity: 1; }
.sv-toast.success { background: var(--sv-success); }
.sv-toast.danger  { background: var(--sv-danger); }
.sv-toast.warning { background: #b45309; }

.sv-badge {
    background: #eef2f7;
    color: var(--sv-primary);
    padding: 3px 10px;
    border-radius: 20px;
    font-size: 0.72rem;
    font-weight: 600;
}
.sv-badge.green { background: #d4edda; color: #155724; }
.sv-badge.red   { background: #f8d7da; color: #721c24; }

@media (max-width: 768px) {
    .sv-header { padding: 14px 18px; }
    .sv-header h1 { font-size: 1.2rem; }
    .sv-scan-input { font-size: 1.2rem; height: 58px; }
    .sv-stat .sv-num { font-size: 1.4rem; }
}
@media print {
    .sv-header, .sv-tabs, .sv-toast, .sv-no-print { display: none !important; }
    body { background: #fff; padding: 0; }
    .sv-card { box-shadow: none; border: 1px solid #ddd; }
}
</style>
</head>
<body>

<div class="sv-header">
    <div>
        <h1><i class="fas fa-clipboard-check me-2"></i>Stock Verification</h1>
        <p>Koha physical inventory — scan, track, reconcile</p>
    </div>
    <div class="sv-user">
        <i class="fas fa-user-circle me-1"></i>
        <?= htmlspecialchars($currentUserName) ?>
        <?php if ($currentUserBn): ?><span class="opacity-75">(#<?= (int)$currentUserBn ?>)</span><?php endif; ?>
    </div>
</div>

<div class="sv-tabs">
    <button class="sv-tab active" data-view="sessions"><i class="fas fa-list"></i> Sessions</button>
    <button class="sv-tab" data-view="scan"><i class="fas fa-barcode"></i> Scan</button>
    <button class="sv-tab" data-view="missing"><i class="fas fa-search-minus"></i> Missing Items</button>
    <button class="sv-tab" data-view="misplaced"><i class="fas fa-map-marker-alt"></i> Misplaced</button>
</div>

<!-- VIEW: Sessions -->
<div class="sv-view" data-view="sessions">
    <div class="sv-card">
        <div class="sv-card-head">
            <span><i class="fas fa-plus-circle me-2"></i>New Verification Session</span>
        </div>
        <div class="sv-card-body">
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label fw-semibold small">Title *</label>
                    <input type="text" id="newTitle" class="form-control" placeholder="e.g., Annual Inventory 2026 — Reference">
                </div>
                <div class="col-md-6">
                    <label class="form-label fw-semibold small">Description</label>
                    <input type="text" id="newDescription" class="form-control" placeholder="Optional description">
                </div>
                <div class="col-md-3">
                    <label class="form-label fw-semibold small">Branch (optional)</label>
                    <select id="newBranch" class="form-select">
                        <option value="">— All Branches —</option>
                        <?php foreach ($firstOptions['branches'] as $b): ?>
                            <option value="<?= htmlspecialchars($b['branchcode']) ?>"><?= htmlspecialchars($b['branchname']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label fw-semibold small">Item Type (optional)</label>
                    <select id="newItype" class="form-select">
                        <option value="">— All Types —</option>
                        <?php foreach ($firstOptions['itemtypes'] as $it): ?>
                            <option value="<?= htmlspecialchars($it['itemtype']) ?>"><?= htmlspecialchars($it['description']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label fw-semibold small">Collection (optional)</label>
                    <select id="newCcode" class="form-select">
                        <option value="">— All Collections —</option>
                        <?php foreach ($firstOptions['ccodes'] as $cc): ?>
                            <option value="<?= htmlspecialchars($cc['authorised_value']) ?>"><?= htmlspecialchars($cc['lib']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-3 d-flex align-items-end">
                    <button class="btn btn-primary w-100" onclick="svCreateSession()">
                        <i class="fas fa-plus me-2"></i>Create Session
                    </button>
                </div>
            </div>
        </div>
    </div>

    <div class="sv-card">
        <div class="sv-card-head">
            <span><i class="fas fa-history me-2"></i>Existing Sessions</span>
            <button class="btn btn-sm btn-outline-secondary" onclick="svLoadSessions()">
                <i class="fas fa-sync me-1"></i> Refresh
            </button>
        </div>
        <div class="sv-card-body p-0">
            <div id="svSessionsList" class="sv-table-wrap">
                <div class="sv-empty"><i class="fas fa-spinner fa-spin"></i>Loading…</div>
            </div>
        </div>
    </div>
</div>

<!-- VIEW: Scan -->
<div class="sv-view d-none" data-view="scan">
    <div class="sv-card">
        <div class="sv-card-head">
            <span><i class="fas fa-barcode me-2"></i>Scan Console</span>
            <span id="svActiveSessionLabel" class="sv-badge">No session selected</span>
        </div>
        <div class="sv-card-body">
            <div class="row g-2 mb-3">
                <div class="col-md-8">
                    <select id="svActiveSessionSelect" class="form-select form-select-lg" onchange="svSelectSession(this.value)">
                        <option value="">— Select an open session —</option>
                    </select>
                </div>
                <div class="col-md-4">
                    <button class="btn btn-outline-danger w-100 btn-lg" onclick="svCloseActiveSession()">
                        <i class="fas fa-flag-checkered me-2"></i>Close Session
                    </button>
                </div>
            </div>

            <input type="text" id="svScanInput" class="sv-scan-input w-100 mb-3" placeholder="Scan or type barcode…" autocomplete="off" autofocus>

            <div class="row g-2">
                <div class="col-md-6">
                    <label class="form-label fw-semibold small">Found Location (optional)</label>
                    <input type="text" id="svFoundLocation" class="form-control" placeholder="e.g., Shelf A-12, Reference">
                </div>
                <div class="col-md-6">
                    <label class="form-label fw-semibold small">Notes (optional)</label>
                    <input type="text" id="svScanNotes" class="form-control" placeholder="Optional note">
                </div>
            </div>

            <label class="form-label fw-semibold small mt-3">Status</label>
            <div class="sv-status-btns" id="svStatusBtns">
                <button class="sv-status-btn active" data-status="found"><i class="fas fa-check"></i> Found</button>
                <button class="sv-status-btn" data-status="missing"><i class="fas fa-times"></i> Missing</button>
                <button class="sv-status-btn" data-status="misplaced"><i class="fas fa-exchange-alt"></i> Misplaced</button>
                <button class="sv-status-btn" data-status="damaged"><i class="fas fa-heart-broken"></i> Damaged</button>
            </div>

            <div id="svScanResult"></div>
        </div>
    </div>

    <div class="row g-3 mb-3" id="svLiveStats">
        <div class="col-md-3"><div class="sv-stat"><div class="sv-num" id="svStatScanned">0</div><div class="sv-lbl">Scanned</div></div></div>
        <div class="col-md-3"><div class="sv-stat found"><div class="sv-num" id="svStatFound">0</div><div class="sv-lbl">Found</div></div></div>
        <div class="col-md-3"><div class="sv-stat missing"><div class="sv-num" id="svStatMissing">0</div><div class="sv-lbl">Missing</div></div></div>
        <div class="col-md-3"><div class="sv-stat misplaced"><div class="sv-num" id="svStatMisplaced">0</div><div class="sv-lbl">Misplaced</div></div></div>
    </div>

    <div class="sv-card">
        <div class="sv-card-head">
            <span><i class="fas fa-list me-2"></i>Scanned in this session</span>
            <div class="d-flex gap-2">
                <select id="svScanFilter" class="form-select form-select-sm" style="width:auto;" onchange="svLoadSessionRows(1)">
                    <option value="all">All statuses</option>
                    <option value="found">Found</option>
                    <option value="missing">Missing / Not found</option>
                    <option value="misplaced">Misplaced</option>
                    <option value="damaged">Damaged</option>
                </select>
                <button class="btn btn-sm btn-outline-success" onclick="svExportCSV()">
                    <i class="fas fa-file-csv me-1"></i> CSV
                </button>
            </div>
        </div>
        <div class="sv-card-body p-0">
            <div id="svScanTable" class="sv-table-wrap">
                <div class="sv-empty"><i class="fas fa-barcode"></i>No items scanned yet</div>
            </div>
        </div>
    </div>
</div>

<!-- VIEW: Missing Items -->
<div class="sv-view d-none" data-view="missing">
    <div class="sv-card">
        <div class="sv-card-head">
            <span><i class="fas fa-search-minus me-2"></i>Items Missing from Verification</span>
            <div class="d-flex gap-2">
                <span id="svMissingCount" class="sv-badge red">0</span>
                <button class="btn btn-sm btn-outline-primary" onclick="svLoadMissing()">
                    <i class="fas fa-sync me-1"></i> Refresh
                </button>
                <button class="btn btn-sm btn-outline-success" onclick="svPrintMissing()">
                    <i class="fas fa-print me-1"></i> Print
                </button>
            </div>
        </div>
        <div class="sv-card-body p-0">
            <div id="svMissingTable" class="sv-table-wrap">
                <div class="sv-empty"><i class="fas fa-info-circle"></i>Select a session first (in Scan view)</div>
            </div>
        </div>
    </div>
</div>

<!-- VIEW: Misplaced -->
<div class="sv-view d-none" data-view="misplaced">
    <div class="sv-card">
        <div class="sv-card-head">
            <span><i class="fas fa-map-marker-alt me-2"></i>Misplaced Items</span>
            <span id="svMisplacedCount" class="sv-badge">0</span>
        </div>
        <div class="sv-card-body p-0">
            <div id="svMisplacedTable" class="sv-table-wrap">
                <div class="sv-empty"><i class="fas fa-info-circle"></i>Items marked as misplaced appear here</div>
            </div>
        </div>
    </div>
</div>

<!-- Toast -->
<div id="svToast" class="sv-toast"></div>

<script>
// ============================================================
// INSTITUTION NAME — exposed to JS as a CLEAN plain string  [CHANGED v1.2]
// ============================================================
window.VMS_INSTITUTION_NAME = <?= json_encode($institutionName, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;

// ============================================================
// STATE
// ============================================================
const SV = {
    activeSessionId: null,
    activeSession: null,
    status: 'found',
    lastResult: null,
    sessionRows: [],
};

// ============================================================
// UTILITIES
// ============================================================
function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, m =>
        ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[m]));
}

function svToast(msg, type = 'success') {
    const t = document.getElementById('svToast');
    t.className = 'sv-toast ' + type;
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(window.__svToastTimer);
    window.__svToastTimer = setTimeout(() => t.classList.remove('show'), 2400);
}

function svFmtDate(s) {
    if (!s) return '—';
    try {
        const d = new Date(s.replace(' ', 'T'));
        return d.toLocaleString();
    } catch (e) { return s; }
}

// ============================================================
// VIEW SWITCHING
// ============================================================
document.querySelectorAll('.sv-tab').forEach(tab => {
    tab.addEventListener('click', () => {
        const view = tab.dataset.view;
        document.querySelectorAll('.sv-tab').forEach(t => t.classList.toggle('active', t === tab));
        document.querySelectorAll('.sv-view').forEach(v => v.classList.toggle('d-none', v.dataset.view !== view));

        if (view === 'scan')      setTimeout(() => document.getElementById('svScanInput').focus(), 100);
        if (view === 'missing')   svLoadMissing();
        if (view === 'misplaced') svLoadMisplaced();
    });
});

// ============================================================
// SESSION LIST
// ============================================================
async function svLoadSessions() {
    const container = document.getElementById('svSessionsList');
    container.innerHTML = '<div class="sv-empty"><i class="fas fa-spinner fa-spin"></i>Loading…</div>';

    try {
        const res = await fetch('stock_verify.php?ajax=list_sessions');
        const data = await res.json();

        if (!data.success || !data.sessions.length) {
            container.innerHTML = '<div class="sv-empty"><i class="fas fa-inbox"></i>No sessions yet. Create one above.</div>';
            return;
        }

        let html = `<table class="sv-table">
            <thead>
                <tr>
                    <th>Code</th>
                    <th>Title</th>
                    <th>Status</th>
                    <th>Scope</th>
                    <th>Scanned / Total</th>
                    <th>Found</th>
                    <th>Missing</th>
                    <th>Started</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>`;

        data.sessions.forEach(s => {
            const scope = [
                s.branch_filter ? 'Branch:' + s.branch_filter : null,
                s.itype_filter ? 'Type:' + s.itype_filter : null,
                s.ccode_filter ? 'Collection:' + s.ccode_filter : null,
                s.location_filter ? 'Loc:' + s.location_filter : null,
            ].filter(Boolean).join(' · ') || 'All items';

            const percent = s.scope_total > 0 ? Math.round((s.total_scanned / s.scope_total) * 100) : 0;
            const isOpen = s.status === 'open';

            html += `<tr>
                <td><code>${esc(s.session_code)}</code></td>
                <td><strong>${esc(s.title)}</strong>${s.description ? '<br><small class="text-muted">' + esc(s.description) + '</small>' : ''}</td>
                <td><span class="sv-pill ${isOpen ? 'found' : 'withdrawn'}">${esc(s.status)}</span></td>
                <td>${esc(scope)}</td>
                <td>
                    ${s.total_scanned} / ${s.scope_total}
                    <div class="progress mt-1" style="height:4px;">
                        <div class="progress-bar bg-primary" style="width:${percent}%"></div>
                    </div>
                </td>
                <td><span class="sv-pill found">${s.total_found}</span></td>
                <td><span class="sv-pill missing">${s.total_missing}</span></td>
                <td>${svFmtDate(s.started_at)}</td>
                <td>
                    <button class="btn btn-sm btn-primary" onclick="svSelectSession(${s.id}); document.querySelector('.sv-tab[data-view=scan]').click();">
                        <i class="fas fa-play"></i>
                    </button>
                    ${isOpen ? `<button class="btn btn-sm btn-outline-warning" onclick="svCloseSession(${s.id})"><i class="fas fa-flag-checkered"></i></button>` : ''}
                    <button class="btn btn-sm btn-outline-danger" onclick="svDeleteSession(${s.id})"><i class="fas fa-trash"></i></button>
                </td>
            </tr>`;
        });

        html += '</tbody></table>';
        container.innerHTML = html;
    } catch (e) {
        container.innerHTML = '<div class="sv-empty"><i class="fas fa-exclamation-triangle text-danger"></i>Failed to load: ' + esc(e.message) + '</div>';
    }
}

// ============================================================
// SESSION CREATE / CLOSE / DELETE
// ============================================================
async function svCreateSession() {
    const title = document.getElementById('newTitle').value.trim();
    if (!title) { svToast('Title is required', 'danger'); return; }

    const payload = {
        title,
        description: document.getElementById('newDescription').value.trim(),
        branch_filter: document.getElementById('newBranch').value,
        itype_filter: document.getElementById('newItype').value,
        ccode_filter: document.getElementById('newCcode').value,
    };

    try {
        const res = await fetch('stock_verify.php?ajax=create_session', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload),
        });
        const data = await res.json();

        if (data.success) {
            svToast('Session created: ' + data.session.session_code, 'success');
            document.getElementById('newTitle').value = '';
            document.getElementById('newDescription').value = '';
            svLoadSessions();
            svReloadSessionDropdown();
        } else {
            svToast(data.error || 'Create failed', 'danger');
        }
    } catch (e) {
        svToast('Network error: ' + e.message, 'danger');
    }
}

async function svCloseSession(id) {
    if (!confirm('Close this session? Scanning will be disabled.')) return;
    await fetch('stock_verify.php?ajax=close_session&id=' + id, { method: 'POST' });
    svToast('Session closed', 'success');
    svLoadSessions();
    svReloadSessionDropdown();
}

async function svDeleteSession(id) {
    if (!confirm('Delete this session AND all its scans? This cannot be undone.')) return;
    await fetch('stock_verify.php?ajax=delete_session&id=' + id, { method: 'POST' });
    svToast('Session deleted', 'success');
    svLoadSessions();
    svReloadSessionDropdown();
}

// ============================================================
// SESSION DROPDOWN (Scan view)
// ============================================================
async function svReloadSessionDropdown() {
    const sel = document.getElementById('svActiveSessionSelect');
    sel.innerHTML = '<option value="">— Select an open session —</option>';

    try {
        const res = await fetch('stock_verify.php?ajax=list_sessions');
        const data = await res.json();
        if (!data.success) return;

        data.sessions.filter(s => s.status === 'open').forEach(s => {
            const opt = document.createElement('option');
            opt.value = s.id;
            opt.textContent = `${s.session_code} — ${s.title} (${s.total_scanned} scanned)`;
            if (SV.activeSessionId == s.id) opt.selected = true;
            sel.appendChild(opt);
        });
    } catch (e) { /* silent */ }
}

async function svSelectSession(id) {
    id = parseInt(id, 10);
    if (!id) {
        SV.activeSessionId = null;
        SV.activeSession = null;
        document.getElementById('svActiveSessionLabel').textContent = 'No session selected';
        document.getElementById('svScanTable').innerHTML = '<div class="sv-empty"><i class="fas fa-barcode"></i>Select a session to start scanning</div>';
        return;
    }

    SV.activeSessionId = id;

    try {
        const res = await fetch('stock_verify.php?ajax=get_session&id=' + id);
        const data = await res.json();
        if (!data.success) { svToast('Session not found', 'danger'); return; }

        SV.activeSession = data.session;
        document.getElementById('svActiveSessionLabel').textContent = data.session.session_code + ' — ' + data.session.title;
        svUpdateLiveStats();
        svLoadSessionRows(1);
        setTimeout(() => document.getElementById('svScanInput').focus(), 100);
    } catch (e) {
        svToast('Load failed: ' + e.message, 'danger');
    }
}

function svCloseActiveSession() {
    if (!SV.activeSessionId) { svToast('No active session', 'warning'); return; }
    svCloseSession(SV.activeSessionId);
    SV.activeSessionId = null;
    SV.activeSession = null;
}

// ============================================================
// SCAN STATUS BUTTONS
// ============================================================
document.querySelectorAll('.sv-status-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        document.querySelectorAll('.sv-status-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        SV.status = btn.dataset.status;
        document.getElementById('svScanInput').focus();
    });
});

// ============================================================
// SCAN SUBMISSION
// ============================================================
const svScanInput = document.getElementById('svScanInput');
let svLastScanTime = 0;

svScanInput.addEventListener('keydown', async (e) => {
    if (e.key !== 'Enter') return;
    e.preventDefault();

    const now = Date.now();
    if (now - svLastScanTime < 400) return;
    svLastScanTime = now;

    const barcode = svScanInput.value.trim();
    if (!barcode) return;
    if (!SV.activeSessionId) { svToast('Select a session first', 'warning'); return; }

    const foundLocation = document.getElementById('svFoundLocation').value.trim();
    const notes = document.getElementById('svScanNotes').value.trim();

    svScanInput.value = '';
    svScanInput.disabled = true;

    try {
        const res = await fetch('stock_verify.php?ajax=scan', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                session_id: SV.activeSessionId,
                barcode,
                status: SV.status,
                found_location: foundLocation,
                notes,
            }),
        });
        const data = await res.json();
        svShowScanResult(data, barcode);
        svUpdateLiveStats();
        svLoadSessionRows(1);
    } catch (e) {
        svToast('Scan failed: ' + e.message, 'danger');
    } finally {
        svScanInput.disabled = false;
        svScanInput.focus();
    }
});

function svShowScanResult(data, barcode) {
    const el = document.getElementById('svScanResult');
    if (!data.success) {
        el.innerHTML = `<div class="sv-result danger">
            <h5><i class="fas fa-exclamation-triangle me-1"></i>Scan rejected</h5>
            <p>${esc(data.error || 'Unknown error')}</p>
        </div>`;
        return;
    }

    if (data.outcome === 'unknown_barcode') {
        el.innerHTML = `<div class="sv-result warn">
            <h5><i class="fas fa-question-circle me-1"></i>Barcode not in catalog</h5>
            <p><code>${esc(barcode)}</code></p>
            <div class="sv-meta">Logged as <strong>not_found</strong>. Check the barcode or add the item to Koha.</div>
        </div>`;
        return;
    }

    if (data.outcome === 'duplicate_updated') {
        const it = data.item || {};
        el.innerHTML = `<div class="sv-result warn">
            <h5><i class="fas fa-redo me-1"></i>Already scanned — status updated</h5>
            <p><strong>${esc(it.title || '')}</strong> ${it.author ? '· ' + esc(it.author) : ''}</p>
            <div class="sv-meta">Barcode: <code>${esc(barcode)}</code> · Previous: <span class="sv-pill ${esc(data.previous)}">${esc(data.previous)}</span> → New: <span class="sv-pill ${esc(data.new)}">${esc(data.new)}</span></div>
        </div>`;
        return;
    }

    const it = data.item || {};
    const cls = data.status === 'found' ? 'ok' :
                data.status === 'missing' ? 'danger' :
                data.status === 'misplaced' ? 'warn' : 'info';

    el.innerHTML = `<div class="sv-result ${cls}">
        <h5><i class="fas fa-check-circle me-1"></i>${esc(it.title || 'Item')}</h5>
        <p>${it.author ? esc(it.author) + ' · ' : ''}<code>${esc(barcode)}</code></p>
        <div class="sv-meta">
            Call No: <strong>${esc(it.itemcallnumber || '—')}</strong>
            · Home: <strong>${esc(it.homebranch_name || it.homebranch || '—')}</strong>
            · Location: <strong>${esc(it.location || '—')}</strong>
            · Status: <span class="sv-pill ${esc(data.status)}">${esc(data.status)}</span>
        </div>
    </div>`;
}

// ============================================================
// SESSION ROWS TABLE
// ============================================================
async function svLoadSessionRows(page = 1) {
    if (!SV.activeSessionId) return;
    const filter = document.getElementById('svScanFilter').value || 'all';
    const container = document.getElementById('svScanTable');

    try {
        const res = await fetch(`stock_verify.php?ajax=session_rows&id=${SV.activeSessionId}&page=${page}&filter=${filter}`);
        const data = await res.json();
        if (!data.success) return;

        if (!data.rows.length) {
            container.innerHTML = '<div class="sv-empty"><i class="fas fa-barcode"></i>No items scanned yet</div>';
            return;
        }

        let html = `<table class="sv-table">
            <thead>
                <tr>
                    <th>When</th><th>Barcode</th><th>Title</th><th>Call No</th>
                    <th>Home</th><th>Found At</th><th>Status</th><th>Notes</th>
                </tr>
            </thead>
            <tbody>`;

        data.rows.forEach(r => {
            html += `<tr>
                <td>${svFmtDate(r.scanned_at)}</td>
                <td><code>${esc(r.barcode)}</code></td>
                <td>${esc(r.title || '—')}<br><small class="text-muted">${esc(r.author || '')}</small></td>
                <td>${esc(r.itemcallnumber || '—')}</td>
                <td>${esc(r.homebranch || '—')}</td>
                <td>${esc(r.found_location || '—')}</td>
                <td><span class="sv-pill ${esc(r.status)}">${esc(r.status)}</span></td>
                <td>${esc(r.notes || '')}</td>
            </tr>`;
        });
        html += '</tbody></table>';
        container.innerHTML = html;
    } catch (e) {
        container.innerHTML = '<div class="sv-empty"><i class="fas fa-exclamation-triangle text-danger"></i>Failed: ' + esc(e.message) + '</div>';
    }
}

// ============================================================
// LIVE STATS
// ============================================================
async function svUpdateLiveStats() {
    if (!SV.activeSessionId) return;
    try {
        const res = await fetch('stock_verify.php?ajax=session_stats&id=' + SV.activeSessionId);
        const data = await res.json();
        if (!data.success) return;

        const s = data.session;
        document.getElementById('svStatScanned').textContent = s.total_scanned;
        document.getElementById('svStatFound').textContent = s.total_found;
        document.getElementById('svStatMissing').textContent = s.total_missing;
        document.getElementById('svStatMisplaced').textContent = s.total_misplaced;
    } catch (e) { /* silent */ }
}

// ============================================================
// MISSING / MISPLACED
// ============================================================
async function svLoadMissing() {
    if (!SV.activeSessionId) {
        document.getElementById('svMissingTable').innerHTML = '<div class="sv-empty"><i class="fas fa-info-circle"></i>Select a session first (in Scan view)</div>';
        return;
    }

    const container = document.getElementById('svMissingTable');
    container.innerHTML = '<div class="sv-empty"><i class="fas fa-spinner fa-spin"></i>Loading…</div>';

    try {
        const res = await fetch('stock_verify.php?ajax=missing_items&id=' + SV.activeSessionId);
        const data = await res.json();
        if (!data.success) throw new Error(data.error);

        document.getElementById('svMissingCount').textContent = data.count;

        if (!data.items.length) {
            container.innerHTML = '<div class="sv-empty"><i class="fas fa-check-circle text-success"></i>No missing items — every item in scope was scanned.</div>';
            return;
        }

        let html = `<table class="sv-table">
            <thead>
                <tr><th>Barcode</th><th>Title</th><th>Call No</th><th>Home Branch</th><th>Location</th><th>Item Type</th></tr>
            </thead><tbody>`;
        data.items.forEach(r => {
            html += `<tr>
                <td><code>${esc(r.barcode)}</code></td>
                <td>${esc(r.title || '—')}<br><small class="text-muted">${esc(r.author || '')}</small></td>
                <td>${esc(r.itemcallnumber || '—')}</td>
                <td>${esc(r.homebranch_name || r.homebranch || '—')}</td>
                <td>${esc(r.location || '—')}</td>
                <td>${esc(r.itype || '—')}</td>
            </tr>`;
        });
        html += '</tbody></table>';
        container.innerHTML = html;
    } catch (e) {
        container.innerHTML = '<div class="sv-empty"><i class="fas fa-exclamation-triangle text-danger"></i>Failed: ' + esc(e.message) + '</div>';
    }
}

async function svLoadMisplaced() {
    if (!SV.activeSessionId) {
        document.getElementById('svMisplacedTable').innerHTML = '<div class="sv-empty"><i class="fas fa-info-circle"></i>Select a session first (in Scan view)</div>';
        return;
    }

    const container = document.getElementById('svMisplacedTable');
    container.innerHTML = '<div class="sv-empty"><i class="fas fa-spinner fa-spin"></i>Loading…</div>';

    try {
        const res = await fetch('stock_verify.php?ajax=misplaced_items&id=' + SV.activeSessionId);
        const data = await res.json();
        if (!data.success) throw new Error(data.error);

        document.getElementById('svMisplacedCount').textContent = data.items.length;

        if (!data.items.length) {
            container.innerHTML = '<div class="sv-empty"><i class="fas fa-check-circle text-success"></i>No misplaced items recorded.</div>';
            return;
        }

        let html = `<table class="sv-table">
            <thead>
                <tr><th>When</th><th>Barcode</th><th>Title</th><th>Expected Location</th><th>Found Location</th><th>Notes</th></tr>
            </thead><tbody>`;
        data.items.forEach(r => {
            html += `<tr>
                <td>${svFmtDate(r.scanned_at)}</td>
                <td><code>${esc(r.barcode)}</code></td>
                <td>${esc(r.title || '—')}</td>
                <td>${esc(r.location || '—')}</td>
                <td><strong>${esc(r.found_location || '—')}</strong></td>
                <td>${esc(r.notes || '')}</td>
            </tr>`;
        });
        html += '</tbody></table>';
        container.innerHTML = html;
    } catch (e) {
        container.innerHTML = '<div class="sv-empty"><i class="fas fa-exclamation-triangle text-danger"></i>Failed: ' + esc(e.message) + '</div>';
    }
}

function svPrintMissing() {
    if (!SV.activeSessionId) { svToast('Select a session first', 'warning'); return; }
    window.print();
}

// ============================================================
// EXPORT
// ============================================================
function svExportCSV() {
    if (!SV.activeSessionId) { svToast('Select a session first', 'warning'); return; }
    window.location.href = 'stock_verify.php?ajax=export_csv&id=' + SV.activeSessionId;
}

// ============================================================
// INIT
// ============================================================
document.addEventListener('DOMContentLoaded', () => {
    svLoadSessions();
    svReloadSessionDropdown();
    setInterval(svLoadSessions, 30000);
});
</script>

<!-- ============================================================
SHARED FOOTER — with entity-collapse post-processing  [CHANGED v1.2]
============================================================ -->
<?php
$__svFooterOut = '';

ob_start();
try {
    if (function_exists('vms_footer_css')) { vms_footer_css(); }
    if (function_exists('vms_footer_js'))  { vms_footer_js();  }

    if (function_exists('vms_render_footer')) {
        vms_render_footer([
            'layout'           => 'compact',
            'institution_name' => $institutionName,
            'institutionName'  => $institutionName,
            'library_name'     => $institutionName,
            'site_name'        => $institutionName,
            'org_name'         => $institutionName,
            'no_escape'        => true,
        ]);
    }
} catch (Throwable $e) {
    error_log('[stock_verify.php] footer render: ' . $e->getMessage());
}
$__svFooterOut = ob_get_clean();

if ($__svFooterOut !== '') {
    // Collapse &amp;amp;amp; → &amp;amp; → &amp; (up to 5 passes)
    $prev = null;
    $out  = $__svFooterOut;
    $i    = 0;
    while ($prev !== $out && $i < 5) {
        $prev = $out;
        $out  = str_replace('&amp;amp;', '&amp;', $out);
        $i++;
    }
    // Final collapse: "word &amp; word" → "word & word" (only between
    // alphanumerics, so we never touch &nbsp; &copy; &quot; etc.)
    $out = preg_replace_callback(
        '/(?<=[A-Za-z0-9])\s*&amp;\s*(?=[A-Za-z0-9])/',
        function () { return ' & '; },
        $out
    );
    echo $out;
}
?>

</body>
</html>
