<?php
/**
 * Computer / System Management — Standalone Edition
 * File: /cgi-bin/koha/visitor/system.php
 * Version: 2.2 FINAL — Independent + Footer Entity Fix
 *
 * Fully self-contained. No dependency on dashboard.php, header.php,
 * footer.php, or any VMS admin scaffolding.
 *
 * Directly connects to:
 *   • Koha DB   → borrowers, categories, patronimage  (member data)
 *   • VMS DB    → computers, computer_sessions, computer_policies,
 *                 computer_attendance, activity_log  (computer mgmt)
 *
 * FIX (v2.2):
 *   • Institution name normalization handles multi-level encoding:
 *       "Library &amp;amp; information" → "Library & information"
 *   • Footer output is now BUFFERED and post-processed to collapse
 *     any residual &amp;amp; / &amp; sequences in the institution name
 *     so it renders as "Library & information" in the browser.
 *   • Works even if the shared footer partial re-encodes the value.
 *
 * URL actions (?action=):
 *   (default)          Dashboard
 *   start              Start session (POST)
 *   end                End session     ?id=N | ?all=1
 *   manage             CRUD terminals
 *   delete_computer    ?id=N
 *   policies           Per-role limits
 *   attendance         Weekly compliance
 *   reports            Filter + Excel / PDF export
 *   ajax_members       JSON: search Koha members
 *   api_health         JSON: {koha, db, stats}
 *   api_sessions       JSON: active sessions
 *   api_start          POST JSON: start session
 *   api_end            POST JSON: end session
 */

// ============================================================
// 1. ERROR REPORTING
// ============================================================
error_reporting(E_ALL);
@ini_set('display_errors', '1');
@ini_set('log_errors', '1');

// ============================================================
// 2. SESSION
// ============================================================
if (session_status() === PHP_SESSION_NONE) {
    session_name('CGISESSID');
    if (isset($_COOKIE['CGISESSID'])) session_id($_COOKIE['CGISESSID']);
    session_start();
}

// ============================================================
// 3. LOAD VMS CONFIG (auto-detect path)
// ============================================================
$configPaths = [
    __DIR__ . '/includes/config.php',
    __DIR__ . '/../includes/config.php',
    dirname(__DIR__) . '/includes/config.php',
    '/usr/share/koha/intranet/cgi-bin/koha/visitor/includes/config.php',
    '/usr/share/koha/intranet/cgi-bin/visitor/includes/config.php',
];

$configLoaded = false;
foreach ($configPaths as $p) {
    if (file_exists($p)) {
        require_once $p;
        $configLoaded = true;
        break;
    }
}

// ============================================================
// 4. LOAD SHARED FOOTER PARTIAL (optional)
// ============================================================
$footerPartialPaths = [
    __DIR__ . '/includes/footer_partial.php',
    __DIR__ . '/../includes/footer_partial.php',
    dirname(__DIR__) . '/includes/footer_partial.php',
    '/usr/share/koha/intranet/cgi-bin/koha/visitor/includes/footer_partial.php',
    '/usr/share/koha/intranet/cgi-bin/visitor/includes/footer_partial.php',
];
$footerPartialLoaded = false;
foreach ($footerPartialPaths as $p) {
    if (file_exists($p)) {
        require_once $p;
        $footerPartialLoaded = true;
        break;
    }
}

// ============================================================
// 5. DB CREDENTIALS
// ============================================================
$dbHost  = defined('DB_HOST')  ? DB_HOST  : 'localhost';
$dbUser  = defined('DB_USER')  ? DB_USER  : 'koha_library';
$dbPass  = defined('DB_PASS')  ? DB_PASS  : '';
$dbName  = defined('DB_NAME')  ? DB_NAME  : 'visitor_management';
$dbCs    = defined('DB_CHARSET') ? DB_CHARSET : 'utf8mb4';

$kohaHost = defined('KOHA_HOST') ? KOHA_HOST : $dbHost;
$kohaUser = defined('KOHA_USER') ? KOHA_USER : $dbUser;
$kohaPass = defined('KOHA_PASS') ? KOHA_PASS : $dbPass;
$kohaName = defined('KOHA_DB')   ? KOHA_DB   : 'koha_library';
$kohaCs   = defined('KOHA_CHARSET') ? KOHA_CHARSET : 'utf8mb4';

// ============================================================
// 6. CONNECT — VMS DB
// ============================================================
$db = null;
try {
    $db = new PDO(
        "mysql:host=$dbHost;dbname=$dbName;charset=$dbCs",
        $dbUser, $dbPass,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
            PDO::ATTR_TIMEOUT            => 5,
        ]
    );
    $db->exec("SET NAMES $dbCs");
} catch (PDOException $e) {
    error_log('[system.php] VMS DB: ' . $e->getMessage());
    die('<div style="font-family:sans-serif;padding:20px;color:#c00;"><h3>Database error</h3><p>'
        . htmlspecialchars($e->getMessage())
        . '</p><p>Check <code>includes/config.php</code> credentials.</p></div>');
}

// ============================================================
// 7. CONNECT — Koha DB
// ============================================================
$koha = null;
$kohaConnected = false;
try {
    $koha = new PDO(
        "mysql:host=$kohaHost;dbname=$kohaName;charset=$kohaCs",
        $kohaUser, $kohaPass,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
            PDO::ATTR_TIMEOUT            => 5,
        ]
    );
    $kohaConnected = true;
} catch (PDOException $e) {
    error_log('[system.php] Koha DB: ' . $e->getMessage());
    $kohaConnected = false;
}

// ============================================================
// 8. INSTITUTION NAME — deeply normalized to plain text
// ============================================================
/**
 * Aggressively normalize an institution name to plain text.
 *
 * Handles:
 *   "Library & information"          → "Library & information"
 *   "Library &amp; information"       → "Library & information"
 *   "Library &amp;amp; information"   → "Library & information"
 *   "Library &amp;amp;amp; info"      → "Library & information"
 *
 * Loops html_entity_decode until the string stops changing (max 5 passes).
 *
 * @param  string $raw
 * @return string  Plain text with raw & < > " ' characters
 */
function sys_clean_institution(string $raw): string
{
    $raw = trim($raw);
    if ($raw === '') return 'My Library';

    // If it looks like a UTF-8 mojibake, try to fix it
    if (!mb_check_encoding($raw, 'UTF-8')) {
        $fixed = @mb_convert_encoding($raw, 'UTF-8', 'ISO-8859-1');
        if ($fixed !== false && $fixed !== '') $raw = $fixed;
    }

    // Decode HTML entities repeatedly until stable
    $prev = null;
    $out  = $raw;
    $i    = 0;
    while ($prev !== $out && $i < 5) {
        $prev = $out;
        $out  = html_entity_decode($out, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $i++;
    }

    // Collapse any remaining literal "&amp;" sequences that survived
    // (defensive — in case a stored value was written as the literal
    // 6 characters "&amp;" without the leading &, which can't happen
    // via html_entity_decode alone).
    $out = str_replace(
        ['&amp;amp;', '&amp;', '&AMP;', '&Amp;'],
        '&',
        $out
    );

    // Same defensive pass for other common entities
    $out = str_replace(
        ['&quot;', '&#039;', '&#39;', '&apos;', '&lt;', '&gt;'],
        ['"',       "'",       "'",      "'",       '<',    '>'],
        $out
    );

    // Normalize whitespace
    $out = preg_replace('/\s+/u', ' ', $out);
    $out = trim($out);

    return $out !== '' ? $out : 'My Library';
}

$institutionName = 'My Library';
try {
    $r = $db->query("SELECT institution_name FROM settings WHERE id = 1 LIMIT 1")->fetchColumn();
    if ($r !== false && $r !== null && trim((string)$r) !== '') {
        $institutionName = sys_clean_institution((string)$r);
    }
} catch (PDOException $e) {
    /* settings table may not exist */
}

if (defined('INSTITUTION_NAME') && trim((string)INSTITUTION_NAME) !== '') {
    $institutionName = sys_clean_institution((string)INSTITUTION_NAME);
}

// Publish the clean value everywhere
$GLOBALS['institution_name'] = $institutionName;
$GLOBALS['institutionName']  = $institutionName;
$GLOBALS['INSTITUTION_NAME'] = $institutionName;
$GLOBALS['library_name']     = $institutionName;
$GLOBALS['site_name']        = $institutionName;

// ============================================================
// 9. ENSURE TABLES EXIST (idempotent)
// ============================================================
try {
    $db->exec("
        CREATE TABLE IF NOT EXISTS computers (
            id INT PRIMARY KEY AUTO_INCREMENT,
            computer_name VARCHAR(100) NOT NULL UNIQUE,
            ip_address VARCHAR(45) NULL,
            location VARCHAR(100) NULL,
            status ENUM('active','maintenance','offline') DEFAULT 'active',
            notes TEXT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_status (status)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
    $db->exec("
        CREATE TABLE IF NOT EXISTS computer_sessions (
            id INT PRIMARY KEY AUTO_INCREMENT,
            borrowernumber INT NOT NULL,
            computer_id INT NOT NULL,
            login_time DATETIME NOT NULL,
            logout_time DATETIME NULL,
            duration_minutes INT NULL,
            started_by INT NULL,
            ended_by INT NULL,
            notes TEXT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_borrower (borrowernumber),
            INDEX idx_computer (computer_id),
            INDEX idx_logout (logout_time),
            INDEX idx_login (login_time),
            INDEX idx_active (logout_time, borrowernumber)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
    $db->exec("
        CREATE TABLE IF NOT EXISTS computer_policies (
            id INT PRIMARY KEY AUTO_INCREMENT,
            user_role VARCHAR(50) NOT NULL UNIQUE,
            max_minutes_per_day INT DEFAULT 0,
            max_minutes_per_week INT DEFAULT 0,
            max_sessions_per_week INT DEFAULT 0,
            require_attendance TINYINT(1) DEFAULT 0,
            weekly_attendance_required INT DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
    $db->exec("
        CREATE TABLE IF NOT EXISTS computer_attendance (
            id INT PRIMARY KEY AUTO_INCREMENT,
            borrowernumber INT NOT NULL,
            week_start_date DATE NOT NULL,
            sessions_count INT DEFAULT 0,
            total_minutes INT DEFAULT 0,
            compliant TINYINT(1) DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY uniq_borrower_week (borrowernumber, week_start_date),
            INDEX idx_week (week_start_date),
            INDEX idx_compliant (compliant)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");

    $c = (int)$db->query("SELECT COUNT(*) FROM computer_policies")->fetchColumn();
    if ($c === 0) {
        $db->exec("
            INSERT INTO computer_policies
                (user_role, max_minutes_per_day, max_minutes_per_week,
                 max_sessions_per_week, require_attendance, weekly_attendance_required)
            VALUES
                ('student', 60,  240, 3,  1, 1),
                ('teacher', 120, 480, 10, 0, 0),
                ('staff',   90,  360, 5,  1, 1),
                ('visitor', 30,  120, 2,  0, 0)
        ");
    }
} catch (PDOException $e) {
    error_log('[system.php] ensure tables: ' . $e->getMessage());
}

// ============================================================
// 10. ACTIVITY LOG HELPER
// ============================================================
function sys_log(PDO $db, int $userId, string $action, string $details = ''): void
{
    try {
        $db->prepare("
            INSERT INTO activity_log (user_id, username, action, details, ip_address, user_agent)
            VALUES (?, ?, ?, ?, ?, ?)
        ")->execute([
            $userId,
            $_SESSION['koha_username'] ?? 'system',
            $action,
            $details,
            $_SERVER['REMOTE_ADDR'] ?? null,
            $_SERVER['HTTP_USER_AGENT'] ?? null,
        ]);
    } catch (PDOException $e) {
        error_log('[system.php] sys_log: ' . $e->getMessage());
    }
}

// ============================================================
// 11. CSRF
// ============================================================
if (empty($_SESSION['sys_csrf'])) {
    $_SESSION['sys_csrf'] = bin2hex(random_bytes(32));
}
$csrf = $_SESSION['sys_csrf'];

function sys_csrf_check(?string $t): bool {
    return !empty($t) && !empty($_SESSION['sys_csrf']) && hash_equals($_SESSION['sys_csrf'], $t);
}
function sys_csrf_rotate(): void {
    $_SESSION['sys_csrf'] = bin2hex(random_bytes(32));
}

// ============================================================
// 12. KOHA MEMBER HELPERS
// ============================================================
function sys_search_members(PDO $koha, string $q, int $limit = 20): array
{
    if (!$koha || strlen($q) < 2) return [];
    try {
        $like = "%$q%";
        $s = $koha->prepare("
            SELECT
                b.borrowernumber,
                b.cardnumber,
                CONCAT_WS(' ',
                    NULLIF(TRIM(b.title),''),
                    NULLIF(TRIM(b.firstname),''),
                    NULLIF(TRIM(b.surname),'')
                ) AS name,
                b.categorycode,
                c.description AS category_description,
                b.sort1 AS class,
                b.sort2 AS division,
                (SELECT imagefile FROM patronimage
                 WHERE borrowernumber = b.borrowernumber LIMIT 1) AS photo_blob
            FROM borrowers b
            LEFT JOIN categories c ON b.categorycode = c.categorycode
            WHERE b.dateexpiry > CURDATE()
              AND (b.lost IS NULL OR b.lost = 0)
              AND (b.debarred IS NULL OR b.debarred = 0)
              AND (b.cardnumber LIKE ? OR b.firstname LIKE ? OR b.surname LIKE ?
                   OR b.sort1 LIKE ? OR b.sort2 LIKE ?)
            ORDER BY b.surname LIMIT ?
        ");
        $s->execute([$like, $like, $like, $like, $like, $limit]);
        $rows = $s->fetchAll();
        foreach ($rows as &$r) {
            $r['photo_base64'] = !empty($r['photo_blob'])
                ? 'data:image/jpeg;base64,' . base64_encode($r['photo_blob'])
                : null;
            unset($r['photo_blob']);
        }
        unset($r);
        return $rows;
    } catch (PDOException $e) {
        error_log('[system.php] search: ' . $e->getMessage());
        return [];
    }
}

function sys_batch_members(PDO $koha, array $ids): array
{
    if (!$koha || empty($ids)) return [];
    try {
        $in = implode(',', array_fill(0, count($ids), '?'));
        $s = $koha->prepare("
            SELECT
                b.borrowernumber,
                b.cardnumber,
                CONCAT_WS(' ',
                    NULLIF(TRIM(b.title),''),
                    NULLIF(TRIM(b.firstname),''),
                    NULLIF(TRIM(b.surname),'')
                ) AS name,
                b.categorycode,
                c.description AS category_description,
                b.sort1 AS class,
                b.sort2 AS division,
                (SELECT imagefile FROM patronimage
                 WHERE borrowernumber = b.borrowernumber LIMIT 1) AS photo_blob
            FROM borrowers b
            LEFT JOIN categories c ON b.categorycode = c.categorycode
            WHERE b.borrowernumber IN ($in)
        ");
        $s->execute($ids);
        $out = [];
        foreach ($s->fetchAll() as $m) {
            $m['photo_base64'] = !empty($m['photo_blob'])
                ? 'data:image/jpeg;base64,' . base64_encode($m['photo_blob'])
                : null;
            unset($m['photo_blob']);
            $out[(int)$m['borrowernumber']] = $m;
        }
        return $out;
    } catch (PDOException $e) {
        error_log('[system.php] batch: ' . $e->getMessage());
        return [];
    }
}

function sys_member_eligible(PDO $koha, int $bn): bool
{
    if (!$koha || !$bn) return false;
    try {
        $s = $koha->prepare("
            SELECT borrowernumber FROM borrowers
            WHERE borrowernumber = ?
              AND dateexpiry > CURDATE()
              AND (lost IS NULL OR lost = 0)
              AND (debarred IS NULL OR debarred = 0)
            LIMIT 1
        ");
        $s->execute([$bn]);
        return (bool)$s->fetchColumn();
    } catch (PDOException $e) {
        return false;
    }
}

// ============================================================
// 13. POLICY HELPERS
// ============================================================
function sys_policy_for(PDO $db, PDO $koha = null, int $bn = 0): array
{
    $role = 'student';
    static $aliases = [
        'student'  => ['stu','student','stud','pg','ug','puc','hsc','school','college'],
        'teacher'  => ['tea','teacher','faculty','prof','professor','lect','lecturer'],
        'staff'    => ['stf','staff','employee','emp','admin','clerk','lib'],
        'visitor'  => ['vis','visitor','guest','ext','external'],
    ];

    if ($koha && $bn) {
        try {
            $s = $koha->prepare("SELECT categorycode FROM borrowers WHERE borrowernumber = ? LIMIT 1");
            $s->execute([$bn]);
            $code = strtolower(trim((string)$s->fetchColumn()));
            if ($code !== '') {
                $p = $db->prepare("SELECT * FROM computer_policies WHERE user_role = ? LIMIT 1");
                $p->execute([$code]);
                $pol = $p->fetch();
                if ($pol) return $pol;
                foreach ($aliases as $canonical => $words) {
                    foreach ($words as $w) {
                        if (strpos($code, $w) !== false) {
                            $p->execute([$canonical]);
                            $pol = $p->fetch();
                            if ($pol) return $pol;
                            $role = $canonical;
                            break 2;
                        }
                    }
                }
            }
        } catch (PDOException $e) { /* ignore */ }
    }

    $p = $db->prepare("SELECT * FROM computer_policies WHERE user_role = ? LIMIT 1");
    $p->execute([$role]);
    $pol = $p->fetch();
    return $pol ?: [
        'user_role' => $role,
        'max_minutes_per_day' => 0,
        'max_minutes_per_week' => 0,
        'max_sessions_per_week' => 0,
        'require_attendance' => 0,
        'weekly_attendance_required' => 0,
    ];
}

function sys_check_policy(PDO $db, int $bn, array $pol): ?string
{
    $s = $db->prepare("
        SELECT COALESCE(SUM(COALESCE(duration_minutes, TIMESTAMPDIFF(MINUTE, login_time, NOW()))), 0)
        FROM computer_sessions
        WHERE borrowernumber = ? AND DATE(login_time) = CURDATE()
    ");
    $s->execute([$bn]);
    $todayMin = (int)$s->fetchColumn();
    if ((int)$pol['max_minutes_per_day'] > 0 && $todayMin >= (int)$pol['max_minutes_per_day']) {
        return 'Daily limit reached (' . $pol['max_minutes_per_day'] . ' min).';
    }

    $wkS = date('Y-m-d 00:00:00', strtotime('monday this week'));
    $wkE = date('Y-m-d 23:59:59', strtotime('sunday this week'));

    $s = $db->prepare("
        SELECT COALESCE(SUM(COALESCE(duration_minutes, TIMESTAMPDIFF(MINUTE, login_time, NOW()))), 0)
        FROM computer_sessions
        WHERE borrowernumber = ? AND login_time BETWEEN ? AND ?
    ");
    $s->execute([$bn, $wkS, $wkE]);
    $wkMin = (int)$s->fetchColumn();
    if ((int)$pol['max_minutes_per_week'] > 0 && $wkMin >= (int)$pol['max_minutes_per_week']) {
        return 'Weekly limit reached (' . $pol['max_minutes_per_week'] . ' min).';
    }

    $s = $db->prepare("
        SELECT COUNT(*) FROM computer_sessions
        WHERE borrowernumber = ? AND login_time BETWEEN ? AND ?
    ");
    $s->execute([$bn, $wkS, $wkE]);
    $wkSess = (int)$s->fetchColumn();
    if ((int)$pol['max_sessions_per_week'] > 0 && $wkSess >= (int)$pol['max_sessions_per_week']) {
        return 'Weekly session limit reached (' . $pol['max_sessions_per_week'] . ').';
    }
    return null;
}

function sys_stats(PDO $db): array
{
    try {
        return [
            'total'          => (int)$db->query("SELECT COUNT(*) FROM computers")->fetchColumn(),
            'active'         => (int)$db->query("SELECT COUNT(*) FROM computers WHERE status='active'")->fetchColumn(),
            'maintenance'    => (int)$db->query("SELECT COUNT(*) FROM computers WHERE status='maintenance'")->fetchColumn(),
            'offline'        => (int)$db->query("SELECT COUNT(*) FROM computers WHERE status='offline'")->fetchColumn(),
            'sessions_now'   => (int)$db->query("SELECT COUNT(*) FROM computer_sessions WHERE logout_time IS NULL")->fetchColumn(),
            'today_usage'    => (int)$db->query("SELECT COALESCE(SUM(duration_minutes),0) FROM computer_sessions WHERE DATE(login_time)=CURDATE()")->fetchColumn(),
            'total_sessions' => (int)$db->query("SELECT COUNT(*) FROM computer_sessions")->fetchColumn(),
        ];
    } catch (PDOException $e) {
        return ['total'=>0,'active'=>0,'maintenance'=>0,'offline'=>0,'sessions_now'=>0,'today_usage'=>0,'total_sessions'=>0];
    }
}

// ============================================================
// 14. AUTH — read Koha session (soft)
// ============================================================
$currentUserBn   = 0;
$currentUserName = 'Staff';
$currentUserRole = 'staff';
$canManage       = true;

if (isset($_COOKIE['CGISESSID']) && $kohaConnected) {
    try {
        $sid = $_COOKIE['CGISESSID'];
        $cols = $koha->query("SHOW COLUMNS FROM sessions")->fetchAll(PDO::FETCH_COLUMN);
        $bn = 0;
        if (in_array('a_session', $cols, true)) {
            $s = $koha->prepare("SELECT a_session FROM sessions WHERE id = ?");
            $s->execute([$sid]);
            $row = (string)$s->fetchColumn();
            if ($row !== '' && preg_match('/"borrowernumber"\s*[:=]\s*"?(\d+)/', $row, $m)) {
                $bn = (int)$m[1];
            }
        } else {
            $s = $koha->prepare("SELECT borrowernumber FROM sessions WHERE sessionid = ? AND lasttime > UNIX_TIMESTAMP() - 3600 LIMIT 1");
            $s->execute([$sid]);
            $bn = (int)$s->fetchColumn();
        }
        if ($bn) {
            $currentUserBn = $bn;
            $u = $koha->prepare("
                SELECT
                    CONCAT_WS(' ', NULLIF(TRIM(title),''), NULLIF(TRIM(firstname),''), NULLIF(TRIM(surname),'')) AS name,
                    categorycode
                FROM borrowers WHERE borrowernumber = ? LIMIT 1
            ");
            $u->execute([$bn]);
            $row = $u->fetch();
            if ($row) {
                $currentUserName = trim($row['name']) ?: ('User #' . $bn);
                try {
                    $perms = $koha->prepare("SELECT permission FROM user_permissions WHERE borrowernumber = ?");
                    $perms->execute([$bn]);
                    $list = $perms->fetchAll(PDO::FETCH_COLUMN);
                    if (in_array('superlibrarian', $list, true)
                        || in_array('manage_sysprefs', $list, true)
                        || in_array('manage_patrons', $list, true)) {
                        $currentUserRole = 'admin';
                    } elseif (in_array('circulate', $list, true)
                           || in_array('catalogue', $list, true)
                           || in_array('tools', $list, true)) {
                        $currentUserRole = 'staff';
                    } else {
                        $currentUserRole = 'viewer';
                    }
                } catch (PDOException $e) {
                    $currentUserRole = $bn === 1 ? 'admin' : 'staff';
                }
            }
        }
    } catch (PDOException $e) {
        error_log('[system.php] koha session: ' . $e->getMessage());
    }
}

// ============================================================
// 15. ROUTER
// ============================================================
$action = $_GET['action'] ?? '';

// ------------------------------------------------------------
// JSON: search members
// ------------------------------------------------------------
if ($action === 'ajax_members') {
    header('Content-Type: application/json; charset=utf-8');
    $q = trim($_GET['q'] ?? '');
    echo json_encode(sys_search_members($koha, $q, 20));
    exit;
}

// ------------------------------------------------------------
// JSON: stats
// ------------------------------------------------------------
if ($action === 'ajax_stats') {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(sys_stats($db));
    exit;
}

// ------------------------------------------------------------
// JSON API
// ------------------------------------------------------------
if (strpos($action, 'api_') === 0) {
    header('Content-Type: application/json; charset=utf-8');
    header('Access-Control-Allow-Origin: *');

    switch ($action) {
        case 'api_health':
            echo json_encode([
                'success' => true,
                'data' => [
                    'koha'    => $kohaConnected,
                    'db'      => true,
                    'stats'   => sys_stats($db),
                    'version' => '2.2',
                    'time'    => date('c'),
                ],
            ]);
            exit;

        case 'api_sessions':
            $status = $_GET['status'] ?? 'active';
            $sql = "
                SELECT cs.id, cs.borrowernumber, cs.computer_id,
                       cs.login_time, cs.logout_time, cs.duration_minutes,
                       c.computer_name
                FROM computer_sessions cs
                JOIN computers c ON cs.computer_id = c.id
            ";
            if ($status === 'active') $sql .= " WHERE cs.logout_time IS NULL";
            $sql .= " ORDER BY cs.login_time DESC LIMIT 200";
            echo json_encode(['success' => true, 'data' => $db->query($sql)->fetchAll()]);
            exit;

        case 'api_start':
            $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
            $bn  = (int)($input['borrowernumber'] ?? 0);
            $cid = (int)($input['computer_id']   ?? 0);
            if (!$bn || !$cid) {
                http_response_code(400); echo json_encode(['error' => 'borrowernumber and computer_id required']); exit;
            }
            $chk = $db->prepare("SELECT id FROM computer_sessions WHERE borrowernumber=? AND logout_time IS NULL");
            $chk->execute([$bn]);
            if ($chk->fetch()) {
                http_response_code(409); echo json_encode(['error' => 'Member already has an active session']); exit;
            }
            if (!sys_member_eligible($koha, $bn)) {
                http_response_code(409); echo json_encode(['error' => 'Member not eligible in Koha']); exit;
            }
            $pol = sys_policy_for($db, $koha, $bn);
            if ($v = sys_check_policy($db, $bn, $pol)) {
                http_response_code(409); echo json_encode(['error' => $v]); exit;
            }
            $db->prepare("
                INSERT INTO computer_sessions (borrowernumber, computer_id, login_time, started_by)
                VALUES (?, ?, NOW(), ?)
            ")->execute([$bn, $cid, $currentUserBn]);
            $sid = (int)$db->lastInsertId();
            sys_log($db, $currentUserBn, 'API_COMPUTER_START', "session #$sid bn #$bn cid #$cid");
            echo json_encode(['success' => true, 'data' => ['session_id' => $sid]]);
            exit;

        case 'api_end':
            $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
            $sid = (int)($input['session_id'] ?? 0);
            if (!$sid) { http_response_code(400); echo json_encode(['error' => 'session_id required']); exit; }
            $u = $db->prepare("
                UPDATE computer_sessions
                SET logout_time = NOW(),
                    duration_minutes = TIMESTAMPDIFF(MINUTE, login_time, NOW()),
                    ended_by = ?
                WHERE id = ? AND logout_time IS NULL
            ");
            $u->execute([$currentUserBn, $sid]);
            if ($u->rowCount() === 0) {
                http_response_code(404); echo json_encode(['error' => 'Session not found or already ended']); exit;
            }
            sys_log($db, $currentUserBn, 'API_COMPUTER_END', "session #$sid");
            echo json_encode(['success' => true, 'data' => ['session_id' => $sid]]);
            exit;
    }

    http_response_code(404);
    echo json_encode(['error' => 'Unknown endpoint']);
    exit;
}

// ------------------------------------------------------------
// END SESSION
// ------------------------------------------------------------
if ($action === 'end') {
    $id    = (int)($_GET['id'] ?? 0);
    $all   = (int)($_GET['all'] ?? 0);
    $token = $_GET['csrf'] ?? $_POST['csrf_token'] ?? '';

    if (!sys_csrf_check($token)) {
        http_response_code(403);
        die('Invalid security token. Reload the page and try again.');
    }

    try {
        if ($all) {
            $hours = max(1, (int)($_GET['hours'] ?? 8));
            $u = $db->prepare("
                UPDATE computer_sessions
                SET logout_time = NOW(),
                    duration_minutes = TIMESTAMPDIFF(MINUTE, login_time, NOW()),
                    ended_by = ?
                WHERE logout_time IS NULL
                  AND login_time < DATE_SUB(NOW(), INTERVAL ? HOUR)
            ");
            $u->execute([$currentUserBn, $hours]);
            sys_log($db, $currentUserBn, 'COMPUTER_SESSIONS_BULK_END', "closed {$u->rowCount()} sessions >{$hours}h");
        } elseif ($id > 0) {
            $u = $db->prepare("
                UPDATE computer_sessions
                SET logout_time = NOW(),
                    duration_minutes = TIMESTAMPDIFF(MINUTE, login_time, NOW()),
                    ended_by = ?
                WHERE id = ? AND logout_time IS NULL
            ");
            $u->execute([$currentUserBn, $id]);
            if ($u->rowCount()) sys_log($db, $currentUserBn, 'COMPUTER_SESSION_END', "session #$id");
        }
        sys_csrf_rotate();
    } catch (PDOException $e) {
        error_log('[system.php] end: ' . $e->getMessage());
    }

    header('Location: system.php');
    exit;
}

// ------------------------------------------------------------
// START SESSION (POST)
// ------------------------------------------------------------
$startError   = '';
$startSuccess = '';

if ($action === 'start' && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['start_session'])) {
    if (!sys_csrf_check($_POST['csrf_token'] ?? '')) {
        $startError = 'Invalid security token. Reload the page and try again.';
    } else {
        $bn  = (int)($_POST['borrowernumber'] ?? 0);
        $cid = (int)($_POST['computer_id']   ?? 0);

        if (!$bn || !$cid) {
            $startError = 'Please select a member and a computer.';
        } else {
            $chk = $db->prepare("
                SELECT cs.id, c.computer_name
                FROM computer_sessions cs
                JOIN computers c ON cs.computer_id = c.id
                WHERE cs.borrowernumber = ? AND cs.logout_time IS NULL
                LIMIT 1
            ");
            $chk->execute([$bn]);
            $existing = $chk->fetch();

            if ($existing) {
                $startError = 'Member already active on ' . htmlspecialchars($existing['computer_name']);
            } elseif (!sys_member_eligible($koha, $bn)) {
                $startError = 'Member not eligible in Koha.';
            } else {
                $pol = sys_policy_for($db, $koha, $bn);
                $violation = sys_check_policy($db, $bn, $pol);
                if ($violation) {
                    $startError = $violation;
                } else {
                    try {
                        $db->prepare("
                            INSERT INTO computer_sessions
                                (borrowernumber, computer_id, login_time, started_by)
                            VALUES (?, ?, NOW(), ?)
                        ")->execute([$bn, $cid, $currentUserBn]);
                        sys_log($db, $currentUserBn, 'COMPUTER_SESSION_START', "bn #$bn cid #$cid");
                        sys_csrf_rotate();
                        $csrf = $_SESSION['sys_csrf'];
                        $startSuccess = 'Session started.';
                    } catch (PDOException $e) {
                        $startError = 'DB error: ' . $e->getMessage();
                    }
                }
            }
        }
    }
}

// ------------------------------------------------------------
// MANAGE COMPUTERS (POST)
// ------------------------------------------------------------
if ($action === 'manage' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!sys_csrf_check($_POST['csrf_token'] ?? '')) {
        $_SESSION['flash_error'] = 'Invalid security token.';
        header('Location: system.php?action=manage'); exit;
    }

    $name   = trim($_POST['computer_name'] ?? '');
    $ip     = trim($_POST['ip_address']    ?? '');
    $loc    = trim($_POST['location']      ?? '');
    $status = $_POST['status'] ?? 'active';
    $notes  = trim($_POST['notes']         ?? '');

    if ($name === '' || !in_array($status, ['active','maintenance','offline'], true)) {
        $_SESSION['flash_error'] = 'Name required / invalid status.';
        header('Location: system.php?action=manage'); exit;
    }

    try {
        if (isset($_POST['add_computer'])) {
            $db->prepare("
                INSERT INTO computers (computer_name, ip_address, location, status, notes)
                VALUES (?, ?, ?, ?, ?)
            ")->execute([$name, $ip, $loc, $status, $notes]);
            sys_log($db, $currentUserBn, 'COMPUTER_ADD', $name);
            $_SESSION['flash_success'] = 'Computer added.';
        } elseif (isset($_POST['update_computer'])) {
            $id = (int)($_POST['id'] ?? 0);
            $db->prepare("
                UPDATE computers
                SET computer_name=?, ip_address=?, location=?, status=?, notes=?
                WHERE id=?
            ")->execute([$name, $ip, $loc, $status, $notes, $id]);
            sys_log($db, $currentUserBn, 'COMPUTER_UPDATE', "#$id");
            $_SESSION['flash_success'] = 'Computer updated.';
        }
        sys_csrf_rotate();
    } catch (PDOException $e) {
        $_SESSION['flash_error'] = 'DB error: ' . $e->getMessage();
    }
    header('Location: system.php?action=manage');
    exit;
}

// ------------------------------------------------------------
// DELETE COMPUTER
// ------------------------------------------------------------
if ($action === 'delete_computer') {
    if (!sys_csrf_check($_GET['csrf'] ?? '')) { http_response_code(403); die('Invalid token'); }
    $id = (int)($_GET['id'] ?? 0);
    $chk = $db->prepare("SELECT COUNT(*) FROM computer_sessions WHERE computer_id=? AND logout_time IS NULL");
    $chk->execute([$id]);
    if ((int)$chk->fetchColumn() > 0) {
        $_SESSION['flash_error'] = 'Cannot delete — computer has active sessions.';
    } else {
        $db->prepare("DELETE FROM computers WHERE id=?")->execute([$id]);
        sys_log($db, $currentUserBn, 'COMPUTER_DELETE', "#$id");
        $_SESSION['flash_success'] = 'Computer deleted.';
    }
    header('Location: system.php?action=manage');
    exit;
}

// ------------------------------------------------------------
// POLICIES (POST)
// ------------------------------------------------------------
if ($action === 'policies' && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_policies'])) {
    if (!sys_csrf_check($_POST['csrf_token'] ?? '')) {
        $_SESSION['flash_error'] = 'Invalid token.';
        header('Location: system.php?action=policies'); exit;
    }
    try {
        $upd = $db->prepare("
            UPDATE computer_policies
            SET max_minutes_per_day=?, max_minutes_per_week=?,
                max_sessions_per_week=?, require_attendance=?,
                weekly_attendance_required=?
            WHERE id=?
        ");
        foreach (($_POST['policy'] ?? []) as $id => $row) {
            $upd->execute([
                (int)($row['max_minutes_per_day']   ?? 0),
                (int)($row['max_minutes_per_week']  ?? 0),
                (int)($row['max_sessions_per_week'] ?? 0),
                isset($row['require_attendance']) ? 1 : 0,
                (int)($row['weekly_attendance_required'] ?? 0),
                (int)$id,
            ]);
        }
        sys_log($db, $currentUserBn, 'COMPUTER_POLICY_UPDATE', '');
        sys_csrf_rotate();
        $_SESSION['flash_success'] = 'Policies updated.';
    } catch (PDOException $e) {
        $_SESSION['flash_error'] = 'DB error: ' . $e->getMessage();
    }
    header('Location: system.php?action=policies');
    exit;
}

// ------------------------------------------------------------
// ATTENDANCE RECALC (POST)
// ------------------------------------------------------------
if ($action === 'attendance' && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['recalc'])) {
    if (!sys_csrf_check($_POST['csrf_token'] ?? '')) {
        $_SESSION['flash_error'] = 'Invalid token.';
        header('Location: system.php?action=attendance'); exit;
    }
    $weekStart = date('Y-m-d', strtotime('monday last week'));
    $weekEnd   = date('Y-m-d', strtotime('sunday last week'));
    $processed = 0;

    if ($kohaConnected) {
        $policies = $db->query("
            SELECT user_role, weekly_attendance_required
            FROM computer_policies WHERE require_attendance = 1
        ")->fetchAll();

        foreach ($policies as $pol) {
            $s = $koha->prepare("
                SELECT borrowernumber FROM borrowers
                WHERE categorycode = ?
                  AND dateexpiry > CURDATE()
                  AND (lost IS NULL OR lost = 0)
                  AND (debarred IS NULL OR debarred = 0)
            ");
            $s->execute([$pol['user_role']]);
            foreach ($s->fetchAll(PDO::FETCH_COLUMN) as $bn) {
                $q = $db->prepare("
                    SELECT COUNT(*) c, COALESCE(SUM(duration_minutes),0) m
                    FROM computer_sessions
                    WHERE borrowernumber = ? AND login_time BETWEEN ? AND ?
                ");
                $q->execute([(int)$bn, "$weekStart 00:00:00", "$weekEnd 23:59:59"]);
                $r = $q->fetch();
                $compliant = ((int)$r['c'] >= (int)$pol['weekly_attendance_required']) ? 1 : 0;
                $db->prepare("
                    INSERT INTO computer_attendance
                        (borrowernumber, week_start_date, sessions_count, total_minutes, compliant)
                    VALUES (?, ?, ?, ?, ?)
                    ON DUPLICATE KEY UPDATE
                        sessions_count=VALUES(sessions_count),
                        total_minutes=VALUES(total_minutes),
                        compliant=VALUES(compliant)
                ")->execute([(int)$bn, $weekStart, (int)$r['c'], (int)$r['m'], $compliant]);
                $processed++;
            }
        }
    }
    sys_log($db, $currentUserBn, 'COMPUTER_ATTENDANCE_RECALC', "processed=$processed");
    sys_csrf_rotate();
    $_SESSION['flash_success'] = "Recalculated $processed borrowers.";
    header('Location: system.php?action=attendance&week=' . urlencode($weekStart));
    exit;
}

// ------------------------------------------------------------
// REPORTS EXPORT (Excel / PDF)
// ------------------------------------------------------------
if ($action === 'reports' && isset($_GET['format'])) {
    $format = $_GET['format'];
    $from   = $_GET['from_date'] ?? date('Y-m-01');
    $to     = $_GET['to_date']   ?? date('Y-m-d');
    $search = trim($_GET['member_search'] ?? '');
    $compId = (int)($_GET['computer_id'] ?? 0);

    $sql = "
        SELECT cs.*, c.computer_name, c.location AS computer_location
        FROM computer_sessions cs
        LEFT JOIN computers c ON cs.computer_id = c.id
        WHERE DATE(cs.login_time) BETWEEN ? AND ?
    ";
    $params = [$from, $to];
    if ($compId > 0) { $sql .= " AND cs.computer_id = ?"; $params[] = $compId; }
    $sql .= " ORDER BY cs.login_time DESC";
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $sessions = $stmt->fetchAll();

    $members = sys_batch_members($koha, array_map(fn($r) => (int)$r['borrowernumber'], $sessions));

    if ($search !== '') {
        $needle = mb_strtolower($search);
        $sessions = array_values(array_filter($sessions, function ($s) use ($members, $needle) {
            $m = $members[(int)$s['borrowernumber']] ?? null;
            if (!$m) return false;
            return mb_strpos(mb_strtolower(($m['name'] ?? '') . ' ' . ($m['cardnumber'] ?? '')), $needle) !== false;
        }));
    }

    $totalSessions = count($sessions);
    $totalMinutes  = (int)array_sum(array_column($sessions, 'duration_minutes'));
    $totalHours    = round($totalMinutes / 60, 1);

    if ($format === 'excel') {
        header('Content-Type: application/vnd.ms-excel; charset=utf-8');
        header('Content-Disposition: attachment; filename="computer_usage_' . date('Y-m-d') . '.xls"');
        echo "\xEF\xBB\xBF";
        ?>
        <html><head><meta charset="UTF-8"><style>
            body{font-family:Arial;font-size:10pt;}
            table{width:100%;border-collapse:collapse;}
            th,td{border:1px solid #ddd;padding:6px;}
            th{background:#1e3c72;color:#fff;}
            h2,h3{text-align:center;}
        </style></head><body>
        <h2><?= htmlspecialchars($institutionName) ?></h2>
        <h3>Computer Usage Report — <?= htmlspecialchars($from) ?> → <?= htmlspecialchars($to) ?></h3>
        <table>
            <thead><tr>
                <th>#</th><th>Member</th><th>Adm No</th><th>Category</th>
                <th>Class</th><th>Division</th><th>Computer</th>
                <th>Login</th><th>Logout</th><th>Min</th>
            </tr></thead>
            <tbody>
            <?php $sn = 1; foreach ($sessions as $s): $m = $members[(int)$s['borrowernumber']] ?? []; ?>
                <tr>
                    <td><?= $sn++ ?></td>
                    <td><?= htmlspecialchars($m['name'] ?? '—') ?></td>
                    <td><?= htmlspecialchars($m['cardnumber'] ?? '—') ?></td>
                    <td><?= htmlspecialchars($m['category_description'] ?? '—') ?></td>
                    <td><?= htmlspecialchars($m['class'] ?? '—') ?></td>
                    <td><?= htmlspecialchars($m['division'] ?? '—') ?></td>
                    <td><?= htmlspecialchars($s['computer_name'] ?? '—') ?></td>
                    <td><?= date('d-m-Y H:i', strtotime($s['login_time'])) ?></td>
                    <td><?= $s['logout_time'] ? date('d-m-Y H:i', strtotime($s['logout_time'])) : 'Active' ?></td>
                    <td><?= (int)($s['duration_minutes'] ?? 0) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <p style="text-align:center;"><b>Total:</b> <?= $totalSessions ?> sessions · <?= $totalHours ?> hours</p>
        <p style="text-align:center;font-size:8pt;color:#777;">Generated <?= date('Y-m-d H:i:s') ?></p>
        </body></html>
        <?php
        exit;
    }

    if ($format === 'pdf') {
        header('Content-Type: text/html; charset=utf-8');
        ?>
        <!doctype html><html><head><meta charset="UTF-8"><title>Computer Usage Report</title>
        <style>
            @page { size: A4 landscape; margin: 12mm; }
            body{font-family:Arial,sans-serif;font-size:10pt;}
            table{width:100%;border-collapse:collapse;margin-top:12px;}
            th,td{border:1px solid #ddd;padding:5px;}
            th{background:#1e3c72;color:#fff;}
            h2,h3{text-align:center;margin:3px 0;}
            @media print { .np{display:none!important;} }
        </style></head><body onload="setTimeout(()=>window.print(),300);">
        <h2><?= htmlspecialchars($institutionName) ?></h2>
        <h3>Computer Usage Report — <?= htmlspecialchars($from) ?> to <?= htmlspecialchars($to) ?></h3>
        <table>
            <thead><tr>
                <th>#</th><th>Member</th><th>Adm No</th><th>Category</th>
                <th>Class</th><th>Division</th><th>Computer</th>
                <th>Login</th><th>Logout</th><th>Min</th>
            </tr></thead>
            <tbody>
            <?php $sn = 1; foreach ($sessions as $s): $m = $members[(int)$s['borrowernumber']] ?? []; ?>
                <tr>
                    <td><?= $sn++ ?></td>
                    <td><?= htmlspecialchars($m['name'] ?? '—') ?></td>
                    <td><?= htmlspecialchars($m['cardnumber'] ?? '—') ?></td>
                    <td><?= htmlspecialchars($m['category_description'] ?? '—') ?></td>
                    <td><?= htmlspecialchars($m['class'] ?? '—') ?></td>
                    <td><?= htmlspecialchars($m['division'] ?? '—') ?></td>
                    <td><?= htmlspecialchars($s['computer_name'] ?? '—') ?></td>
                    <td><?= date('d-m-Y H:i', strtotime($s['login_time'])) ?></td>
                    <td><?= $s['logout_time'] ? date('d-m-Y H:i', strtotime($s['logout_time'])) : 'Active' ?></td>
                    <td><?= (int)($s['duration_minutes'] ?? 0) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <p style="text-align:center;"><b>Total:</b> <?= $totalSessions ?> sessions · <?= $totalHours ?> hours</p>
        <button class="np" onclick="window.print()" style="display:block;margin:12px auto;padding:8px 18px;">Print / Save as PDF</button>
        </body></html>
        <?php
        exit;
    }
}

// ============================================================
// 16. HTML
// ============================================================
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Computer / System Management — <?= htmlspecialchars($institutionName, ENT_QUOTES, 'UTF-8', false) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<style>
:root{
    --sys-primary: #1e3c72;
    --sys-secondary: #2a5298;
    --sys-bg: #f0f2f5;
    --sys-radius: 16px;
}
* { box-sizing: border-box; }
body { font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; background: var(--sys-bg); margin: 0; }

.sys-header {
    background: linear-gradient(135deg, var(--sys-primary), var(--sys-secondary));
    color: #fff;
    padding: 18px 0;
    box-shadow: 0 2px 12px rgba(0,0,0,.08);
    margin-bottom: 20px;
}
.sys-header .container-fluid { display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px; }
.sys-header h4 { margin: 0; font-weight: 700; }
.sys-header .sys-user { font-size: .8rem; opacity: .9; }

.sys-tabs .nav-link {
    color: var(--sys-primary);
    font-weight: 600;
    border: none;
    border-bottom: 3px solid transparent;
    padding: 10px 18px;
    background: transparent;
}
.sys-tabs .nav-link.active {
    border-bottom-color: var(--sys-primary);
    background: transparent;
}
.sys-tabs .nav-link:hover { color: var(--sys-secondary); }

.sys-card {
    background: #fff;
    border-radius: var(--sys-radius);
    box-shadow: 0 2px 10px rgba(0,0,0,.05);
    overflow: hidden;
    margin-bottom: 20px;
}
.sys-card-header {
    padding: 14px 20px;
    background: #f8fafc;
    border-bottom: 1px solid #e9ecef;
    font-weight: 600;
    color: var(--sys-primary);
    display: flex;
    justify-content: space-between;
    align-items: center;
}
.sys-card-body { padding: 20px; }
.sys-card-footer {
    padding: 12px 20px;
    background: #f8fafc;
    border-top: 1px solid #e9ecef;
}

.sys-stat {
    background: #fff;
    border-radius: var(--sys-radius);
    padding: 18px;
    text-align: center;
    box-shadow: 0 2px 10px rgba(0,0,0,.04);
    border-left: 4px solid var(--sys-primary);
    transition: transform .25s ease;
    height: 100%;
}
.sys-stat:hover { transform: translateY(-4px); box-shadow: 0 8px 24px rgba(0,0,0,.08); }
.sys-stat .value { font-size: 1.8rem; font-weight: 800; color: #1e293b; line-height: 1.1; }
.sys-stat .label { font-size: .72rem; color: #6c757d; text-transform: uppercase; margin-top: 4px; letter-spacing: .4px; }
.sys-stat .icon { font-size: 1.4rem; color: var(--sys-primary); opacity: .7; margin-bottom: 6px; }

.sys-photo { width: 42px; height: 42px; border-radius: 50%; object-fit: cover; border: 2px solid #e9ecef; }
.sys-photo-lg { width: 64px; height: 64px; border-radius: 50%; object-fit: cover; border: 3px solid var(--sys-primary); }
.sys-photo-ph { width: 42px; height: 42px; border-radius: 50%; background: linear-gradient(135deg,#e9ecef,#dee2e6); display: flex; align-items: center; justify-content: center; color: #6c757d; font-size: 1.1rem; border: 2px solid #e9ecef; }

.sys-status { display: inline-flex; align-items: center; gap: 4px; padding: 3px 10px; border-radius: 12px; font-size: .72rem; font-weight: 600; }
.sys-status-active      { background: #d4edda; color: #155724; }
.sys-status-maintenance { background: #fff3cd; color: #856404; }
.sys-status-offline     { background: #f8d7da; color: #721c24; }

.sys-duration { font-family: Consolas, monospace; font-weight: 600; }

#sysMemberResults .list-group-item { cursor: pointer; transition: background .15s; }
#sysMemberResults .list-group-item:hover { background: #f0f4f8; }

@media (max-width: 768px) {
    .sys-header .container-fluid { flex-direction: column; align-items: flex-start; }
    .sys-tabs .nav-link { padding: 8px 12px; font-size: .85rem; }
    .sys-stat .value { font-size: 1.4rem; }
}
@media print {
    .sys-header, .sys-tabs, .btn, .sys-stat { display: none !important; }
    body { background: #fff; }
    .sys-card { box-shadow: none; border: 1px solid #ddd; }
}
</style>
</head>
<body>

<!-- ============================================================
HEADER
============================================================ -->
<div class="sys-header">
    <div class="container-fluid px-4">
        <h4><i class="fas fa-desktop me-2"></i> Computer / System Management</h4>
        <div class="d-flex gap-3 align-items-center flex-wrap">
            <span class="sys-user">
                <i class="fas fa-user-circle me-1"></i>
                <?= htmlspecialchars($currentUserName) ?>
                <?php if ($currentUserBn): ?><span class="opacity-75">(#<?= (int)$currentUserBn ?>)</span><?php endif; ?>
            </span>
            <a href="?action=start" class="btn btn-sm btn-success"><i class="fas fa-play me-1"></i>Start Session</a>
            <a href="?action=manage" class="btn btn-sm btn-outline-light"><i class="fas fa-server me-1"></i>Manage</a>
            <a href="?action=reports" class="btn btn-sm btn-outline-light"><i class="fas fa-chart-bar me-1"></i>Reports</a>
            <a href="../dashboard.php" class="btn btn-sm btn-outline-light" onclick="return confirm('Leave to VMS dashboard?');">
                <i class="fas fa-arrow-left me-1"></i>VMS
            </a>
        </div>
    </div>
</div>

<div class="container-fluid px-4">

<?php
if (!empty($_SESSION['flash_success'])) {
    echo '<div class="alert alert-success alert-dismissible fade show">' . htmlspecialchars($_SESSION['flash_success']) .
         '<button class="btn-close" data-bs-dismiss="alert"></button></div>';
    unset($_SESSION['flash_success']);
}
if (!empty($_SESSION['flash_error'])) {
    echo '<div class="alert alert-danger alert-dismissible fade show">' . htmlspecialchars($_SESSION['flash_error']) .
         '<button class="btn-close" data-bs-dismiss="alert"></button></div>';
    unset($_SESSION['flash_error']);
}
if (!empty($startSuccess)) echo '<div class="alert alert-success">' . htmlspecialchars($startSuccess) . '</div>';
if (!empty($startError))   echo '<div class="alert alert-danger">'  . htmlspecialchars($startError)   . '</div>';

if (!$kohaConnected) {
    echo '<div class="alert alert-warning"><i class="fas fa-exclamation-triangle me-2"></i>'
        . 'Koha database is not connected — member lookups will fail. '
        . 'Check <code>KOHA_HOST</code>, <code>KOHA_DB</code>, <code>KOHA_USER</code>, <code>KOHA_PASS</code> '
        . 'in your config or in the defaults at the top of this file.</div>';
}
?>

<ul class="nav nav-tabs sys-tabs mb-4">
    <?php
    $tabs = [
        ''           => ['fa-tachometer-alt', 'Dashboard'],
        'start'      => ['fa-play',           'Start Session'],
        'manage'     => ['fa-server',         'Computers'],
        'policies'   => ['fa-sliders-h',      'Policies'],
        'attendance' => ['fa-calendar-check', 'Attendance'],
        'reports'    => ['fa-chart-bar',      'Reports'],
    ];
    foreach ($tabs as $key => $meta):
        $isActive = ($action === $key) || ($key === '' && ($action === '' || $action === 'end'));
        $url = $key === '' ? 'system.php' : "system.php?action=$key";
    ?>
        <li class="nav-item">
            <a class="nav-link <?= $isActive ? 'active' : '' ?>" href="<?= $url ?>">
                <i class="fas <?= $meta[0] ?> me-1"></i> <?= $meta[1] ?>
            </a>
        </li>
    <?php endforeach; ?>
</ul>

<?php
// ============================================================
// TAB: DASHBOARD
// ============================================================
if ($action === '' || $action === 'end'):
    $stats = sys_stats($db);

    $search     = trim($_GET['search'] ?? '');
    $compFilter = (int)($_GET['computer'] ?? 0);

    $sql = "
        SELECT cs.id, cs.login_time, cs.borrowernumber,
               c.computer_name, c.location AS computer_location
        FROM computer_sessions cs
        JOIN computers c ON cs.computer_id = c.id
        WHERE cs.logout_time IS NULL
    ";
    $params = [];
    if ($compFilter > 0) { $sql .= " AND cs.computer_id = ?"; $params[] = $compFilter; }
    $sql .= " ORDER BY cs.login_time ASC";
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $sessions = $stmt->fetchAll();

    $members = sys_batch_members($koha, array_map(fn($r) => (int)$r['borrowernumber'], $sessions));

    if ($search !== '') {
        $needle = mb_strtolower($search);
        $sessions = array_values(array_filter($sessions, function ($s) use ($members, $needle) {
            $m = $members[(int)$s['borrowernumber']] ?? null;
            if (!$m) return false;
            return mb_strpos(mb_strtolower(($m['name'] ?? '') . ' ' . ($m['cardnumber'] ?? '')), $needle) !== false;
        }));
    }

    $computers       = $db->query("SELECT * FROM computers ORDER BY computer_name")->fetchAll();
    $computerOptions = $db->query("SELECT id, computer_name FROM computers ORDER BY computer_name")->fetchAll();
?>

<div class="row g-3 mb-4">
    <?php
    $cards = [
        ['Total',       $stats['total'],                        'fa-desktop'],
        ['Active',      $stats['active'],                       'fa-check-circle'],
        ['Maintenance', $stats['maintenance'],                  'fa-tools'],
        ['Offline',     $stats['offline'],                      'fa-power-off'],
        ['Sessions',    $stats['sessions_now'],                 'fa-hourglass-half'],
        ['Today',       round($stats['today_usage']/60,1).'h',  'fa-clock'],
    ];
    foreach ($cards as $c): ?>
        <div class="col-lg-2 col-md-4 col-6">
            <div class="sys-stat">
                <i class="fas <?= $c[2] ?> icon"></i>
                <div class="value"><?= $c[1] ?></div>
                <div class="label"><?= $c[0] ?></div>
            </div>
        </div>
    <?php endforeach; ?>
</div>

<div class="row g-4">
    <div class="col-lg-8">
        <div class="sys-card">
            <div class="sys-card-header">
                <span><i class="fas fa-hourglass-half text-warning me-2"></i>Active Sessions</span>
                <div class="d-flex gap-2 align-items-center">
                    <span class="badge bg-secondary"><?= count($sessions) ?> active</span>
                    <?php if (!empty($sessions)): ?>
                        <a href="?action=end&all=1&hours=8&csrf=<?= htmlspecialchars($csrf) ?>"
                           class="btn btn-sm btn-outline-danger"
                           onclick="return confirm('Force-end sessions older than 8 hours?');">
                            <i class="fas fa-broom me-1"></i>End Stale
                        </a>
                    <?php endif; ?>
                </div>
            </div>
            <div class="sys-card-body">
                <form method="GET" class="row g-2 mb-3">
                    <div class="col-md-5">
                        <input type="text" name="search" class="form-control form-control-sm"
                               placeholder="Search member / admno…"
                               value="<?= htmlspecialchars($search) ?>">
                    </div>
                    <div class="col-md-5">
                        <select name="computer" class="form-select form-select-sm">
                            <option value="0">All Computers</option>
                            <?php foreach ($computerOptions as $comp): ?>
                                <option value="<?= (int)$comp['id'] ?>" <?= $compFilter==$comp['id']?'selected':'' ?>>
                                    <?= htmlspecialchars($comp['computer_name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <button class="btn btn-sm btn-primary w-100"><i class="fas fa-search me-1"></i>Filter</button>
                    </div>
                </form>

                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th style="width:50px;">Photo</th>
                                <th>Member</th>
                                <th>ID</th>
                                <th>Class / Div</th>
                                <th>Computer</th>
                                <th>Login</th>
                                <th>Duration</th>
                                <th class="text-end">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php if (empty($sessions)): ?>
                            <tr><td colspan="8" class="text-center text-muted py-4">
                                <i class="fas fa-desktop fa-2x mb-2 d-block opacity-25"></i>
                                No active sessions.
                            </td></tr>
                        <?php else: foreach ($sessions as $s):
                            $m = $members[(int)$s['borrowernumber']] ?? null;
                            $dur = max(0, (int)round((time() - strtotime($s['login_time'])) / 60));
                            $durTxt = $dur < 60 ? "$dur min" : floor($dur/60) . 'h ' . ($dur%60) . 'm';
                            $durCls = $dur > 120 ? 'text-danger' : ($dur > 60 ? 'text-warning' : 'text-success');
                        ?>
                            <tr>
                                <td class="text-center">
                                    <?php if (!empty($m['photo_base64'])): ?>
                                        <img src="<?= htmlspecialchars($m['photo_base64']) ?>" class="sys-photo">
                                    <?php else: ?>
                                        <div class="sys-photo-ph"><i class="fas fa-user"></i></div>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="fw-semibold"><?= htmlspecialchars($m['name'] ?? 'Unknown') ?></div>
                                    <div class="small text-muted">
                                        <i class="fas fa-tag"></i>
                                        <?= htmlspecialchars($m['category_description'] ?? $m['categorycode'] ?? '—') ?>
                                    </div>
                                </td>
                                <td><strong><?= htmlspecialchars($m['cardnumber'] ?? '—') ?></strong></td>
                                <td>
                                    <?= htmlspecialchars($m['class'] ?? '—') ?>
                                    <br><small class="text-muted"><?= htmlspecialchars($m['division'] ?? '—') ?></small>
                                </td>
                                <td>
                                    <strong><?= htmlspecialchars($s['computer_name']) ?></strong>
                                    <br><small class="text-muted"><?= htmlspecialchars($s['computer_location'] ?? '') ?></small>
                                </td>
                                <td><?= date('d-m-Y H:i', strtotime($s['login_time'])) ?></td>
                                <td><span class="sys-duration <?= $durCls ?>"><?= $durTxt ?></span></td>
                                <td class="text-end">
                                    <a href="?action=end&id=<?= (int)$s['id'] ?>&csrf=<?= htmlspecialchars($csrf) ?>"
                                       class="btn btn-sm btn-danger"
                                       onclick="return confirm('End this session?');">
                                        <i class="fas fa-stop"></i>
                                    </a>
                                    <button class="btn btn-sm btn-outline-secondary" data-bs-toggle="modal"
                                            data-bs-target="#memberModal"
                                            data-name="<?= htmlspecialchars($m['name'] ?? '', ENT_QUOTES) ?>"
                                            data-admno="<?= htmlspecialchars($m['cardnumber'] ?? '', ENT_QUOTES) ?>"
                                            data-category="<?= htmlspecialchars($m['category_description'] ?? '', ENT_QUOTES) ?>"
                                            data-class="<?= htmlspecialchars($m['class'] ?? '', ENT_QUOTES) ?>"
                                            data-division="<?= htmlspecialchars($m['division'] ?? '', ENT_QUOTES) ?>"
                                            data-photo="<?= htmlspecialchars($m['photo_base64'] ?? '', ENT_QUOTES) ?>">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div class="col-lg-4">
        <div class="sys-card">
            <div class="sys-card-header">
                <span><i class="fas fa-server text-primary me-2"></i>Terminals</span>
                <a href="?action=manage" class="btn btn-sm btn-outline-primary">Manage</a>
            </div>
            <div class="sys-card-body p-0">
                <div class="list-group list-group-flush">
                <?php if (empty($computers)): ?>
                    <div class="list-group-item text-center text-muted py-4">
                        <i class="fas fa-desktop fa-2x mb-2 d-block opacity-25"></i>
                        No computers yet.
                    </div>
                <?php else: foreach ($computers as $c): ?>
                    <div class="list-group-item">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <strong><?= htmlspecialchars($c['computer_name']) ?></strong><br>
                                <small class="text-muted">
                                    <?= htmlspecialchars($c['ip_address'] ?? 'No IP') ?>
                                    <?= $c['location'] ? ' · ' . htmlspecialchars($c['location']) : '' ?>
                                </small>
                            </div>
                            <span class="sys-status sys-status-<?= $c['status'] ?>">
                                <?= ucfirst($c['status']) ?>
                            </span>
                        </div>
                    </div>
                <?php endforeach; endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Member Modal -->
<div class="modal fade" id="memberModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header" style="background:linear-gradient(135deg,var(--sys-primary),var(--sys-secondary));color:#fff;">
                <h5 class="modal-title"><i class="fas fa-user me-1"></i> Member</h5>
                <button class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="memberModalBody"></div>
            <div class="modal-footer">
                <button class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<script>
document.getElementById('memberModal').addEventListener('show.bs.modal', function (e) {
    const d = e.relatedTarget.dataset;
    const photo = d.photo
        ? `<img src="${d.photo}" style="width:110px;height:110px;object-fit:cover;border-radius:50%;border:3px solid #1e3c72;">`
        : `<div style="width:110px;height:110px;border-radius:50%;background:#e9ecef;display:flex;align-items:center;justify-content:center;border:3px solid #1e3c72;color:#6c757d;font-size:2.5rem;"><i class="fas fa-user"></i></div>`;
    document.getElementById('memberModalBody').innerHTML = `
        <div class="text-center mb-3">
            ${photo}
            <h4 class="mt-2">${d.name || ''}</h4>
            <span class="badge bg-primary">${d.category || ''}</span>
        </div>
        <hr>
        <div class="row">
            <div class="col-6"><strong>Adm No:</strong></div><div class="col-6">${d.admno || '—'}</div>
            <div class="col-6"><strong>Class:</strong></div><div class="col-6">${d.class || '—'}</div>
            <div class="col-6"><strong>Division:</strong></div><div class="col-6">${d.division || '—'}</div>
        </div>`;
});
</script>

<?php
// ============================================================
// TAB: START SESSION
// ============================================================
elseif ($action === 'start'):
    $computers = $db->query("
        SELECT id, computer_name, location FROM computers
        WHERE status = 'active' ORDER BY computer_name
    ")->fetchAll();
?>

<div class="sys-card" style="max-width:820px;margin:0 auto;">
    <div class="sys-card-header">
        <span><i class="fas fa-play-circle text-success me-2"></i>Start Computer Session</span>
    </div>
    <div class="sys-card-body">
        <form method="POST" action="?action=start" id="startForm">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf) ?>">
            <input type="hidden" name="start_session" value="1">
            <input type="hidden" id="selectedBorrowerNumber" name="borrowernumber" required>

            <div class="mb-4">
                <label class="form-label fw-bold">1. Search Member (Koha)</label>
                <input type="text" id="memberSearch" class="form-control form-control-lg"
                       placeholder="Type cardnumber, name, class, or division…"
                       autocomplete="off" autofocus>
                <div id="sysMemberResults" class="list-group mt-2" style="max-height:320px; overflow-y:auto;"></div>

                <div id="selectedMemberInfo" class="alert alert-info mt-3 d-none">
                    <div class="d-flex align-items-center gap-3">
                        <img id="selectedMemberPhoto" src="" alt="" class="sys-photo-lg d-none">
                        <div>
                            <div><strong>Selected:</strong>
                                <span id="selectedMemberName"></span>
                                <span class="text-muted">(ID: <span id="selectedMemberAdmno"></span>)</span>
                            </div>
                            <small>Class: <span id="selectedMemberClass"></span> ·
                                   Division: <span id="selectedMemberDivision"></span></small>
                        </div>
                    </div>
                </div>
            </div>

            <div class="mb-4">
                <label class="form-label fw-bold">2. Computer</label>
                <select name="computer_id" class="form-select form-select-lg" required>
                    <option value="">— Select Computer —</option>
                    <?php foreach ($computers as $c): ?>
                        <option value="<?= (int)$c['id'] ?>">
                            <?= htmlspecialchars($c['computer_name']) ?>
                            (<?= htmlspecialchars($c['location'] ?? 'No location') ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
                <?php if (empty($computers)): ?>
                    <div class="text-danger mt-1">No active computers. <a href="?action=manage">Add one first.</a></div>
                <?php endif; ?>
            </div>

            <button type="submit" class="btn btn-success btn-lg px-5"
                    <?= empty($computers) ? 'disabled' : '' ?>>
                <i class="fas fa-play me-2"></i>Start Session
            </button>
        </form>
    </div>
</div>

<script>
(function () {
    const input = document.getElementById('memberSearch');
    const results = document.getElementById('sysMemberResults');
    const hiddenBn = document.getElementById('selectedBorrowerNumber');
    const infoBox = document.getElementById('selectedMemberInfo');
    const nameSpan = document.getElementById('selectedMemberName');
    const admnoSpan = document.getElementById('selectedMemberAdmno');
    const classSpan = document.getElementById('selectedMemberClass');
    const divSpan = document.getElementById('selectedMemberDivision');
    const photoImg = document.getElementById('selectedMemberPhoto');

    let t = null;
    function esc(s) {
        return String(s == null ? '' : s).replace(/[&<>"']/g, m => ({
            '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'
        }[m]));
    }

    input.addEventListener('input', function () {
        clearTimeout(t);
        const q = this.value.trim();
        if (q.length < 2) { results.innerHTML = ''; return; }

        t = setTimeout(() => {
            fetch('system.php?action=ajax_members&q=' + encodeURIComponent(q), { credentials: 'same-origin' })
            .then(r => r.json())
            .then(data => {
                if (!Array.isArray(data) || data.length === 0) {
                    results.innerHTML = '<div class="list-group-item text-muted">No members found</div>';
                    return;
                }
                results.innerHTML = data.map(m => `
                    <button type="button" class="list-group-item list-group-item-action member-result"
                            data-id="${m.borrowernumber}"
                            data-admno="${esc(m.cardnumber)}"
                            data-name="${esc(m.name)}"
                            data-category="${esc(m.category_description || m.categorycode || '')}"
                            data-class="${esc(m.class || '')}"
                            data-division="${esc(m.division || '')}"
                            data-photo="${m.photo_base64 ? esc(m.photo_base64) : ''}">
                        <div class="d-flex align-items-center gap-2">
                            ${m.photo_base64
                                ? `<img src="${esc(m.photo_base64)}" class="sys-photo">`
                                : `<div class="sys-photo-ph"><i class="fas fa-user"></i></div>`}
                            <div class="text-start">
                                <strong>${esc(m.name)}</strong>
                                <span class="text-muted">(${esc(m.cardnumber)})</span><br>
                                <small>${esc(m.category_description || m.categorycode || '')}
                                    · Class: ${esc(m.class || '-')}
                                    · Div: ${esc(m.division || '-')}</small>
                            </div>
                        </div>
                    </button>
                `).join('');

                results.querySelectorAll('.member-result').forEach(btn => {
                    btn.addEventListener('click', function () {
                        hiddenBn.value = this.dataset.id;
                        nameSpan.textContent = this.dataset.name;
                        admnoSpan.textContent = this.dataset.admno;
                        classSpan.textContent = this.dataset.class || '-';
                        divSpan.textContent = this.dataset.division || '-';
                        if (photoImg) {
                            if (this.dataset.photo) {
                                photoImg.src = this.dataset.photo;
                                photoImg.classList.remove('d-none');
                            } else {
                                photoImg.classList.add('d-none');
                            }
                        }
                        infoBox.classList.remove('d-none');
                        input.value = `${this.dataset.name} (${this.dataset.admno})`;
                        results.innerHTML = '';
                    });
                });
            })
            .catch(err => {
                console.error(err);
                results.innerHTML = '<div class="list-group-item text-danger">Search failed</div>';
            });
        }, 300);
    });
})();
</script>

<?php
// ============================================================
// TAB: MANAGE COMPUTERS
// ============================================================
elseif ($action === 'manage'):
    $editRow = null;
    if (isset($_GET['edit'])) {
        $s = $db->prepare("SELECT * FROM computers WHERE id = ?");
        $s->execute([(int)$_GET['edit']]);
        $editRow = $s->fetch() ?: null;
    }
    $computers = $db->query("SELECT * FROM computers ORDER BY computer_name")->fetchAll();
?>

<div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
    <h5 class="mb-0"><i class="fas fa-server me-2 text-primary"></i>Computer Terminals</h5>
    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addModal">
        <i class="fas fa-plus me-1"></i>Add Computer
    </button>
</div>

<div class="sys-card">
    <div class="sys-card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead class="table-light">
                    <tr><th>Name</th><th>IP</th><th>Location</th><th>Status</th><th>Notes</th><th class="text-end">Actions</th></tr>
                </thead>
                <tbody>
                <?php if (empty($computers)): ?>
                    <tr><td colspan="6" class="text-center text-muted py-4">No computers yet.</td></tr>
                <?php else: foreach ($computers as $c): ?>
                    <tr>
                        <td><strong><?= htmlspecialchars($c['computer_name']) ?></strong></td>
                        <td><?= htmlspecialchars($c['ip_address'] ?? '—') ?></td>
                        <td><?= htmlspecialchars($c['location'] ?? '—') ?></td>
                        <td><span class="sys-status sys-status-<?= $c['status'] ?>"><?= ucfirst($c['status']) ?></span></td>
                        <td><?= htmlspecialchars($c['notes'] ?? '—') ?></td>
                        <td class="text-end">
                            <a href="?action=manage&edit=<?= (int)$c['id'] ?>" class="btn btn-sm btn-warning"><i class="fas fa-edit"></i></a>
                            <a href="?action=delete_computer&id=<?= (int)$c['id'] ?>&csrf=<?= htmlspecialchars($csrf) ?>"
                               class="btn btn-sm btn-danger"
                               onclick="return confirm('Delete this computer?');">
                                <i class="fas fa-trash"></i>
                            </a>
                        </td>
                    </tr>
                <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Add Modal -->
<div class="modal fade" id="addModal" tabindex="-1">
    <div class="modal-dialog"><div class="modal-content">
        <form method="POST" action="?action=manage">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf) ?>">
            <div class="modal-header" style="background:linear-gradient(135deg,var(--sys-primary),var(--sys-secondary));color:#fff;">
                <h5 class="modal-title"><i class="fas fa-plus me-1"></i>Add Computer</h5>
                <button class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="mb-2"><label class="form-label">Name *</label>
                    <input type="text" name="computer_name" class="form-control" required></div>
                <div class="mb-2"><label class="form-label">IP Address</label>
                    <input type="text" name="ip_address" class="form-control" placeholder="192.168.1.100"></div>
                <div class="mb-2"><label class="form-label">Location</label>
                    <input type="text" name="location" class="form-control"></div>
                <div class="mb-2"><label class="form-label">Status</label>
                    <select name="status" class="form-select">
                        <option value="active">Active</option>
                        <option value="maintenance">Maintenance</option>
                        <option value="offline">Offline</option>
                    </select></div>
                <div class="mb-2"><label class="form-label">Notes</label>
                    <textarea name="notes" class="form-control" rows="2"></textarea></div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button name="add_computer" class="btn btn-primary">Save</button>
            </div>
        </form>
    </div></div>
</div>

<?php if ($editRow): ?>
<div class="modal fade show" id="editModal" tabindex="-1" style="display:block;background:rgba(0,0,0,.5);">
    <div class="modal-dialog"><div class="modal-content">
        <form method="POST" action="?action=manage">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf) ?>">
            <input type="hidden" name="id" value="<?= (int)$editRow['id'] ?>">
            <div class="modal-header" style="background:linear-gradient(135deg,var(--sys-primary),var(--sys-secondary));color:#fff;">
                <h5 class="modal-title"><i class="fas fa-edit me-1"></i>Edit Computer</h5>
                <a href="?action=manage" class="btn-close btn-close-white"></a>
            </div>
            <div class="modal-body">
                <div class="mb-2"><label class="form-label">Name *</label>
                    <input type="text" name="computer_name" class="form-control"
                           value="<?= htmlspecialchars($editRow['computer_name']) ?>" required></div>
                <div class="mb-2"><label class="form-label">IP</label>
                    <input type="text" name="ip_address" class="form-control"
                           value="<?= htmlspecialchars($editRow['ip_address'] ?? '') ?>"></div>
                <div class="mb-2"><label class="form-label">Location</label>
                    <input type="text" name="location" class="form-control"
                           value="<?= htmlspecialchars($editRow['location'] ?? '') ?>"></div>
                <div class="mb-2"><label class="form-label">Status</label>
                    <select name="status" class="form-select">
                        <?php foreach (['active','maintenance','offline'] as $st): ?>
                            <option value="<?= $st ?>" <?= $editRow['status']===$st?'selected':'' ?>><?= ucfirst($st) ?></option>
                        <?php endforeach; ?>
                    </select></div>
                <div class="mb-2"><label class="form-label">Notes</label>
                    <textarea name="notes" class="form-control" rows="2"><?= htmlspecialchars($editRow['notes'] ?? '') ?></textarea></div>
            </div>
            <div class="modal-footer">
                <a href="?action=manage" class="btn btn-secondary">Cancel</a>
                <button name="update_computer" class="btn btn-primary">Update</button>
            </div>
        </form>
    </div></div>
</div>
<?php endif; ?>

<?php
// ============================================================
// TAB: POLICIES
// ============================================================
elseif ($action === 'policies'):
    $policies = $db->query("SELECT * FROM computer_policies ORDER BY user_role")->fetchAll();
?>

<h5 class="mb-3"><i class="fas fa-sliders-h me-2 text-primary"></i>Computer Usage Policies (by Koha Category)</h5>

<form method="POST" action="?action=policies">
    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf) ?>">
    <input type="hidden" name="update_policies" value="1">
    <div class="sys-card">
        <div class="sys-card-body p-0">
            <div class="table-responsive">
                <table class="table table-bordered mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>Koha Category</th>
                            <th>Max min/day</th>
                            <th>Max min/week</th>
                            <th>Max sessions/week</th>
                            <th class="text-center">Require Attendance</th>
                            <th>Sessions/week required</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($policies as $p): ?>
                        <tr>
                            <td>
                                <input type="hidden" name="policy[<?= (int)$p['id'] ?>][role]"
                                       value="<?= htmlspecialchars($p['user_role']) ?>">
                                <strong><?= htmlspecialchars(ucfirst($p['user_role'])) ?></strong>
                            </td>
                            <td><input type="number" min="0" class="form-control"
                                name="policy[<?= (int)$p['id'] ?>][max_minutes_per_day]"
                                value="<?= (int)$p['max_minutes_per_day'] ?>"></td>
                            <td><input type="number" min="0" class="form-control"
                                name="policy[<?= (int)$p['id'] ?>][max_minutes_per_week]"
                                value="<?= (int)$p['max_minutes_per_week'] ?>"></td>
                            <td><input type="number" min="0" class="form-control"
                                name="policy[<?= (int)$p['id'] ?>][max_sessions_per_week]"
                                value="<?= (int)$p['max_sessions_per_week'] ?>"></td>
                            <td class="text-center">
                                <input type="checkbox"
                                       name="policy[<?= (int)$p['id'] ?>][require_attendance]"
                                       value="1" <?= $p['require_attendance'] ? 'checked' : '' ?>>
                            </td>
                            <td><input type="number" min="0" class="form-control"
                                name="policy[<?= (int)$p['id'] ?>][weekly_attendance_required]"
                                value="<?= (int)$p['weekly_attendance_required'] ?>"></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="sys-card-footer text-end">
            <button type="submit" class="btn btn-primary">
                <i class="fas fa-save me-1"></i>Save Policies
            </button>
        </div>
    </div>
</form>

<?php
// ============================================================
// TAB: ATTENDANCE
// ============================================================
elseif ($action === 'attendance'):
    $weekStart = $_GET['week'] ?? date('Y-m-d', strtotime('monday last week'));
    $ts = strtotime($weekStart);
    if (date('N', $ts) !== '1') $weekStart = date('Y-m-d', strtotime('monday this week', $ts));
    $weekEnd = date('Y-m-d', strtotime($weekStart . ' +6 days'));

    $s = $db->prepare("
        SELECT * FROM computer_attendance
        WHERE week_start_date = ?
        ORDER BY compliant DESC, total_minutes DESC
    ");
    $s->execute([$weekStart]);
    $rows = $s->fetchAll();
    $members = sys_batch_members($koha, array_map(fn($r) => (int)$r['borrowernumber'], $rows));
?>

<div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
    <h5 class="mb-0"><i class="fas fa-calendar-check me-2 text-primary"></i>Weekly Attendance Compliance</h5>
    <form method="POST" action="?action=attendance" class="d-inline">
        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf) ?>">
        <button name="recalc" class="btn btn-warning">
            <i class="fas fa-sync me-1"></i>Recalculate Last Week
        </button>
    </form>
</div>

<div class="sys-card mb-4">
    <div class="sys-card-body">
        <form method="GET" class="d-flex gap-2 align-items-end">
            <input type="hidden" name="action" value="attendance">
            <div>
                <label class="form-label">Week starting</label>
                <input type="date" name="week" class="form-control" value="<?= htmlspecialchars($weekStart) ?>">
            </div>
            <button class="btn btn-primary"><i class="fas fa-search me-1"></i>View</button>
        </form>
    </div>
</div>

<div class="sys-card">
    <div class="sys-card-header">
        <span>Week <?= htmlspecialchars($weekStart) ?> → <?= htmlspecialchars($weekEnd) ?></span>
        <span class="badge bg-secondary"><?= count($rows) ?> members</span>
    </div>
    <div class="sys-card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead class="table-light">
                    <tr><th>Member</th><th>Card No</th><th>Category</th><th>Sessions</th><th>Total Min</th><th>Compliant</th></tr>
                </thead>
                <tbody>
                <?php if (empty($rows)): ?>
                    <tr><td colspan="6" class="text-center text-muted py-4">
                        No attendance records for this week.<br>
                        <small>Click <b>Recalculate Last Week</b> or run the cron script.</small>
                    </td></tr>
                <?php else: foreach ($rows as $r): $m = $members[(int)$r['borrowernumber']] ?? null; ?>
                    <tr>
                        <td><strong><?= htmlspecialchars($m['name'] ?? '—') ?></strong></td>
                        <td><?= htmlspecialchars($m['cardnumber'] ?? '—') ?></td>
                        <td><?= htmlspecialchars($m['category_description'] ?? $m['categorycode'] ?? '—') ?></td>
                        <td><?= (int)$r['sessions_count'] ?></td>
                        <td><?= (int)$r['total_minutes'] ?></td>
                        <td><span class="badge <?= $r['compliant'] ? 'bg-success' : 'bg-danger' ?>">
                            <?= $r['compliant'] ? 'Compliant' : 'Below Requirement' ?>
                        </span></td>
                    </tr>
                <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php
// ============================================================
// TAB: REPORTS
// ============================================================
elseif ($action === 'reports'):
    $from   = $_GET['from_date'] ?? date('Y-m-01');
    $to     = $_GET['to_date']   ?? date('Y-m-d');
    $search = trim($_GET['member_search'] ?? '');
    $compId = (int)($_GET['computer_id'] ?? 0);

    $sql = "
        SELECT cs.*, c.computer_name, c.location AS computer_location
        FROM computer_sessions cs
        LEFT JOIN computers c ON cs.computer_id = c.id
        WHERE DATE(cs.login_time) BETWEEN ? AND ?
    ";
    $params = [$from, $to];
    if ($compId > 0) { $sql .= " AND cs.computer_id = ?"; $params[] = $compId; }
    $sql .= " ORDER BY cs.login_time DESC LIMIT 1000";
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $sessions = $stmt->fetchAll();

    $members = sys_batch_members($koha, array_map(fn($r) => (int)$r['borrowernumber'], $sessions));

    if ($search !== '') {
        $needle = mb_strtolower($search);
        $sessions = array_values(array_filter($sessions, function ($s) use ($members, $needle) {
            $m = $members[(int)$s['borrowernumber']] ?? null;
            if (!$m) return false;
            return mb_strpos(mb_strtolower(($m['name'] ?? '') . ' ' . ($m['cardnumber'] ?? '')), $needle) !== false;
        }));
    }

    $totalSessions = count($sessions);
    $totalMinutes  = (int)array_sum(array_column($sessions, 'duration_minutes'));
    $totalHours    = round($totalMinutes / 60, 1);
    $avgMinutes    = $totalSessions ? round($totalMinutes / $totalSessions, 1) : 0;

    $computers = $db->query("SELECT id, computer_name FROM computers ORDER BY computer_name")->fetchAll();
?>

<h5 class="mb-3"><i class="fas fa-chart-bar me-2 text-primary"></i>Computer Usage Report</h5>

<div class="sys-card mb-4">
    <div class="sys-card-body">
        <form method="GET" class="row g-3 align-items-end">
            <input type="hidden" name="action" value="reports">
            <div class="col-md-2"><label class="form-label">From</label>
                <input type="date" name="from_date" class="form-control" value="<?= htmlspecialchars($from) ?>"></div>
            <div class="col-md-2"><label class="form-label">To</label>
                <input type="date" name="to_date" class="form-control" value="<?= htmlspecialchars($to) ?>"></div>
            <div class="col-md-3"><label class="form-label">Member</label>
                <input type="text" name="member_search" class="form-control" value="<?= htmlspecialchars($search) ?>" placeholder="Name / AdmNo"></div>
            <div class="col-md-2"><label class="form-label">Computer</label>
                <select name="computer_id" class="form-select">
                    <option value="0">All</option>
                    <?php foreach ($computers as $c): ?>
                        <option value="<?= (int)$c['id'] ?>" <?= $compId==$c['id']?'selected':'' ?>>
                            <?= htmlspecialchars($c['computer_name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select></div>
            <div class="col-md-3">
                <button class="btn btn-primary"><i class="fas fa-search me-1"></i>Filter</button>
                <a class="btn btn-success"
                   href="?action=reports&format=excel&from_date=<?= urlencode($from) ?>&to_date=<?= urlencode($to) ?>&member_search=<?= urlencode($search) ?>&computer_id=<?= $compId ?>">
                    <i class="fas fa-file-excel me-1"></i>Excel
                </a>
                <a class="btn btn-danger"
                   href="?action=reports&format=pdf&from_date=<?= urlencode($from) ?>&to_date=<?= urlencode($to) ?>&member_search=<?= urlencode($search) ?>&computer_id=<?= $compId ?>">
                    <i class="fas fa-file-pdf me-1"></i>PDF
                </a>
            </div>
        </form>
    </div>
</div>

<div class="row g-3 mb-4">
    <div class="col-md-3 col-6"><div class="sys-stat"><div class="value"><?= $totalSessions ?></div><div class="label">Sessions</div></div></div>
    <div class="col-md-3 col-6"><div class="sys-stat"><div class="value"><?= $totalHours ?>h</div><div class="label">Total Hours</div></div></div>
    <div class="col-md-3 col-6"><div class="sys-stat"><div class="value"><?= $avgMinutes ?>m</div><div class="label">Avg Duration</div></div></div>
    <div class="col-md-3 col-6"><div class="sys-stat"><div class="value"><?= count($members) ?></div><div class="label">Unique Members</div></div></div>
</div>

<div class="sys-card">
    <div class="sys-card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover table-striped mb-0">
                <thead class="table-dark">
                    <tr>
                        <th>#</th><th>Member</th><th>Adm No</th><th>Category</th>
                        <th>Class</th><th>Division</th><th>Computer</th>
                        <th>Login</th><th>Logout</th><th>Min</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (empty($sessions)): ?>
                    <tr><td colspan="10" class="text-center text-muted py-4">No sessions found.</td></tr>
                <?php else: $sn=1; foreach ($sessions as $s): $m = $members[(int)$s['borrowernumber']] ?? []; ?>
                    <tr>
                        <td><?= $sn++ ?></td>
                        <td><?= htmlspecialchars($m['name'] ?? '—') ?></td>
                        <td><?= htmlspecialchars($m['cardnumber'] ?? '—') ?></td>
                        <td><?= htmlspecialchars($m['category_description'] ?? '—') ?></td>
                        <td><?= htmlspecialchars($m['class'] ?? '—') ?></td>
                        <td><?= htmlspecialchars($m['division'] ?? '—') ?></td>
                        <td><?= htmlspecialchars($s['computer_name'] ?? '—') ?></td>
                        <td><?= date('d-m-Y H:i', strtotime($s['login_time'])) ?></td>
                        <td><?= $s['logout_time'] ? date('d-m-Y H:i', strtotime($s['logout_time'])) : '<span class="badge bg-warning">Active</span>' ?></td>
                        <td><?= (int)($s['duration_minutes'] ?? 0) ?></td>
                    </tr>
                <?php endforeach; endif; ?>
                </tbody>
                <tfoot class="table-light fw-bold">
                    <tr>
                        <td colspan="9" class="text-end">Total: <?= $totalSessions ?> sessions · <?= $totalHours ?> h</td>
                        <td><?= $totalMinutes ?></td>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>
</div>

<?php endif; ?>

</div><!-- /.container-fluid -->

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<?php
// ============================================================
// FOOTER — with entity-collapse post-processing
// ============================================================
//
// The shared vms_render_footer() may escape the institution name again
// (producing "Library &amp; information" literally in the HTML output).
// To guarantee the browser renders "Library & information", we:
//   1. Buffer whatever the footer emits.
//   2. Collapse any nested/duplicated &amp; sequences back to "&".
//   3. Echo the cleaned output.
//
// This is safe because the only place these entities appear in the
// footer is the institution name; there is no user input flowing in.

$__sysFooterOut = '';

ob_start();
try {
    if (function_exists('vms_footer_css')) { vms_footer_css(); }
    if (function_exists('vms_footer_js'))  { vms_footer_js();  }

    if (function_exists('vms_render_footer')) {
        // Hand the footer the plain name in every key it might read.
        vms_render_footer([
            'layout'           => 'compact',
            'institution_name' => $institutionName,
            'institutionName'  => $institutionName,
            'library_name'     => $institutionName,
            'site_name'        => $institutionName,
            'org_name'         => $institutionName,
            'no_escape'        => true,
        ]);
    }
} catch (Throwable $e) {
    error_log('[system.php] footer render: ' . $e->getMessage());
}
$__sysFooterOut = ob_get_clean();

// Post-process: collapse any over-encoded "&amp;" sequences that were
// produced by the footer's own escaping. This makes "Library &amp;
// information" render as "Library & information".
if ($__sysFooterOut !== '') {
    // Collapse &amp;amp;amp; / &amp;amp; / &amp; → &  (repeatedly)
    $prev = null;
    $out  = $__sysFooterOut;
    $i    = 0;
    while ($prev !== $out && $i < 5) {
        $prev = $out;
        $out  = str_replace('&amp;amp;', '&amp;', $out);
        $i++;
    }
    // Final pass: turn the outermost &amp; back to a literal & ONLY
    // inside the footer. This is the exact bug you're seeing.
    //
    // We do this carefully: only collapse sequences of the form
    //   word &amp; word   →   word & word
    // so we don't break legitimate entities like &nbsp; &copy; etc.
    $out = preg_replace_callback(
        '/(?<=[A-Za-z0-9])\s*&amp;\s*(?=[A-Za-z0-9])/',
        function () { return ' & '; },
        $out
    );

    echo $out;
}
?>

</body>
</html>
