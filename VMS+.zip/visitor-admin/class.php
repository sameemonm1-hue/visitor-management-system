<?php
/**
 * Subject Classification System – Professional Advanced Edition
 * Version: 8.1 ADVANCED — Institution Name Fix
 *
 * FIX (v8.1):
 *   • Aggressive institution-name normalization (multi-level entity decode).
 *   • Publishes clean plain string to JS as window.VMS_INSTITUTION_NAME.
 *   • Footer institution slot rendered via .textContent (never re-encodes).
 *   • Shared footer output buffered + post-processed to collapse &amp; chains.
 *   • Adds <span id="footerInstitution"> for JS injection.
 *
 * RETAINED from v8.0:
 *   • Multi-scheme (DDC / LCC / UDC / Colon) with scheme-aware lookup
 *   • Fuzzy matching (Levenshtein + token Jaccard) + confidence score
 *   • Synonyms, cross-references (see / see also), hierarchy (parent/child)
 *   • Top-5 suggestions with confidence bars
 *   • Batch title→classification
 *   • Analytics (top hits, top misses, hourly heatmap)
 *   • Audit log for every DB mutation
 *   • Command palette (Ctrl+K) + keyboard shortcuts
 *   • Koha write-back (itemcallnumber sync)
 *   • Import wizard (LCSH / FAST / Koha categories)
 *   • Export: PDF / Excel / CSV / JSON / XML / PNG / MARC-ish
 *   • Live search, dark mode, undo/redo
 */

// ============================================================
// OUTPUT BUFFERING — MUST BE FIRST
// ============================================================
ob_start();

// ============================================================
// ERROR REPORTING
// ============================================================
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', sys_get_temp_dir() . '/class_php_errors.log');

// ============================================================
// SESSION
// ============================================================
if (session_status() === PHP_SESSION_NONE) {
    session_name('CGISESSID');
    if (isset($_COOKIE['CGISESSID'])) session_id($_COOKIE['CGISESSID']);
    session_start();
}

// ============================================================
// FATAL ERROR HANDLER
// ============================================================
register_shutdown_function(function () {
    $err = error_get_last();
    if ($err && in_array($err['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR])) {
        while (ob_get_level() > 0) { ob_end_clean(); }
        $isAjax = !empty($_GET['ajax_action']) || !empty($_POST['ajax_action']);
        if ($isAjax) {
            header('Content-Type: application/json; charset=utf-8');
            http_response_code(500);
            echo json_encode([
                'success' => false,
                'error'   => 'PHP Fatal: ' . $err['message'],
                'file'    => basename($err['file']),
                'line'    => (int)$err['line'],
            ]);
        } else {
            header('Content-Type: text/html; charset=utf-8');
            echo '<!DOCTYPE html><html><body style="font-family:sans-serif;padding:20px;">';
            echo '<h2 style="color:#dc3545;">⚠️ System Error</h2>';
            echo '<p><strong>' . htmlspecialchars($err['message']) . '</strong></p>';
            echo '<p>File: <code>' . htmlspecialchars(basename($err['file'])) . '</code> line ' . (int)$err['line'] . '</p>';
            echo '</body></html>';
        }
    }
});

// ============================================================
// HELPER: Send clean JSON and exit
// ============================================================
function sendJson($data) {
    while (ob_get_level() > 0) { ob_end_clean(); }
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-cache, no-store, must-revalidate');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

// ============================================================
// BOOTSTRAP – Load main VMS config
// ============================================================
$configPaths = [
    __DIR__ . '/includes/config.php',
    __DIR__ . '/../includes/config.php',
    '/usr/share/koha/intranet/cgi-bin/visitor/includes/config.php',
    '/usr/share/koha/intranet/cgi-bin/koha/visitor/includes/config.php',
];
$mainConfigLoaded = false;
foreach ($configPaths as $path) {
    if (file_exists($path)) { require_once $path; $mainConfigLoaded = true; break; }
}

// ============================================================
// LOAD SHARED FOOTER PARTIAL
// ============================================================
$footerPartialPaths = [
    __DIR__ . '/includes/footer_partial.php',
    __DIR__ . '/../includes/footer_partial.php',
    '/usr/share/koha/intranet/cgi-bin/visitor/includes/footer_partial.php',
    '/usr/share/koha/intranet/cgi-bin/koha/visitor/includes/footer_partial.php',
];
foreach ($footerPartialPaths as $p) {
    if (file_exists($p)) { require_once $p; break; }
}

// ============================================================
// KOHA CONNECTION
// ============================================================
$kohaConnected = false;
$koha = null;
$kohaError = '';
if (function_exists('getKoha')) {
    $koha = getKoha();
    if ($koha) $kohaConnected = true;
}
if (!$kohaConnected && defined('KOHA_HOST') && defined('KOHA_DB')) {
    try {
        $dsn = "mysql:host=" . KOHA_HOST . ";dbname=" . KOHA_DB . ";charset=" . (defined('KOHA_CHARSET') ? KOHA_CHARSET : 'utf8mb4');
        $koha = new PDO($dsn, KOHA_USER, KOHA_PASS, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
            PDO::ATTR_TIMEOUT => 5,
        ]);
        $kohaConnected = true;
    } catch (PDOException $e) {
        $kohaError = $e->getMessage();
        error_log("class.php: Koha fallback failed: " . $e->getMessage());
    }
}
if (!$kohaConnected && !defined('KOHA_HOST')) {
    try {
        $koha = new PDO("mysql:host=localhost;dbname=koha_library;charset=utf8mb4", 'koha_library', 'mysqlroot', [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_TIMEOUT => 5,
        ]);
        $kohaConnected = true;
    } catch (PDOException $e) { $kohaError = $e->getMessage(); }
}

// ============================================================
// VMS DB
// ============================================================
$db = null;
if (function_exists('getDB')) $db = getDB();

// Fallback: open VMS DB directly so we can read the settings table
if (!$db) {
    $__dbHost = defined('DB_HOST') ? DB_HOST : 'localhost';
    $__dbUser = defined('DB_USER') ? DB_USER : 'koha_library';
    $__dbPass = defined('DB_PASS') ? DB_PASS : '';
    $__dbName = defined('DB_NAME') ? DB_NAME : 'visitor_management';
    $__dbCs   = defined('DB_CHARSET') ? DB_CHARSET : 'utf8mb4';
    try {
        $db = new PDO(
            "mysql:host=$__dbHost;dbname=$__dbName;charset=$__dbCs",
            $__dbUser, $__dbPass,
            [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_TIMEOUT => 5,
            ]
        );
    } catch (PDOException $e) {
        $db = null;
    }
}

// ============================================================
// INSTITUTION NAME — deeply normalized to plain text  [CHANGED]
// ============================================================
/**
 * Aggressively normalize an institution name to plain text.
 *
 * "Library & information"          → "Library & information"
 * "Library &amp; information"       → "Library & information"
 * "Library &amp;amp; information"   → "Library & information"
 */
function class_clean_institution(string $raw): string {
    $raw = trim($raw);
    if ($raw === '') return 'My Library';

    if (!mb_check_encoding($raw, 'UTF-8')) {
        $fixed = @mb_convert_encoding($raw, 'UTF-8', 'ISO-8859-1');
        if ($fixed !== false && $fixed !== '') $raw = $fixed;
    }

    // Loop-decode until stable (max 5 passes)
    $prev = null; $out = $raw; $i = 0;
    while ($prev !== $out && $i < 5) {
        $prev = $out;
        $out  = html_entity_decode($out, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $i++;
    }

    // Defensive collapse of residual literal entity sequences
    $out = str_replace(
        ['&amp;amp;amp;', '&amp;amp;', '&amp;', '&AMP;', '&Amp;'],
        '&',
        $out
    );
    $out = str_replace(
        ['&quot;', '&#039;', '&#39;', '&apos;', '&lt;', '&gt;', '&nbsp;'],
        ['"',       "'",       "'",      "'",       '<',    '>',    ' '],
        $out
    );

    $out = preg_replace('/\s+/u', ' ', $out);
    $out = trim($out);

    return $out !== '' ? $out : 'My Library';
}

$institutionName = 'My Library';
if ($mainConfigLoaded && function_exists('getSettings')) {
    $settings = getSettings();
    $rawName = $settings['institution_name'] ?? '';
    if (trim((string)$rawName) !== '') {
        $institutionName = class_clean_institution((string)$rawName);
    }
}
// Fallback: read directly from the settings table
if ($institutionName === 'My Library' && $db) {
    try {
        $r = $db->query("SELECT institution_name FROM settings WHERE id = 1 LIMIT 1")->fetchColumn();
        if ($r !== false && $r !== null && trim((string)$r) !== '') {
            $institutionName = class_clean_institution((string)$r);
        }
    } catch (PDOException $e) { /* settings table missing */ }
}
if (defined('INSTITUTION_NAME') && trim((string)INSTITUTION_NAME) !== '') {
    $institutionName = class_clean_institution((string)INSTITUTION_NAME);
}

// Publish everywhere so any footer partial can read it
$GLOBALS['institution_name'] = $institutionName;
$GLOBALS['institutionName']  = $institutionName;
$GLOBALS['INSTITUTION_NAME'] = $institutionName;

// ============================================================
// CREATE / MIGRATE TABLES
// ============================================================
$classificationTableReady = false;
$auditTableReady = false;
$analyticsTableReady = false;

function hasColumn(PDO $db, string $table, string $col): bool {
    try {
        $s = $db->prepare("
            SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
            WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?
        ");
        $s->execute([$table, $col]);
        return (int)$s->fetchColumn() > 0;
    } catch (PDOException $e) { return false; }
}
function addColumn(PDO $db, string $table, string $col, string $def): void {
    if (hasColumn($db, $table, $col)) return;
    try { $db->exec("ALTER TABLE `$table` ADD COLUMN `$col` $def"); }
    catch (PDOException $e) { error_log("addColumn $table.$col: " . $e->getMessage()); }
}

if ($db) {
    try {
        $db->exec("
            CREATE TABLE IF NOT EXISTS classification_data (
                id INT AUTO_INCREMENT PRIMARY KEY,
                code VARCHAR(32) NOT NULL UNIQUE,
                subjects TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                INDEX idx_code (code)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        addColumn($db, 'classification_data', 'scheme',        "VARCHAR(16) DEFAULT 'DDC'");
        addColumn($db, 'classification_data', 'parent_code',   "VARCHAR(32) NULL");
        addColumn($db, 'classification_data', 'synonyms',      "TEXT NULL");
        addColumn($db, 'classification_data', 'see_also',      "TEXT NULL");
        addColumn($db, 'classification_data', 'description',   "TEXT NULL");
        addColumn($db, 'classification_data', 'hits',          "INT DEFAULT 0");
        addColumn($db, 'classification_data', 'misses',        "INT DEFAULT 0");
        $classificationTableReady = true;
    } catch (PDOException $e) {
        error_log("class.php: classification_data migration: " . $e->getMessage());
    }

    try {
        $db->exec("
            CREATE TABLE IF NOT EXISTS classification_audit (
                id INT AUTO_INCREMENT PRIMARY KEY,
                action VARCHAR(32) NOT NULL,
                code VARCHAR(32) NULL,
                before_json TEXT NULL,
                after_json TEXT NULL,
                username VARCHAR(100) NULL,
                ip VARCHAR(45) NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_action (action),
                INDEX idx_code (code),
                INDEX idx_created (created_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        $auditTableReady = true;
    } catch (PDOException $e) {
        error_log("class.php: audit table: " . $e->getMessage());
    }

    try {
        $db->exec("
            CREATE TABLE IF NOT EXISTS classification_analytics (
                id INT AUTO_INCREMENT PRIMARY KEY,
                query VARCHAR(255) NOT NULL,
                matched_code VARCHAR(32) NULL,
                confidence DECIMAL(5,2) NULL,
                source VARCHAR(32) NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_query (query),
                INDEX idx_code (matched_code),
                INDEX idx_created (created_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        $analyticsTableReady = true;
    } catch (PDOException $e) {
        error_log("class.php: analytics table: " . $e->getMessage());
    }
}

// ============================================================
// AUDIT HELPER
// ============================================================
function audit_log($db, $ready, string $action, ?string $code = null, $before = null, $after = null): void {
    if (!$ready || !$db) return;
    try {
        $db->prepare("
            INSERT INTO classification_audit (action, code, before_json, after_json, username, ip)
            VALUES (?, ?, ?, ?, ?, ?)
        ")->execute([
            $action, $code,
            $before === null ? null : json_encode($before, JSON_UNESCAPED_UNICODE),
            $after  === null ? null : json_encode($after, JSON_UNESCAPED_UNICODE),
            $_SESSION['koha_username'] ?? 'system',
            $_SERVER['REMOTE_ADDR'] ?? null,
        ]);
    } catch (PDOException $e) { error_log("audit_log: " . $e->getMessage()); }
}

// ============================================================
// LOAD / SAVE CLASSIFICATION
// ============================================================
function loadCurrentClassificationData($db, $tableReady, $jsonFile) {
    if ($tableReady && $db) {
        try {
            $stmt = $db->query("
                SELECT code, subjects, scheme, parent_code, synonyms, see_also, description, hits, misses
                FROM classification_data ORDER BY code
            ");
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
            if (!empty($rows)) {
                $out = [];
                foreach ($rows as $r) {
                    $out[] = [
                        'code'        => $r['code'],
                        'subjects'    => array_values(array_filter(array_map('trim', explode('|', $r['subjects'])))),
                        'scheme'      => $r['scheme'] ?: 'DDC',
                        'parent_code' => $r['parent_code'] ?: null,
                        'synonyms'    => $r['synonyms'] ? array_values(array_filter(array_map('trim', explode('|', $r['synonyms'])))) : [],
                        'see_also'    => $r['see_also'] ? array_values(array_filter(array_map('trim', explode('|', $r['see_also'])))) : [],
                        'description' => $r['description'] ?: '',
                        'hits'        => (int)($r['hits'] ?? 0),
                        'misses'      => (int)($r['misses'] ?? 0),
                    ];
                }
                return $out;
            }
        } catch (PDOException $e) {
            error_log("load: " . $e->getMessage());
        }
    }
    if (file_exists($jsonFile)) {
        $content = @file_get_contents($jsonFile);
        if ($content !== false) {
            $data = json_decode($content, true);
            if (is_array($data) && !empty($data)) return $data;
        }
    }
    return [];
}

function saveClassificationData($data, $db, $tableReady, $jsonFile) {
    $okDb = false; $okJson = false;
    if ($tableReady && $db) {
        try {
            $db->beginTransaction();
            $db->exec("DELETE FROM classification_data");
            $stmt = $db->prepare("
                INSERT INTO classification_data
                    (code, subjects, scheme, parent_code, synonyms, see_also, description, hits, misses)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            $count = 0;
            foreach ($data as $row) {
                if (empty($row['code']) || empty($row['subjects'])) continue;
                $subjects = is_array($row['subjects']) ? implode('|', $row['subjects']) : (string)$row['subjects'];
                $synonyms = !empty($row['synonyms']) ? (is_array($row['synonyms']) ? implode('|', $row['synonyms']) : (string)$row['synonyms']) : null;
                $seeAlso  = !empty($row['see_also']) ? (is_array($row['see_also']) ? implode('|', $row['see_also']) : (string)$row['see_also']) : null;
                $stmt->execute([
                    (string)$row['code'], $subjects,
                    $row['scheme'] ?? 'DDC',
                    $row['parent_code'] ?? null,
                    $synonyms, $seeAlso,
                    $row['description'] ?? null,
                    (int)($row['hits'] ?? 0),
                    (int)($row['misses'] ?? 0),
                ]);
                $count++;
            }
            $db->commit();
            $okDb = true;
        } catch (PDOException $e) {
            if ($db->inTransaction()) $db->rollBack();
            error_log("save MySQL: " . $e->getMessage());
        }
    }
    try {
        $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        if ($json !== false) {
            if (@file_put_contents($jsonFile, $json, LOCK_EX) !== false) $okJson = true;
        }
    } catch (Exception $e) { error_log("save JSON: " . $e->getMessage()); }
    return $okDb || $okJson;
}

// ============================================================
// DEFAULT SEED DATA
// ============================================================
function getDefaultClassificationData() {
    $seed = [
        ['000', ['Computer science','Generalities','General works']],
        ['004', ['Data processing','Computer science','Computing']],
        ['005', ['Computer programming','Programming','Software']],
        ['005.133', ['Programming languages','Python','Java','C++','JavaScript']],
        ['006.3', ['Artificial intelligence','AI','Machine learning']],
        ['020', ['Library science','LIS']],
        ['025.3', ['Cataloging','Classification','Metadata']],
        ['100', ['Philosophy','Psychology']],
        ['150', ['Psychology','Mental processes']],
        ['200', ['Religion','Theology']],
        ['297', ['Islam','Muslims','Quran','Hadith']],
        ['300', ['Social sciences','Sociology','Economics']],
        ['320', ['Political science','Politics','Government']],
        ['330', ['Economics','Finance','Business']],
        ['370', ['Education','Teaching','Schools']],
        ['500', ['Science','Natural sciences']],
        ['510', ['Mathematics','Algebra','Geometry']],
        ['510.01', ['Mathematics','Statistics']],
        ['530', ['Physics','Mechanics','Thermodynamics']],
        ['540', ['Chemistry','Organic','Inorganic']],
        ['570', ['Biology','Life sciences','Genetics']],
        ['600', ['Technology','Applied sciences']],
        ['610', ['Medicine','Health','Medical sciences']],
        ['620', ['Engineering','Mechanical','Electrical']],
        ['650', ['Management','Business','Leadership']],
        ['700', ['Arts','Recreation','Music']],
        ['800', ['Literature','Rhetoric','Poetry']],
        ['820', ['English literature','British literature']],
        ['890', ['Arabic literature','Other literatures']],
        ['900', ['History','Geography','Biography']],
        ['940', ['European history','World War']],
        ['950', ['Asian history','Middle East']],
        ['960', ['African history','Africa']],
        ['970', ['North American history','USA']],
        ['980', ['South American history','Latin America']],
    ];
    $out = [];
    foreach ($seed as $row) {
        $out[] = [
            'code' => $row[0], 'subjects' => $row[1],
            'scheme' => 'DDC', 'parent_code' => null,
            'synonyms' => [], 'see_also' => [],
            'description' => '', 'hits' => 0, 'misses' => 0,
        ];
    }
    return $out;
}

function getSampleBooks() {
    return [
        ['barcode'=>'BK001','title'=>'The Great Gatsby','author'=>'F. Scott Fitzgerald','call_number'=>'FIC FIT','category'=>'Fiction','isbn'=>'978-0-7432-7356-5'],
        ['barcode'=>'BK002','title'=>'1984','author'=>'George Orwell','call_number'=>'FIC ORW','category'=>'Fiction','isbn'=>'978-0-452-28423-4'],
        ['barcode'=>'BK003','title'=>'To Kill a Mockingbird','author'=>'Harper Lee','call_number'=>'FIC LEE','category'=>'Fiction','isbn'=>'978-0-06-112008-4'],
        ['barcode'=>'BK005','title'=>'The Hobbit','author'=>'J.R.R. Tolkien','call_number'=>'FIC TOL','category'=>'Fantasy','isbn'=>'978-0-547-92822-7'],
        ['barcode'=>'BK006','title'=>'A Brief History of Time','author'=>'Stephen Hawking','call_number'=>'530.1 HAW','category'=>'Science','isbn'=>'978-0-553-38016-3'],
    ];
}

// ============================================================
// LOAD CLASSIFICATION DATA
// ============================================================
$classFile = __DIR__ . '/classification_data.json';
$classificationData = loadCurrentClassificationData($db, $classificationTableReady, $classFile);
if (empty($classificationData)) {
    $classificationData = getDefaultClassificationData();
    saveClassificationData($classificationData, $db, $classificationTableReady, $classFile);
    $classificationData = loadCurrentClassificationData($db, $classificationTableReady, $classFile);
}

// ============================================================
// AJAX DETECTION
// ============================================================
$ajaxAction = '';
$jsonBodyInput = null;

if (!empty($_GET['ajax_action']))  $ajaxAction = $_GET['ajax_action'];
if (empty($ajaxAction) && !empty($_POST['ajax_action'])) $ajaxAction = $_POST['ajax_action'];

$contentType = $_SERVER['CONTENT_TYPE'] ?? '';
$isJsonRequest = (stripos($contentType, 'application/json') !== false);

if ($isJsonRequest || empty($ajaxAction)) {
    $rawBody = @file_get_contents('php://input');
    if (!empty($rawBody)) {
        $decoded = json_decode($rawBody, true);
        if (is_array($decoded)) {
            $jsonBodyInput = $decoded;
            if (empty($ajaxAction) && !empty($decoded['ajax_action'])) {
                $ajaxAction = $decoded['ajax_action'];
            }
        }
    }
}
if (empty($ajaxAction) && $isJsonRequest) {
    sendJson(['success' => false, 'error' => 'Missing ajax_action in JSON body']);
}

// ============================================================
// AJAX ROUTER
// ============================================================
if (!empty($ajaxAction)) {
    while (ob_get_level() > 0) { ob_end_clean(); }
    try {
        handleClassAjax($ajaxAction, $koha, $kohaConnected, $db, $classificationTableReady,
                        $classFile, $classificationData, $jsonBodyInput,
                        $auditTableReady, $analyticsTableReady);
    } catch (Throwable $e) {
        sendJson([
            'success' => false,
            'error'   => 'Server exception: ' . $e->getMessage(),
            'file'    => basename($e->getFile()),
            'line'    => (int)$e->getLine(),
        ]);
    }
    exit;
}

// ============================================================
// AJAX HANDLER
// ============================================================
function handleClassAjax($action, $koha, $kohaConnected, $db, $tableReady, $jsonFile, $currentData,
                        $jsonBodyInput = null, $auditReady = false, $analyticsReady = false) {

    switch ($action) {
        case 'all_books':
            sendJson(fetchKohaBooks($koha, $kohaConnected));
            return;

        case 'books_by_barcode':
            $barcodes = json_decode($_POST['barcodes'] ?? '[]', true);
            sendJson(fetchKohaBooksByBarcode($koha, $kohaConnected, $barcodes));
            return;

        case 'search_books_by_subject':
            sendJson(searchKohaBooksBySubject($koha, $kohaConnected, $_GET['subject'] ?? ''));
            return;

        case 'search_koha_items':
            sendJson(searchKohaItems($koha, $kohaConnected, $_GET['q'] ?? ''));
            return;

        case 'koha_writeback':
            $input = $jsonBodyInput ?: json_decode(file_get_contents('php://input'), true) ?: [];
            if (!$kohaConnected || !$koha) sendJson(['success'=>false,'error'=>'Koha not connected']);
            $updates = $input['updates'] ?? [];
            if (!is_array($updates) || empty($updates)) sendJson(['success'=>false,'error'=>'No updates']);
            $done = 0; $errs = [];
            try {
                $stmt = $koha->prepare("UPDATE items SET itemcallnumber = ? WHERE barcode = ?");
                foreach ($updates as $u) {
                    $bc = trim($u['barcode'] ?? '');
                    $cn = trim($u['call_number'] ?? '');
                    if (!$bc || !$cn) continue;
                    $stmt->execute([$cn, $bc]);
                    $done++;
                }
            } catch (PDOException $e) { $errs[] = $e->getMessage(); }
            audit_log($db, $auditReady, 'koha_writeback', null, null, ['count'=>$done]);
            sendJson(['success'=>true,'updated'=>$done,'errors'=>$errs]);
            return;

        case 'lookup':
            $q = trim(($_GET['q'] ?? ($jsonBodyInput['q'] ?? '')));
            $scheme = $_GET['scheme'] ?? 'DDC';
            if ($q === '') sendJson(['success'=>false,'error'=>'Empty query']);
            $res = classLookup($q, $currentData, $scheme);
            if ($analyticsReady && $db) {
                try {
                    $db->prepare("INSERT INTO classification_analytics (query, matched_code, confidence, source) VALUES (?, ?, ?, ?)")
                       ->execute([$q, $res['code'] ?? null, $res['confidence'] ?? null, 'lookup']);
                } catch (PDOException $e) {}
            }
            sendJson(['success'=>true,'data'=>$res]);
            return;

        case 'suggest':
            $q = trim(($_GET['q'] ?? ''));
            if ($q === '') sendJson(['success'=>true,'suggestions'=>[]]);
            $sugg = classSuggest($q, $currentData, 5);
            sendJson(['success'=>true,'suggestions'=>$sugg]);
            return;

        case 'batch_classify':
            $titles = $jsonBodyInput['titles'] ?? [];
            if (!is_array($titles) || empty($titles)) sendJson(['success'=>false,'error'=>'No titles']);
            $out = [];
            foreach ($titles as $t) {
                $out[] = ['title' => $t, 'result' => classLookup((string)$t, $currentData)];
            }
            sendJson(['success'=>true,'results'=>$out]);
            return;

        case 'get_classification_data':
            sendJson(loadCurrentClassificationData($db, $tableReady, $jsonFile));
            return;

        case 'save_classification':
            $raw = file_get_contents('php://input');
            $input = $jsonBodyInput ?: json_decode($raw, true);
            if (!$input || !isset($input['classification'])) {
                sendJson(['success'=>false,'error'=>'Invalid JSON or missing "classification" key']);
            }
            $classification = $input['classification'];
            $isFullReplace = !empty($input['full_replace']);
            $isList = is_array($classification) && isset($classification[0]) && is_array($classification[0])
                      && (isset($classification[0]['code']) || isset($classification[0]['subjects']));
            if (!$isList && is_array($classification) && isset($classification['code'])) {
                $classification = [$classification]; $isList = true;
            }
            if (!$isList) sendJson(['success'=>false,'error'=>'Classification must be an array']);

            $finalData = $isFullReplace
                ? $classification
                : classMergeArrays(loadCurrentClassificationData($db, $tableReady, $jsonFile), $classification);

            usort($finalData, fn($a,$b) => strcmp($a['code'], $b['code']));
            saveClassificationData($finalData, $db, $tableReady, $jsonFile);
            audit_log($db, $auditReady, $isFullReplace ? 'save_full' : 'save_merge', null, null, ['count'=>count($finalData)]);
            $verified = loadCurrentClassificationData($db, $tableReady, $jsonFile);
            sendJson(['success'=>true,'message'=>'Saved ' . count($finalData) . ' entries','count'=>count($verified),'data'=>$verified]);
            return;

        case 'add_classification':
            $input = $jsonBodyInput ?: json_decode(file_get_contents('php://input'), true);
            if (!$input || !isset($input['code']) || !isset($input['subjects'])) {
                sendJson(['success'=>false,'error'=>'Missing code or subjects']);
            }
            $code = trim($input['code']);
            $subjects = array_values(array_filter(array_map('trim', (array)$input['subjects'])));
            $scheme = trim($input['scheme'] ?? 'DDC');
            $parent = trim($input['parent_code'] ?? '') ?: null;
            $synonyms = array_values(array_filter(array_map('trim', (array)($input['synonyms'] ?? []))));
            $seeAlso  = array_values(array_filter(array_map('trim', (array)($input['see_also'] ?? []))));
            $description = trim($input['description'] ?? '');

            if (!preg_match('/^[A-Za-z0-9]{1,3}(\.\d+)?[A-Za-z0-9\-]*$/', $code)) {
                sendJson(['success'=>false,'error'=>'Invalid code format']);
            }
            if (empty($subjects)) sendJson(['success'=>false,'error'=>'No subjects provided']);

            $existing = loadCurrentClassificationData($db, $tableReady, $jsonFile);
            $merged = classMergeOne($existing, [
                'code' => $code, 'subjects' => $subjects, 'scheme' => $scheme,
                'parent_code' => $parent, 'synonyms' => $synonyms, 'see_also' => $seeAlso,
                'description' => $description,
            ]);
            usort($merged, fn($a,$b) => strcmp($a['code'],$b['code']));
            $dbWritten = saveClassificationData($merged, $db, $tableReady, $jsonFile);
            audit_log($db, $auditReady, 'add', $code, null, ['subjects'=>$subjects]);
            $verified = loadCurrentClassificationData($db, $tableReady, $jsonFile);
            sendJson(['success'=>true,'message'=>'Added successfully','db_written'=>$dbWritten,'data'=>$verified]);
            return;

        case 'update_classification':
            $input = $jsonBodyInput ?: json_decode(file_get_contents('php://input'), true);
            if (!$input || !isset($input['code'])) sendJson(['success'=>false,'error'=>'Missing code']);
            $code = trim($input['code']);
            $existing = loadCurrentClassificationData($db, $tableReady, $jsonFile);
            $before = null;
            foreach ($existing as &$row) {
                if ($row['code'] === $code) {
                    $before = $row;
                    if (isset($input['subjects']))    $row['subjects']    = array_values(array_filter(array_map('trim',(array)$input['subjects'])));
                    if (isset($input['scheme']))      $row['scheme']      = trim($input['scheme']);
                    if (isset($input['parent_code'])) $row['parent_code'] = trim($input['parent_code']) ?: null;
                    if (isset($input['synonyms']))    $row['synonyms']    = array_values(array_filter(array_map('trim',(array)$input['synonyms'])));
                    if (isset($input['see_also']))    $row['see_also']    = array_values(array_filter(array_map('trim',(array)$input['see_also'])));
                    if (isset($input['description'])) $row['description'] = trim($input['description']);
                    break;
                }
            }
            unset($row);
            if (!$before) sendJson(['success'=>false,'error'=>'Code not found']);
            saveClassificationData($existing, $db, $tableReady, $jsonFile);
            audit_log($db, $auditReady, 'update', $code, $before, $input);
            sendJson(['success'=>true,'data'=>loadCurrentClassificationData($db, $tableReady, $jsonFile)]);
            return;

        case 'delete_classification':
            $input = $jsonBodyInput ?: json_decode(file_get_contents('php://input'), true);
            if (!$input || !isset($input['code'])) sendJson(['success'=>false,'error'=>'Missing code']);
            $code = $input['code'];
            $existing = loadCurrentClassificationData($db, $tableReady, $jsonFile);
            $before = null;
            foreach ($existing as $row) { if ($row['code'] === $code) { $before = $row; break; } }
            $existing = array_values(array_filter($existing, fn($r) => $r['code'] !== $code));
            saveClassificationData($existing, $db, $tableReady, $jsonFile);
            audit_log($db, $auditReady, 'delete', $code, $before, null);
            sendJson(['success'=>true,'message'=>'Deleted','data'=>loadCurrentClassificationData($db, $tableReady, $jsonFile)]);
            return;

        case 'audit_log':
            if (!$auditReady || !$db) sendJson(['success'=>true,'entries'=>[]]);
            try {
                $limit = min(500, max(1, (int)($_GET['limit'] ?? 100)));
                $rows = $db->query("SELECT * FROM classification_audit ORDER BY id DESC LIMIT $limit")->fetchAll();
                sendJson(['success'=>true,'entries'=>$rows]);
            } catch (PDOException $e) { sendJson(['success'=>false,'error'=>$e->getMessage()]); }
            return;

        case 'analytics':
            if (!$analyticsReady || !$db) sendJson(['success'=>true,'stats'=>[]]);
            try {
                $topHits = $db->query("
                    SELECT matched_code, COUNT(*) c FROM classification_analytics
                    WHERE matched_code IS NOT NULL
                    GROUP BY matched_code ORDER BY c DESC LIMIT 20
                ")->fetchAll();
                $topMisses = $db->query("
                    SELECT query, COUNT(*) c FROM classification_analytics
                    WHERE matched_code IS NULL OR matched_code='000'
                    GROUP BY query ORDER BY c DESC LIMIT 20
                ")->fetchAll();
                $hourly = $db->query("
                    SELECT HOUR(created_at) h, COUNT(*) c FROM classification_analytics
                    WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
                    GROUP BY h ORDER BY h
                ")->fetchAll();
                sendJson(['success'=>true,'top_hits'=>$topHits,'top_misses'=>$topMisses,'hourly'=>$hourly]);
            } catch (PDOException $e) { sendJson(['success'=>false,'error'=>$e->getMessage()]); }
            return;

        case 'validate':
            $issues = classValidate($currentData);
            sendJson(['success'=>true,'issues'=>$issues]);
            return;

        default:
            sendJson(['success'=>false,'error'=>'Unknown action: ' . $action]);
    }
}

// ============================================================
// MERGE HELPERS
// ============================================================
function classMergeArrays(array $existing, array $incoming): array {
    foreach ($incoming as $new) {
        if (empty($new['code']) || empty($new['subjects'])) continue;
        $existing = classMergeOne($existing, $new);
    }
    return $existing;
}
function classMergeOne(array $existing, array $new): array {
    foreach ($existing as &$row) {
        if ($row['code'] === $new['code']) {
            $row['subjects'] = array_values(array_unique(array_merge(
                $row['subjects'] ?? [], (array)($new['subjects'] ?? [])
            )));
            if (!empty($new['scheme'])) $row['scheme'] = $new['scheme'];
            if (!empty($new['parent_code'])) $row['parent_code'] = $new['parent_code'];
            if (!empty($new['synonyms'])) $row['synonyms'] = array_values(array_unique(array_merge($row['synonyms'] ?? [], $new['synonyms'])));
            if (!empty($new['see_also'])) $row['see_also'] = array_values(array_unique(array_merge($row['see_also'] ?? [], $new['see_also'])));
            if (!empty($new['description'])) $row['description'] = $new['description'];
            return $existing;
        }
    }
    unset($row);
    $existing[] = [
        'code' => $new['code'],
        'subjects' => array_values((array)$new['subjects']),
        'scheme' => $new['scheme'] ?? 'DDC',
        'parent_code' => $new['parent_code'] ?? null,
        'synonyms' => $new['synonyms'] ?? [],
        'see_also' => $new['see_also'] ?? [],
        'description' => $new['description'] ?? '',
        'hits' => 0, 'misses' => 0,
    ];
    return $existing;
}

// ============================================================
// FUZZY LOOKUP HELPERS
// ============================================================
function classNormalize(string $s): string {
    $s = mb_strtolower(trim($s));
    $s = preg_replace('/[^\p{L}\p{N}\s]/u', ' ', $s);
    return trim(preg_replace('/\s+/', ' ', $s));
}
function classLevenshteinRatio(string $a, string $b): float {
    $a = classNormalize($a); $b = classNormalize($b);
    if ($a === '' && $b === '') return 1.0;
    $len = max(strlen($a), strlen($b));
    if ($len === 0) return 1.0;
    return 1.0 - (levenshtein($a, $b) / $len);
}
function classTokens(string $s): array {
    return array_values(array_filter(explode(' ', classNormalize($s))));
}
function classJaccard(array $a, array $b): float {
    if (empty($a) && empty($b)) return 0.0;
    $sa = array_unique($a); $sb = array_unique($b);
    $inter = count(array_intersect($sa, $sb));
    $union = count(array_unique(array_merge($sa, $sb)));
    return $union ? $inter / $union : 0.0;
}
function classScore(string $query, string $subject): float {
    $lev = classLevenshteinRatio($query, $subject);
    $jac = classJaccard(classTokens($query), classTokens($subject));
    return 0.55 * $lev + 0.45 * $jac;
}

function classLookup(string $query, array $data, string $scheme = 'DDC'): array {
    $q = trim($query);
    if ($q === '') return ['code'=>'000','matched_subject'=>'(empty)','confidence'=>0,'prefix'=>'000','suggestions'=>[]];

    if (preg_match('/^\d{3}(\.\d+)?$/', $q)) {
        foreach ($data as $row) {
            if ($row['code'] === $q && ($scheme === '' || ($row['scheme'] ?? 'DDC') === $scheme)) {
                return ['code'=>$row['code'],'matched_subject'=>$row['subjects'][0] ?? '[Direct]','confidence'=>100,'prefix'=>substr($row['code'],0,3),'suggestions'=>[]];
            }
        }
    }

    $scored = [];
    $qTokens = classTokens($q);
    foreach ($data as $row) {
        if ($scheme && ($row['scheme'] ?? 'DDC') !== $scheme) continue;
        $best = 0; $bestSubject = '';
        foreach (($row['subjects'] ?? []) as $s) {
            $sc = classScore($q, $s);
            if ($sc > $best) { $best = $sc; $bestSubject = $s; }
        }
        foreach (($row['synonyms'] ?? []) as $s) {
            $sc = classScore($q, $s);
            if ($sc > $best) { $best = $sc; $bestSubject = "[syn] " . $s; }
        }
        if ($best > 0) $scored[] = ['code'=>$row['code'],'matched_subject'=>$bestSubject,'score'=>$best];
    }
    usort($scored, fn($a,$b) => $b['score'] <=> $a['score']);

    if (empty($scored)) {
        return ['code'=>'000','matched_subject'=>'(no match)','confidence'=>0,'prefix'=>'000','suggestions'=>[]];
    }
    $best = $scored[0];
    return [
        'code' => $best['code'],
        'matched_subject' => $best['matched_subject'],
        'confidence' => round($best['score'] * 100, 1),
        'prefix' => substr($best['code'], 0, 3),
        'suggestions' => array_slice($scored, 0, 5),
    ];
}
function classSuggest(string $query, array $data, int $limit = 5): array {
    $r = classLookup($query, $data);
    return $r['suggestions'] ?? [];
}

// ============================================================
// VALIDATION
// ============================================================
function classValidate(array $data): array {
    $issues = [];
    $byCode = [];
    foreach ($data as $row) {
        $byCode[$row['code']] = $row;
    }
    foreach ($data as $row) {
        if (empty($row['subjects'])) $issues[] = ['code'=>$row['code'],'level'=>'warning','msg'=>'No subjects'];
        if (empty($row['code']) || !preg_match('/^[A-Za-z0-9]{1,3}(\.\d+)?/', $row['code'])) {
            $issues[] = ['code'=>$row['code'],'level'=>'error','msg'=>'Invalid code format'];
        }
        if (!empty($row['parent_code']) && !isset($byCode[$row['parent_code']])) {
            $issues[] = ['code'=>$row['code'],'level'=>'warning','msg'=>'Parent code not found: '.$row['parent_code']];
        }
        foreach ($row['subjects'] as $s) {
            $sNorm = classNormalize($s);
            foreach ($data as $o) {
                if ($o['code'] === $row['code']) continue;
                foreach ($o['subjects'] as $os) {
                    if (classNormalize($os) === $sNorm) {
                        $issues[] = ['code'=>$row['code'],'level'=>'info','msg'=>"Subject \"$s\" also on {$o['code']}"];
                        break 2;
                    }
                }
            }
        }
    }
    return $issues;
}

// ============================================================
// KOHA DATA FETCHERS
// ============================================================
function fetchKohaBooks($koha, $kohaConnected, $limit = 500) {
    if (!$kohaConnected || !$koha) return getSampleBooks();
    try {
        $stmt = $koha->prepare("
            SELECT i.barcode, b.title, b.author,
                   i.itemcallnumber AS call_number,
                   i.itype AS category,
                   b.isbn, b.publishercode AS publisher,
                   b.copyrightdate AS year
            FROM items i
            JOIN biblio b ON i.biblionumber = b.biblionumber
            WHERE i.notforloan = 0
            ORDER BY b.title LIMIT ?
        ");
        $stmt->execute([$limit]);
        return $stmt->fetchAll() ?: getSampleBooks();
    } catch (PDOException $e) { return getSampleBooks(); }
}
function fetchKohaBooksByBarcode($koha, $kohaConnected, $barcodes) {
    if (!$kohaConnected || !$koha || empty($barcodes)) return ['success'=>false,'books'=>[]];
    try {
        $ph = implode(',', array_fill(0, count($barcodes), '?'));
        $stmt = $koha->prepare("
            SELECT i.barcode, b.title, b.author, i.itemcallnumber AS call_number
            FROM items i JOIN biblio b ON i.biblionumber = b.biblionumber
            WHERE i.barcode IN ($ph)
        ");
        $stmt->execute($barcodes);
        return ['success'=>true,'books'=>$stmt->fetchAll()];
    } catch (PDOException $e) {
        return ['success'=>false,'error'=>$e->getMessage(),'books'=>[]];
    }
}
function searchKohaBooksBySubject($koha, $kohaConnected, $subject) {
    if (!$kohaConnected || !$koha || empty($subject)) return ['success'=>false,'books'=>[]];
    try {
        $like = '%' . $subject . '%';
        $stmt = $koha->prepare("
            SELECT i.barcode, b.title, b.author, i.itemcallnumber AS call_number
            FROM items i JOIN biblio b ON i.biblionumber = b.biblionumber
            WHERE b.title LIKE ? OR b.author LIKE ? OR i.itemcallnumber LIKE ?
            LIMIT 50
        ");
        $stmt->execute([$like,$like,$like]);
        return ['success'=>true,'books'=>$stmt->fetchAll()];
    } catch (PDOException $e) { return ['success'=>false,'books'=>[]]; }
}
function searchKohaItems($koha, $kohaConnected, $term) {
    if (!$kohaConnected || !$koha || empty($term)) return ['success'=>false,'books'=>[]];
    try {
        $like = '%' . $term . '%';
        $stmt = $koha->prepare("
            SELECT i.barcode, b.title, b.author, i.itemcallnumber AS call_number, i.itype AS category
            FROM items i JOIN biblio b ON i.biblionumber = b.biblionumber
            WHERE b.title LIKE ? OR b.author LIKE ? OR b.isbn LIKE ? OR i.barcode LIKE ?
            LIMIT 100
        ");
        $stmt->execute([$like,$like,$like,$like]);
        return ['success'=>true,'books'=>$stmt->fetchAll()];
    } catch (PDOException $e) { return ['success'=>false,'books'=>[]]; }
}

// ============================================================
// PRINT SETTINGS
// ============================================================
$defaultPrintSettings = [
    'page_size' => 'A4', 'orientation' => 'portrait',
    'margin_top' => 12, 'margin_bottom' => 12, 'margin_left' => 12, 'margin_right' => 12,
    'col_gap' => 4, 'row_gap' => 4, 'columns' => 3,
    'font_family' => 'Arial', 'font_size' => 10,
    'font_color' => '#000000', 'bg_color' => '#ffffff',
    'border_color' => '#cccccc', 'border_width' => 0.3,
    'show_border' => 1, 'show_cut_lines' => 0,
    'print_header' => 1, 'header_text' => '',
    'include_subjects' => 1, 'include_code' => 1,
];
if (isset($_SESSION['class_print_settings'])) {
    $defaultPrintSettings = array_merge($defaultPrintSettings, $_SESSION['class_print_settings']);
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_print_settings'])) {
    $new = [];
    foreach ($defaultPrintSettings as $k => $v) {
        if (isset($_POST['print_' . $k])) {
            $new[$k] = is_numeric($_POST['print_' . $k]) ? $_POST['print_' . $k] + 0 : $_POST['print_' . $k];
        }
    }
    $_SESSION['class_print_settings'] = $new;
    $defaultPrintSettings = array_merge($defaultPrintSettings, $new);
}
$p = $defaultPrintSettings;

// ============================================================
// FETCH BOOKS FOR PAGE
// ============================================================
$books = [];
$categories = [];
if ($kohaConnected && $koha) {
    try {
        $stmt = $koha->query("
            SELECT i.barcode, b.title, b.author,
                   i.itemcallnumber AS call_number,
                   i.itype AS category,
                   b.isbn, b.publishercode AS publisher,
                   b.copyrightdate AS year
            FROM items i JOIN biblio b ON i.biblionumber = b.biblionumber
            WHERE i.notforloan = 0
              AND (i.damaged IS NULL OR i.damaged = 0)
              AND (i.itemlost IS NULL OR i.itemlost = 0)
            ORDER BY b.title LIMIT 500
        ");
        $books = $stmt->fetchAll();
        $stmt = $koha->query("SELECT DISTINCT itype FROM items WHERE itype IS NOT NULL AND itype != '' ORDER BY itype");
        $categories = $stmt->fetchAll(PDO::FETCH_COLUMN);
    } catch (PDOException $e) {
        error_log("class.php: fetch: " . $e->getMessage());
    }
}
if (empty($books)) $books = getSampleBooks();

// clear buffer before HTML
while (ob_get_level() > 0) { ob_end_clean(); }

?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Subject Classification System – v8.1</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
<style>
:root{
    --primary:#1a2a6c; --primary-light:#2a4a8a;
    --bg:#eef2f7; --fg:#1e293b; --card:#fff; --card-border:#e9ecef;
    --shadow-sm:0 2px 12px rgba(0,0,0,.06);
    --shadow-md:0 8px 32px rgba(0,0,0,.10);
    --shadow-lg:0 16px 48px rgba(0,0,0,.14);
    --radius-lg:24px; --radius-md:16px; --radius-sm:12px;
    --transition:all .3s cubic-bezier(.25,.46,.45,.94);
}
[data-theme="dark"]{ --bg:#0f172a; --fg:#e2e8f0; --card:#1e293b; --card-border:#334155; }
* { box-sizing: border-box; }
body{
    font-family:'Inter',-apple-system,sans-serif;
    background:var(--bg); color:var(--fg);
    padding:20px; min-height:100vh;
    transition:background .3s,color .3s;
}
.app-header{
    background:linear-gradient(135deg,#1a2a6c 0%,#2a4a8a 50%,#3a6aaa 100%);
    padding:20px 30px; border-radius:var(--radius-lg);
    margin-bottom:28px; box-shadow:var(--shadow-lg);
    position:relative; overflow:hidden;
}
.app-header::before{
    content:''; position:absolute; top:-50%; right:-20%;
    width:300px; height:300px; border-radius:50%;
    background:rgba(255,215,0,.08); pointer-events:none;
}
.app-header .header-content{
    position:relative; z-index:1;
    display:flex; justify-content:space-between; align-items:center;
    flex-wrap:wrap; gap:15px;
}
.app-header .header-left{ display:flex; align-items:center; gap:18px; }
.app-header .header-left .icon-wrapper{
    width:56px; height:56px; border-radius:var(--radius-md);
    background:rgba(255,255,255,.15); backdrop-filter:blur(10px);
    display:flex; align-items:center; justify-content:center;
    font-size:28px; color:#ffd700;
}
.app-header h1{ color:white; font-weight:800; font-size:1.8rem; margin:0; letter-spacing:-.5px; }
.app-header p{ color:rgba(255,255,255,.7); margin:0; font-size:.85rem; }
.badge-version{
    background:rgba(255,215,0,.2); color:#ffd700;
    padding:6px 16px; border-radius:30px;
    font-size:.7rem; font-weight:600;
    border:1px solid rgba(255,215,0,.15);
}
.koha-status{
    background:rgba(255,255,255,.1); padding:4px 12px;
    border-radius:20px; font-size:.7rem; color:rgba(255,255,255,.8);
}
.koha-status .connected{ color:#7dffb3; }
.koha-status .disconnected{ color:#ff7d7d; }
.card-premium{
    background:var(--card); backdrop-filter:blur(20px);
    border-radius:var(--radius-lg);
    border:1px solid var(--card-border);
    box-shadow:var(--shadow-sm); transition:var(--transition);
    overflow:hidden; margin-bottom:20px;
}
.card-premium:hover{ box-shadow:var(--shadow-md); }
.card-premium .card-header-premium{
    padding:16px 24px; background:rgba(0,0,0,.02);
    border-bottom:1px solid var(--card-border);
    font-weight:700; font-size:.95rem; color:var(--primary);
    display:flex; align-items:center; gap:10px;
}
[data-theme="dark"] .card-premium .card-header-premium{ color:#93c5fd; }
.card-premium .card-body-premium{ padding:20px 24px; }
.btn-premium{
    padding:8px 20px; border-radius:var(--radius-sm);
    font-weight:600; font-size:.85rem;
    transition:var(--transition); border:none;
}
.btn-premium-primary{ background:linear-gradient(135deg,#1a2a6c,#2a4a8a); color:white; }
.btn-premium-primary:hover{ transform:translateY(-2px); box-shadow:0 8px 25px rgba(26,42,108,.3); color:white; }
.btn-premium-success{ background:linear-gradient(135deg,#11998e,#38ef7d); color:white; }
.btn-premium-success:hover{ transform:translateY(-2px); box-shadow:0 8px 25px rgba(17,153,142,.3); color:white; }
.btn-premium-danger{ background:linear-gradient(135deg,#c0392b,#e74c3c); color:white; }
.btn-premium-danger:hover{ transform:translateY(-2px); box-shadow:0 8px 25px rgba(192,57,43,.3); color:white; }
.btn-premium-warning{ background:linear-gradient(135deg,#d97706,#f59e0b); color:white; }
.btn-premium-warning:hover{ transform:translateY(-2px); box-shadow:0 8px 25px rgba(217,119,6,.3); color:white; }
.btn-premium-info{ background:linear-gradient(135deg,#0284c7,#0ea5e9); color:white; }
.btn-premium-info:hover{ transform:translateY(-2px); box-shadow:0 8px 25px rgba(2,132,199,.3); color:white; }
.result-box{
    background:rgba(26,42,108,.04);
    border-radius:var(--radius-sm);
    padding:16px; border-left:4px solid var(--primary);
    margin-top:10px;
}
.result-box .class-number{ font-size:2rem; font-weight:800; color:var(--primary); }
.result-box .class-prefix{ font-size:1.2rem; font-weight:600; color:var(--primary-light); }
.confidence-bar{
    height:8px; border-radius:4px;
    background:linear-gradient(90deg,#10b981,#38ef7d);
    transition:width .3s;
}
.confidence-wrap{ background:#e5e7eb; border-radius:4px; overflow:hidden; height:8px; }
.table-custom th{ background:var(--primary); color:white; font-weight:600; position:sticky; top:0; z-index:2; }
.table-custom td{ vertical-align:middle; }
.table-custom .label-tag{
    background:rgba(26,42,108,.08); color:var(--primary);
    padding:2px 10px; border-radius:12px; font-size:.75rem;
    display:inline-block; margin:2px;
}
[data-theme="dark"] .table-custom .label-tag{ color:#93c5fd; background:rgba(147,197,253,.1); }
.status-bar{
    background:rgba(0,0,0,.04); border-radius:var(--radius-sm);
    padding:8px 16px; font-size:.85rem; color:#6c757d; margin-top:10px;
}
[data-theme="dark"] .status-bar{ color:#cbd5e1; }
.status-bar.success{ background:#d4edda; color:#155724; border:1px solid #c3e6cb; }
.status-bar.error{ background:#f8d7da; color:#721c24; border:1px solid #f5c6cb; }
.status-bar.info{ background:#d1ecf1; color:#0c5460; border:1px solid #bee5eb; }
.nav-tabs-modern{
    border:none; gap:6px;
    background:rgba(255,255,255,.5); padding:6px;
    border-radius:var(--radius-md); backdrop-filter:blur(10px);
    margin-bottom:24px;
}
[data-theme="dark"] .nav-tabs-modern{ background:rgba(30,41,59,.6); }
.nav-tabs-modern .nav-link{
    border:none; border-radius:var(--radius-sm);
    padding:10px 24px; font-weight:600; color:#6c757d;
    transition:var(--transition); background:transparent;
}
.nav-tabs-modern .nav-link:hover{ color:var(--primary); background:rgba(26,42,108,.06); }
.nav-tabs-modern .nav-link.active{ background:var(--card); color:var(--primary); box-shadow:var(--shadow-sm); }
[data-theme="dark"] .nav-tabs-modern .nav-link.active{ color:#93c5fd; }
.nav-tabs-modern .nav-link i{ margin-right:10px; }
.class-table-wrap{ max-height:500px; overflow-y:auto; }
.class-table-wrap::-webkit-scrollbar{ width:4px; }
.class-table-wrap::-webkit-scrollbar-thumb{ background:#dce4ed; border-radius:4px; }
.stats-bar{
    background:linear-gradient(135deg,#1a2a6c,#2a4a8a); color:white;
    padding:12px 24px; border-radius:var(--radius-md);
    display:flex; justify-content:space-between; align-items:center;
    flex-wrap:wrap; gap:10px; margin-bottom:20px;
}
.book-list{
    max-height:300px; overflow-y:auto;
    border-radius:var(--radius-sm);
    border:1px solid var(--card-border);
}
.book-list::-webkit-scrollbar{ width:4px; }
.book-list::-webkit-scrollbar-thumb{ background:#dce4ed; border-radius:4px; }
.book-item{
    padding:8px 14px; border-bottom:1px solid rgba(0,0,0,.04);
    transition:var(--transition); cursor:pointer;
}
.book-item:hover{ background:rgba(26,42,108,.04); }
.book-item.selected{ background:rgba(26,42,108,.08); border-left:3px solid var(--primary); }
.book-item .book-title{ font-weight:600; font-size:.9rem; }
.book-item .book-meta{ font-size:.75rem; color:#6c757d; }
.btn-category{
    background:rgba(26,42,108,.06); border:1px solid var(--card-border);
    color:var(--primary); font-weight:500; font-size:.75rem;
    padding:4px 10px;
}
.btn-category:hover{ background:var(--primary); color:white; border-color:var(--primary); }
[data-theme="dark"] .btn-category{ color:#93c5fd; }
.export-toolbar{
    display:flex; gap:8px; flex-wrap:wrap;
    padding:12px 16px; background:rgba(0,0,0,.02);
    border-radius:var(--radius-sm); margin-bottom:12px;
    border:1px solid var(--card-border);
}
[data-theme="dark"] .export-toolbar{ background:rgba(255,255,255,.03); }
.export-toolbar .btn{ font-size:.78rem; font-weight:600; }
.print-settings-grid{
    display:grid; grid-template-columns:repeat(auto-fit,minmax(140px,1fr));
    gap:10px;
}
.print-settings-grid label{
    font-size:.65rem; font-weight:600; color:#6c757d;
    text-transform:uppercase; margin-bottom:2px; display:block;
}
.print-settings-grid input,
.print-settings-grid select{ font-size:.8rem; }
.form-control, .form-select{
    background:var(--card); color:var(--fg);
    border-color:var(--card-border);
}
[data-theme="dark"] .form-control,
[data-theme="dark"] .form-select{
    background:#0f172a; color:#e2e8f0; border-color:#334155;
}
[data-theme="dark"] .modal-content{ background:var(--card); color:var(--fg); }
[data-theme="dark"] .list-group-item{ background:var(--card); color:var(--fg); border-color:var(--card-border); }
.toast-notif{
    position:fixed; bottom:20px; right:20px; z-index:99999;
    padding:12px 24px; border-radius:12px;
    box-shadow:0 8px 32px rgba(0,0,0,.2);
    font-weight:500; max-width:400px; color:white;
    animation:slideUp .3s ease;
}
.toast-notif.success{ background:#11998e; }
.toast-notif.error{ background:#dc3545; }
.toast-notif.info{ background:#1a2a6c; }
@keyframes slideUp{ from{ transform:translateY(100%); opacity:0; } to{ transform:translateY(0); opacity:1; } }
.cmd-palette{
    position:fixed; top:0; left:0; right:0; bottom:0;
    background:rgba(0,0,0,.6); z-index:99998;
    display:none; align-items:flex-start; justify-content:center;
    padding-top:80px;
}
.cmd-palette.show{ display:flex; }
.cmd-palette .cmd-box{
    width:min(640px,90vw); background:var(--card);
    border-radius:var(--radius-md); box-shadow:var(--shadow-lg);
    overflow:hidden;
}
.cmd-palette .cmd-input{
    width:100%; padding:16px 20px; border:none; outline:none;
    font-size:1.1rem; background:transparent; color:var(--fg);
    border-bottom:1px solid var(--card-border);
}
.cmd-palette .cmd-results{ max-height:400px; overflow-y:auto; }
.cmd-palette .cmd-item{
    padding:12px 20px; cursor:pointer; display:flex;
    justify-content:space-between; align-items:center;
    border-bottom:1px solid var(--card-border);
}
.cmd-palette .cmd-item:hover,
.cmd-palette .cmd-item.active{ background:rgba(26,42,108,.08); }
.kbd{
    display:inline-block; padding:2px 6px; font-size:.7rem;
    font-family:monospace; background:rgba(0,0,0,.06);
    border-radius:4px; border:1px solid var(--card-border);
    color:var(--fg);
}
[data-theme="dark"] .kbd{ background:rgba(255,255,255,.1); }
.audit-row{ font-size:.8rem; padding:6px 0; border-bottom:1px solid var(--card-border); }
.scheme-chip{
    display:inline-block; padding:2px 8px; border-radius:10px;
    font-size:.7rem; font-weight:600; margin-left:6px;
}
.scheme-DDC{ background:#dbeafe; color:#1e40af; }
.scheme-LCC{ background:#fef3c7; color:#92400e; }
.scheme-UDC{ background:#dcfce7; color:#166534; }
.scheme-Colon{ background:#fce7f3; color:#9d174d; }
@media (max-width:768px){
    .app-header{ padding:16px 20px; }
    .app-header h1{ font-size:1.3rem; }
    .app-header .header-left .icon-wrapper{ width:44px; height:44px; font-size:20px; }
    .nav-tabs-modern .nav-link{ padding:8px 14px; font-size:.8rem; }
    .card-premium .card-body-premium{ padding:14px 16px; }
}
@media (max-width:480px){
    body{ padding:10px; }
    .nav-tabs-modern .nav-link{ padding:6px 10px; font-size:.7rem; }
    .nav-tabs-modern .nav-link i{ margin-right:4px; }
}
#printPreviewModal .modal-dialog{ max-width:95vw; }
#printPreviewModal .modal-body{ background:#f0f2f5; padding:20px; max-height:75vh; overflow-y:auto; }
#printPreviewModal .preview-page{
    background:white; box-shadow:0 4px 20px rgba(0,0,0,.15);
    margin:0 auto 20px; position:relative;
}
@media print {
    .no-print{ display:none !important; }
    body{ background:white !important; padding:0 !important; }
}
</style>
</head>
<body>

<!-- HEADER -->
<div class="app-header no-print">
    <div class="header-content">
        <div class="header-left">
            <div class="icon-wrapper"><i class="fas fa-tags"></i></div>
            <div>
                <h1>Subject Classification System</h1>
                <p>Professional Library Classification — v8.1</p>
            </div>
        </div>
        <div class="d-flex align-items-center gap-3 flex-wrap">
            <span class="badge-version"><i class="fas fa-code-branch me-1"></i> v8.1</span>
            <span class="koha-status">
                <i class="fas fa-database me-1"></i>
                Koha: <span id="kohaStatus" class="<?= $kohaConnected ? 'connected' : 'disconnected' ?>">
                    <?= $kohaConnected ? '✓ Connected' : '✗ Offline' ?>
                </span>
            </span>
            <span class="badge-version" style="background:rgba(255,255,255,.1);color:white;border-color:rgba(255,255,255,.2);">
                <i class="fas fa-database me-1"></i> <span id="entryCount"><?= count($classificationData) ?></span> entries
            </span>
            <button class="btn btn-light btn-sm" style="background:rgba(255,255,255,.1);color:white;border-color:rgba(255,255,255,.2);"
                    onclick="toggleTheme()" title="Dark mode">
                <i class="fas fa-moon" id="themeIcon"></i>
            </button>
            <button class="btn btn-light btn-sm" style="background:rgba(255,255,255,.1);color:white;border-color:rgba(255,255,255,.2);"
                    onclick="openCmdPalette()" title="Command palette (Ctrl+K)">
                <i class="fas fa-terminal"></i>
            </button>
        </div>
    </div>
</div>

<?php if (!$kohaConnected): ?>
<div class="alert alert-warning no-print">
    <i class="fas fa-exclamation-triangle me-2"></i>
    <strong>Koha not connected.</strong> Using sample data.
    <?php if (!empty($kohaError)): ?><br><small>Error: <?= htmlspecialchars($kohaError) ?></small><?php endif; ?>
</div>
<?php endif; ?>

<!-- STATS -->
<div class="stats-bar no-print">
    <span><i class="fas fa-tags me-2"></i> <span id="totalClasses"><?= count($classificationData) ?></span> classification numbers</span>
    <span style="font-size:.75rem;opacity:.8;">
        <i class="fas fa-keyboard me-1"></i>
        <span class="kbd">Ctrl</span>+<span class="kbd">K</span> Command palette ·
        <span class="kbd">Ctrl</span>+<span class="kbd">Shift</span>+<span class="kbd">S</span> Focus search
    </span>
</div>

<!-- PRINT SETTINGS -->
<div class="card-premium no-print">
    <div class="card-header-premium">
        <i class="fas fa-sliders-h"></i> Print Settings
        <span class="ms-auto" style="font-size:.7rem;font-weight:400;color:#6c757d;">
            <i class="fas fa-save"></i> Persisted in session
        </span>
    </div>
    <div class="card-body-premium">
        <form method="POST" id="classPrintSettingsForm">
            <div class="print-settings-grid">
                <div><label>Page Size</label>
                    <select name="print_page_size" class="form-select form-select-sm">
                        <?php foreach (['A4','Letter','Legal','A3'] as $ps): ?>
                            <option value="<?= $ps ?>" <?= $p['page_size']==$ps?'selected':'' ?>><?= $ps ?></option>
                        <?php endforeach; ?>
                    </select></div>
                <div><label>Orientation</label>
                    <select name="print_orientation" class="form-select form-select-sm">
                        <option value="portrait" <?= $p['orientation']=='portrait'?'selected':'' ?>>Portrait</option>
                        <option value="landscape" <?= $p['orientation']=='landscape'?'selected':'' ?>>Landscape</option>
                    </select></div>
                <div><label>Margin Top (mm)</label><input type="number" name="print_margin_top" class="form-control form-control-sm" value="<?= $p['margin_top'] ?>" min="0" max="50"></div>
                <div><label>Margin Bottom (mm)</label><input type="number" name="print_margin_bottom" class="form-control form-control-sm" value="<?= $p['margin_bottom'] ?>" min="0" max="50"></div>
                <div><label>Margin Left (mm)</label><input type="number" name="print_margin_left" class="form-control form-control-sm" value="<?= $p['margin_left'] ?>" min="0" max="50"></div>
                <div><label>Margin Right (mm)</label><input type="number" name="print_margin_right" class="form-control form-control-sm" value="<?= $p['margin_right'] ?>" min="0" max="50"></div>
                <div><label>Columns</label><input type="number" name="print_columns" class="form-control form-control-sm" value="<?= $p['columns'] ?>" min="1" max="8"></div>
                <div><label>Col Gap (mm)</label><input type="number" name="print_col_gap" class="form-control form-control-sm" value="<?= $p['col_gap'] ?>" min="0" max="30"></div>
                <div><label>Row Gap (mm)</label><input type="number" name="print_row_gap" class="form-control form-control-sm" value="<?= $p['row_gap'] ?>" min="0" max="30"></div>
                <div><label>Font</label>
                    <select name="print_font_family" class="form-select form-select-sm">
                        <?php foreach (['Arial','Helvetica','Times New Roman','Courier New','Georgia','Verdana','Inter'] as $f): ?>
                            <option value="<?= $f ?>" <?= $p['font_family']==$f?'selected':'' ?>><?= $f ?></option>
                        <?php endforeach; ?>
                    </select></div>
                <div><label>Font Size (pt)</label><input type="number" name="print_font_size" class="form-control form-control-sm" value="<?= $p['font_size'] ?>" min="6" max="24"></div>
                <div><label>Font Color</label><input type="color" name="print_font_color" class="form-control form-control-color form-control-sm" value="<?= $p['font_color'] ?>"></div>
                <div><label>Background</label><input type="color" name="print_bg_color" class="form-control form-control-color form-control-sm" value="<?= $p['bg_color'] ?>"></div>
                <div><label>Border Color</label><input type="color" name="print_border_color" class="form-control form-control-color form-control-sm" value="<?= $p['border_color'] ?>"></div>
                <div><label>Border Width (mm)</label><input type="number" name="print_border_width" class="form-control form-control-sm" value="<?= $p['border_width'] ?>" min="0" max="3" step="0.1"></div>
                <div><label>Show Border</label>
                    <select name="print_show_border" class="form-select form-select-sm">
                        <option value="1" <?= $p['show_border']?'selected':'' ?>>Yes</option>
                        <option value="0" <?= !$p['show_border']?'selected':'' ?>>No</option>
                    </select></div>
                <div><label>Print Header</label>
                    <select name="print_print_header" class="form-select form-select-sm">
                        <option value="1" <?= $p['print_header']?'selected':'' ?>>Yes</option>
                        <option value="0" <?= !$p['print_header']?'selected':'' ?>>No</option>
                    </select></div>
                <div style="grid-column: span 2;">
                    <label>Header Text</label>
                    <input type="text" name="print_header_text" class="form-control form-control-sm"
                           value="<?= htmlspecialchars($p['header_text'], ENT_QUOTES, 'UTF-8', false) ?>"
                           placeholder="e.g., <?= htmlspecialchars($institutionName, ENT_QUOTES, 'UTF-8', false) ?> – Classification">
                </div>
                <div><label>Include Code</label>
                    <select name="print_include_code" class="form-select form-select-sm">
                        <option value="1" <?= $p['include_code']?'selected':'' ?>>Yes</option>
                        <option value="0" <?= !$p['include_code']?'selected':'' ?>>No</option>
                    </select></div>
                <div><label>Include Subjects</label>
                    <select name="print_include_subjects" class="form-select form-select-sm">
                        <option value="1" <?= $p['include_subjects']?'selected':'' ?>>Yes</option>
                        <option value="0" <?= !$p['include_subjects']?'selected':'' ?>>No</option>
                    </select></div>
            </div>
            <div class="mt-3 d-flex gap-2 flex-wrap">
                <button type="submit" name="save_print_settings" value="1" class="btn-premium btn-premium-primary btn-sm">
                    <i class="fas fa-save me-1"></i> Save
                </button>
                <button type="button" class="btn-premium btn-premium-info btn-sm" onclick="location.reload()">
                    <i class="fas fa-sync me-1"></i> Reload
                </button>
            </div>
        </form>
    </div>
</div>

<!-- TABS -->
<ul class="nav nav-tabs-modern no-print" role="tablist">
    <li class="nav-item"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#search-tab" data-classtab="search"><i class="fas fa-search"></i> Search &amp; Classify</button></li>
    <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#manage-tab" data-classtab="manage"><i class="fas fa-edit"></i> Manage</button></li>
    <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#koha-tab" data-classtab="koha"><i class="fas fa-book"></i> Koha Books</button></li>
    <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#analytics-tab" data-classtab="analytics"><i class="fas fa-chart-line"></i> Analytics</button></li>
    <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#audit-tab" data-classtab="audit"><i class="fas fa-history"></i> Audit</button></li>
</ul>

<div class="tab-content">

    <!-- SEARCH TAB -->
    <div class="tab-pane fade show active" id="search-tab">
        <div class="row g-4">
            <div class="col-lg-5">
                <div class="card-premium">
                    <div class="card-header-premium">
                        <i class="fas fa-search"></i> Search by Subject
                        <span class="ms-auto">
                            <select id="searchScheme" class="form-select form-select-sm d-inline-block" style="width:auto;">
                                <option value="">All Schemes</option>
                                <option value="DDC" selected>DDC</option>
                                <option value="LCC">LCC</option>
                                <option value="UDC">UDC</option>
                                <option value="Colon">Colon</option>
                            </select>
                        </span>
                    </div>
                    <div class="card-body-premium">
                        <div class="input-group mb-3">
                            <input type="text" id="subjectSearch" class="form-control form-control-lg"
                                   placeholder="Type subject or number…"
                                   oninput="liveSearch(this.value)"
                                   onkeydown="if(event.key==='Enter') searchBySubject()">
                            <button class="btn btn-premium-primary" onclick="searchBySubject()"><i class="fas fa-arrow-right"></i></button>
                        </div>
                        <div id="liveSuggest" class="mb-2"></div>
                        <div id="subjectResult" class="result-box" style="display:none;">
                            <div class="d-flex justify-content-between align-items-start mb-2">
                                <div>
                                    <div class="text-muted small">Matched Subject</div>
                                    <div id="matchedLabel" class="fw-semibold">—</div>
                                </div>
                                <button class="btn btn-sm btn-outline-success" onclick="copyClassResult()"><i class="fas fa-copy"></i> Copy</button>
                            </div>
                            <div class="row">
                                <div class="col-6">
                                    <div class="text-muted small">Number</div>
                                    <div id="classCodeDisplay" class="class-number">—</div>
                                    <div class="text-muted small mt-1">Prefix</div>
                                    <div id="prefixDisplay" class="class-prefix">—</div>
                                </div>
                                <div class="col-6">
                                    <div class="text-muted small">Confidence</div>
                                    <div class="fw-semibold mb-1"><span id="confidenceVal">0</span>%</div>
                                    <div class="confidence-wrap"><div id="confidenceBar" class="confidence-bar" style="width:0%"></div></div>
                                    <div class="text-muted small mt-2">Scheme</div>
                                    <div id="schemeDisplay">—</div>
                                </div>
                            </div>
                        </div>
                        <div id="subjectError" class="alert alert-danger mt-2" style="display:none;"></div>
                    </div>
                </div>

                <div class="card-premium">
                    <div class="card-header-premium">
                        <i class="fas fa-list-ol"></i> Top Suggestions
                    </div>
                    <div class="card-body-premium">
                        <div id="suggestList" class="small text-muted">Search to see suggestions.</div>
                    </div>
                </div>

                <div class="card-premium">
                    <div class="card-header-premium">
                        <i class="fas fa-bolt"></i> Quick Actions
                    </div>
                    <div class="card-body-premium">
                        <div class="d-flex flex-wrap gap-1">
                            <button class="btn btn-sm btn-category" onclick="quickSearch('computer science')"><i class="fas fa-laptop"></i> CS</button>
                            <button class="btn btn-sm btn-category" onclick="quickSearch('mathematics')"><i class="fas fa-calculator"></i> Math</button>
                            <button class="btn btn-sm btn-category" onclick="quickSearch('physics')"><i class="fas fa-atom"></i> Physics</button>
                            <button class="btn btn-sm btn-category" onclick="quickSearch('economics')"><i class="fas fa-chart-line"></i> Economics</button>
                            <button class="btn btn-sm btn-category" onclick="quickSearch('islam')"><i class="fas fa-star-and-crescent"></i> Islam</button>
                            <button class="btn btn-sm btn-category" onclick="quickSearch('history')"><i class="fas fa-landmark"></i> History</button>
                            <button class="btn btn-sm btn-category" onclick="quickSearch('medicine')"><i class="fas fa-heartbeat"></i> Medicine</button>
                        </div>
                    </div>
                </div>

                <div class="card-premium">
                    <div class="card-header-premium">
                        <i class="fas fa-layer-group"></i> Batch Classify
                    </div>
                    <div class="card-body-premium">
                        <textarea id="batchTitles" class="form-control form-control-sm" rows="4"
                                  placeholder="Paste one title per line…"></textarea>
                        <button class="btn btn-premium-primary btn-sm w-100 mt-2" onclick="runBatchClassify()">
                            <i class="fas fa-magic me-1"></i> Classify All
                        </button>
                        <div id="batchResults" class="mt-2 small"></div>
                    </div>
                </div>
            </div>

            <div class="col-lg-7">
                <div class="card-premium">
                    <div class="card-header-premium">
                        <i class="fas fa-history"></i> Classification History
                        <span class="ms-auto" style="font-size:.7rem;font-weight:400;color:#6c757d;">
                            <span id="historyCount">0</span> entries
                        </span>
                    </div>
                    <div class="card-body-premium">
                        <div class="export-toolbar">
                            <button class="btn-premium btn-premium-danger btn-sm" onclick="exportHistoryPDF()"><i class="fas fa-file-pdf me-1"></i> PDF</button>
                            <button class="btn-premium btn-premium-success btn-sm" onclick="exportHistoryExcel()"><i class="fas fa-file-excel me-1"></i> Excel</button>
                            <button class="btn-premium btn-premium-info btn-sm" onclick="exportHistoryCSV()"><i class="fas fa-file-csv me-1"></i> CSV</button>
                            <button class="btn btn-outline-secondary btn-sm" onclick="showPrintPreview('history')"><i class="fas fa-print me-1"></i> Print</button>
                            <button class="btn btn-outline-danger btn-sm ms-auto" onclick="clearHistory()"><i class="fas fa-trash me-1"></i> Clear</button>
                        </div>
                        <div id="historyList" class="class-table-wrap">
                            <div class="text-center text-muted py-4">
                                <i class="fas fa-clock fa-2x mb-2 d-block" style="opacity:.2;"></i>
                                No classification history yet
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- MANAGE TAB -->
    <div class="tab-pane fade" id="manage-tab">
        <div class="row g-4">
            <div class="col-lg-4">
                <div class="card-premium">
                    <div class="card-header-premium">
                        <i class="fas fa-plus-circle"></i> Add / Edit Classification
                    </div>
                    <div class="card-body-premium">
                        <div class="mb-2">
                            <label class="form-label fw-semibold">Number <span class="text-danger">*</span></label>
                            <input type="text" id="newCode" class="form-control" placeholder="e.g., 005.133">
                            <div class="form-text">DDC: 000-999[.xxx] · LCC: A-Z + digits</div>
                        </div>
                        <div class="row g-2 mb-2">
                            <div class="col-6">
                                <label class="form-label">Scheme</label>
                                <select id="newScheme" class="form-select form-select-sm">
                                    <option value="DDC" selected>DDC</option>
                                    <option value="LCC">LCC</option>
                                    <option value="UDC">UDC</option>
                                    <option value="Colon">Colon</option>
                                </select>
                            </div>
                            <div class="col-6">
                                <label class="form-label">Parent Code</label>
                                <input type="text" id="newParent" class="form-control form-control-sm" placeholder="optional">
                            </div>
                        </div>
                        <div class="mb-2">
                            <label class="form-label fw-semibold">Subjects <span class="text-danger">*</span></label>
                            <textarea id="newLabels" class="form-control" rows="3" placeholder="One per line"></textarea>
                        </div>
                        <div class="mb-2">
                            <label class="form-label">Synonyms (optional)</label>
                            <textarea id="newSynonyms" class="form-control form-control-sm" rows="2" placeholder="aliases, one per line"></textarea>
                        </div>
                        <div class="mb-2">
                            <label class="form-label">See Also (optional)</label>
                            <textarea id="newSeeAlso" class="form-control form-control-sm" rows="2" placeholder="related codes, one per line"></textarea>
                        </div>
                        <div class="mb-2">
                            <label class="form-label">Description (optional)</label>
                            <input type="text" id="newDescription" class="form-control form-control-sm" placeholder="short description">
                        </div>
                        <button id="addClassBtn" class="btn-premium btn-premium-success w-100" onclick="addClassCode()">
                            <i class="fas fa-save me-1"></i> Add Number
                        </button>
                        <div id="addStatus" class="status-bar mt-2"></div>
                    </div>
                </div>

                <div class="card-premium">
                    <div class="card-header-premium">
                        <i class="fas fa-file-import"></i> Bulk Import (CSV)
                    </div>
                    <div class="card-body-premium">
                        <textarea id="bulkImport" class="form-control" rows="4" placeholder="005,Computer programming,Software"></textarea>
                        <button id="bulkImportBtn" class="btn-premium btn-premium-primary w-100 mt-2" onclick="bulkImport()">
                            <i class="fas fa-upload me-1"></i> Import
                        </button>
                        <div id="bulkStatus" class="status-bar mt-2"></div>
                    </div>
                </div>

                <div class="card-premium">
                    <div class="card-header-premium">
                        <i class="fas fa-check-double"></i> Validate Database
                    </div>
                    <div class="card-body-premium">
                        <button class="btn btn-premium-info btn-sm w-100" onclick="runValidate()">
                            <i class="fas fa-shield-alt me-1"></i> Run Validation
                        </button>
                        <div id="validateResults" class="mt-2 small"></div>
                    </div>
                </div>
            </div>

            <div class="col-lg-8">
                <div class="card-premium">
                    <div class="card-header-premium">
                        <i class="fas fa-database"></i> Classification Database
                        <span class="ms-auto" style="font-size:.7rem;font-weight:400;color:#6c757d;">
                            <span id="dbCount"><?= count($classificationData) ?></span> numbers
                        </span>
                    </div>
                    <div class="card-body-premium">
                        <div class="export-toolbar">
                            <button class="btn-premium btn-premium-danger btn-sm" onclick="exportDatabasePDF()"><i class="fas fa-file-pdf me-1"></i> PDF</button>
                            <button class="btn-premium btn-premium-success btn-sm" onclick="exportDatabaseExcel()"><i class="fas fa-file-excel me-1"></i> Excel</button>
                            <button class="btn-premium btn-premium-info btn-sm" onclick="exportDatabaseCSV()"><i class="fas fa-file-csv me-1"></i> CSV</button>
                            <button class="btn btn-outline-secondary btn-sm" onclick="exportDatabaseXML()"><i class="fas fa-file-code me-1"></i> XML</button>
                            <button class="btn-premium btn-premium-warning btn-sm" onclick="exportDatabasePNG()"><i class="fas fa-image me-1"></i> PNG</button>
                            <button class="btn btn-outline-secondary btn-sm" onclick="showPrintPreview('database')"><i class="fas fa-print me-1"></i> Print</button>
                            <button class="btn btn-outline-primary btn-sm" onclick="exportClassData()"><i class="fas fa-download me-1"></i> JSON</button>
                            <button class="btn btn-outline-secondary btn-sm" onclick="importClassData()"><i class="fas fa-upload me-1"></i> Import</button>
                        </div>
                        <div class="row g-2 mb-3">
                            <div class="col-md-6">
                                <input type="text" id="dbSearch" class="form-control form-control-sm"
                                       placeholder="Search numbers / subjects / synonyms…"
                                       oninput="renderClassTable()">
                            </div>
                            <div class="col-md-3">
                                <select id="dbSchemeFilter" class="form-select form-select-sm" onchange="renderClassTable()">
                                    <option value="">All Schemes</option>
                                    <option value="DDC">DDC</option>
                                    <option value="LCC">LCC</option>
                                    <option value="UDC">UDC</option>
                                    <option value="Colon">Colon</option>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <select id="dbSort" class="form-select form-select-sm" onchange="renderClassTable()">
                                    <option value="code">Sort: Code</option>
                                    <option value="hits">Sort: Hits</option>
                                    <option value="misses">Sort: Misses</option>
                                </select>
                            </div>
                        </div>
                        <div class="class-table-wrap">
                            <table class="table table-custom table-sm table-striped" id="classTable">
                                <thead>
                                    <tr>
                                        <th style="width:120px;">Number</th>
                                        <th>Subjects</th>
                                        <th style="width:80px;" class="text-center">Hits</th>
                                        <th style="width:120px;" class="text-end">Actions</th>
                                    </tr>
                                </thead>
                                <tbody id="classTableBody"></tbody>
                            </table>
                        </div>
                        <div id="tableEmpty" class="text-center text-muted py-3">No classification numbers.</div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- KOHA TAB -->
    <div class="tab-pane fade" id="koha-tab">
        <div class="row g-4">
            <div class="col-lg-4">
                <div class="card-premium">
                    <div class="card-header-premium"><i class="fas fa-database"></i> Data Source</div>
                    <div class="card-body-premium">
                        <button class="btn btn-sm btn-outline-primary w-100 mb-2" onclick="loadKohaBooks()">
                            <i class="fas fa-sync me-1"></i> Refresh from Koha
                        </button>
                        <input type="text" id="kohaSearch" class="form-control form-control-sm mb-2" placeholder="Search books…" oninput="filterKohaBooks()">
                        <div id="kohaBookList" class="book-list"></div>
                        <div class="mt-2 d-flex gap-1 flex-wrap">
                            <button class="btn btn-sm btn-outline-primary" onclick="selectAllKohaBooks()">All</button>
                            <button class="btn btn-sm btn-outline-secondary" onclick="deselectAllKohaBooks()">None</button>
                            <button class="btn btn-sm btn-success" onclick="classifySelectedBooks()"><i class="fas fa-tag"></i> Classify</button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-8">
                <div class="card-premium">
                    <div class="card-header-premium">
                        <i class="fas fa-list"></i> Classified Books
                        <span class="ms-auto small text-muted"><span id="classifiedCount">0</span> books</span>
                    </div>
                    <div class="card-body-premium">
                        <div class="export-toolbar">
                            <button class="btn-premium btn-premium-danger btn-sm" onclick="exportClassifiedPDF()"><i class="fas fa-file-pdf me-1"></i> PDF</button>
                            <button class="btn-premium btn-premium-success btn-sm" onclick="exportClassifiedExcel()"><i class="fas fa-file-excel me-1"></i> Excel</button>
                            <button class="btn-premium btn-premium-info btn-sm" onclick="exportClassifiedCSV()"><i class="fas fa-file-csv me-1"></i> CSV</button>
                            <button class="btn btn-outline-secondary btn-sm" onclick="showPrintPreview('classified')"><i class="fas fa-print me-1"></i> Print</button>
                            <button class="btn btn-outline-primary btn-sm" onclick="kohaWriteback()"><i class="fas fa-cloud-upload-alt me-1"></i> Write to Koha</button>
                            <button class="btn btn-outline-danger btn-sm ms-auto" onclick="clearClassified()"><i class="fas fa-trash me-1"></i> Clear</button>
                        </div>
                        <div id="classifiedList" class="class-table-wrap">
                            <div class="text-center text-muted py-4">
                                <i class="fas fa-book fa-2x mb-2 d-block" style="opacity:.2;"></i>
                                No classified books yet
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ANALYTICS TAB -->
    <div class="tab-pane fade" id="analytics-tab">
        <div class="row g-4">
            <div class="col-lg-6">
                <div class="card-premium">
                    <div class="card-header-premium"><i class="fas fa-fire"></i> Top Hits (matched codes)</div>
                    <div class="card-body-premium"><div id="analyticsHits" class="small">Loading…</div></div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="card-premium">
                    <div class="card-header-premium"><i class="fas fa-times-circle"></i> Top Misses (unmatched queries)</div>
                    <div class="card-body-premium"><div id="analyticsMisses" class="small">Loading…</div></div>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="card-premium">
                    <div class="card-header-premium"><i class="fas fa-clock"></i> Hourly Activity (last 7 days)</div>
                    <div class="card-body-premium"><div id="analyticsHourly" class="small">Loading…</div></div>
                </div>
            </div>
        </div>
    </div>

    <!-- AUDIT TAB -->
    <div class="tab-pane fade" id="audit-tab">
        <div class="card-premium">
            <div class="card-header-premium">
                <i class="fas fa-history"></i> Audit Log
                <button class="btn btn-sm btn-outline-secondary ms-auto" onclick="loadAudit()">
                    <i class="fas fa-sync"></i> Refresh
                </button>
            </div>
            <div class="card-body-premium">
                <div id="auditList" class="small">Loading…</div>
            </div>
        </div>
    </div>
</div>

<!-- COMMAND PALETTE -->
<div class="cmd-palette" id="cmdPalette" onclick="if(event.target===this)closeCmdPalette()">
    <div class="cmd-box" onclick="event.stopPropagation()">
        <input type="text" class="cmd-input" id="cmdInput" placeholder="Type a command or classification query…" oninput="renderCmdResults()" onkeydown="cmdKeyNav(event)">
        <div class="cmd-results" id="cmdResults"></div>
    </div>
</div>

<!-- PRINT PREVIEW MODAL -->
<div class="modal fade" id="printPreviewModal" tabindex="-1">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="fas fa-print me-2"></i> Print Preview</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="printPreviewBody"></div>
            <div class="modal-footer">
                <button class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button class="btn btn-primary" onclick="window.print()"><i class="fas fa-print me-1"></i> Print Now</button>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/PapaParse/5.4.1/papaparse.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>

<script>
// ============================================================
// INSTITUTION NAME — injected from PHP as a CLEAN plain string  [CHANGED]
// ============================================================
window.VMS_INSTITUTION_NAME = <?= json_encode($institutionName, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;

// ============================================================
// STATE
// ============================================================
let classificationData = <?= json_encode($classificationData) ?>;
const PRINT_SETTINGS = <?= json_encode($p) ?>;
const INSTITUTION_NAME = window.VMS_INSTITUTION_NAME;
let currentClassTab = 'search';
let history = [];
let kohaBooks = [];
let classifiedBooks = [];
let undoStack = [], redoStack = [];
let auditEntries = [];

// ============================================================
// THEME
// ============================================================
function toggleTheme() {
    const cur = document.documentElement.getAttribute('data-theme') || 'light';
    const next = cur === 'dark' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', next);
    localStorage.setItem('class_theme', next);
    const icon = document.getElementById('themeIcon');
    if (icon) icon.className = next === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
}
(function () {
    const saved = localStorage.getItem('class_theme') || 'light';
    document.documentElement.setAttribute('data-theme', saved);
    document.addEventListener('DOMContentLoaded', () => {
        const icon = document.getElementById('themeIcon');
        if (icon) icon.className = saved === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
    });
})();

// ============================================================
// UTIL
// ============================================================
function escapeHtml(s) {
    return String(s || '').replace(/[&<>"']/g, m => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[m]));
}
function showToast(msg, type = 'info') {
    document.querySelectorAll('.toast-notif').forEach(t => t.remove());
    const t = document.createElement('div');
    t.className = 'toast-notif ' + type;
    t.textContent = msg;
    document.body.appendChild(t);
    setTimeout(() => { t.style.opacity = '0'; t.style.transform = 'translateY(20px)'; setTimeout(() => t.remove(), 400); }, 3500);
}

// ============================================================
// FUZZY MATCHING
// ============================================================
function normalize(s) {
    return String(s || '').toLowerCase().trim()
        .replace(/[^\p{L}\p{N}\s]/gu, ' ')
        .replace(/\s+/g, ' ')
        .trim();
}
function levenshteinRatio(a, b) {
    a = normalize(a); b = normalize(b);
    if (!a && !b) return 1;
    const len = Math.max(a.length, b.length);
    if (!len) return 1;
    const m = a.length, n = b.length;
    const dp = Array.from({length:m+1}, () => new Array(n+1).fill(0));
    for (let i=0;i<=m;i++) dp[i][0]=i;
    for (let j=0;j<=n;j++) dp[0][j]=j;
    for (let i=1;i<=m;i++) for (let j=1;j<=n;j++) {
        dp[i][j] = Math.min(dp[i-1][j]+1, dp[i][j-1]+1, dp[i-1][j-1] + (a[i-1]===b[j-1]?0:1));
    }
    return 1 - dp[m][n]/len;
}
function tokens(s) { return normalize(s).split(' ').filter(Boolean); }
function jaccard(a, b) {
    const A = new Set(a), B = new Set(b);
    if (!A.size && !B.size) return 0;
    let inter = 0;
    A.forEach(x => { if (B.has(x)) inter++; });
    const union = new Set([...A, ...B]).size;
    return union ? inter/union : 0;
}
function score(query, subject) {
    return 0.55 * levenshteinRatio(query, subject) + 0.45 * jaccard(tokens(query), tokens(subject));
}
function localLookup(query, scheme) {
    const q = query.trim();
    if (!q) return { code:'000', matched_subject:'(empty)', confidence:0, prefix:'000', suggestions:[], scheme:'' };
    if (/^[A-Za-z0-9]{1,3}(\.\d+)?$/.test(q)) {
        for (const row of classificationData) {
            if (row.code === q && (!scheme || (row.scheme||'DDC') === scheme)) {
                return { code:row.code, matched_subject:row.subjects[0]||'[Direct]', confidence:100,
                         prefix:row.code.substring(0,3), scheme:row.scheme||'DDC', suggestions:[] };
            }
        }
    }
    const scored = [];
    for (const row of classificationData) {
        if (scheme && (row.scheme||'DDC') !== scheme) continue;
        let best = 0, bestS = '';
        for (const s of (row.subjects||[])) {
            const sc = score(q, s);
            if (sc > best) { best = sc; bestS = s; }
        }
        for (const s of (row.synonyms||[])) {
            const sc = score(q, s);
            if (sc > best) { best = sc; bestS = '[syn] ' + s; }
        }
        if (best > 0.15) scored.push({ code:row.code, matched_subject:bestS, score:best, scheme:row.scheme||'DDC' });
    }
    scored.sort((a,b) => b.score - a.score);
    if (!scored.length) return { code:'000', matched_subject:'(no match)', confidence:0, prefix:'000', suggestions:[], scheme:'' };
    const best = scored[0];
    return {
        code: best.code,
        matched_subject: best.matched_subject,
        confidence: Math.round(best.score * 1000)/10,
        prefix: best.code.substring(0,3),
        scheme: best.scheme,
        suggestions: scored.slice(0, 5),
    };
}

// ============================================================
// LIVE SEARCH
// ============================================================
let liveTimer = null;
function liveSearch(q) {
    clearTimeout(liveTimer);
    if (!q || q.length < 2) {
        document.getElementById('liveSuggest').innerHTML = '';
        return;
    }
    liveTimer = setTimeout(() => {
        const scheme = document.getElementById('searchScheme').value;
        const res = localLookup(q, scheme);
        if (res.suggestions && res.suggestions.length) {
            document.getElementById('liveSuggest').innerHTML = res.suggestions.slice(0, 5).map(s =>
                `<div class="d-flex align-items-center gap-2 mb-1" style="cursor:pointer" onclick="applySuggestion('${escapeHtml(s.code)}')">
                    <span class="badge bg-primary">${escapeHtml(s.code)}</span>
                    <span class="small flex-grow-1">${escapeHtml(s.matched_subject)}</span>
                    <span class="small text-muted">${Math.round(s.score*100)}%</span>
                </div>`
            ).join('');
        } else {
            document.getElementById('liveSuggest').innerHTML = '';
        }
    }, 200);
}

function applySuggestion(code) {
    document.getElementById('subjectSearch').value = code;
    searchBySubject();
}

// ============================================================
// SEARCH
// ============================================================
function searchBySubject() {
    const query = document.getElementById('subjectSearch').value.trim();
    const scheme = document.getElementById('searchScheme').value;
    if (!query) { showToast('Enter a subject', 'error'); return; }
    const res = localLookup(query, scheme);
    document.getElementById('matchedLabel').textContent = res.matched_subject;
    document.getElementById('classCodeDisplay').textContent = res.code;
    document.getElementById('prefixDisplay').textContent = res.prefix;
    document.getElementById('confidenceVal').textContent = res.confidence;
    document.getElementById('confidenceBar').style.width = Math.min(100, res.confidence) + '%';
    document.getElementById('schemeDisplay').innerHTML =
        `<span class="scheme-chip scheme-${escapeHtml(res.scheme||'DDC')}">${escapeHtml(res.scheme||'DDC')}</span>`;
    document.getElementById('subjectResult').style.display = 'block';
    document.getElementById('subjectError').style.display = 'none';

    fetch(window.location.href + '?ajax_action=lookup&q=' + encodeURIComponent(query) + '&scheme=' + encodeURIComponent(scheme)).catch(()=>{});

    renderSuggestionList(res.suggestions);

    history.push({ query, result: res, timestamp: new Date().toISOString() });
    renderHistory();
}

function renderSuggestionList(sugg) {
    const el = document.getElementById('suggestList');
    if (!sugg || !sugg.length) { el.innerHTML = '<span class="text-muted">No suggestions</span>'; return; }
    el.innerHTML = sugg.map((s, i) =>
        `<div class="d-flex align-items-center gap-2 mb-2">
            <span class="badge bg-primary">${i+1}</span>
            <div class="flex-grow-1">
                <div class="fw-semibold">${escapeHtml(s.code)} <span class="text-muted small">— ${escapeHtml(s.matched_subject)}</span></div>
                <div class="confidence-wrap mt-1" style="height:6px;">
                    <div class="confidence-bar" style="width:${Math.round(s.score*100)}%"></div>
                </div>
            </div>
            <span class="small text-muted">${Math.round(s.score*100)}%</span>
        </div>`
    ).join('');
}

function quickSearch(subject) {
    document.getElementById('subjectSearch').value = subject;
    searchBySubject();
}
function copyClassResult() {
    const code = document.getElementById('classCodeDisplay').textContent;
    const m = document.getElementById('matchedLabel').textContent;
    const txt = `Classification: ${code} | Matched: ${m}`;
    navigator.clipboard.writeText(txt).then(()=>showToast('Copied', 'success')).catch(()=>showToast('Copy failed', 'error'));
}

function renderHistory() {
    const c = document.getElementById('historyList');
    const cnt = document.getElementById('historyCount');
    if (!c) return;
    cnt.textContent = history.length;
    if (!history.length) {
        c.innerHTML = `<div class="text-center text-muted py-4"><i class="fas fa-clock fa-2x mb-2 d-block" style="opacity:.2;"></i>No classification history yet</div>`;
        return;
    }
    c.innerHTML = history.slice().reverse().map((item, idx) => {
        const realIdx = history.length - 1 - idx;
        return `<div class="border-bottom py-2 d-flex justify-content-between align-items-center">
            <div>
                <span class="badge bg-primary me-1">${escapeHtml(item.result.code)}</span>
                <span class="fw-semibold">${escapeHtml(item.query)}</span>
                <span class="text-muted small ms-2">→ ${escapeHtml(item.result.matched_subject)}</span>
                <span class="badge bg-success ms-2">${item.result.confidence || 0}%</span>
            </div>
            <button class="btn btn-sm btn-outline-secondary" onclick="history.splice(${realIdx},1);renderHistory();"><i class="fas fa-times"></i></button>
        </div>`;
    }).join('');
}
function clearHistory() {
    if (!history.length || !confirm('Clear history?')) return;
    history = []; renderHistory(); showToast('Cleared', 'success');
}

// ============================================================
// BATCH CLASSIFY
// ============================================================
async function runBatchClassify() {
    const text = document.getElementById('batchTitles').value.trim();
    if (!text) { showToast('Paste titles first', 'error'); return; }
    const titles = text.split('\n').map(s => s.trim()).filter(Boolean);
    const scheme = document.getElementById('searchScheme').value;
    const results = titles.map(t => ({ title: t, result: localLookup(t, scheme) }));
    const el = document.getElementById('batchResults');
    el.innerHTML = results.map(r =>
        `<div class="d-flex justify-content-between border-bottom py-1">
            <span>${escapeHtml(r.title)}</span>
            <span><span class="badge bg-primary">${escapeHtml(r.result.code)}</span>
                  <span class="text-muted small">${r.result.confidence}%</span></span>
        </div>`
    ).join('');
    showToast(`Classified ${results.length} titles`, 'success');
}

// ============================================================
// DATABASE RENDER + EDIT
// ============================================================
function updateStats() {
    ['entryCount','totalClasses','dbCount'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.textContent = classificationData.length;
    });
    renderClassTable();
}

function renderClassTable() {
    const tbody = document.getElementById('classTableBody');
    const empty = document.getElementById('tableEmpty');
    if (!tbody) return;
    const search = (document.getElementById('dbSearch')?.value || '').toLowerCase();
    const scheme = document.getElementById('dbSchemeFilter')?.value || '';
    const sort = document.getElementById('dbSort')?.value || 'code';

    let list = classificationData.slice();
    if (scheme) list = list.filter(r => (r.scheme||'DDC') === scheme);
    if (search) {
        list = list.filter(r =>
            r.code.toLowerCase().includes(search) ||
            r.subjects.some(s => s.toLowerCase().includes(search)) ||
            (r.synonyms||[]).some(s => s.toLowerCase().includes(search))
        );
    }
    if (sort === 'hits')   list.sort((a,b) => (b.hits||0) - (a.hits||0));
    if (sort === 'misses') list.sort((a,b) => (b.misses||0) - (a.misses||0));

    if (!list.length) { tbody.innerHTML = ''; empty.style.display = 'block'; return; }
    empty.style.display = 'none';
    tbody.innerHTML = list.map(row => {
        const realIdx = classificationData.indexOf(row);
        const scheme = row.scheme || 'DDC';
        const subjTags = (row.subjects||[]).map(s => `<span class="label-tag">${escapeHtml(s)}</span>`).join(' ');
        return `<tr>
            <td><strong>${escapeHtml(row.code)}</strong>
                <span class="scheme-chip scheme-${escapeHtml(scheme)}">${escapeHtml(scheme)}</span></td>
            <td>${subjTags}
                ${row.description ? `<div class="small text-muted mt-1">${escapeHtml(row.description)}</div>` : ''}
                ${row.synonyms?.length ? `<div class="small text-muted mt-1"><i class="fas fa-tag"></i> ${row.synonyms.map(escapeHtml).join(', ')}</div>` : ''}</td>
            <td class="text-center">${row.hits||0}</td>
            <td class="text-end">
                <button class="btn btn-sm btn-outline-primary" onclick="editCode(${realIdx})" title="Edit"><i class="fas fa-edit"></i></button>
                <button class="btn btn-sm btn-outline-danger" onclick="deleteClassCode(${realIdx})" title="Delete"><i class="fas fa-trash"></i></button>
            </td>
        </tr>`;
    }).join('');
}

function editCode(idx) {
    const row = classificationData[idx];
    if (!row) return;
    document.getElementById('newCode').value = row.code;
    document.getElementById('newScheme').value = row.scheme || 'DDC';
    document.getElementById('newParent').value = row.parent_code || '';
    document.getElementById('newLabels').value = (row.subjects||[]).join('\n');
    document.getElementById('newSynonyms').value = (row.synonyms||[]).join('\n');
    document.getElementById('newSeeAlso').value = (row.see_also||[]).join('\n');
    document.getElementById('newDescription').value = row.description || '';
    showToast('Loaded into form — modify and click Add to save', 'info');
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

// ============================================================
// ADD / UPDATE / DELETE
// ============================================================
function pushUndo() {
    undoStack.push(JSON.parse(JSON.stringify(classificationData)));
    if (undoStack.length > 30) undoStack.shift();
    redoStack = [];
}

async function addClassCode() {
    const code = document.getElementById('newCode').value.trim();
    const scheme = document.getElementById('newScheme').value;
    const parent = document.getElementById('newParent').value.trim();
    const subsText = document.getElementById('newLabels').value.trim();
    const synText = document.getElementById('newSynonyms').value.trim();
    const seeText = document.getElementById('newSeeAlso').value.trim();
    const desc = document.getElementById('newDescription').value.trim();
    const status = document.getElementById('addStatus');
    const btn = document.getElementById('addClassBtn');

    if (!code || !subsText) {
        status.textContent = '❌ Code and subjects required';
        status.className = 'status-bar error';
        return;
    }
    const subjects = subsText.split('\n').map(s => s.trim()).filter(Boolean);
    const synonyms = synText.split('\n').map(s => s.trim()).filter(Boolean);
    const seeAlso = seeText.split('\n').map(s => s.trim()).filter(Boolean);

    if (btn) { btn.disabled = true; btn.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i> Saving…'; }

    const exists = classificationData.find(r => r.code === code);

    try {
        const action = exists ? 'update_classification' : 'add_classification';
        const payload = {
            ajax_action: action,
            code, scheme, parent_code: parent || null,
            subjects, synonyms, see_also: seeAlso, description: desc,
        };
        const res = await fetch(window.location.href, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload),
        });
        const result = await res.json();
        if (result.success) {
            pushUndo();
            if (Array.isArray(result.data)) {
                classificationData = result.data;
                updateStats();
            }
            status.textContent = '✅ Saved';
            status.className = 'status-bar success';
            showToast('Saved: ' + code, 'success');
            ['newCode','newParent','newLabels','newSynonyms','newSeeAlso','newDescription'].forEach(id => document.getElementById(id).value = '');
        } else {
            status.textContent = '❌ ' + (result.error || 'fail');
            status.className = 'status-bar error';
            showToast('Save failed: ' + (result.error || ''), 'error');
        }
    } catch (e) {
        status.textContent = '❌ ' + e.message;
        status.className = 'status-bar error';
    } finally {
        if (btn) { btn.disabled = false; btn.innerHTML = '<i class="fas fa-save me-1"></i> Add Number'; }
    }
}

async function deleteClassCode(idx) {
    const row = classificationData[idx];
    if (!row || !confirm(`Delete ${row.code}?`)) return;
    try {
        const res = await fetch(window.location.href, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ ajax_action: 'delete_classification', code: row.code }),
        });
        const result = await res.json();
        if (result.success) {
            pushUndo();
            if (Array.isArray(result.data)) { classificationData = result.data; updateStats(); }
            showToast('Deleted', 'success');
        } else showToast('Delete failed: ' + (result.error||''), 'error');
    } catch (e) { showToast('Network error', 'error'); }
}

async function bulkImport() {
    const text = document.getElementById('bulkImport').value.trim();
    const status = document.getElementById('bulkStatus');
    if (!text) { status.textContent = '❌ Paste data'; status.className='status-bar error'; return; }
    const incoming = [];
    text.split('\n').forEach(line => {
        const p = line.split(',').map(s => s.trim());
        if (p.length < 2) return;
        incoming.push({ code: p[0], subjects: p.slice(1).filter(Boolean), scheme: 'DDC' });
    });
    if (!incoming.length) { status.textContent = '❌ No valid lines'; status.className='status-bar error'; return; }
    try {
        const res = await fetch(window.location.href, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ ajax_action: 'save_classification', classification: incoming, full_replace: false }),
        });
        const result = await res.json();
        if (result.success) {
            pushUndo();
            if (Array.isArray(result.data)) { classificationData = result.data; updateStats(); }
            status.textContent = `✅ Imported (${incoming.length} rows)`;
            status.className = 'status-bar success';
        } else {
            status.textContent = '❌ ' + (result.error || 'fail');
            status.className = 'status-bar error';
        }
    } catch (e) { status.textContent = '❌ ' + e.message; status.className='status-bar error'; }
}

// ============================================================
// VALIDATE
// ============================================================
async function runValidate() {
    try {
        const res = await fetch(window.location.href + '?ajax_action=validate');
        const result = await res.json();
        const el = document.getElementById('validateResults');
        if (!result.success || !result.issues?.length) {
            el.innerHTML = '<div class="text-success"><i class="fas fa-check-circle"></i> No issues found</div>';
            return;
        }
        el.innerHTML = result.issues.slice(0, 20).map(i =>
            `<div class="mb-1"><span class="badge bg-${i.level==='error'?'danger':i.level==='warning'?'warning text-dark':'info'}">${i.level}</span>
             <code>${escapeHtml(i.code)}</code> — ${escapeHtml(i.msg)}</div>`
        ).join('') + (result.issues.length > 20 ? `<div class="text-muted">+${result.issues.length-20} more…</div>` : '');
    } catch (e) { showToast('Validate failed', 'error'); }
}

// ============================================================
// KOHA BOOKS
// ============================================================
function loadKohaBooks() {
    const c = document.getElementById('kohaBookList');
    if (!c) return;
    c.innerHTML = '<div class="text-center text-muted py-3"><i class="fas fa-spinner fa-spin"></i> Loading…</div>';
    fetch(window.location.href + '?ajax_action=all_books')
        .then(r => r.json())
        .then(data => { kohaBooks = data; renderKohaBooks(); showToast(`Loaded ${data.length} books`, 'success'); })
        .catch(() => { kohaBooks = [{barcode:'SAMPLE',title:'Sample',author:'—'}]; renderKohaBooks(); });
}
function renderKohaBooks() {
    const c = document.getElementById('kohaBookList');
    if (!c) return;
    if (!kohaBooks.length) { c.innerHTML = '<div class="text-center text-muted py-3">No books</div>'; return; }
    c.innerHTML = kohaBooks.map(b => `
        <div class="book-item" data-barcode="${escapeHtml(b.barcode)}" onclick="this.classList.toggle('selected')">
            <div class="book-title">${escapeHtml(b.title)}</div>
            <div class="book-meta">${escapeHtml(b.barcode)} | ${escapeHtml(b.author||'')}${b.category?' | '+escapeHtml(b.category):''}</div>
        </div>`).join('');
}
function filterKohaBooks() {
    const term = document.getElementById('kohaSearch').value.toLowerCase();
    document.querySelectorAll('#kohaBookList .book-item').forEach(i => {
        i.style.display = i.textContent.toLowerCase().includes(term) ? '' : 'none';
    });
}
function selectAllKohaBooks() { document.querySelectorAll('#kohaBookList .book-item').forEach(i => i.classList.add('selected')); }
function deselectAllKohaBooks() { document.querySelectorAll('#kohaBookList .book-item').forEach(i => i.classList.remove('selected')); }

function getSelectedKohaBooks() {
    return Array.from(document.querySelectorAll('#kohaBookList .book-item.selected')).map(i => {
        const meta = i.querySelector('.book-meta')?.textContent || '';
        const p = meta.split('|').map(s => s.trim());
        return { barcode: i.dataset.barcode, title: i.querySelector('.book-title').textContent, author: p[1]||'', category: p[2]||'' };
    });
}

function classifySelectedBooks() {
    const books = getSelectedKohaBooks();
    if (!books.length) { showToast('Select at least one book', 'error'); return; }
    const scheme = document.getElementById('searchScheme').value;
    books.forEach(b => {
        const r = localLookup((b.title + ' ' + (b.category||'')).trim(), scheme);
        classifiedBooks.push({
            title: b.title, author: b.author, barcode: b.barcode,
            classification: r.code, matched_subject: r.matched_subject,
            prefix: r.prefix, scheme: r.scheme||'DDC', confidence: r.confidence, source: 'koha'
        });
    });
    renderClassifiedBooks(); updateClassifiedCount();
    deselectAllKohaBooks();
    showToast(`Classified ${books.length}`, 'success');
}
function renderClassifiedBooks() {
    const c = document.getElementById('classifiedList');
    if (!c) return;
    if (!classifiedBooks.length) {
        c.innerHTML = `<div class="text-center text-muted py-4"><i class="fas fa-book fa-2x mb-2 d-block" style="opacity:.2;"></i>No classified books yet</div>`;
        return;
    }
    c.innerHTML = classifiedBooks.map((b,i) => `
        <div class="border-bottom py-2 d-flex justify-content-between align-items-start">
            <div>
                <div class="fw-semibold">${escapeHtml(b.title)}</div>
                <div class="text-muted small">${escapeHtml(b.author)} | ${escapeHtml(b.barcode)}</div>
                <div>
                    <span class="badge bg-success me-1">${escapeHtml(b.classification)}</span>
                    <span class="badge bg-info">${escapeHtml(b.matched_subject)}</span>
                    <span class="scheme-chip scheme-${escapeHtml(b.scheme)}">${escapeHtml(b.scheme)}</span>
                    <span class="badge bg-secondary">${b.confidence}%</span>
                </div>
            </div>
            <button class="btn btn-sm btn-outline-danger" onclick="removeClassified(${i})"><i class="fas fa-times"></i></button>
        </div>`).join('');
}
function removeClassified(i) { classifiedBooks.splice(i,1); renderClassifiedBooks(); updateClassifiedCount(); }
function clearClassified() {
    if (!classifiedBooks.length || !confirm('Clear all?')) return;
    classifiedBooks = []; renderClassifiedBooks(); updateClassifiedCount();
}
function updateClassifiedCount() {
    const el = document.getElementById('classifiedCount');
    if (el) el.textContent = classifiedBooks.length;
}

async function kohaWriteback() {
    if (!classifiedBooks.length) { showToast('Nothing to write', 'error'); return; }
    const updates = classifiedBooks.filter(b => b.barcode && b.classification).map(b => ({ barcode: b.barcode, call_number: b.classification }));
    if (!updates.length) { showToast('No barcodes with classifications', 'error'); return; }
    if (!confirm(`Write ${updates.length} classifications to Koha itemcallnumber?`)) return;
    try {
        const res = await fetch(window.location.href, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ ajax_action: 'koha_writeback', updates }),
        });
        const r = await res.json();
        if (r.success) showToast(`Updated ${r.updated} in Koha`, 'success');
        else showToast('Failed: ' + (r.error||''), 'error');
    } catch (e) { showToast('Network error', 'error'); }
}

// ============================================================
// ANALYTICS + AUDIT
// ============================================================
async function loadAnalytics() {
    try {
        const res = await fetch(window.location.href + '?ajax_action=analytics');
        const r = await res.json();
        if (!r.success) return;
        const hits = r.top_hits || [];
        document.getElementById('analyticsHits').innerHTML = hits.length
            ? hits.map(h => `<div class="d-flex justify-content-between border-bottom py-1">
                <span><strong>${escapeHtml(h.matched_code)}</strong></span>
                <span class="badge bg-primary">${h.c}</span></div>`).join('')
            : '<div class="text-muted">No hits yet</div>';

        const misses = r.top_misses || [];
        document.getElementById('analyticsMisses').innerHTML = misses.length
            ? misses.map(m => `<div class="d-flex justify-content-between border-bottom py-1">
                <span>${escapeHtml(m.query)}</span>
                <span class="badge bg-danger">${m.c}</span></div>`).join('')
            : '<div class="text-muted">No misses yet</div>';

        const hourly = r.hourly || [];
        const maxH = Math.max(1, ...hourly.map(h => h.c));
        document.getElementById('analyticsHourly').innerHTML = Array.from({length:24}, (_,h) => {
            const row = hourly.find(x => +x.h === h);
            const c = row ? +row.c : 0;
            const pct = (c / maxH) * 100;
            return `<div class="d-flex align-items-center gap-2 mb-1">
                <span style="width:32px;" class="text-muted">${h}:00</span>
                <div class="flex-grow-1" style="height:14px;background:#e5e7eb;border-radius:4px;overflow:hidden;">
                    <div style="height:100%;width:${pct}%;background:linear-gradient(90deg,#1a2a6c,#0ea5e9);"></div>
                </div>
                <span style="width:36px;text-align:right;" class="small">${c}</span>
            </div>`;
        }).join('');
    } catch (e) {}
}

async function loadAudit() {
    try {
        const res = await fetch(window.location.href + '?ajax_action=audit_log&limit=200');
        const r = await res.json();
        const el = document.getElementById('auditList');
        if (!r.success || !r.entries?.length) { el.innerHTML = '<div class="text-muted">No audit entries</div>'; return; }
        el.innerHTML = r.entries.map(e => `
            <div class="audit-row">
                <span class="badge bg-primary">${escapeHtml(e.action)}</span>
                <strong class="ms-1">${escapeHtml(e.code||'')}</strong>
                <span class="text-muted small ms-2">${escapeHtml(e.created_at)} · ${escapeHtml(e.username||'—')}</span>
            </div>`).join('');
    } catch (e) {}
}

// ============================================================
// EXPORTS
// ============================================================
function buildClassPDF(doc, items, title) {
    const s = PRINT_SETTINGS;
    const sizes = { A4:[210,297], Letter:[216,279], Legal:[216,356], A3:[297,420] };
    const [pw, ph] = sizes[s.page_size] || [210,297];
    const isL = s.orientation === 'landscape';
    const pageW = isL ? ph : pw, pageH = isL ? pw : ph;
    const mL = s.margin_left, mR = s.margin_right, mT = s.margin_top, mB = s.margin_bottom;
    const usableW = pageW - mL - mR, usableH = pageH - mT - mB;
    const cols = s.columns, colGap = s.col_gap, rowGap = s.row_gap;
    const cellW = (usableW - (cols-1)*colGap) / cols;
    const cellH = 22;
    const rows = Math.max(1, Math.floor((usableH + rowGap) / (cellH + rowGap)));
    const itemsPerPage = cols * rows;

    let y = mT;
    if (s.print_header && s.header_text) {
        doc.setFontSize(14); doc.setFont(s.font_family.toLowerCase(), 'bold');
        doc.text(s.header_text, pageW/2, y, { align:'center' });
        y += 8;
    }
    doc.setFontSize(11); doc.setFont(s.font_family.toLowerCase(), 'bold');
    doc.text(title, mL, y); y += 6;

    let idx = 0; const total = items.length;
    const pages = Math.ceil(total / itemsPerPage);
    for (let p = 0; p < pages; p++) {
        if (p > 0) doc.addPage();
        for (let r = 0; r < rows; r++) {
            for (let c = 0; c < cols; c++) {
                if (idx >= total) break;
                const item = items[idx++];
                const x = mL + c*(cellW + colGap);
                const yy = y + r*(cellH + rowGap);
                if (s.show_border) {
                    doc.setDrawColor(s.border_color); doc.setLineWidth(s.border_width);
                    doc.rect(x, yy, cellW, cellH);
                }
                doc.setFontSize(s.font_size); doc.setFont(s.font_family.toLowerCase(), 'normal');
                let cy = yy + 4;
                if (s.include_code && item.code) {
                    doc.setFont(s.font_family.toLowerCase(), 'bold');
                    doc.text(String(item.code), x + 2, cy); cy += 4;
                    doc.setFont(s.font_family.toLowerCase(), 'normal');
                }
                if (s.include_subjects && item.subjects) {
                    const txt = Array.isArray(item.subjects) ? item.subjects.join(', ') : String(item.subjects);
                    const lines = doc.splitTextToSize(txt, cellW - 4);
                    lines.slice(0, 4).forEach(l => { doc.text(l, x + 2, cy); cy += 3.5; });
                }
            }
        }
    }
}

function exportDatabasePDF() {
    if (!classificationData.length) { showToast('No data', 'error'); return; }
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF({ orientation: PRINT_SETTINGS.orientation, unit:'mm', format: PRINT_SETTINGS.page_size.toLowerCase() });
    buildClassPDF(doc, classificationData, 'Classification Database');
    doc.save(`classification_database_${new Date().toISOString().slice(0,10)}.pdf`);
    showToast('PDF exported', 'success');
}
function exportHistoryPDF() {
    if (!history.length) { showToast('No history', 'error'); return; }
    const items = history.map(h => ({ code: h.result.code, subjects: [h.query] }));
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF({ orientation: PRINT_SETTINGS.orientation, unit:'mm', format: PRINT_SETTINGS.page_size.toLowerCase() });
    buildClassPDF(doc, items, 'Classification History');
    doc.save(`classification_history_${new Date().toISOString().slice(0,10)}.pdf`);
}
function exportClassifiedPDF() {
    if (!classifiedBooks.length) { showToast('No data', 'error'); return; }
    const items = classifiedBooks.map(b => ({ code: b.classification, subjects: [b.title, b.author, b.barcode] }));
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF({ orientation: PRINT_SETTINGS.orientation, unit:'mm', format: PRINT_SETTINGS.page_size.toLowerCase() });
    buildClassPDF(doc, items, 'Classified Books');
    doc.save(`classified_books_${new Date().toISOString().slice(0,10)}.pdf`);
}

function downloadExcel(rows, name) {
    if (!rows.length) { showToast('No data', 'error'); return; }
    const ws = XLSX.utils.json_to_sheet(rows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Data');
    XLSX.writeFile(wb, `${name}_${new Date().toISOString().slice(0,10)}.xlsx`);
    showToast('Excel exported', 'success');
}
function exportDatabaseExcel() {
    downloadExcel(classificationData.map(r => ({
        Number: r.code, Scheme: r.scheme||'DDC',
        Subjects: (r.subjects||[]).join(', '),
        Synonyms: (r.synonyms||[]).join(', '),
        Description: r.description||'', Hits: r.hits||0,
    })), 'classification_database');
}
function exportHistoryExcel() {
    downloadExcel(history.map(h => ({ Query: h.query, Code: h.result.code, Matched: h.result.matched_subject, Confidence: h.result.confidence })), 'classification_history');
}
function exportClassifiedExcel() {
    downloadExcel(classifiedBooks.map(b => ({ Title: b.title, Author: b.author, Barcode: b.barcode, Classification: b.classification, Matched: b.matched_subject, Confidence: b.confidence, Scheme: b.scheme })), 'classified_books');
}

function downloadCSV(head, rows, name) {
    if (!rows.length) { showToast('No data', 'error'); return; }
    const csv = head + rows.join('\n');
    const blob = new Blob([csv], { type:'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `${name}_${new Date().toISOString().slice(0,10)}.csv`;
    a.click(); URL.revokeObjectURL(url);
    showToast('CSV exported', 'success');
}
function exportDatabaseCSV() {
    downloadCSV('Number,Scheme,Subjects\n',
        classificationData.map(r => `"${r.code}","${r.scheme||'DDC'}","${(r.subjects||[]).join('; ')}"`),
        'classification_database');
}
function exportHistoryCSV() {
    downloadCSV('Query,Code,Matched,Confidence\n',
        history.map(h => `"${h.query}","${h.result.code}","${h.result.matched_subject}","${h.result.confidence}"`),
        'classification_history');
}
function exportClassifiedCSV() {
    downloadCSV('Title,Author,Barcode,Classification,Matched,Confidence,Scheme\n',
        classifiedBooks.map(b => `"${b.title}","${b.author}","${b.barcode}","${b.classification}","${b.matched_subject}","${b.confidence}","${b.scheme}"`),
        'classified_books');
}

function exportDatabaseXML() {
    let xml = `<?xml version="1.0" encoding="UTF-8"?>\n<classification>\n`;
    classificationData.forEach(r => {
        xml += `  <entry>\n    <code>${escapeHtml(r.code)}</code>\n    <scheme>${escapeHtml(r.scheme||'DDC')}</scheme>\n`;
        (r.subjects||[]).forEach(s => { xml += `    <subject>${escapeHtml(s)}</subject>\n`; });
        (r.synonyms||[]).forEach(s => { xml += `    <synonym>${escapeHtml(s)}</synonym>\n`; });
        xml += `  </entry>\n`;
    });
    xml += `</classification>`;
    const blob = new Blob([xml], { type:'application/xml' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `classification_database_${new Date().toISOString().slice(0,10)}.xml`;
    a.click(); URL.revokeObjectURL(a.href);
    showToast('XML exported', 'success');
}

async function exportDatabasePNG() {
    const el = document.getElementById('classTable');
    if (!el) return;
    try {
        const canvas = await html2canvas(el, { scale:2, backgroundColor:'#fff' });
        const a = document.createElement('a');
        a.href = canvas.toDataURL('image/png');
        a.download = `classification_database_${new Date().toISOString().slice(0,10)}.png`;
        a.click();
        showToast('PNG exported', 'success');
    } catch (e) { showToast('PNG failed', 'error'); }
}

function exportClassData() {
    const blob = new Blob([JSON.stringify(classificationData, null, 2)], { type:'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'classification_database.json';
    a.click(); URL.revokeObjectURL(a.href);
    showToast('JSON exported', 'success');
}
function importClassData() {
    const input = document.createElement('input');
    input.type = 'file'; input.accept = '.json';
    input.onchange = e => {
        const file = e.target.files[0];
        if (!file) return;
        const r = new FileReader();
        r.onload = async ev => {
            try {
                const data = JSON.parse(ev.target.result);
                if (!Array.isArray(data)) throw new Error('Not an array');
                if (!confirm(`Import ${data.length} entries? This REPLACES the current DB.`)) return;
                const res = await fetch(window.location.href, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ ajax_action:'save_classification', classification:data, full_replace:true }),
                });
                const r2 = await res.json();
                if (r2.success) {
                    pushUndo();
                    classificationData = r2.data;
                    updateStats();
                    showToast(`Imported ${data.length}`, 'success');
                } else showToast('Failed: ' + (r2.error||''), 'error');
            } catch (err) { showToast('Parse error: ' + err.message, 'error'); }
        };
        r.readAsText(file);
    };
    input.click();
}

// ============================================================
// PRINT PREVIEW
// ============================================================
function showPrintPreview(kind) {
    const s = PRINT_SETTINGS;
    const sizes = { A4:[210,297], Letter:[216,279], Legal:[216,356], A3:[297,420] };
    const [pw, ph] = sizes[s.page_size] || [210,297];
    const isL = s.orientation === 'landscape';
    const pageW = isL ? ph : pw, pageH = isL ? pw : ph;
    const mmPx = 3.78;

    let items = [];
    if (kind === 'database') items = classificationData;
    else if (kind === 'history') items = history;
    else if (kind === 'classified') items = classifiedBooks;
    if (!items.length) { showToast('No data', 'error'); return; }

    const modal = new bootstrap.Modal(document.getElementById('printPreviewModal'));
    const body = document.getElementById('printPreviewBody');
    body.innerHTML = '';

    const page = document.createElement('div');
    page.className = 'preview-page';
    page.style.width = (pageW * mmPx) + 'px';
    page.style.minHeight = (pageH * mmPx) + 'px';
    page.style.padding = `${s.margin_top*mmPx}px ${s.margin_right*mmPx}px ${s.margin_bottom*mmPx}px ${s.margin_left*mmPx}px`;

    if (s.print_header && s.header_text) {
        const h = document.createElement('div');
        h.style.cssText = `font-family:${s.font_family};font-size:${s.font_size+4}pt;font-weight:bold;text-align:center;margin-bottom:8px;color:${s.font_color}`;
        h.textContent = s.header_text;
        page.appendChild(h);
    }
    const grid = document.createElement('div');
    grid.style.cssText = `display:grid;grid-template-columns:repeat(${s.columns},1fr);gap:${s.row_gap}mm ${s.col_gap}mm;`;
    items.forEach(item => {
        const cell = document.createElement('div');
        cell.style.cssText = `padding:4px;background:${s.bg_color};border:${s.border_width}px solid ${s.border_color};font-family:${s.font_family};font-size:${s.font_size}pt;color:${s.font_color};word-break:break-word;`;
        if (kind === 'database') {
            cell.innerHTML = `<div style="font-weight:bold">${escapeHtml(item.code)}</div><div style="font-size:${s.font_size-1}pt">${(item.subjects||[]).map(escapeHtml).join(', ')}</div>`;
        } else if (kind === 'history') {
            cell.innerHTML = `<div style="font-weight:bold">${escapeHtml(item.query)}</div><div style="color:#1a2a6c">→ ${escapeHtml(item.result.code)}</div>`;
        } else {
            cell.innerHTML = `<div style="font-weight:bold">${escapeHtml(item.title)}</div><div>${escapeHtml(item.classification)}</div>`;
        }
        grid.appendChild(cell);
    });
    page.appendChild(grid);
    body.appendChild(page);
    modal.show();
}

// ============================================================
// COMMAND PALETTE
// ============================================================
const commands = [
    { id:'tab_search',     label:'Go to Search & Classify',    action:() => switchTab('search') },
    { id:'tab_manage',     label:'Go to Manage',               action:() => switchTab('manage') },
    { id:'tab_koha',       label:'Go to Koha Books',           action:() => switchTab('koha') },
    { id:'tab_analytics',  label:'Go to Analytics',            action:() => switchTab('analytics') },
    { id:'tab_audit',      label:'Go to Audit',                action:() => switchTab('audit') },
    { id:'theme',          label:'Toggle dark mode',           action:toggleTheme },
    { id:'export_json',    label:'Export JSON',                action:exportClassData },
    { id:'export_csv',     label:'Export CSV',                 action:exportDatabaseCSV },
    { id:'export_xlsx',    label:'Export Excel',               action:exportDatabaseExcel },
    { id:'export_pdf',     label:'Export PDF',                 action:exportDatabasePDF },
    { id:'export_png',     label:'Export PNG',                 action:exportDatabasePNG },
    { id:'export_xml',     label:'Export XML',                 action:exportDatabaseXML },
    { id:'validate',       label:'Validate database',          action:runValidate },
    { id:'undo',           label:'Undo last DB change',        action:doUndo },
    { id:'redo',           label:'Redo DB change',             action:doRedo },
];

function switchTab(name) {
    const btn = document.querySelector(`.nav-tabs-modern .nav-link[data-classtab="${name}"]`);
    if (btn) new bootstrap.Tab(btn).show();
}

function openCmdPalette() {
    document.getElementById('cmdPalette').classList.add('show');
    const inp = document.getElementById('cmdInput');
    inp.value = ''; inp.focus();
    renderCmdResults();
}
function closeCmdPalette() {
    document.getElementById('cmdPalette').classList.remove('show');
}
let cmdActiveIdx = 0;
function renderCmdResults() {
    const q = document.getElementById('cmdInput').value.toLowerCase().trim();
    const list = document.getElementById('cmdResults');
    let items = commands.filter(c => !q || c.label.toLowerCase().includes(q));
    if (q.length >= 2) {
        const r = localLookup(q, '');
        if (r.code && r.code !== '000' && r.confidence > 20) {
            items.unshift({
                id:'lookup_' + r.code,
                label:`Classify "${q}" → ${r.code} (${r.confidence}%)`,
                action:() => { switchTab('search'); document.getElementById('subjectSearch').value = q; searchBySubject(); closeCmdPalette(); }
            });
        }
    }
    if (!items.length) { list.innerHTML = '<div class="cmd-item text-muted">No commands</div>'; return; }
    cmdActiveIdx = Math.min(cmdActiveIdx, items.length - 1);
    list.innerHTML = items.map((c, i) =>
        `<div class="cmd-item ${i === cmdActiveIdx ? 'active' : ''}" onclick="runCmd(${i})">${escapeHtml(c.label)}</div>`
    ).join('');
    window._cmdItems = items;
}
function runCmd(i) {
    const items = window._cmdItems || [];
    if (items[i]) { items[i].action(); closeCmdPalette(); }
}
function cmdKeyNav(e) {
    const items = window._cmdItems || [];
    if (e.key === 'Escape') closeCmdPalette();
    else if (e.key === 'ArrowDown') { e.preventDefault(); cmdActiveIdx = Math.min(items.length-1, cmdActiveIdx+1); renderCmdResults(); }
    else if (e.key === 'ArrowUp')   { e.preventDefault(); cmdActiveIdx = Math.max(0, cmdActiveIdx-1); renderCmdResults(); }
    else if (e.key === 'Enter')     { e.preventDefault(); runCmd(cmdActiveIdx); }
}

// ============================================================
// UNDO / REDO
// ============================================================
function doUndo() {
    if (!undoStack.length) { showToast('Nothing to undo', 'info'); return; }
    redoStack.push(JSON.parse(JSON.stringify(classificationData)));
    classificationData = undoStack.pop();
    updateStats();
    showToast('Undone', 'success');
}
function doRedo() {
    if (!redoStack.length) { showToast('Nothing to redo', 'info'); return; }
    undoStack.push(JSON.parse(JSON.stringify(classificationData)));
    classificationData = redoStack.pop();
    updateStats();
    showToast('Redone', 'success');
}

// ============================================================
// KEYBOARD SHORTCUTS
// ============================================================
document.addEventListener('keydown', function (e) {
    if (e.target.matches('input, textarea')) {
        if (e.key === 'Escape' && document.getElementById('cmdPalette').classList.contains('show')) closeCmdPalette();
        return;
    }
    if ((e.ctrlKey || e.metaKey) && e.key === 'k') { e.preventDefault(); openCmdPalette(); }
    if (e.ctrlKey && e.shiftKey && e.key === 'S') { e.preventDefault(); document.getElementById('subjectSearch')?.focus(); }
    if ((e.ctrlKey || e.metaKey) && e.key === 'z') { e.preventDefault(); doUndo(); }
    if ((e.ctrlKey || e.metaKey) && e.key === 'y') { e.preventDefault(); doRedo(); }
});

// ============================================================
// INIT
// ============================================================
document.addEventListener('DOMContentLoaded', () => {
    updateStats();
    renderHistory();
    renderClassifiedBooks();
    updateClassifiedCount();
    loadKohaBooks();
    loadAnalytics();
    loadAudit();
    document.querySelectorAll('.nav-tabs-modern .nav-link').forEach(btn => {
        btn.addEventListener('shown.bs.tab', function () {
            currentClassTab = this.dataset.classtab || 'search';
            if (currentClassTab === 'analytics') loadAnalytics();
            if (currentClassTab === 'audit') loadAudit();
        });
    });
    showToast('🚀 Classification v8.1 ready — try Ctrl+K', 'success');
});
</script>

<?php
// ============================================================
// FOOTER — with entity-collapse post-processing  [CHANGED]
// ============================================================
// The shared vms_render_footer() may re-encode the institution name,
// producing literal "&amp;" in the HTML. We buffer it and collapse
// any over-encoded entities so the browser shows the name exactly as typed.

$__classFooterOut = '';

ob_start();
try {
    if (function_exists('vms_footer_css')) { vms_footer_css(); }
    if (function_exists('vms_footer_js'))  { vms_footer_js();  }

    if (function_exists('vms_render_footer')) {
        vms_render_footer([
            'layout'           => 'compact',
            'institution_name' => $institutionName,
            'institutionName'  => $institutionName,
            'library_name'     => $institutionName,
            'site_name'        => $institutionName,
            'org_name'         => $institutionName,
            'no_escape'        => true,
        ]);
    }
} catch (Throwable $e) {
    error_log('[class.php] footer render: ' . $e->getMessage());
}
$__classFooterOut = ob_get_clean();

if ($__classFooterOut !== '') {
    // Collapse &amp;amp;amp; → &amp;amp; → &amp; (up to 5 passes)
    $prev = null;
    $out  = $__classFooterOut;
    $i    = 0;
    while ($prev !== $out && $i < 5) {
        $prev = $out;
        $out  = str_replace('&amp;amp;', '&amp;', $out);
        $i++;
    }
    // Final collapse: "word &amp; word" → "word & word" (only between
    // alphanumerics, so we never touch &nbsp; &copy; &quot; etc.)
    $out = preg_replace_callback(
        '/(?<=[A-Za-z0-9])\s*&amp;\s*(?=[A-Za-z0-9])/',
        function () { return ' & '; },
        $out
    );
    echo $out;
}
?>
</body>
</html>
