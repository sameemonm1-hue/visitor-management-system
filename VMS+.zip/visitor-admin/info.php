<?php
/**
 * Visitor Management System - PHP Info
 * Version: 7.3 FINAL
 * 
 * This file displays PHP configuration information for debugging purposes.
 * Access: http://localhost:8081/cgi-bin/koha/visitor/info.php
 * 
 * WARNING: Remove this file in production for security!
 */

// Display PHP info
phpinfo();
?>
