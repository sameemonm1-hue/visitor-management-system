<?php
/**
 * Visitor Management System — Guest Photo Streaming Endpoint
 * Version: 1.1 STANDALONE — Institution name normalization
 *
 * Streams a guest photo from uploads/guest_photos/ to authenticated
 * staff. Used by guests.php to display photo thumbnails without
 * exposing the raw uploads directory.
 *
 * Usage:   guest_photo.php?f=guest_20250115_142233_a1b2c3d4.jpg
 * Denies:  any filename that is not a valid guest photo
 * Returns: the image bytes, or a styled HTML error page.
 *
 * FIX (v1.1):
 *   • Institution name aggressively normalized (multi-level entity
 *     decode) so any wrapper or error page gets a clean value.
 *   • Error responses render a styled HTML page instead of raw text,
 *     displaying the institution name with a single "&".
 *   • Content-Type strictly enforced for streamed images.
 */

error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

// ============================================================
// 1. Bootstrap VMS config + auth (best-effort)
// ============================================================
$possiblePaths = [
    __DIR__ . '/includes',
    dirname(__DIR__) . '/includes',
    '/usr/share/koha/intranet/cgi-bin/koha/visitor/includes',
    '/usr/share/koha/intranet/cgi-bin/visitor/includes',
];

$includePath = null;
foreach ($possiblePaths as $p) {
    if (file_exists($p . '/config.php')) { $includePath = $p; break; }
}

if ($includePath) {
    require_once $includePath . '/config.php';
    if (file_exists($includePath . '/functions.php')) require_once $includePath . '/functions.php';
    if (file_exists($includePath . '/koha.php'))      require_once $includePath . '/koha.php';
    if (file_exists($includePath . '/auth.php'))      require_once $includePath . '/auth.php';
}

// Session + auth — best-effort
if (function_exists('startSecureSession')) {
    startSecureSession();
} elseif (session_status() === PHP_SESSION_NONE) {
    session_name('CGISESSID');
    if (isset($_COOKIE['CGISESSID'])) session_id($_COOKIE['CGISESSID']);
    session_start();
}

if (function_exists('isKohaLoggedIn') && !isKohaLoggedIn()) {
    http_response_code(401);
    exit('Not logged in');
}
if (function_exists('requireKohaLogin')) {
    requireKohaLogin();
}

// ============================================================
// 2. INSTITUTION NAME — deeply normalized to plain text
// ============================================================
if (!function_exists('gp_clean_institution')) {
    /**
     * Aggressively normalize an institution name to plain text.
     *
     * "Library & information"          → "Library & information"
     * "Library &amp; information"       → "Library & information"
     * "Library &amp;amp; information"   → "Library & information"
     * "Library &amp;amp;amp; info"      → "Library & information"
     */
    function gp_clean_institution(string $raw): string {
        $raw = trim($raw);
        if ($raw === '') return 'My Library';

        if (!mb_check_encoding($raw, 'UTF-8')) {
            $fixed = @mb_convert_encoding($raw, 'UTF-8', 'ISO-8859-1');
            if ($fixed !== false && $fixed !== '') $raw = $fixed;
        }

        // Loop-decode until stable (max 5 passes)
        $prev = null; $out = $raw; $i = 0;
        while ($prev !== $out && $i < 5) {
            $prev = $out;
            $out  = html_entity_decode($out, ENT_QUOTES | ENT_HTML5, 'UTF-8');
            $i++;
        }

        // Defensive collapse of residual literal entity sequences
        $out = str_replace(
            ['&amp;amp;amp;', '&amp;amp;', '&amp;', '&AMP;', '&Amp;'],
            '&',
            $out
        );
        $out = str_replace(
            ['&quot;', '&#039;', '&#39;', '&apos;', '&lt;', '&gt;', '&nbsp;'],
            ['"',       "'",       "'",      "'",       '<',    '>',    ' '],
            $out
        );

        $out = preg_replace('/\s+/u', ' ', $out);
        $out = trim($out);

        return $out !== '' ? $out : 'My Library';
    }
}

$institutionName = 'My Library';
if (function_exists('getSettings')) {
    try {
        $settings = getSettings();
        if (is_array($settings) && !empty($settings['institution_name'])) {
            $institutionName = gp_clean_institution((string)$settings['institution_name']);
        }
    } catch (Throwable $e) {
        // fall through to constant
    }
}
if ($institutionName === 'My Library'
    && defined('INSTITUTION_NAME')
    && trim((string)INSTITUTION_NAME) !== '') {
    $institutionName = gp_clean_institution((string)INSTITUTION_NAME);
}

// Publish everywhere (harmless for an image endpoint, but useful if
// any wrapper or error page reads it).
$GLOBALS['institution_name'] = $institutionName;
$GLOBALS['institutionName']  = $institutionName;
$GLOBALS['INSTITUTION_NAME'] = $institutionName;

// ============================================================
// 3. Helper: styled error page (single safe encode)
// ============================================================
if (!function_exists('gp_render_error')) {
    function gp_render_error(int $code, string $title, string $detail, string $institutionName): void {
        http_response_code($code);
        header('Content-Type: text/html; charset=utf-8');

        // Single safe encode; the false flag disables double-encoding.
        $inst      = htmlspecialchars($institutionName, ENT_QUOTES, 'UTF-8', false);
        $titleEsc  = htmlspecialchars($title, ENT_QUOTES, 'UTF-8');
        $detailEsc = htmlspecialchars($detail, ENT_QUOTES, 'UTF-8');

        echo '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8">';
        echo '<meta name="viewport" content="width=device-width, initial-scale=1">';
        echo '<title>' . $titleEsc . ' — ' . $inst . '</title>';
        echo '<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">';
        echo '<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">';
        echo '<style>
            body { font-family: Inter, -apple-system, sans-serif; background: #eef2f7; padding: 40px; }
            .gp-err-card {
                max-width: 520px; margin: 40px auto; background: #fff;
                border-radius: 16px; border: 1px solid #e9ecef; overflow: hidden;
                box-shadow: 0 10px 32px rgba(30,60,114,0.08);
            }
            .gp-err-head {
                background: linear-gradient(135deg, #1e3c72, #2a5298);
                color: #fff; padding: 18px 22px; font-weight: 700; font-size: 1.1rem;
            }
            .gp-err-body { padding: 22px; }
            .gp-err-body h5 { color: #1e3c72; font-weight: 700; }
            .gp-err-body p { color: #6c757d; margin: 0; }
            .gp-err-foot {
                padding: 12px 22px; background: #f8fafc;
                border-top: 1px solid #e9ecef;
                color: #6c757d; font-size: .8rem;
                display: flex; justify-content: space-between; flex-wrap: wrap; gap: 8px;
            }
        </style>';
        echo '</head><body>';
        echo '<div class="gp-err-card">';
        echo '  <div class="gp-err-head"><i class="fas fa-image me-2"></i>Guest Photo</div>';
        echo '  <div class="gp-err-body">';
        echo '    <h5><i class="fas fa-exclamation-triangle me-2"></i>' . $titleEsc . '</h5>';
        echo '    <p class="mt-2">' . $detailEsc . '</p>';
        echo '  </div>';
        echo '  <div class="gp-err-foot">';
        echo '    <span><i class="fas fa-book-open me-1"></i>' . $inst . '</span>';
        echo '    <span>Error ' . (int)$code . '</span>';
        echo '  </div>';
        echo '</div>';
        echo '</body></html>';
        exit;
    }
}

// ============================================================
// 4. Validate the requested filename
// ============================================================
$file = isset($_GET['f']) ? (string)$_GET['f'] : '';

// Strip any path separators — only basename is allowed.
$file = basename($file);

if ($file === '' || !preg_match('/^guest_[A-Za-z0-9_\-]+\.(jpg|jpeg|png|webp)$/i', $file)) {
    gp_render_error(
        404,
        'Photo not found',
        'The requested photo does not exist or the filename is invalid.',
        $institutionName
    );
}

// ============================================================
// 5. Resolve the on-disk path
// ============================================================
$baseDir = null;
if (defined('UPLOAD_PATH')) {
    $baseDir = rtrim(UPLOAD_PATH, '/');
} elseif (defined('ROOT_PATH')) {
    $baseDir = rtrim(ROOT_PATH, '/') . '/uploads';
} else {
    $baseDir = rtrim(dirname(__DIR__), '/') . '/uploads';
}

$path = $baseDir . '/guest_photos/' . $file;

if (!is_file($path)) {
    gp_render_error(
        404,
        'Photo not found',
        'The photo file was not found on disk.',
        $institutionName
    );
}

// ============================================================
// 6. Determine and validate the MIME type from content
// ============================================================
$finfo = finfo_open(FILEINFO_MIME_TYPE);
$mime  = $finfo ? finfo_file($finfo, $path) : null;
if ($finfo) finfo_close($finfo);

$allowed = ['image/jpeg', 'image/png', 'image/webp'];
if (!in_array($mime, $allowed, true)) {
    gp_render_error(
        415,
        'Unsupported file type',
        'The stored photo is not a supported image format.',
        $institutionName
    );
}

// ============================================================
// 7. Stream the image
// ============================================================
while (ob_get_level() > 0) { ob_end_clean(); }

header('Content-Type: ' . $mime);
header('Content-Length: ' . filesize($path));
header('Cache-Control: private, max-age=86400');
header('X-Content-Type-Options: nosniff');
header('Pragma: private');

readfile($path);
exit;
