<?php
/**
 * Visitor Management System - Logout
 * Version: 7.4 FINAL - WORKING
 */

// Auto-detect paths
$possiblePaths = [
    __DIR__ . '/includes',
    dirname(__DIR__) . '/includes',
    '/usr/share/koha/intranet/cgi-bin/koha/visitor/includes',
    '/usr/share/koha/intranet/cgi-bin/visitor/includes',
];

$includePath = null;
foreach ($possiblePaths as $path) {
    if (file_exists($path . '/config.php')) {
        $includePath = $path;
        break;
    }
}

if (!$includePath) {
    $testPath = __DIR__;
    for ($i = 0; $i < 5; $i++) {
        $testPath = dirname($testPath);
        if (file_exists($testPath . '/includes/config.php')) {
            $includePath = $testPath . '/includes';
            break;
        }
    }
}

if (!$includePath) {
    die('Could not find includes directory.');
}

define('VMS_INCLUDES', $includePath);
require_once VMS_INCLUDES . '/config.php';
require_once VMS_INCLUDES . '/functions.php';
require_once VMS_INCLUDES . '/koha.php';
require_once VMS_INCLUDES . '/auth.php';

startSecureSession();

// Log the logout
if (isset($_SESSION['koha_user_id'])) {
    logActivity($_SESSION['koha_user_id'] ?? 0, 'LOGOUT', "User logged out");
}

// Destroy session and redirect to Koha
kohaLogout();

// If Koha logout fails, redirect to Koha main page
header('Location: ' . KOHA_INTRANET_URL . '/cgi-bin/koha/mainpage.pl');
exit;
