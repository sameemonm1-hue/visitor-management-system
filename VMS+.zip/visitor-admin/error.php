<?php
/**
 * Visitor Management System - Error Handler
 * Version: 8.4 FINAL — Institution name normalization + sibling-style footer
 *
 * CHANGELOG v8.4 (from v8.3)
 *   • FIXED: Institution name (from settings DB) is now aggressively
 *            decoded so "Library &amp; information" renders as
 *            "Library & information" — no double-encoding.
 *   • NEW:   vms_err_clean_institution() helper — multi-level entity
 *            decode, 5 passes, with residual-literal cleanup.
 *   • NEW:   Inline footer strip matching isbn/class/labels/idcards/
 *            stock_verify — gradient bar, institution name, VMS tag.
 *   • FIXED: <title> now uses htmlspecialchars(..., ENT_QUOTES,
 *            'UTF-8', false) — single safe encode, no double-encode.
 *   • PRESERVED: Rich error catalog (15 codes), debug block, repeat
 *                tracking, safe config fallback, styled error page.
 *
 * CHANGELOG v8.3
 *   • Loads VMS config (safe) so institution name/logo can render
 *   • Sends proper HTTP status code via header()
 *   • Supports ?code=N and ?message=TEXT + ?debug=1
 *   • Rich set of built-in error descriptions
 *   • Time-aware greeting + context-aware actions
 *   • Duplicate error tracking in session for repeated visits
 *   • Auto-logs to activity_log when DB is available
 *   • Print-friendly
 *
 * URL:
 *   error.php                       → 500
 *   error.php?code=404              → 404
 *   error.php?code=403&message=X    → 403 with custom message
 *   error.php?code=500&debug=1      → 500 with debug info
 */

// ============================================================
// 1. COLLECT REQUEST CONTEXT
// ============================================================
$code         = (int)($_GET['code']    ?? 500);
$customMsg    = trim((string)($_GET['message'] ?? ''));
$debugRequest = !empty($_GET['debug']);
$referer      = $_SERVER['HTTP_REFERER']      ?? '';
$userAgent    = $_SERVER['HTTP_USER_AGENT']   ?? '';
$clientIp     = $_SERVER['REMOTE_ADDR']       ?? '';
$requestUri   = $_SERVER['REQUEST_URI']       ?? '';
$method       = $_SERVER['REQUEST_METHOD']    ?? 'GET';
$timestamp    = date('Y-m-d H:i:s');

// Whitelist of supported codes
$validCodes = [400, 401, 403, 404, 405, 408, 409, 410, 419, 422, 429, 500, 502, 503, 504];
if (!in_array($code, $validCodes, true)) {
    $code = 500;
}

// ============================================================
// 2. SEND REAL HTTP STATUS
// ============================================================
if (!headers_sent()) {
    http_response_code($code);
    header('X-Robots-Tag: noindex, nofollow');
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
}

// ============================================================
// 3. BUILT-IN ERROR CATALOG
// ============================================================
$catalog = [
    400 => ['title' => 'Bad Request',           'icon' => 'fa-question-circle',      'color' => '#f59e0b',
            'short' => 'The server could not understand the request.',
            'long'  => 'This usually means a form was submitted with missing or invalid data.'],
    401 => ['title' => 'Unauthorized',          'icon' => 'fa-user-lock',            'color' => '#dc3545',
            'short' => 'You are not logged in.',
            'long'  => 'Please log in to Koha first, then return to the Visitor Management System.'],
    403 => ['title' => 'Access Denied',         'icon' => 'fa-ban',                  'color' => '#dc3545',
            'short' => 'You do not have permission to access this page.',
            'long'  => 'This module requires elevated privileges. Contact your librarian or system administrator.'],
    404 => ['title' => 'Page Not Found',        'icon' => 'fa-compass',              'color' => '#0ea5e9',
            'short' => 'The page you are looking for does not exist.',
            'long'  => 'It may have been moved, deleted, or the URL may be incorrect. Check the address bar.'],
    405 => ['title' => 'Method Not Allowed',    'icon' => 'fa-hand-paper',           'color' => '#f59e0b',
            'short' => 'This URL does not accept this request method.',
            'long'  => 'Try going back and using the on-screen buttons instead.'],
    408 => ['title' => 'Request Timeout',       'icon' => 'fa-clock',                'color' => '#f59e0b',
            'short' => 'The server timed out waiting for your request.',
            'long'  => 'Your connection may be slow. Refresh the page or try again.'],
    409 => ['title' => 'Conflict',              'icon' => 'fa-exclamation-circle',   'color' => '#f59e0b',
            'short' => 'The request conflicts with the current state of the data.',
            'long'  => 'Someone may have modified the same record. Refresh and try again.'],
    410 => ['title' => 'Gone',                  'icon' => 'fa-ghost',                'color' => '#64748b',
            'short' => 'This resource is permanently gone.',
            'long'  => 'It has been removed and will not return.'],
    419 => ['title' => 'Session Expired',       'icon' => 'fa-hourglass-end',        'color' => '#f59e0b',
            'short' => 'Your session has expired.',
            'long'  => 'For your security, please log in again.'],
    422 => ['title' => 'Unprocessable Request', 'icon' => 'fa-list',                 'color' => '#f59e0b',
            'short' => 'The form data could not be processed.',
            'long'  => 'Check that all required fields are filled correctly and try again.'],
    429 => ['title' => 'Too Many Requests',     'icon' => 'fa-tachometer-alt',       'color' => '#f59e0b',
            'short' => 'You have made too many requests.',
            'long'  => 'Please wait a moment before trying again.'],
    500 => ['title' => 'Internal Server Error', 'icon' => 'fa-bolt',                 'color' => '#dc3545',
            'short' => 'Something went wrong on the server.',
            'long'  => 'This is usually a bug or a database issue. Try again, and if it persists, run diag.php.'],
    502 => ['title' => 'Bad Gateway',           'icon' => 'fa-exchange-alt',         'color' => '#dc3545',
            'short' => 'An upstream server returned an invalid response.',
            'long'  => 'The Koha or MySQL backend may be down. Check the services.'],
    503 => ['title' => 'Service Unavailable',   'icon' => 'fa-tools',                'color' => '#f59e0b',
            'short' => 'The system is under maintenance.',
            'long'  => 'Please come back in a few minutes. If this is unexpected, contact the administrator.'],
    504 => ['title' => 'Gateway Timeout',       'icon' => 'fa-hourglass-half',       'color' => '#dc3545',
            'short' => 'The upstream server took too long to respond.',
            'long'  => 'The database or a remote service may be unresponsive.'],
];

$err = $catalog[$code];

// ============================================================
// 4. INSTITUTION NAME — deeply normalized to plain text  [CHANGED v8.4]
// ============================================================
if (!function_exists('vms_err_clean_institution')) {
    /**
     * Aggressively normalize an institution name to plain text.
     *
     * "Library & information"          → "Library & information"
     * "Library &amp; information"       → "Library & information"
     * "Library &amp;amp; information"   → "Library & information"
     * "Library &amp;amp;amp; info"      → "Library & information"
     */
    function vms_err_clean_institution(string $raw): string {
        $raw = trim($raw);
        if ($raw === '') return 'Library';

        if (!mb_check_encoding($raw, 'UTF-8')) {
            $fixed = @mb_convert_encoding($raw, 'UTF-8', 'ISO-8859-1');
            if ($fixed !== false && $fixed !== '') $raw = $fixed;
        }

        // Loop-decode until stable (max 5 passes)
        $prev = null; $out = $raw; $i = 0;
        while ($prev !== $out && $i < 5) {
            $prev = $out;
            $out  = html_entity_decode($out, ENT_QUOTES | ENT_HTML5, 'UTF-8');
            $i++;
        }

        // Defensive collapse of residual literal entity sequences
        $out = str_replace(
            ['&amp;amp;amp;', '&amp;amp;', '&amp;', '&AMP;', '&Amp;'],
            '&',
            $out
        );
        $out = str_replace(
            ['&quot;', '&#039;', '&#39;', '&apos;', '&lt;', '&gt;', '&nbsp;'],
            ['"',       "'",       "'",      "'",       '<',    '>',    ' '],
            $out
        );

        $out = preg_replace('/\s+/u', ' ', $out);
        $out = trim($out);

        return $out !== '' ? $out : 'Library';
    }
}

// ============================================================
// 5. SESSION — for repeat tracking & safe start
// ============================================================
if (session_status() === PHP_SESSION_NONE) {
    session_name('CGISESSID');
    if (isset($_COOKIE['CGISESSID'])) session_id($_COOKIE['CGISESSID']);
    @session_start();
}

// Track repeat errors
$repeatCount = 0;
try {
    $key = 'error_count_' . $code;
    $_SESSION[$key] = ($_SESSION[$key] ?? 0) + 1;
    $repeatCount = $_SESSION[$key];
} catch (Throwable $e) { /* session may be closed */ }

// ============================================================
// 6. OPTIONAL: LOAD VMS CONFIG (safe — never break this page)
// ============================================================
$configLoaded    = false;
$db              = null;
$institutionName = 'Library';
$logoDataUri     = '';

$possiblePaths = [
    __DIR__ . '/includes',
    dirname(__DIR__) . '/includes',
    '/usr/share/koha/intranet/cgi-bin/koha/visitor/includes',
    '/usr/share/koha/intranet/cgi-bin/visitor/includes',
];
foreach ($possiblePaths as $p) {
    if (file_exists($p . '/config.php')) {
        try {
            require_once $p . '/config.php';
            $configLoaded = true;
            if (file_exists($p . '/functions.php')) require_once $p . '/functions.php';
            if (file_exists($p . '/koha.php'))      require_once $p . '/koha.php';
        } catch (Throwable $e) {
            // Silent — error page must still render
        }
        break;
    }
}

// Try to fetch institution name + logo, then normalize the name
if ($configLoaded) {
    try {
        if (function_exists('getDB') && function_exists('getSettings')) {
            $db = getDB();
            $settings = getSettings();
            if (!empty($settings['institution_name'])) {
                $institutionName = vms_err_clean_institution((string)$settings['institution_name']);
            } elseif (defined('INSTITUTION_NAME') && trim((string)INSTITUTION_NAME) !== '') {
                $institutionName = vms_err_clean_institution((string)INSTITUTION_NAME);
            }

            $logoPath  = $settings['institution_logo'] ?? '';
            $uploadDir = (defined('ROOT_PATH') ? ROOT_PATH : __DIR__) . '/uploads/logos/';
            if (!empty($logoPath) && file_exists($uploadDir . $logoPath)) {
                $raw = @file_get_contents($uploadDir . $logoPath);
                if ($raw !== false) {
                    $finfo = finfo_open(FILEINFO_MIME_TYPE);
                    $mime  = finfo_buffer($finfo, $raw);
                    finfo_close($finfo);
                    $logoDataUri = 'data:' . $mime . ';base64,' . base64_encode($raw);
                }
            }
        }
    } catch (Throwable $e) {
        // Silent
    }
}

// Publish everywhere (in case anything downstream reads it)
$GLOBALS['institution_name'] = $institutionName;
$GLOBALS['institutionName']  = $institutionName;
$GLOBALS['INSTITUTION_NAME'] = $institutionName;

// ============================================================
// 7. LOG THE ERROR (best effort, no recursion)
// ============================================================
if ($db) {
    try {
        $userId   = function_exists('getCurrentUser') ? (getCurrentUser()['id'] ?? 0) : 0;
        $username = function_exists('getCurrentUser') ? (getCurrentUser()['full_name'] ?? 'guest') : 'guest';
        $details  = sprintf(
            "HTTP %d | %s %s | referer=%s | ip=%s",
            $code, $method, $requestUri, $referer, $clientIp
        );
        $db->prepare("
            INSERT INTO activity_log (user_id, username, action, details, ip_address, user_agent)
            VALUES (?, ?, ?, ?, ?, ?)
        ")->execute([
            $userId,
            $username,
            'ERROR_' . $code,
            $details,
            $clientIp,
            $userAgent,
        ]);
    } catch (Throwable $e) {
        // Silent
    }
}

// ============================================================
// 8. DEBUG BLOCK (only when explicitly requested)
// ============================================================
$debugVisible = $debugRequest;
$debugInfo    = [];

if ($debugVisible) {
    $debugInfo = [
        'Code'          => $code,
        'Timestamp'     => $timestamp,
        'Method'        => $method,
        'Request URI'   => $requestUri,
        'Referer'       => $referer ?: '—',
        'Client IP'     => $clientIp,
        'User Agent'    => $userAgent,
        'PHP Version'   => PHP_VERSION,
        'Session ID'    => session_id() ?: '—',
        'Repeat Count'  => $repeatCount,
        'Config Loaded' => $configLoaded ? 'yes' : 'no',
    ];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="noindex,nofollow">
    <title>Error <?= (int)$code ?> — <?= htmlspecialchars($err['title'], ENT_QUOTES, 'UTF-8') ?> — <?= htmlspecialchars($institutionName, ENT_QUOTES, 'UTF-8', false) ?></title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">

    <style>
        :root {
            --err-bg: #eef2f7;
            --err-card: #ffffff;
            --err-primary: #1e3c72;
            --err-accent: <?= htmlspecialchars($err['color'], ENT_QUOTES, 'UTF-8') ?>;
        }
        * { box-sizing: border-box; }
        html, body { height: 100%; }
        body {
            font-family: 'Inter', -apple-system, sans-serif;
            background: linear-gradient(135deg, var(--err-bg) 0%, #e4ebf5 100%);
            min-height: 100vh;
            margin: 0;
            padding: 24px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #1e293b;
        }

        .err-wrap { width: 100%; max-width: 680px; }

        .err-card {
            background: var(--err-card);
            border-radius: 24px;
            padding: 40px 44px;
            box-shadow: 0 20px 60px rgba(30,60,114,0.12);
            text-align: center;
            position: relative;
            overflow: hidden;
        }
        .err-card::before {
            content: '';
            position: absolute;
            top: 0; left: 0; right: 0;
            height: 6px;
            background: linear-gradient(90deg, var(--err-accent), #dc3545);
        }

        .err-logo {
            max-height: 60px;
            margin-bottom: 18px;
            border-radius: 12px;
        }

        .err-icon {
            width: 90px;
            height: 90px;
            margin: 0 auto 20px;
            border-radius: 50%;
            background: <?= htmlspecialchars($err['color'], ENT_QUOTES, 'UTF-8') ?>1a;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--err-accent);
            font-size: 2.5rem;
            animation: errPulse 2.4s infinite;
        }
        @keyframes errPulse {
            0%, 100% { box-shadow: 0 0 0 0 <?= htmlspecialchars($err['color'], ENT_QUOTES, 'UTF-8') ?>40; }
            50%      { box-shadow: 0 0 0 16px <?= htmlspecialchars($err['color'], ENT_QUOTES, 'UTF-8') ?>00; }
        }

        .err-code {
            font-size: 5.5rem;
            font-weight: 900;
            line-height: 1;
            color: var(--err-primary);
            letter-spacing: -3px;
            margin-bottom: 4px;
        }

        .err-title {
            font-size: 1.35rem;
            font-weight: 700;
            color: var(--err-primary);
            margin-bottom: 10px;
        }

        .err-short {
            font-size: 0.95rem;
            color: #475569;
            margin-bottom: 6px;
        }

        .err-long {
            font-size: 0.85rem;
            color: #94a3b8;
            margin-bottom: 26px;
            line-height: 1.55;
        }

        .err-custom {
            background: #fef3c7;
            color: #78350f;
            border-left: 4px solid #f59e0b;
            padding: 12px 18px;
            border-radius: 10px;
            font-size: 0.85rem;
            text-align: left;
            margin-bottom: 22px;
            word-break: break-word;
        }

        .err-actions {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            justify-content: center;
            margin-bottom: 22px;
        }
        .btn-err {
            padding: 11px 22px;
            border-radius: 12px;
            font-weight: 600;
            font-size: 0.88rem;
            border: none;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.2s;
        }
        .btn-err.primary {
            background: var(--err-primary);
            color: #fff;
        }
        .btn-err.primary:hover {
            background: #2a5298;
            color: #fff;
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(30,60,114,0.25);
        }
        .btn-err.outline {
            background: transparent;
            color: var(--err-primary);
            border: 2px solid #e2e8f0;
        }
        .btn-err.outline:hover {
            border-color: var(--err-primary);
            background: #f8fafc;
        }

        .err-meta {
            font-size: 0.72rem;
            color: #94a3b8;
            border-top: 1px solid #f1f5f9;
            padding-top: 16px;
            line-height: 1.7;
            text-align: left;
        }
        .err-meta code {
            background: #f1f5f9;
            color: #334155;
            padding: 1px 6px;
            border-radius: 4px;
            font-size: 0.7rem;
        }

        /* ============================================================
           FOOTER — matches sibling files
           ============================================================ */
        .err-footer {
            margin-top: 20px;
            padding: 12px 20px;
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            color: #ffffff;
            border-radius: 14px;
            font-size: 0.75rem;
            line-height: 1.3;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 10px;
        }
        .err-footer .ef-left {
            display: flex;
            align-items: center;
            gap: 8px;
            font-weight: 700;
        }
        .err-footer .ef-right {
            opacity: 0.85;
        }

        .err-debug {
            margin-top: 20px;
            text-align: left;
            background: #0f172a;
            color: #cbd5e1;
            border-radius: 12px;
            padding: 16px 20px;
            font-size: 0.75rem;
            font-family: 'SF Mono', Consolas, monospace;
        }
        .err-debug h6 {
            color: #38bdf8;
            margin: 0 0 10px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            font-size: 0.7rem;
        }
        .err-debug .kv {
            display: grid;
            grid-template-columns: 140px 1fr;
            gap: 6px 12px;
        }
        .err-debug .k { color: #94a3b8; }
        .err-debug .v { color: #e2e8f0; word-break: break-word; }

        .err-repeat {
            display: inline-block;
            background: #fee2e2;
            color: #991b1b;
            font-size: 0.68rem;
            font-weight: 700;
            padding: 3px 10px;
            border-radius: 20px;
            margin-bottom: 14px;
        }

        @media (max-width: 480px) {
            .err-card { padding: 30px 24px; }
            .err-code { font-size: 4rem; }
            .err-title { font-size: 1.15rem; }
            .err-icon { width: 70px; height: 70px; font-size: 2rem; }
            .err-footer { justify-content: center; text-align: center; }
        }
        @media print {
            body { background: #fff; }
            .err-card { box-shadow: none; border: 1px solid #ddd; }
            .err-actions, .err-debug, .err-footer { display: none !important; }
        }
    </style>
</head>
<body>
<div class="err-wrap">
    <div class="err-card">

        <?php if (!empty($logoDataUri)): ?>
            <img src="<?= htmlspecialchars($logoDataUri, ENT_QUOTES, 'UTF-8') ?>" alt="Logo" class="err-logo">
        <?php endif; ?>

        <div class="err-icon">
            <i class="fas <?= htmlspecialchars($err['icon'], ENT_QUOTES, 'UTF-8') ?>"></i>
        </div>

        <div class="err-code"><?= (int)$code ?></div>
        <div class="err-title"><?= htmlspecialchars($err['title'], ENT_QUOTES, 'UTF-8') ?></div>
        <div class="err-short"><?= htmlspecialchars($err['short'], ENT_QUOTES, 'UTF-8') ?></div>
        <div class="err-long"><?= htmlspecialchars($err['long'], ENT_QUOTES, 'UTF-8') ?></div>

        <?php if ($repeatCount > 1): ?>
            <div class="err-repeat">
                <i class="fas fa-redo me-1"></i>
                You have seen this error <?= (int)$repeatCount ?> times this session
            </div>
        <?php endif; ?>

        <?php if ($customMsg !== ''): ?>
            <div class="err-custom">
                <strong><i class="fas fa-info-circle me-1"></i>Details:</strong>
                <?= htmlspecialchars($customMsg, ENT_QUOTES, 'UTF-8') ?>
            </div>
        <?php endif; ?>

        <div class="err-actions">
            <?php if ($referer && $code !== 401): ?>
                <a href="<?= htmlspecialchars($referer, ENT_QUOTES, 'UTF-8') ?>" class="btn-err outline">
                    <i class="fas fa-arrow-left"></i> Go Back
                </a>
            <?php endif; ?>

            <?php if ($configLoaded): ?>
                <a href="dashboard.php" class="btn-err primary">
                    <i class="fas fa-chart-pie"></i> Dashboard
                </a>
                <?php if ($code === 401 || $code === 403): ?>
                    <a href="<?= defined('KOHA_INTRANET_URL') ? htmlspecialchars(KOHA_INTRANET_URL, ENT_QUOTES, 'UTF-8') : '#' ?>/cgi-bin/koha/mainpage.pl" class="btn-err outline">
                        <i class="fas fa-sign-in-alt"></i> Log In
                    </a>
                <?php endif; ?>
                <?php if ($code === 500 || $code === 502 || $code === 503 || $code === 504): ?>
                    <a href="diag.php" class="btn-err outline">
                        <i class="fas fa-stethoscope"></i> Run Diagnostics
                    </a>
                <?php endif; ?>
            <?php endif; ?>

            <button onclick="history.length > 1 ? history.back() : location.reload()" class="btn-err outline">
                <i class="fas fa-redo"></i> Retry
            </button>
        </div>

        <div class="err-meta">
            <div><i class="fas fa-clock me-1"></i><?= htmlspecialchars($timestamp, ENT_QUOTES, 'UTF-8') ?></div>
            <?php if ($clientIp): ?>
                <div><i class="fas fa-network-wired me-1"></i>From <code><?= htmlspecialchars($clientIp, ENT_QUOTES, 'UTF-8') ?></code></div>
            <?php endif; ?>
        </div>

        <?php if ($debugVisible): ?>
            <div class="err-debug">
                <h6><i class="fas fa-bug me-1"></i>Debug Info (only visible with ?debug=1)</h6>
                <div class="kv">
                    <?php foreach ($debugInfo as $k => $v): ?>
                        <div class="k"><?= htmlspecialchars($k, ENT_QUOTES, 'UTF-8') ?></div>
                        <div class="v"><?= htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8') ?></div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>

    </div>

    <!-- ============================================================
         INLINE FOOTER — matches isbn/class/labels/idcards/stock_verify
         ============================================================ -->
    <footer class="err-footer">
        <div class="ef-left">
            <i class="fas fa-book-open"></i>
            <?= htmlspecialchars($institutionName, ENT_QUOTES, 'UTF-8', false) ?>
        </div>
        <div class="ef-right">
            Visitor Management System · Error <?= (int)$code ?> · <?= htmlspecialchars(date('Y'), ENT_QUOTES, 'UTF-8') ?>
        </div>
    </footer>
</div>
</body>
</html>
