<?php
/**
 * Visitor Management System - Real-Time Occupancy Monitor
 * Version: 7.5 Advanced Edition
 * 
 * Features:
 * - Live occupancy tracking
 * - Capacity alerts (warning/critical)
 * - Historical occupancy charts
 * - Peak time analysis
 * - Auto-refresh every 15 seconds
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

$possiblePaths = [
    __DIR__ . '/includes',
    dirname(__DIR__) . '/includes',
    '/usr/share/koha/intranet/cgi-bin/koha/visitor/includes',
];
$includePath = null;
foreach ($possiblePaths as $path) {
    if (file_exists($path . '/config.php')) { $includePath = $path; break; }
}
if (!$includePath) {
    $testPath = __DIR__;
    for ($i = 0; $i < 5; $i++) {
        $testPath = dirname($testPath);
        if (file_exists($testPath . '/includes/config.php')) { $includePath = $testPath . '/includes'; break; }
    }
}
if (!$includePath) die('Could not find includes directory.');

define('VMS_INCLUDES', $includePath);
require_once VMS_INCLUDES . '/config.php';

startSecureSession();
requireKohaLogin();

$db = getDB();
$settings = getSettings();
$user = getCurrentUser();

// Get capacity settings
$maxCapacity = (int)($settings['max_capacity'] ?? 100);
$warningPercent = (int)($settings['occupancy_warning_percent'] ?? 80);
$criticalPercent = (int)($settings['occupancy_critical_percent'] ?? 95);

// Current occupancy
$currentInside = (int)$db->query("SELECT COUNT(*) FROM entry_exit_logs WHERE status = 'inside'")->fetchColumn();
$currentGuests = (int)$db->query("SELECT COUNT(*) FROM entry_exit_logs WHERE status = 'inside' AND entry_type = 'guest'")->fetchColumn();
$membersInside = $currentInside - $currentGuests;
$occupancyPercent = $maxCapacity > 0 ? round(($currentInside / $maxCapacity) * 100, 1) : 0;

// Get today's peak
$peakToday = $db->query("
    SELECT MAX(inside_count) FROM occupancy_snapshots 
    WHERE DATE(snapshot_time) = CURDATE()
")->fetchColumn() ?: $currentInside;

// Get last 24 hours of occupancy
$hourlyOccupancy = $db->query("
    SELECT 
        DATE_FORMAT(snapshot_time, '%H:00') as hour,
        MAX(inside_count) as max_count
    FROM occupancy_snapshots
    WHERE snapshot_time >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
    GROUP BY DATE_FORMAT(snapshot_time, '%Y-%m-%d %H')
    ORDER BY snapshot_time
")->fetchAll();

// Get top 5 busiest hours today
$busiestHours = $db->query("
    SELECT 
        HOUR(snapshot_time) as hour,
        MAX(inside_count) as peak_count
    FROM occupancy_snapshots
    WHERE DATE(snapshot_time) = CURDATE()
    GROUP BY HOUR(snapshot_time)
    ORDER BY peak_count DESC
    LIMIT 5
")->fetchAll();

// Status determination
$status = 'normal';
$statusColor = '#28a745';
$statusText = 'Normal';
if ($occupancyPercent >= $criticalPercent) {
    $status = 'critical';
    $statusColor = '#dc3545';
    $statusText = 'CRITICAL - Near Capacity';
} elseif ($occupancyPercent >= $warningPercent) {
    $status = 'warning';
    $statusColor = '#ffc107';
    $statusText = 'Warning - High Occupancy';
}

// Record snapshot
try {
    $snapTime = date('Y-m-d H:i:00');
    $db->prepare("
        INSERT INTO occupancy_snapshots (snapshot_time, inside_count, guest_count, total_count, capacity, occupancy_percent)
        VALUES (?, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE 
            inside_count = VALUES(inside_count),
            guest_count = VALUES(guest_count),
            total_count = VALUES(total_count),
            occupancy_percent = VALUES(occupancy_percent)
    ")->execute([$snapTime, $currentInside, $currentGuests, $currentInside, $maxCapacity, $occupancyPercent]);
} catch (PDOException $e) { /* ignore */ }

$pageTitle = 'Occupancy Monitor';
include __DIR__ . '/header.php';
?>

<style>
.occupancy-gauge {
    position: relative;
    width: 280px;
    height: 280px;
    margin: 0 auto;
}
.gauge-svg { transform: rotate(-90deg); }
.gauge-bg { fill: none; stroke: #e9ecef; stroke-width: 20; }
.gauge-fill { fill: none; stroke-width: 20; stroke-linecap: round; transition: stroke-dasharray 0.8s ease, stroke 0.3s ease; }
.gauge-center {
    position: absolute;
    top: 50%; left: 50%;
    transform: translate(-50%, -50%);
    text-align: center;
}
.gauge-number { font-size: 3.5rem; font-weight: 800; line-height: 1; color: #2c3e50; }
.gauge-label { font-size: 0.85rem; color: #6c757d; margin-top: 4px; }
.gauge-percent { font-size: 1.2rem; font-weight: 700; margin-top: 4px; }
.status-banner {
    padding: 20px 30px;
    border-radius: 16px;
    color: white;
    text-align: center;
    font-weight: 700;
    font-size: 1.1rem;
    margin-bottom: 24px;
    animation: pulse 2s infinite;
}
@keyframes pulse { 0%, 100% { transform: scale(1); } 50% { transform: scale(1.02); } }
.stat-mini { text-align: center; padding: 16px; background: #f8f9fa; border-radius: 12px; }
.stat-mini .value { font-size: 1.6rem; font-weight: 700; color: #1e3c72; }
.stat-mini .label { font-size: 0.75rem; color: #6c757d; }
.stat-mini.guest .value { color: #20c997; }
.stat-mini.member .value { color: #1e3c72; }
.chart-wrap { position: relative; height: 300px; }
.live-dot { width: 8px; height: 8px; background: #28a745; border-radius: 50%; display: inline-block; animation: blink 1.5s infinite; }
@keyframes blink { 0%, 100% { opacity: 1; } 50% { opacity: 0.3; } }
@media (max-width: 576px) {
    .occupancy-gauge { width: 220px; height: 220px; }
    .gauge-number { font-size: 2.5rem; }
}
</style>

<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
        <h4 class="mb-0">
            <i class="fas fa-users me-2 text-primary"></i>Real-Time Occupancy
            <span class="badge bg-success ms-2"><span class="live-dot"></span> Live</span>
        </h4>
        <div class="d-flex gap-2">
            <a href="settings.php" class="btn btn-outline-secondary btn-sm">
                <i class="fas fa-cog me-1"></i> Configure
            </a>
            <button onclick="location.reload()" class="btn btn-primary btn-sm">
                <i class="fas fa-sync me-1"></i> Refresh
            </button>
        </div>
    </div>

    <!-- Status Banner -->
    <div class="status-banner" style="background:<?= $statusColor ?>;">
        <i class="fas <?= $status === 'critical' ? 'fa-exclamation-triangle' : ($status === 'warning' ? 'fa-exclamation-circle' : 'fa-check-circle') ?> me-2"></i>
        <?= $statusText ?> — <?= number_format($currentInside) ?> / <?= number_format($maxCapacity) ?> (<?= $occupancyPercent ?>%)
    </div>

    <div class="row g-4">
        <!-- Main Gauge -->
        <div class="col-lg-5">
            <div class="card shadow-sm h-100">
                <div class="card-body text-center">
                    <div class="occupancy-gauge">
                        <svg class="gauge-svg" width="280" height="280" viewBox="0 0 280 280">
                            <circle class="gauge-bg" cx="140" cy="140" r="110"/>
                            <circle class="gauge-fill" id="gaugeFill" cx="140" cy="140" r="110"
                                    stroke="<?= $statusColor ?>"
                                    stroke-dasharray="0 691.15"
                                    data-percent="<?= min(100, $occupancyPercent) ?>"/>
                        </svg>
                        <div class="gauge-center">
                            <div class="gauge-number" id="currentCount"><?= number_format($currentInside) ?></div>
                            <div class="gauge-label">Inside Now</div>
                            <div class="gauge-percent" style="color:<?= $statusColor ?>;" id="percentDisplay"><?= $occupancyPercent ?>%</div>
                        </div>
                    </div>
                    <div class="mt-3 text-muted small">
                        <i class="fas fa-info-circle me-1"></i> Auto-refreshes every 15 seconds
                    </div>
                </div>
            </div>
        </div>

        <!-- Stats -->
        <div class="col-lg-7">
            <div class="row g-3">
                <div class="col-6 col-md-3">
                    <div class="stat-mini member">
                        <div class="value" id="membersInside"><?= number_format($membersInside) ?></div>
                        <div class="label"><i class="fas fa-user me-1"></i>Members</div>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="stat-mini guest">
                        <div class="value" id="guestsInside"><?= number_format($currentGuests) ?></div>
                        <div class="label"><i class="fas fa-user-friends me-1"></i>Guests</div>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="stat-mini">
                        <div class="value" style="color:#ffc107;"><?= number_format($peakToday) ?></div>
                        <div class="label"><i class="fas fa-chart-line me-1"></i>Today Peak</div>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="stat-mini">
                        <div class="value" style="color:#dc3545;"><?= number_format($maxCapacity) ?></div>
                        <div class="label"><i class="fas fa-warehouse me-1"></i>Capacity</div>
                    </div>
                </div>
            </div>

            <!-- Chart -->
            <div class="card shadow-sm mt-3">
                <div class="card-header bg-white">
                    <h6 class="mb-0"><i class="fas fa-chart-area me-2 text-primary"></i>Last 24 Hours Occupancy</h6>
                </div>
                <div class="card-body">
                    <div class="chart-wrap">
                        <canvas id="occupancyChart"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Busiest Hours -->
    <?php if (!empty($busiestHours)): ?>
    <div class="card shadow-sm mt-4">
        <div class="card-header bg-white">
            <h6 class="mb-0"><i class="fas fa-fire me-2 text-warning"></i>Today's Busiest Hours</h6>
        </div>
        <div class="card-body">
            <div class="row g-2">
                <?php 
                $maxPeak = max(array_column($busiestHours, 'peak_count')) ?: 1;
                foreach ($busiestHours as $h): 
                    $pct = ($h['peak_count'] / $maxPeak) * 100;
                ?>
                <div class="col-12">
                    <div class="d-flex align-items-center gap-3">
                        <div style="min-width:60px;font-weight:700;color:#1e3c72;">
                            <?= str_pad($h['hour'], 2, '0', STR_PAD_LEFT) ?>:00
                        </div>
                        <div class="flex-grow-1">
                            <div class="progress" style="height:20px;">
                                <div class="progress-bar bg-warning" style="width:<?= $pct ?>%;">
                                    <?= number_format($h['peak_count']) ?>
                                </div>
                            </div>
                        </div>
                        <div class="text-muted small" style="min-width:80px;text-align:right;">
                            <?= number_format($h['peak_count']) ?> visitors
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
// Initialize gauge
const gaugeFill = document.getElementById('gaugeFill');
const circumference = 2 * Math.PI * 110;
const percent = Math.min(100, parseFloat(gaugeFill.dataset.percent));
gaugeFill.style.strokeDasharray = (percent / 100) * circumference + ' ' + circumference;

// Chart
const chartData = <?= json_encode($hourlyOccupancy) ?>;
const ctx = document.getElementById('occupancyChart').getContext('2d');
new Chart(ctx, {
    type: 'line',
    data: {
        labels: chartData.map(d => d.hour),
        datasets: [{
            label: 'Occupancy',
            data: chartData.map(d => d.max_count),
            borderColor: '#1e3c72',
            backgroundColor: 'rgba(30,60,114,0.1)',
            fill: true,
            tension: 0.4,
            pointRadius: 3
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
            y: { beginAtZero: true, grid: { color: 'rgba(0,0,0,0.05)' } },
            x: { grid: { display: false } }
        }
    }
});

// Auto-refresh every 15 seconds
let refreshInterval = setInterval(async () => {
    try {
        const res = await fetch('ajax.php?action=stats');
        const data = await res.json();
        const inside = data.insideCount || 0;
        const guests = data.guestCount || 0;
        const members = inside - guests;
        const max = <?= $maxCapacity ?>;
        const pct = max > 0 ? ((inside / max) * 100).toFixed(1) : 0;
        
        document.getElementById('currentCount').textContent = inside.toLocaleString();
        document.getElementById('percentDisplay').textContent = pct + '%';
        document.getElementById('membersInside').textContent = members.toLocaleString();
        document.getElementById('guestsInside').textContent = guests.toLocaleString();
        
        // Update gauge
        const newPercent = Math.min(100, parseFloat(pct));
        gaugeFill.style.strokeDasharray = (newPercent / 100) * circumference + ' ' + circumference;
    } catch (e) {
        console.error('Refresh error:', e);
    }
}, 15000);
</script>

<?php include __DIR__ . '/footer.php'; ?>