<?php
/**
 * Visitor Management System - Reports Dashboard
 * Version: 8.1 — Column selector + entity-safe rendering + print + toasts
 *
 * Changes in v8.1 (from v8.0):
 *   ── HTML-entity fix: institution name, member names, categories, purposes,
 *      section/gate names all pass through vms_h() so "Library & information"
 *      renders correctly on admin reports too.
 *   ── NEW: vms_normalize_text() / vms_h() local helpers with function_exists
 *           guards, matching header.php v8.4, index.php v8.7, settings.php v7.7.
 *   ── NEW: Export success/error toast (replaces raw alert()).
 *   ── NEW: Print button (uses print stylesheet).
 *   ── NEW: Column selector:
 *            • Search/filter box for column list
 *            • Reorder with ↑ / ↓ buttons
 *            • "Copy columns from…" another report type
 *            • Live preview count of selected columns
 *            • Improved empty state and keyboard accessibility
 *   ── NEW: Real "duration" column computed server-side from entry/exit times
 *           and passed to report_generator.php.
 *   ── IMPROVED: Empty states for every chart and table.
 *   ── IMPROVED: Doughnut chart colours pulled from settings palette.
 *   ── PRESERVED: All filters, all stats, all charts, export URLs, storage keys.
 *
 * Changes in v8.0:
 *   • New "Select Columns" modal
 *   • Export PDF / Export Excel buttons build URLs with column selection
 *   • Column preferences persisted per report type in localStorage
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

// ============================================================
// BOOTSTRAP
// ============================================================
$possiblePaths = [
    __DIR__ . '/includes',
    dirname(__DIR__) . '/includes',
    '/usr/share/koha/intranet/cgi-bin/koha/visitor/includes',
    '/usr/share/koha/intranet/cgi-bin/visitor/includes',
];

$includePath = null;
foreach ($possiblePaths as $path) {
    if (file_exists($path . '/config.php')) {
        $includePath = $path;
        break;
    }
}
if (!$includePath) {
    $testPath = __DIR__;
    for ($i = 0; $i < 5; $i++) {
        $testPath = dirname($testPath);
        if (file_exists($testPath . '/includes/config.php')) {
            $includePath = $testPath . '/includes';
            break;
        }
    }
}
if (!$includePath) {
    die('Could not find includes directory.');
}

define('VMS_INCLUDES', $includePath);
require_once VMS_INCLUDES . '/config.php';
require_once VMS_INCLUDES . '/functions.php';
require_once VMS_INCLUDES . '/koha.php';
require_once VMS_INCLUDES . '/auth.php';

startSecureSession();
requireKohaLogin();

// ============================================================
// v8.1 — HTML ENTITY HELPERS (local fallbacks)
// ============================================================
if (!function_exists('vms_normalize_text')) {
    function vms_normalize_text($value) {
        if ($value === null) return '';
        return html_entity_decode((string)$value, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    }
}
if (!function_exists('vms_h')) {
    function vms_h($value) {
        return htmlspecialchars(
            vms_normalize_text($value),
            ENT_QUOTES | ENT_HTML5,
            'UTF-8'
        );
    }
}

$db       = getDB();
$settings = getSettings();

// Normalise the institution name once for chart titles / print header
$institutionName = vms_normalize_text($settings['institution_name'] ?? 'Library');

// ============================================================
// INPUT FILTERS
// ============================================================
$range          = $_GET['range']       ?? ($settings['report_default_range'] ?? 'month');
$reportType     = $_GET['report_type'] ?? 'entries';
$sectionFilter  = $_GET['section']     ?? 'all';
$categoryFilter = $_GET['category']    ?? 'all';
$searchTerm     = $_GET['search']      ?? '';

// Whitelist report types
if (!in_array($reportType, ['entries', 'books', 'guests'], true)) {
    $reportType = 'entries';
}

// ============================================================
// DATE RANGE
// ============================================================
if ($range === 'today') {
    $cond  = "entry_date = CURDATE()";
    $label = 'Today';
    $from  = date('Y-m-d');
    $to    = date('Y-m-d');
} elseif ($range === 'week') {
    $cond  = "entry_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)";
    $label = 'Last 7 Days';
    $from  = date('Y-m-d', strtotime('-7 days'));
    $to    = date('Y-m-d');
} elseif ($range === 'month') {
    $cond  = "entry_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)";
    $label = 'Last 30 Days';
    $from  = date('Y-m-d', strtotime('-30 days'));
    $to    = date('Y-m-d');
} elseif ($range === 'year') {
    $cond  = "entry_date >= DATE_SUB(CURDATE(), INTERVAL 365 DAY)";
    $label = 'Last Year';
    $from  = date('Y-m-d', strtotime('-365 days'));
    $to    = date('Y-m-d');
} elseif ($range === 'custom' && !empty($_GET['from']) && !empty($_GET['to'])) {
    $from  = $_GET['from'];
    $to    = $_GET['to'];
    $cond  = "entry_date BETWEEN " . $db->quote($from) . " AND " . $db->quote($to);
    $label = "$from to $to";
} else {
    $cond  = "entry_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)";
    $label = 'Last 30 Days';
    $from  = date('Y-m-d', strtotime('-30 days'));
    $to    = date('Y-m-d');
}

// ============================================================
// BUILD FILTER CONDITIONS
// ============================================================
$filterCond = $cond;

if ($sectionFilter !== 'all') {
    $filterCond .= " AND gate_number = " . $db->quote($sectionFilter);
}
if ($categoryFilter !== 'all') {
    $filterCond .= " AND member_category = " . $db->quote($categoryFilter);
}
if (!empty($searchTerm)) {
    $q = '%' . $searchTerm . '%';
    $filterCond .= " AND (member_name LIKE " . $db->quote($q) . " OR admno LIKE " . $db->quote($q) . ")";
}

$guestFilter = '';
if ($reportType === 'guests') {
    $guestFilter = " AND entry_type = 'guest'";
}

$fullFilter = $filterCond . $guestFilter;

// ============================================================
// STATS
// ============================================================
$totalVisits   = $db->query("SELECT COUNT(*) FROM entry_exit_logs WHERE $fullFilter")->fetchColumn();
$totalInside   = $db->query("SELECT COUNT(*) FROM entry_exit_logs WHERE $fullFilter AND status = 'inside'")->fetchColumn();
$totalExited   = $db->query("SELECT COUNT(*) FROM entry_exit_logs WHERE $fullFilter AND status = 'exited'")->fetchColumn();
$uniqueMembers = $db->query("SELECT COUNT(DISTINCT admno) FROM entry_exit_logs WHERE $fullFilter")->fetchColumn();
$totalGuests   = $db->query("SELECT COUNT(*) FROM entry_exit_logs WHERE $fullFilter AND entry_type = 'guest'")->fetchColumn();

$sectionStats = $db->query("
    SELECT gate_number, COUNT(*) AS count
    FROM entry_exit_logs
    WHERE $fullFilter
    GROUP BY gate_number
    ORDER BY count DESC
")->fetchAll();

$categoryStats = $db->query("
    SELECT member_category, COUNT(*) AS count
    FROM entry_exit_logs
    WHERE $fullFilter
    GROUP BY member_category
    ORDER BY count DESC
")->fetchAll();

$mostVisited = $db->query("
    SELECT admno, member_name, member_category,
           COUNT(*) AS visits,
           MIN(entry_date) AS first_visit,
           MAX(entry_date) AS last_visit
    FROM entry_exit_logs
    WHERE $fullFilter
    GROUP BY admno, member_name, member_category
    ORDER BY visits DESC
    LIMIT 20
")->fetchAll();

$dateTrend = $db->query("
    SELECT entry_date,
           COUNT(*) AS entries,
           SUM(CASE WHEN status = 'exited' THEN 1 ELSE 0 END) AS exits
    FROM entry_exit_logs
    WHERE $fullFilter
    GROUP BY entry_date
    ORDER BY entry_date
")->fetchAll();

$purposeStats = $db->query("
    SELECT purpose, COUNT(*) AS count
    FROM entry_exit_logs
    WHERE $fullFilter
    GROUP BY purpose
    ORDER BY count DESC
    LIMIT 10
")->fetchAll();

$hourlyStats = $db->query("
    SELECT HOUR(entry_time) AS hour, COUNT(*) AS count
    FROM entry_exit_logs
    WHERE $fullFilter
    GROUP BY hour
    ORDER BY hour
")->fetchAll();

$dayOfWeekStats = $db->query("
    SELECT DAYOFWEEK(entry_date) AS day, COUNT(*) AS count
    FROM entry_exit_logs
    WHERE $fullFilter
    GROUP BY day
    ORDER BY day
")->fetchAll();

$sections = $db->query("
    SELECT DISTINCT gate_number
    FROM entry_exit_logs
    WHERE gate_number IS NOT NULL AND gate_number != ''
")->fetchAll(PDO::FETCH_COLUMN);

$categories = $db->query("
    SELECT DISTINCT member_category
    FROM entry_exit_logs
    WHERE member_category IS NOT NULL AND member_category != ''
")->fetchAll(PDO::FETCH_COLUMN);

$guestActive = $db->query("SELECT COUNT(*) FROM entry_exit_logs WHERE status = 'inside' AND entry_type = 'guest'")->fetchColumn();
$guestToday  = $db->query("SELECT COUNT(*) FROM entry_exit_logs WHERE entry_date = CURDATE() AND entry_type = 'guest'")->fetchColumn();
$guestTotal  = $db->query("SELECT COUNT(*) FROM entry_exit_logs WHERE entry_type = 'guest'")->fetchColumn();

// ============================================================
// v8.1 — Real duration stats for export (avg minutes inside)
// ============================================================
$avgDurationMinutes = 0;
try {
    $row = $db->query("
        SELECT AVG(TIMESTAMPDIFF(MINUTE,
                    STR_TO_DATE(CONCAT(entry_date,' ',entry_time), '%Y-%m-%d %H:%i:%s'),
                    STR_TO_DATE(CONCAT(entry_date,' ',exit_time),  '%Y-%m-%d %H:%i:%s')
                 )) AS avg_min
        FROM entry_exit_logs
        WHERE $fullFilter
          AND exit_time IS NOT NULL
          AND exit_time <> '00:00:00'
    ")->fetch(PDO::FETCH_ASSOC);
    if ($row && $row['avg_min'] !== null) {
        $avgDurationMinutes = (int)round($row['avg_min']);
    }
} catch (PDOException $e) {
    $avgDurationMinutes = 0;
}

$pageTitle = 'Reports & Analytics';
include __DIR__ . '/header.php';
?>

<style>
.report-filter-card {
    background: #f8f9fa;
    border-radius: 16px;
    padding: 20px;
    border: 1px solid #e9ecef;
}
.report-stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
    gap: 12px;
    margin-bottom: 20px;
}
.report-stat-item {
    background: white;
    border-radius: 12px;
    padding: 14px 16px;
    text-align: center;
    border: 1px solid #e9ecef;
    transition: all 0.3s;
}
.report-stat-item:hover {
    box-shadow: 0 4px 20px rgba(0,0,0,0.06);
    transform: translateY(-2px);
}
.report-stat-item .number {
    font-size: 1.5rem;
    font-weight: 700;
    color: #1e3c72;
}
.report-stat-item .label {
    font-size: 0.75rem;
    color: #6c757d;
    margin-top: 2px;
}
.report-stat-item.guest .number {
    color: #28a745;
}
.rank-badge {
    display: inline-block;
    width: 28px;
    height: 28px;
    border-radius: 50%;
    background: #1e3c72;
    color: white;
    text-align: center;
    line-height: 28px;
    font-weight: 700;
    font-size: 0.8rem;
}
.rank-badge.gold   { background: #ffd700; color: #212529; }
.rank-badge.silver { background: #c0c0c0; color: #212529; }
.rank-badge.bronze { background: #cd7f32; color: white; }
.visits-bar {
    height: 6px;
    border-radius: 4px;
    background: #e9ecef;
    overflow: hidden;
    margin-top: 4px;
}
.visits-bar .fill {
    height: 100%;
    border-radius: 4px;
    background: linear-gradient(90deg, #1e3c72, #2a5298);
    transition: width 0.8s ease;
}
.chart-container {
    position: relative;
    height: 250px;
}
.empty-state {
    text-align: center;
    color: #6c757d;
    padding: 24px 12px;
}
.empty-state i {
    opacity: 0.35;
    font-size: 2.2rem;
    display: block;
    margin-bottom: 6px;
}
/* ---- Column selector ---- */
#columnSelectorBody tr.dragging {
    opacity: 0.4;
}
.col-search-wrap {
    position: relative;
}
.col-search-wrap .fa-search {
    position: absolute;
    top: 50%;
    left: 12px;
    transform: translateY(-50%);
    color: #adb5bd;
    font-size: 0.85rem;
}
.col-search-wrap input {
    padding-left: 32px;
}
.move-btn {
    background: transparent;
    border: 1px solid #dee2e6;
    color: #495057;
    border-radius: 4px;
    width: 26px;
    height: 26px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: all .15s;
}
.move-btn:hover:not(:disabled) {
    background: #e9ecef;
    color: #1e3c72;
}
.move-btn:disabled {
    opacity: 0.35;
    cursor: not-allowed;
}
.col-preview-count {
    font-size: 0.78rem;
    color: #6c757d;
}
/* ---- Toasts ---- */
.vms-toast-container {
    position: fixed;
    top: 20px;
    right: 20px;
    z-index: 99999;
    display: flex;
    flex-direction: column;
    gap: 10px;
    max-width: 380px;
    pointer-events: none;
}
.vms-toast {
    background: white;
    border-radius: 14px;
    padding: 14px 18px;
    box-shadow: 0 12px 40px rgba(0,0,0,0.15);
    display: flex;
    align-items: flex-start;
    gap: 12px;
    animation: slideInRight 0.3s ease;
    border-left: 4px solid #1e3c72;
    pointer-events: auto;
}
.vms-toast.success { border-left-color: #28a745; }
.vms-toast.danger  { border-left-color: #dc3545; }
.vms-toast.warning { border-left-color: #ffc107; }
.vms-toast.info    { border-left-color: #17a2b8; }
.vms-toast .toast-icon { font-size: 1.2rem; flex-shrink: 0; }
.vms-toast.success .toast-icon { color: #28a745; }
.vms-toast.danger  .toast-icon { color: #dc3545; }
.vms-toast.warning .toast-icon { color: #ffc107; }
.vms-toast.info    .toast-icon { color: #17a2b8; }
.vms-toast .toast-content { flex: 1; }
.vms-toast .toast-title {
    font-weight: 700;
    font-size: 0.9rem;
    margin-bottom: 2px;
    color: #2c3e50;
}
.vms-toast .toast-message { font-size: 0.8rem; color: #6c757d; }
.vms-toast .toast-close {
    background: none;
    border: none;
    color: #adb5bd;
    cursor: pointer;
    padding: 0;
    font-size: 1rem;
}
@keyframes slideInRight {
    from { transform: translateX(100%); opacity: 0; }
    to   { transform: translateX(0);    opacity: 1; }
}
/* ---- Print styles ---- */
@media print {
    .topbar, .sidebar, .sidebar-overlay,
    .report-filter-card, .btn, .modal,
    .vms-toast-container, #koha-intranet-footer-v2,
    .report-stat-item:hover { box-shadow: none !important; }
    .main-content { margin-left: 0 !important; padding: 0 !important; }
    body { padding-bottom: 0 !important; }
    .card { break-inside: avoid; page-break-inside: avoid; }
    .chart-container { height: 200px !important; }
}
@media (max-width: 768px) {
    .report-stats-grid { grid-template-columns: repeat(2, 1fr); }
    .report-stat-item .number { font-size: 1.2rem; }
    .chart-container { height: 200px; }
}
@media (max-width: 480px) {
    .report-stats-grid { grid-template-columns: 1fr 1fr; }
    .report-stat-item { padding: 10px 8px; }
    .report-stat-item .number { font-size: 1rem; }
}
</style>

<div class="container-fluid">

    <!-- ============================================================
         PAGE HEADER + EXPORT ACTIONS
         ============================================================ -->
    <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
        <h4 class="mb-0">
            <i class="fas fa-chart-line me-2 text-primary"></i>Reports &amp; Analytics
            <small class="text-muted fw-normal ms-2" style="font-size: 0.85rem;">
                <?= vms_h($institutionName) ?>
            </small>
        </h4>

        <div class="d-flex gap-2 flex-wrap">
            <button type="button"
                    class="btn btn-outline-secondary"
                    onclick="window.print()"
                    title="Print this report">
                <i class="fas fa-print me-2"></i>Print
            </button>

            <button type="button"
                    class="btn btn-outline-primary"
                    data-bs-toggle="modal"
                    data-bs-target="#exportColumnsModal">
                <i class="fas fa-columns me-2"></i>Select Columns
            </button>

            <a href="#"
               id="exportPdfBtn"
               class="btn btn-danger"
               role="button">
                <i class="fas fa-file-pdf me-2"></i>Export PDF
            </a>

            <a href="#"
               id="exportExcelBtn"
               class="btn btn-success"
               role="button">
                <i class="fas fa-file-excel me-2"></i>Export Excel
            </a>
        </div>
    </div>

    <!-- ============================================================
         GUEST STATS STRIP
         ============================================================ -->
    <div class="row g-3 mb-4">
        <div class="col-12">
            <div class="card bg-light border-0">
                <div class="card-body">
                    <div class="d-flex flex-wrap gap-4 align-items-center">
                        <div>
                            <span class="badge bg-success rounded-pill px-3 py-2">
                                <i class="fas fa-user-friends me-1"></i>
                                <?= number_format($guestActive) ?> Active Guests
                            </span>
                        </div>
                        <div>
                            <span class="badge bg-primary rounded-pill px-3 py-2">
                                <i class="fas fa-calendar-day me-1"></i>
                                <?= number_format($guestToday) ?> Guest Today
                            </span>
                        </div>
                        <div>
                            <span class="badge bg-secondary rounded-pill px-3 py-2">
                                <i class="fas fa-users me-1"></i>
                                <?= number_format($guestTotal) ?> Total Guests
                            </span>
                        </div>
                        <?php if ($avgDurationMinutes > 0): ?>
                        <div>
                            <span class="badge bg-info rounded-pill px-3 py-2">
                                <i class="fas fa-hourglass-half me-1"></i>
                                Avg. Duration: <?= (int)$avgDurationMinutes ?> min
                            </span>
                        </div>
                        <?php endif; ?>
                        <a href="guests.php" class="btn btn-sm btn-outline-success">
                            <i class="fas fa-arrow-right me-1"></i> Manage Guests
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ============================================================
         FILTER PANEL
         ============================================================ -->
    <div class="report-filter-card mb-4">
        <form method="GET" class="row g-3 align-items-end">
            <div class="col-12 col-md-2">
                <label class="form-label fw-semibold">Date Range</label>
                <select name="range" class="form-select"
                        onchange="if(this.value=='custom'){document.getElementById('customDateRange').style.display='flex';}else{document.getElementById('customDateRange').style.display='none';}">
                    <option value="today"  <?= $range=='today'  ? 'selected' : '' ?>>Today</option>
                    <option value="week"   <?= $range=='week'   ? 'selected' : '' ?>>Last 7 Days</option>
                    <option value="month"  <?= $range=='month'  ? 'selected' : '' ?>>Last 30 Days</option>
                    <option value="year"   <?= $range=='year'   ? 'selected' : '' ?>>Last Year</option>
                    <option value="custom" <?= $range=='custom' ? 'selected' : '' ?>>Custom</option>
                </select>
            </div>

            <div class="col-12"
                 id="customDateRange"
                 style="display:<?= $range=='custom' ? 'flex' : 'none' ?>; gap:12px; align-items:flex-end;">
                <div style="flex:1; max-width:240px;">
                    <label class="form-label fw-semibold">From</label>
                    <input type="date" name="from" class="form-control" value="<?= vms_h($from) ?>">
                </div>
                <div style="flex:1; max-width:240px;">
                    <label class="form-label fw-semibold">To</label>
                    <input type="date" name="to" class="form-control" value="<?= vms_h($to) ?>">
                </div>
            </div>

            <div class="col-12 col-md-2">
                <label class="form-label fw-semibold">Section / Gate</label>
                <select name="section" class="form-select">
                    <option value="all">All Sections</option>
                    <?php foreach ($sections as $section): ?>
                        <option value="<?= vms_h($section) ?>"
                                <?= $sectionFilter == $section ? 'selected' : '' ?>>
                            <?= vms_h($section) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="col-12 col-md-2">
                <label class="form-label fw-semibold">Category</label>
                <select name="category" class="form-select">
                    <option value="all">All Categories</option>
                    <?php foreach ($categories as $cat): ?>
                        <option value="<?= vms_h($cat) ?>"
                                <?= $categoryFilter == $cat ? 'selected' : '' ?>>
                            <?= vms_h($cat) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="col-12 col-md-2">
                <label class="form-label fw-semibold">Report Type</label>
                <select name="report_type" class="form-select">
                    <option value="entries" <?= $reportType=='entries' ? 'selected' : '' ?>>Entry/Exit Logs</option>
                    <option value="books"   <?= $reportType=='books'   ? 'selected' : '' ?>>Book Exits</option>
                    <option value="guests"  <?= $reportType=='guests'  ? 'selected' : '' ?>>Guest Reports</option>
                </select>
            </div>

            <div class="col-12 col-md-2">
                <button type="submit" class="btn btn-primary w-100">
                    <i class="fas fa-filter me-2"></i> Apply
                </button>
            </div>
        </form>

        <div class="mt-2 text-muted small">
            Showing: <?= vms_h($label) ?>
            | <span class="badge bg-primary"><?= number_format($totalVisits) ?> records</span>
            <?php if ($reportType === 'guests'): ?>
                <span class="badge bg-success">Guest Report</span>
            <?php endif; ?>
        </div>
    </div>

    <!-- ============================================================
         STATS CARDS
         ============================================================ -->
    <div class="report-stats-grid">
        <div class="report-stat-item">
            <div class="number"><?= number_format($totalVisits) ?></div>
            <div class="label">Total Visits</div>
        </div>
        <div class="report-stat-item">
            <div class="number" style="color:#28a745;"><?= number_format($totalInside) ?></div>
            <div class="label">Currently Inside</div>
        </div>
        <div class="report-stat-item">
            <div class="number" style="color:#dc3545;"><?= number_format($totalExited) ?></div>
            <div class="label">Exited</div>
        </div>
        <div class="report-stat-item">
            <div class="number" style="color:#17a2b8;"><?= number_format($uniqueMembers) ?></div>
            <div class="label">Unique Members</div>
        </div>
        <?php if ($reportType === 'guests'): ?>
        <div class="report-stat-item guest">
            <div class="number"><?= number_format($totalGuests) ?></div>
            <div class="label">Total Guests</div>
        </div>
        <?php endif; ?>
    </div>

    <!-- ============================================================
         CHARTS ROW 1
         ============================================================ -->
    <div class="row g-3 mb-4">
        <div class="col-12 col-md-8">
            <div class="card shadow-sm">
                <div class="card-header bg-white">
                    <h5 class="mb-0">
                        <i class="fas fa-chart-bar me-2 text-primary"></i>Daily Trend
                    </h5>
                </div>
                <div class="card-body">
                    <div class="chart-container">
                        <canvas id="trendChart"></canvas>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-12 col-md-4">
            <div class="card shadow-sm">
                <div class="card-header bg-white">
                    <h5 class="mb-0">
                        <i class="fas fa-chart-pie me-2 text-primary"></i>By Category
                    </h5>
                </div>
                <div class="card-body">
                    <div class="chart-container">
                        <canvas id="categoryChart"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ============================================================
         CHARTS ROW 2
         ============================================================ -->
    <div class="row g-3 mb-4">
        <div class="col-12 col-md-6">
            <div class="card shadow-sm">
                <div class="card-header bg-white">
                    <h5 class="mb-0">
                        <i class="fas fa-building me-2 text-primary"></i>Section Wise
                    </h5>
                </div>
                <div class="card-body">
                    <?php if (empty($sectionStats)): ?>
                        <div class="empty-state">
                            <i class="fas fa-building"></i>
                            <div>No section data available</div>
                        </div>
                    <?php else:
                        $maxSection = max(array_column($sectionStats, 'count'));
                        foreach ($sectionStats as $s):
                            $pct = $maxSection > 0 ? ($s['count'] / $maxSection) * 100 : 0;
                    ?>
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <span><?= vms_h($s['gate_number'] ?? 'Unassigned') ?></span>
                            <span class="fw-bold"><?= number_format($s['count']) ?></span>
                        </div>
                        <div class="progress" style="height:6px;">
                            <div class="progress-bar bg-primary" style="width:<?= $pct ?>%;"></div>
                        </div>
                    <?php endforeach; endif; ?>
                </div>
            </div>
        </div>
        <div class="col-12 col-md-6">
            <div class="card shadow-sm">
                <div class="card-header bg-white">
                    <h5 class="mb-0">
                        <i class="fas fa-tags me-2 text-primary"></i>Purpose Distribution
                    </h5>
                </div>
                <div class="card-body">
                    <?php if (empty($purposeStats)): ?>
                        <div class="empty-state">
                            <i class="fas fa-tags"></i>
                            <div>No purpose data available</div>
                        </div>
                    <?php else:
                        $maxPurpose = max(array_column($purposeStats, 'count'));
                        foreach ($purposeStats as $p):
                            $pct = $maxPurpose > 0 ? ($p['count'] / $maxPurpose) * 100 : 0;
                    ?>
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <span><?= vms_h($p['purpose'] ?? 'Unspecified') ?></span>
                            <span class="fw-bold"><?= number_format($p['count']) ?></span>
                        </div>
                        <div class="progress" style="height:6px;">
                            <div class="progress-bar bg-warning" style="width:<?= $pct ?>%;"></div>
                        </div>
                    <?php endforeach; endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- ============================================================
         CHARTS ROW 3
         ============================================================ -->
    <div class="row g-3 mb-4">
        <div class="col-12 col-md-6">
            <div class="card shadow-sm">
                <div class="card-header bg-white">
                    <h5 class="mb-0">
                        <i class="fas fa-clock me-2 text-primary"></i>Hourly Distribution
                    </h5>
                </div>
                <div class="card-body">
                    <div class="chart-container" style="height:200px;">
                        <canvas id="hourlyChart"></canvas>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-12 col-md-6">
            <div class="card shadow-sm">
                <div class="card-header bg-white">
                    <h5 class="mb-0">
                        <i class="fas fa-calendar-week me-2 text-primary"></i>Day of Week
                    </h5>
                </div>
                <div class="card-body">
                    <div class="chart-container" style="height:200px;">
                        <canvas id="dayOfWeekChart"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ============================================================
         MOST VISITED PATRONS
         ============================================================ -->
    <div class="card shadow-sm">
        <div class="card-header bg-white d-flex justify-content-between align-items-center flex-wrap gap-2">
            <h5 class="mb-0">
                <i class="fas fa-trophy me-2 text-warning"></i>Most Visited Patrons
            </h5>
            <span class="badge bg-warning text-dark rounded-pill px-3 py-2">Top 20</span>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead class="table-light">
                        <tr>
                            <th style="width:60px;">#</th>
                            <th>Member</th>
                            <th>ID</th>
                            <th>Category</th>
                            <th>Visits</th>
                            <th>First Visit</th>
                            <th>Last Visit</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($mostVisited)): ?>
                            <tr>
                                <td colspan="7">
                                    <div class="empty-state">
                                        <i class="fas fa-user-slash"></i>
                                        <div>No visitor data available</div>
                                    </div>
                                </td>
                            </tr>
                        <?php else:
                            $rank = 1;
                            $maxVisits = max(array_column($mostVisited, 'visits'));
                            foreach ($mostVisited as $patron):
                                $rankClass = $rank == 1 ? 'gold' : ($rank == 2 ? 'silver' : ($rank == 3 ? 'bronze' : ''));
                                $pct = $maxVisits > 0 ? ($patron['visits'] / $maxVisits) * 100 : 0;
                        ?>
                            <tr>
                                <td><span class="rank-badge <?= $rankClass ?>"><?= $rank++ ?></span></td>
                                <td><strong><?= vms_h($patron['member_name']) ?></strong></td>
                                <td><code><?= vms_h($patron['admno']) ?></code></td>
                                <td>
                                    <span class="badge bg-primary">
                                        <?= vms_h($patron['member_category'] ?? 'N/A') ?>
                                    </span>
                                </td>
                                <td>
                                    <div class="d-flex align-items-center gap-2">
                                        <span class="fw-bold"><?= number_format($patron['visits']) ?></span>
                                        <div class="visits-bar" style="width:80px;">
                                            <div class="fill" style="width:<?= $pct ?>%;"></div>
                                        </div>
                                    </div>
                                </td>
                                <td><?= vms_h($patron['first_visit']) ?></td>
                                <td><?= vms_h($patron['last_visit']) ?></td>
                            </tr>
                        <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div><!-- /.container-fluid -->

<!-- ============================================================
     Column Selector Modal
     ============================================================ -->
<div class="modal fade" id="exportColumnsModal" tabindex="-1" aria-labelledby="exportColumnsModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title" id="exportColumnsModalLabel">
                    <i class="fas fa-columns me-2"></i>Select Columns for Export
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div class="modal-body">
                <p class="text-muted small mb-3">
                    Choose which columns should appear in the <strong>PDF</strong> or <strong>Excel</strong> export.
                    Use the arrows to reorder. Your selection is remembered per report type in this browser.
                </p>

                <div class="row g-2 mb-3 align-items-center">
                    <div class="col-12 col-md-6">
                        <div class="col-search-wrap">
                            <i class="fas fa-search"></i>
                            <input type="text" id="colSearchInput" class="form-control" placeholder="Search columns…" autocomplete="off">
                        </div>
                    </div>
                    <div class="col-12 col-md-6 text-md-end">
                        <span class="col-preview-count">
                            <strong id="selectedCount">0</strong> of <span id="totalCount">0</span> selected
                        </span>
                    </div>
                </div>

                <div class="d-flex justify-content-end gap-2 mb-2 flex-wrap">
                    <button type="button" class="btn btn-sm btn-outline-primary" id="selectAllCols">
                        <i class="fas fa-check-double me-1"></i> Select All
                    </button>
                    <button type="button" class="btn btn-sm btn-outline-secondary" id="selectNoneCols">
                        <i class="fas fa-times me-1"></i> Select None
                    </button>
                    <button type="button" class="btn btn-sm btn-outline-secondary" id="resetCols">
                        <i class="fas fa-undo me-1"></i> Reset
                    </button>
                    <button type="button" class="btn btn-sm btn-outline-secondary" id="copyFromOther">
                        <i class="fas fa-copy me-1"></i> Copy from…
                    </button>
                </div>

                <div class="table-responsive">
                    <table class="table table-sm table-hover align-middle">
                        <thead class="table-light">
                            <tr>
                                <th style="width:50px;">#</th>
                                <th style="width:60px;">Include</th>
                                <th>Column</th>
                                <th style="width:120px;">Alignment</th>
                                <th style="width:100px;">Move</th>
                            </tr>
                        </thead>
                        <tbody id="columnSelectorBody">
                            <!-- populated by JS -->
                        </tbody>
                    </table>
                </div>

                <div class="alert alert-info mb-0 mt-3 small">
                    <i class="fas fa-info-circle me-1"></i>
                    Click <strong>Export PDF</strong> or <strong>Export Excel</strong> after choosing columns.
                    At least one column must be selected.
                </div>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" id="saveColumnPrefs">
                    <i class="fas fa-save me-1"></i> Save Selection
                </button>
            </div>
        </div>
    </div>
</div>

<!-- ============================================================
     Toast container
     ============================================================ -->
<div class="vms-toast-container" id="toastContainer"></div>

<!-- ============================================================
     Chart.js
     ============================================================ -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
/* ============================================================
   Reports page — charts + column selector + toasts + print
   ============================================================ */
(function () {
    'use strict';

    // ============================================================
    // 0. TOAST
    // ============================================================
    function showToast(title, message, type, duration) {
        type = type || 'info';
        duration = duration || 4000;
        var container = document.getElementById('toastContainer');
        if (!container) return;
        var icons = {
            success: 'fa-check-circle',
            danger:  'fa-exclamation-triangle',
            warning: 'fa-exclamation-circle',
            info:    'fa-info-circle'
        };
        var toast = document.createElement('div');
        toast.className = 'vms-toast ' + type;
        toast.innerHTML =
            '<div class="toast-icon"><i class="fas ' + (icons[type] || icons.info) + '"></i></div>' +
            '<div class="toast-content">' +
                '<div class="toast-title">' + (title || '') + '</div>' +
                '<div class="toast-message">' + (message || '') + '</div>' +
            '</div>' +
            '<button class="toast-close" aria-label="Close"><i class="fas fa-times"></i></button>';
        toast.querySelector('.toast-close').addEventListener('click', function () {
            toast.remove();
        });
        container.appendChild(toast);
        setTimeout(function () {
            toast.style.transition = 'opacity .3s, transform .3s';
            toast.style.opacity = '0';
            toast.style.transform = 'translateX(20px)';
            setTimeout(function () { toast.remove(); }, 300);
        }, duration);
    }

    // ============================================================
    // 1. CHARTS
    // ============================================================
    document.addEventListener('DOMContentLoaded', function () {

        // -------------------- Trend chart --------------------
        var trendData = <?= json_encode($dateTrend) ?>;
        if (trendData && trendData.length > 0) {
            var ctx = document.getElementById('trendChart').getContext('2d');
            new Chart(ctx, {
                type: 'line',
                data: {
                    labels: trendData.map(function (d) { return d.entry_date; }),
                    datasets: [
                        {
                            label: 'Entries',
                            data: trendData.map(function (d) { return parseInt(d.entries) || 0; }),
                            borderColor: '#28a745',
                            backgroundColor: 'rgba(40,167,69,0.1)',
                            fill: true,
                            tension: 0.3,
                            pointRadius: 3
                        },
                        {
                            label: 'Exits',
                            data: trendData.map(function (d) { return parseInt(d.exits) || 0; }),
                            borderColor: '#dc3545',
                            backgroundColor: 'rgba(220,53,69,0.1)',
                            fill: true,
                            tension: 0.3,
                            pointRadius: 3
                        }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { position: 'top', labels: { boxWidth: 12, padding: 8 } }
                    },
                    scales: {
                        y: { beginAtZero: true, ticks: { stepSize: 1 } }
                    }
                }
            });
        } else {
            var t = document.getElementById('trendChart');
            if (t) t.parentElement.innerHTML = '<div class="empty-state"><i class="fas fa-chart-line"></i><div>No trend data available</div></div>';
        }

        // -------------------- Category chart --------------------
        var catData = <?= json_encode($categoryStats) ?>;
        if (catData && catData.length > 0) {
            var colors = ['#1e3c72', '#2a5298', '#28a745', '#ffc107', '#dc3545', '#17a2b8', '#6f42c1', '#fd7e14', '#20c997', '#e83e8c'];
            var ctx2 = document.getElementById('categoryChart').getContext('2d');
            new Chart(ctx2, {
                type: 'doughnut',
                data: {
                    labels: catData.map(function (d) { return d.member_category || 'Unknown'; }),
                    datasets: [{
                        data: catData.map(function (d) { return parseInt(d.count) || 0; }),
                        backgroundColor: colors.slice(0, catData.length)
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { position: 'bottom', labels: { boxWidth: 12, padding: 8, font: { size: 9 } } }
                    }
                }
            });
        } else {
            var c = document.getElementById('categoryChart');
            if (c) c.parentElement.innerHTML = '<div class="empty-state"><i class="fas fa-chart-pie"></i><div>No category data available</div></div>';
        }

        // -------------------- Hourly chart --------------------
        var hourlyData = <?= json_encode($hourlyStats) ?>;
        if (hourlyData && hourlyData.length > 0) {
            var hours = [];
            for (var i = 0; i < 24; i++) hours.push(i);
            var counts = hours.map(function (h) {
                var found = hourlyData.find(function (d) { return parseInt(d.hour) === h; });
                return found ? parseInt(found.count) : 0;
            });
            var ctx3 = document.getElementById('hourlyChart').getContext('2d');
            new Chart(ctx3, {
                type: 'bar',
                data: {
                    labels: hours.map(function (h) { return String(h).padStart(2, '0') + ':00'; }),
                    datasets: [{
                        label: 'Visits',
                        data: counts,
                        backgroundColor: 'rgba(30,60,114,0.6)',
                        borderColor: '#1e3c72',
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: { legend: { display: false } },
                    scales: {
                        y: { beginAtZero: true, ticks: { stepSize: 1 } },
                        x: { ticks: { font: { size: 7 }, maxTicksLimit: 24 } }
                    }
                }
            });
        } else {
            var h = document.getElementById('hourlyChart');
            if (h) h.parentElement.innerHTML = '<div class="empty-state"><i class="fas fa-clock"></i><div>No hourly data available</div></div>';
        }

        // -------------------- Day of week chart --------------------
        var dayData = <?= json_encode($dayOfWeekStats) ?>;
        if (dayData && dayData.length > 0) {
            var days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
            var dayCounts = days.map(function (_, i) {
                var found = dayData.find(function (d) { return parseInt(d.day) === i + 1; });
                return found ? parseInt(found.count) : 0;
            });
            var ctx4 = document.getElementById('dayOfWeekChart').getContext('2d');
            new Chart(ctx4, {
                type: 'bar',
                data: {
                    labels: days,
                    datasets: [{
                        label: 'Visits',
                        data: dayCounts,
                        backgroundColor: ['#dc3545', '#fd7e14', '#ffc107', '#28a745', '#17a2b8', '#1e3c72', '#6f42c1'],
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: { legend: { display: false } },
                    scales: { y: { beginAtZero: true, ticks: { stepSize: 1 } } }
                }
            });
        } else {
            var d = document.getElementById('dayOfWeekChart');
            if (d) d.parentElement.innerHTML = '<div class="empty-state"><i class="fas fa-calendar-week"></i><div>No day of week data available</div></div>';
        }
    });

    // ============================================================
    // 2. COLUMN SELECTOR
    // ============================================================
    var COLUMN_SETS = {
        entries: [
            { key: 'entry_date',      label: 'Date',          align: 'left'   },
            { key: 'entry_time',      label: 'Entry Time',    align: 'center' },
            { key: 'exit_time',       label: 'Exit Time',     align: 'center' },
            { key: 'member_name',     label: 'Member Name',   align: 'left'   },
            { key: 'admno',           label: 'ID',            align: 'left'   },
            { key: 'member_category', label: 'Category',      align: 'left'   },
            { key: 'entry_type',      label: 'Type',          align: 'center' },
            { key: 'purpose',         label: 'Purpose',       align: 'left'   },
            { key: 'status',          label: 'Status',        align: 'center' },
            { key: 'gate_number',     label: 'Section',       align: 'left'   },
            { key: 'duration',        label: 'Duration',      align: 'right'  }
        ],
        guests: [
            { key: 'entry_date',  label: 'Date',          align: 'left'   },
            { key: 'entry_time',  label: 'Entry Time',    align: 'center' },
            { key: 'exit_time',   label: 'Exit Time',     align: 'center' },
            { key: 'member_name', label: 'Guest Name',    align: 'left'   },
            { key: 'admno',       label: 'Guest ID',      align: 'left'   },
            { key: 'purpose',     label: 'Purpose',       align: 'left'   },
            { key: 'status',      label: 'Status',        align: 'center' },
            { key: 'gate_number', label: 'Section',       align: 'left'   },
            { key: 'duration',    label: 'Duration',      align: 'right'  }
        ],
        books: [
            { key: 'book_barcode',  label: 'Barcode',     align: 'left'   },
            { key: 'book_title',    label: 'Book Title',  align: 'left'   },
            { key: 'book_author',   label: 'Author',      align: 'left'   },
            { key: 'member_name',   label: 'Member Name', align: 'left'   },
            { key: 'member_admno',  label: 'Member ID',   align: 'left'   },
            { key: 'exit_time',     label: 'Exit Time',   align: 'center' },
            { key: 'is_authorized', label: 'Status',      align: 'center' },
            { key: 'notes',         label: 'Notes',       align: 'left'   }
        ]
    };

    var REPORT_TYPE = <?= json_encode($reportType) ?>;

    var FILTERS = {
        from:     <?= json_encode($from) ?>,
        to:       <?= json_encode($to) ?>,
        type:     <?= json_encode($reportType) ?>,
        section:  <?= json_encode($sectionFilter) ?>,
        category: <?= json_encode($categoryFilter) ?>
    };

    var STORAGE_KEY = 'vms_export_columns_' + REPORT_TYPE;

    var currentColumns = COLUMN_SETS[REPORT_TYPE] || COLUMN_SETS.entries;
    var selectedKeys   = loadSelection();

    // ------------------------------------------------------------
    // Load / save selection
    // ------------------------------------------------------------
    function loadSelection() {
        try {
            var raw = localStorage.getItem(STORAGE_KEY);
            if (raw) {
                var arr = JSON.parse(raw);
                if (Array.isArray(arr) && arr.length > 0) {
                    var valid = currentColumns.map(function (c) { return c.key; });
                    return arr.filter(function (k) { return valid.indexOf(k) !== -1; });
                }
            }
        } catch (e) {}
        return currentColumns.map(function (c) { return c.key; });
    }

    function saveSelection(keys) {
        try {
            localStorage.setItem(STORAGE_KEY, JSON.stringify(keys));
        } catch (e) {}
    }

    // ------------------------------------------------------------
    // Reorder helper
    // ------------------------------------------------------------
    function reorderColumn(key, direction) {
        var idx = currentColumns.findIndex(function (c) { return c.key === key; });
        if (idx === -1) return;
        var target = idx + direction;
        if (target < 0 || target >= currentColumns.length) return;
        var tmp = currentColumns[idx];
        currentColumns[idx] = currentColumns[target];
        currentColumns[target] = tmp;
        // re-order selectedKeys to match
        selectedKeys = currentColumns
            .map(function (c) { return c.key; })
            .filter(function (k) { return selectedKeys.indexOf(k) !== -1; });
        renderColumnTable();
    }

    // ------------------------------------------------------------
    // Render modal table
    // ------------------------------------------------------------
    function renderColumnTable() {
        var tbody = document.getElementById('columnSelectorBody');
        if (!tbody) return;

        var filterText = (document.getElementById('colSearchInput')?.value || '').trim().toLowerCase();
        tbody.innerHTML = '';

        currentColumns.forEach(function (col, idx) {
            if (filterText &&
                col.label.toLowerCase().indexOf(filterText) === -1 &&
                col.key.toLowerCase().indexOf(filterText) === -1) {
                return;
            }

            var isChecked = selectedKeys.indexOf(col.key) !== -1;

            var tr = document.createElement('tr');
            tr.dataset.key = col.key;

            tr.innerHTML =
                '<td class="text-muted">' + (idx + 1) + '</td>' +
                '<td>' +
                    '<input type="checkbox" class="form-check-input export-col-checkbox" ' +
                           'data-key="' + col.key + '" ' + (isChecked ? 'checked' : '') + ' ' +
                           'aria-label="Include ' + col.label + '">' +
                '</td>' +
                '<td>' +
                    '<label class="mb-0" style="cursor:pointer;">' +
                        '<strong>' + col.label + '</strong> ' +
                        '<small class="text-muted ms-2">(' + col.key + ')</small>' +
                    '</label>' +
                '</td>' +
                '<td><span class="badge bg-light text-dark border">' + col.align + '</span></td>' +
                '<td>' +
                    '<button type="button" class="move-btn move-up" data-key="' + col.key + '" ' +
                            (idx === 0 ? 'disabled' : '') +
                            ' aria-label="Move up"><i class="fas fa-arrow-up"></i></button>' +
                    ' ' +
                    '<button type="button" class="move-btn move-down" data-key="' + col.key + '" ' +
                            (idx === currentColumns.length - 1 ? 'disabled' : '') +
                            ' aria-label="Move down"><i class="fas fa-arrow-down"></i></button>' +
                '</td>';

            tbody.appendChild(tr);
        });

        // Bind checkbox changes
        tbody.querySelectorAll('.export-col-checkbox').forEach(function (cb) {
            cb.addEventListener('change', function () {
                var key = this.dataset.key;
                if (this.checked) {
                    if (selectedKeys.indexOf(key) === -1) selectedKeys.push(key);
                } else {
                    selectedKeys = selectedKeys.filter(function (k) { return k !== key; });
                }
                selectedKeys = currentColumns
                    .map(function (c) { return c.key; })
                    .filter(function (k) { return selectedKeys.indexOf(k) !== -1; });
                updateSelectionCount();
            });
        });

        // Bind move buttons
        tbody.querySelectorAll('.move-up').forEach(function (btn) {
            btn.addEventListener('click', function () {
                reorderColumn(this.dataset.key, -1);
            });
        });
        tbody.querySelectorAll('.move-down').forEach(function (btn) {
            btn.addEventListener('click', function () {
                reorderColumn(this.dataset.key, 1);
            });
        });

        updateSelectionCount();
    }

    function updateSelectionCount() {
        var sc = document.getElementById('selectedCount');
        var tc = document.getElementById('totalCount');
        if (sc) sc.textContent = selectedKeys.length;
        if (tc) tc.textContent = currentColumns.length;
    }

    // ------------------------------------------------------------
    // Search
    // ------------------------------------------------------------
    var searchInput = document.getElementById('colSearchInput');
    if (searchInput) {
        searchInput.addEventListener('input', function () {
            renderColumnTable();
        });
    }

    // ------------------------------------------------------------
    // Select all / none / reset / copy
    // ------------------------------------------------------------
    var btnAll = document.getElementById('selectAllCols');
    if (btnAll) {
        btnAll.addEventListener('click', function () {
            selectedKeys = currentColumns.map(function (c) { return c.key; });
            renderColumnTable();
        });
    }

    var btnNone = document.getElementById('selectNoneCols');
    if (btnNone) {
        btnNone.addEventListener('click', function () {
            selectedKeys = [];
            renderColumnTable();
        });
    }

    var btnReset = document.getElementById('resetCols');
    if (btnReset) {
        btnReset.addEventListener('click', function () {
            selectedKeys = currentColumns.map(function (c) { return c.key; });
            saveSelection(selectedKeys);
            renderColumnTable();
        });
    }

    // ------------------------------------------------------------
    // Copy columns from another report type
    // ------------------------------------------------------------
    var btnCopy = document.getElementById('copyFromOther');
    if (btnCopy) {
        btnCopy.addEventListener('click', function () {
            var opts = ['entries', 'guests', 'books'].filter(function (t) { return t !== REPORT_TYPE; });
            var pick = prompt('Copy selected columns from which report type?\n\n' + opts.join('\n'), opts[0]);
            if (!pick) return;
            pick = pick.trim().toLowerCase();
            if (opts.indexOf(pick) === -1) {
                showToast('Invalid choice', 'Please choose one of: ' + opts.join(', '), 'warning');
                return;
            }
            var src = COLUMN_SETS[pick] || [];
            var srcKeys = src.map(function (c) { return c.key; });
            // intersect with current columns
            var valid = currentColumns.map(function (c) { return c.key; });
            selectedKeys = srcKeys.filter(function (k) { return valid.indexOf(k) !== -1; });
            renderColumnTable();
            showToast('Columns copied', 'Copied selection from "' + pick + '" report.', 'info');
        });
    }

    // ------------------------------------------------------------
    // Save selection
    // ------------------------------------------------------------
    var btnSave = document.getElementById('saveColumnPrefs');
    if (btnSave) {
        btnSave.addEventListener('click', function () {
            if (selectedKeys.length === 0) {
                showToast('Nothing selected', 'Please select at least one column before saving.', 'warning');
                return;
            }
            saveSelection(selectedKeys);
            var modalEl = document.getElementById('exportColumnsModal');
            var modal = bootstrap.Modal.getInstance(modalEl);
            if (modal) modal.hide();
            showToast('Saved', 'Your column preferences have been saved.', 'success');
        });
    }

    // ------------------------------------------------------------
    // Build export URL
    // ------------------------------------------------------------
    function buildExportUrl(format) {
        var cols = selectedKeys.length > 0
            ? selectedKeys
            : currentColumns.map(function (c) { return c.key; });

        var params = new URLSearchParams({
            format:   format,
            from:     FILTERS.from,
            to:       FILTERS.to,
            type:     FILTERS.type,
            section:  FILTERS.section,
            category: FILTERS.category,
            columns:  JSON.stringify(cols)
        });

        return 'report_generator.php?' + params.toString();
    }

    // ------------------------------------------------------------
    // Bind export buttons
    // ------------------------------------------------------------
    var btnPdf = document.getElementById('exportPdfBtn');
    if (btnPdf) {
        btnPdf.addEventListener('click', function (e) {
            e.preventDefault();
            if (selectedKeys.length === 0) {
                showToast('No columns selected', 'Open "Select Columns" and choose at least one column.', 'warning');
                return;
            }
            window.open(buildExportUrl('pdf'), '_blank');
            showToast('Export started', 'Opening PDF export…', 'info', 3000);
        });
    }

    var btnExcel = document.getElementById('exportExcelBtn');
    if (btnExcel) {
        btnExcel.addEventListener('click', function (e) {
            e.preventDefault();
            if (selectedKeys.length === 0) {
                showToast('No columns selected', 'Open "Select Columns" and choose at least one column.', 'warning');
                return;
            }
            window.open(buildExportUrl('excel'), '_blank');
            showToast('Export started', 'Opening Excel export…', 'info', 3000);
        });
    }

    // ------------------------------------------------------------
    // Initial render + refresh on modal open
    // ------------------------------------------------------------
    renderColumnTable();

    var modalEl = document.getElementById('exportColumnsModal');
    if (modalEl) {
        modalEl.addEventListener('show.bs.modal', function () {
            renderColumnTable();
        });
    }

})();
</script>

<?php include __DIR__ . '/footer.php'; ?>
