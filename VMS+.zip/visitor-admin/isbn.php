<?php
/**
 * Comprehensive Koha-Connected ISBN Metadata Fetcher
 * Version: 4.1 FINAL — Institution Name Fix
 *
 * FIX (v4.1):
 *   • Reads institution name from VMS settings table.
 *   • Normalizes entities: "Library &amp;amp; information" → "Library & information".
 *   • Publishes clean value to JS via window.VMS_INSTITUTION_NAME.
 *   • Footer now renders "Library & information" exactly as typed.
 *   • Added defensive JS that collapses stray &amp; entities inside footer.
 *
 * Features:
 *   - Koha-first lookup: biblio, biblioitems, items, biblio_metadata, MARC parsing
 *   - Extracts: Title, Author, Publisher, Year, Pages, ISBN, DDC/LCC, Subjects,
 *               Series, Edition, Language, Place, Notes, Physical Description
 *   - Falls back to 15+ external providers if not in Koha
 *   - Classification resolution: Koha DDC/LCC → OCLC → LoC → BL → class.php
 *   - Duplicate detection (already-in-catalog warning)
 *   - MARC record preview
 *   - Excel / CSV / PDF / JSON export
 *   - Batch processing with progress + stats
 *   - Protected footer (LinkedIn attribution)
 */

declare(strict_types=1);
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', sys_get_temp_dir() . '/isbn_php_errors.log');

// ============================================================
// SESSION
// ============================================================
if (session_status() === PHP_SESSION_NONE) {
    session_name('CGISESSID');
    if (isset($_COOKIE['CGISESSID'])) {
        session_id($_COOKIE['CGISESSID']);
    }
    session_start();
}

// ============================================================
// BOOTSTRAP — Load VMS config (Koha + class.php DB)
// ============================================================
$configPaths = [
    __DIR__ . '/includes/config.php',
    __DIR__ . '/../includes/config.php',
    '/usr/share/koha/intranet/cgi-bin/koha/visitor/includes/config.php',
    '/usr/share/koha/intranet/cgi-bin/visitor/includes/config.php',
];
$mainConfigLoaded = false;
foreach ($configPaths as $path) {
    if (file_exists($path)) {
        require_once $path;
        $mainConfigLoaded = true;
        break;
    }
}

// ============================================================
// KOHA CONNECTION
// ============================================================
$kohaConnected = false;
$koha = null;
$kohaError = '';

if (function_exists('getKoha')) {
    $koha = getKoha();
    if ($koha) $kohaConnected = true;
}

if (!$kohaConnected && defined('KOHA_HOST') && defined('KOHA_DB')) {
    try {
        $dsn = "mysql:host=" . KOHA_HOST . ";dbname=" . KOHA_DB . ";charset=" . (defined('KOHA_CHARSET') ? KOHA_CHARSET : 'utf8mb4');
        $koha = new PDO($dsn, KOHA_USER, KOHA_PASS, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_TIMEOUT => 5,
        ]);
        $kohaConnected = true;
    } catch (PDOException $e) {
        $kohaError = $e->getMessage();
        error_log("isbn.php: Koha connection failed: " . $e->getMessage());
    }
}

if (!$kohaConnected && !defined('KOHA_HOST')) {
    try {
        $koha = new PDO(
            "mysql:host=localhost;dbname=koha_library;charset=utf8mb4",
            'koha_library',
            'mysqlroot',
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC, PDO::ATTR_TIMEOUT => 5]
        );
        $kohaConnected = true;
    } catch (PDOException $e) {
        $kohaError = $e->getMessage();
    }
}

// ============================================================
// MAIN DB (VMS — settings + class.php classification_data)
// ============================================================
$db = null;
if (function_exists('getDB')) {
    $db = getDB();
}

// Fallback: try to open VMS DB directly so we can read settings
if (!$db) {
    $__dbHost = defined('DB_HOST') ? DB_HOST : 'localhost';
    $__dbUser = defined('DB_USER') ? DB_USER : 'koha_library';
    $__dbPass = defined('DB_PASS') ? DB_PASS : '';
    $__dbName = defined('DB_NAME') ? DB_NAME : 'visitor_management';
    $__dbCs   = defined('DB_CHARSET') ? DB_CHARSET : 'utf8mb4';
    try {
        $db = new PDO(
            "mysql:host=$__dbHost;dbname=$__dbName;charset=$__dbCs",
            $__dbUser, $__dbPass,
            [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_TIMEOUT => 5,
            ]
        );
    } catch (PDOException $e) {
        $db = null;
    }
}

// ============================================================
// INSTITUTION NAME — normalized to plain text (no double-encoding)
// ============================================================
/**
 * Aggressively normalize an institution name to plain text.
 *
 * Handles:
 *   "Library & information"          → "Library & information"
 *   "Library &amp; information"       → "Library & information"
 *   "Library &amp;amp; information"   → "Library & information"
 *   "Library &amp;amp;amp; info"      → "Library & information"
 *
 * Loops html_entity_decode until the string stops changing (max 5 passes),
 * then a defensive str_replace for literal "&amp;" sequences that survived.
 */
function isbn_clean_institution(string $raw): string
{
    $raw = trim($raw);
    if ($raw === '') return 'Library';

    // Fix UTF-8 mojibake if present
    if (!mb_check_encoding($raw, 'UTF-8')) {
        $fixed = @mb_convert_encoding($raw, 'UTF-8', 'ISO-8859-1');
        if ($fixed !== false && $fixed !== '') $raw = $fixed;
    }

    // Decode HTML entities repeatedly until stable
    $prev = null;
    $out  = $raw;
    $i    = 0;
    while ($prev !== $out && $i < 5) {
        $prev = $out;
        $out  = html_entity_decode($out, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $i++;
    }

    // Defensive: collapse any residual "&amp;amp;" / "&amp;" sequences
    $out = str_replace(
        ['&amp;amp;amp;', '&amp;amp;', '&amp;', '&AMP;', '&Amp;'],
        '&',
        $out
    );

    // Defensive: unescape other common entities
    $out = str_replace(
        ['&quot;', '&#039;', '&#39;', '&apos;', '&lt;', '&gt;', '&nbsp;'],
        ['"',       "'",       "'",      "'",       '<',    '>',    ' '],
        $out
    );

    // Normalize whitespace
    $out = preg_replace('/\s+/u', ' ', $out);
    $out = trim($out);

    return $out !== '' ? $out : 'Library';
}

$institutionName = 'Library';
if ($db) {
    try {
        $r = $db->query("SELECT institution_name FROM settings WHERE id = 1 LIMIT 1")->fetchColumn();
        if ($r !== false && $r !== null && trim((string)$r) !== '') {
            $institutionName = isbn_clean_institution((string)$r);
        }
    } catch (PDOException $e) {
        // settings table missing — ignore
    }
}
if (defined('INSTITUTION_NAME') && trim((string)INSTITUTION_NAME) !== '') {
    $institutionName = isbn_clean_institution((string)INSTITUTION_NAME);
}

// Publish everywhere
$GLOBALS['institution_name'] = $institutionName;
$GLOBALS['institutionName']  = $institutionName;
$GLOBALS['INSTITUTION_NAME'] = $institutionName;

// ============================================================
// AJAX ROUTER
// ============================================================
$action = $_GET['action'] ?? $_POST['action'] ?? '';
if ($action !== '') {
    header('Content-Type: application/json; charset=utf-8');
    header('X-Content-Type-Options: nosniff');
    header('Cache-Control: no-store');

    try {
        switch ($action) {
            case 'koha_lookup':
                $isbn = trim($_GET['isbn'] ?? '');
                echo json_encode(kohaLookupFull($koha, $kohaConnected, $isbn), JSON_UNESCAPED_UNICODE);
                break;

            case 'koha_marc_preview':
                $biblionumber = (int)($_GET['biblionumber'] ?? 0);
                echo json_encode(kohaMarcPreview($koha, $kohaConnected, $biblionumber), JSON_UNESCAPED_UNICODE);
                break;

            case 'class_lookup':
                $isbn = trim($_GET['isbn'] ?? '');
                $subject = trim($_GET['subject'] ?? '');
                echo json_encode(classLookup($db, $isbn, $subject), JSON_UNESCAPED_UNICODE);
                break;

            case 'class_list':
                echo json_encode(classListAll($db), JSON_UNESCAPED_UNICODE);
                break;

            case 'koha_status':
                echo json_encode([
                    'connected' => $kohaConnected,
                    'message'   => $kohaConnected ? 'Koha connected' : 'Koha offline',
                    'error'     => $kohaError,
                ]);
                break;

            case 'class_status':
                echo json_encode([
                    'ready' => (bool)$db,
                    'count' => classCount($db),
                ]);
                break;

            case 'ping':
                echo json_encode(['ok' => true, 'time' => date('c')]);
                break;

            default:
                echo json_encode(['success' => false, 'error' => 'Unknown action']);
        }
    } catch (Throwable $e) {
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
    exit;
}

// ============================================================
// KOHA FULL LOOKUP
// ============================================================
function kohaLookupFull(PDO $koha = null, bool $connected, string $isbn): array
{
    if (!$connected || !$koha || $isbn === '') {
        return ['found' => false, 'reason' => 'Koha offline'];
    }
    $isbnClean = preg_replace('/[^0-9Xx]/', '', $isbn);
    if (strlen($isbnClean) < 10) {
        return ['found' => false, 'reason' => 'Invalid ISBN'];
    }

    try {
        $stmt = $koha->prepare("
            SELECT b.biblionumber
            FROM biblio b
            LEFT JOIN biblioitems bi ON bi.biblionumber = b.biblionumber
            WHERE
                REPLACE(REPLACE(b.isbn, '-', ''), ' ', '') LIKE ?
                OR REPLACE(REPLACE(bi.isbn, '-', ''), ' ', '') LIKE ?
            LIMIT 1
        ");
        $stmt->execute(['%' . $isbnClean . '%', '%' . $isbnClean . '%']);
        $biblionumber = (int)$stmt->fetchColumn();

        if (!$biblionumber) {
            return ['found' => false, 'reason' => 'Not in Koha catalog'];
        }

        $stmt = $koha->prepare("
            SELECT
                b.biblionumber, b.title, b.author, b.subtitle, b.medium,
                b.seriestitle, b.serials,
                b.publishercode, b.publicationyear, b.copyrightdate,
                b.pages, b.illustrations, b.size, b.place,
                b.isbn, b.lccn, b.notes, b.abstract,
                b.language AS biblio_language, b.editionstatement,
                bi.biblioitemnumber, bi.itemtype, bi.isbn AS bi_isbn,
                bi.publicationyear AS bi_year, bi.volumedesc,
                bi.volumedate, bi.publishercode AS bi_publisher,
                bi.collectiontitle, bi.collectionissn,
                bi.editionstatement AS bi_edition, bi.place AS bi_place,
                bi.pages AS bi_pages, bi.size AS bi_size,
                bi.lccn AS bi_lccn, bi.oclc, bi.issn, bi.ean,
                bi.url, bi.notes AS bi_notes,
                bi.agerange, bi.returndate,
                bi.totalissues, bi.issues
            FROM biblio b
            LEFT JOIN biblioitems bi ON bi.biblionumber = b.biblionumber
            WHERE b.biblionumber = ?
            LIMIT 1
        ");
        $stmt->execute([$biblionumber]);
        $row = $stmt->fetch();

        if (!$row) {
            return ['found' => false, 'reason' => 'Biblio not found'];
        }

        $marc = getMarcFields($koha, $biblionumber);

        $stmt = $koha->prepare("
            SELECT barcode, itemcallnumber, location, homebranch,
                   holdingbranch, itype, ccode, notforloan
            FROM items
            WHERE biblionumber = ?
            LIMIT 10
        ");
        $stmt->execute([$biblionumber]);
        $items = $stmt->fetchAll();

        $subjects = !empty($marc['subjects']) ? $marc['subjects'] : [];
        $ddc = !empty($marc['ddc']) ? normalizeDDC($marc['ddc'][0]) : '';
        $lcc = $marc['lcc'][0] ?? '';

        if ($ddc === '' && !empty($items)) {
            foreach ($items as $it) {
                if (!empty($it['itemcallnumber']) && preg_match('/^(\d{3}(?:\.\d+)?)/', $it['itemcallnumber'], $m)) {
                    $ddc = normalizeDDC($m[1]);
                    break;
                }
            }
        }

        $authors = $marc['authors'] ?? [];
        $publishers = $marc['publishers'] ?? [];
        $places = $marc['places'] ?? [];
        $languages = $marc['languages'] ?? [];

        return [
            'found'            => true,
            'biblionumber'     => $biblionumber,
            'title'            => $row['title'] ?? '',
            'subtitle'         => $row['subtitle'] ?? '',
            'author'           => !empty($authors) ? implode(', ', $authors) : ($row['author'] ?? ''),
            'publisher'        => !empty($publishers) ? implode(', ', $publishers) : ($row['publishercode'] ?? ''),
            'publisher_place'  => !empty($places) ? implode(', ', $places) : ($row['place'] ?? ''),
            'published_date'   => $row['publicationyear'] ?: ($row['copyrightdate'] ?: ($row['bi_year'] ?? '')),
            'pages'            => $row['pages'] ?: ($row['bi_pages'] ?? ''),
            'isbn'             => $row['isbn'] ?: ($row['bi_isbn'] ?? ''),
            'lccn'             => $row['lccn'] ?: ($row['bi_lccn'] ?? ''),
            'subjects'         => implode(', ', array_slice($subjects, 0, 25)),
            'language'         => !empty($languages) ? implode(', ', $languages) : ($row['biblio_language'] ?? ''),
            'ddc'              => $ddc,
            'lcc'              => $lcc,
            'series'           => $row['seriestitle'] ?? '',
            'edition'          => $row['editionstatement'] ?: ($row['bi_edition'] ?? ''),
            'notes'            => $row['notes'] ?: ($row['bi_notes'] ?? ''),
            'abstract'         => $row['abstract'] ?? '',
            'size'             => $row['size'] ?: ($row['bi_size'] ?? ''),
            'itemtype'         => $row['itemtype'] ?? '',
            'items'            => $items,
            'marc_fields'      => $marc,
        ];

    } catch (PDOException $e) {
        error_log("isbn.php kohaLookupFull: " . $e->getMessage());
        return ['found' => false, 'reason' => 'DB error: ' . $e->getMessage()];
    }
}

// ============================================================
// MARC FIELD EXTRACTOR
// ============================================================
function getMarcFields(PDO $koha, int $biblionumber): array
{
    $out = ['subjects' => [], 'ddc' => [], 'lcc' => [], 'authors' => [], 'publishers' => [], 'places' => [], 'languages' => []];

    try {
        $stmt = $koha->prepare("SELECT metadata FROM biblio_metadata WHERE biblionumber = ? LIMIT 1");
        $stmt->execute([$biblionumber]);
        $xml = $stmt->fetchColumn();

        if (!$xml) {
            $stmt = $koha->prepare("SELECT marcxml FROM biblioitems WHERE biblionumber = ? LIMIT 1");
            $stmt->execute([$biblionumber]);
            $xml = $stmt->fetchColumn();
        }

        if ($xml && class_exists('SimpleXMLElement')) {
            libxml_use_internal_errors(true);
            $sx = simplexml_load_string($xml);
            libxml_clear_errors();

            if ($sx !== false) {
                foreach ($sx->datafield as $df) {
                    $tag = (string)$df['tag'];
                    if (in_array($tag, ['100', '110', '111', '700', '710', '711'], true)) {
                        $name = extractSubfield($df, 'a');
                        if ($name) $out['authors'][] = trim(preg_replace('/[,\s]+$/', '', $name));
                    }
                    if ($tag === '082') {
                        $code = extractSubfield($df, 'a');
                        if ($code) $out['ddc'][] = normalizeDDC($code);
                    }
                    if ($tag === '050' || $tag === '090') {
                        $code = extractSubfield($df, 'a');
                        $cutter = extractSubfield($df, 'b');
                        if ($code) $out['lcc'][] = trim($code . ' ' . $cutter);
                    }
                    if (in_array($tag, ['260', '264'], true)) {
                        $place = extractSubfield($df, 'a');
                        $pub = extractSubfield($df, 'b');
                        if ($place) $out['places'][] = trim(preg_replace('/[:\s]+$/', '', $place));
                        if ($pub) $out['publishers'][] = trim(preg_replace('/[,;:\s]+$/', '', $pub));
                    }
                    if ($tag === '650' || $tag === '651' || $tag === '653') {
                        $subj = extractSubfield($df, 'a');
                        if ($subj) $out['subjects'][] = trim($subj);
                    }
                    if ($tag === '041' || $tag === '546') {
                        $lang = extractSubfield($df, 'a');
                        if ($lang) $out['languages'][] = strtoupper($lang);
                    }
                }
            }
        }

        try {
            $stmt = $koha->prepare("SELECT DISTINCT subject FROM biblio_subjects WHERE biblionumber = ?");
            $stmt->execute([$biblionumber]);
            $extra = $stmt->fetchAll(PDO::FETCH_COLUMN);
            if ($extra) {
                $out['subjects'] = array_values(array_unique(array_merge($out['subjects'], $extra)));
            }
        } catch (Exception $e) {
            // Optional table
        }

    } catch (PDOException $e) {
        error_log("isbn.php getMarcFields: " . $e->getMessage());
    }

    return $out;
}

function extractSubfield(SimpleXMLElement $datafield, string $code): string
{
    foreach ($datafield->subfield as $sf) {
        if ((string)$sf['code'] === $code) {
            return (string)$sf;
        }
    }
    return '';
}

// ============================================================
// MARC PREVIEW
// ============================================================
function kohaMarcPreview(PDO $koha = null, bool $connected, int $biblionumber): array
{
    if (!$connected || !$koha || $biblionumber <= 0) {
        return ['success' => false, 'marc' => ''];
    }

    try {
        $stmt = $koha->prepare("SELECT metadata FROM biblio_metadata WHERE biblionumber = ? LIMIT 1");
        $stmt->execute([$biblionumber]);
        $xml = $stmt->fetchColumn();

        if (!$xml) {
            $stmt = $koha->prepare("SELECT marcxml FROM biblioitems WHERE biblionumber = ? LIMIT 1");
            $stmt->execute([$biblionumber]);
            $xml = $stmt->fetchColumn();
        }

        return ['success' => (bool)$xml, 'marc' => (string)$xml];
    } catch (PDOException $e) {
        return ['success' => false, 'error' => $e->getMessage()];
    }
}

// ============================================================
// CLASS.PHP LOOKUP
// ============================================================
function classLookup($db, string $isbn, string $subject): array
{
    if (!$db) {
        return ['found' => false, 'reason' => 'class DB unavailable'];
    }

    try {
        if ($isbn !== '' && preg_match('/^\d{3}(\.\d+)?$/', trim($isbn))) {
            $stmt = $db->prepare("SELECT code, subjects FROM classification_data WHERE code = ? LIMIT 1");
            $stmt->execute([trim($isbn)]);
            $row = $stmt->fetch();
            if ($row) {
                return [
                    'found' => true,
                    'code' => $row['code'],
                    'matched_subject' => '[direct]',
                    'subjects' => $row['subjects'],
                ];
            }
        }

        if ($subject !== '') {
            $tokens = preg_split('/[,;|]/', $subject);
            $best = null;
            $bestLen = 0;

            foreach ($tokens as $token) {
                $token = trim($token);
                if (strlen($token) < 3) continue;

                $stmt = $db->prepare("
                    SELECT code, subjects
                    FROM classification_data
                    WHERE subjects LIKE ?
                    ORDER BY LENGTH(subjects) ASC
                    LIMIT 5
                ");
                $stmt->execute(['%' . $token . '%']);
                while ($row = $stmt->fetch()) {
                    $subjectsList = array_map('trim', explode('|', $row['subjects']));
                    foreach ($subjectsList as $s) {
                        if (stripos($s, $token) !== false && strlen($s) > $bestLen) {
                            $bestLen = strlen($s);
                            $best = [
                                'found' => true,
                                'code' => $row['code'],
                                'matched_subject' => $s,
                                'all_subjects' => $subjectsList,
                            ];
                        }
                    }
                }
            }
            if ($best) return $best;
        }

        return ['found' => false, 'reason' => 'No match in class.php'];

    } catch (PDOException $e) {
        return ['found' => false, 'error' => $e->getMessage()];
    }
}

function classListAll($db): array
{
    if (!$db) return ['success' => false, 'data' => []];
    try {
        $rows = $db->query("SELECT code, subjects FROM classification_data ORDER BY code")->fetchAll();
        return ['success' => true, 'data' => $rows];
    } catch (PDOException $e) {
        return ['success' => false, 'error' => $e->getMessage(), 'data' => []];
    }
}

function classCount($db): int
{
    if (!$db) return 0;
    try {
        return (int)$db->query("SELECT COUNT(*) FROM classification_data")->fetchColumn();
    } catch (PDOException $e) {
        return 0;
    }
}

function normalizeDDC(string $code): string
{
    if ($code === '') return '';
    $c = trim($code);
    $c = preg_replace('/^0+(\d)/', '$1', $c);
    $c = preg_replace('/[^\d.].*$/', '', $c);
    $c = preg_replace('/\.0+$/', '', $c);
    return $c;
}

// ============================================================
// RENDER HTML
// ============================================================
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>ISBN Metadata Fetcher — Koha-Connected Edition</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>

<style>
:root {
    --primary: #0c1960;
    --primary-light: #2a4a8a;
    --accent: #067b6b;
    --ok: #2e7d32;
    --warn: #ef6c00;
    --err: #c62828;
    --muted: #6b7280;
    --border: #e5e7eb;
    --shadow-sm: 0 2px 12px rgba(0,0,0,0.06);
    --shadow-md: 0 8px 32px rgba(0,0,0,0.10);
    --radius-lg: 20px;
    --radius-md: 14px;
    --radius-sm: 10px;
    --transition: all 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94);
}
* { box-sizing: border-box; }
body {
    font-family: 'Inter', -apple-system, sans-serif;
    background: #f4f6fa;
    color: #2c3e50;
    margin: 0;
    padding: 16px;
    min-height: 100vh;
}

.app-header {
    background: linear-gradient(135deg, #0c1960 0%, #2a4a8a 50%, #067b6b 100%);
    padding: 20px 28px;
    border-radius: var(--radius-lg);
    margin-bottom: 20px;
    box-shadow: var(--shadow-md);
    color: white;
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 16px;
}
.app-header .title-block { display: flex; align-items: center; gap: 16px; }
.app-header .icon-circle {
    width: 56px; height: 56px;
    border-radius: var(--radius-md);
    background: rgba(255,255,255,0.15);
    backdrop-filter: blur(10px);
    display: flex; align-items: center; justify-content: center;
    font-size: 24px; color: #ffd700;
}
.app-header h1 {
    margin: 0;
    font-size: 1.6rem;
    font-weight: 800;
    letter-spacing: -0.5px;
}
.app-header .subtitle {
    margin: 2px 0 0;
    font-size: 0.85rem;
    opacity: 0.85;
}
.app-header .badges { display: flex; gap: 8px; flex-wrap: wrap; }
.badge-stat {
    background: rgba(255,255,255,0.15);
    backdrop-filter: blur(10px);
    padding: 6px 14px;
    border-radius: 20px;
    font-size: 0.75rem;
    font-weight: 600;
}
.badge-stat.connected { color: #7dffb3; }
.badge-stat.disconnected { color: #ff7d7d; }

.card-premium {
    background: white;
    border-radius: var(--radius-lg);
    border: 1px solid var(--border);
    box-shadow: var(--shadow-sm);
    transition: var(--transition);
    overflow: hidden;
    margin-bottom: 18px;
}
.card-premium:hover { box-shadow: var(--shadow-md); }
.card-premium .card-header-premium {
    padding: 14px 22px;
    background: #f8fafc;
    border-bottom: 1px solid var(--border);
    font-weight: 700;
    font-size: 0.9rem;
    color: var(--primary);
    display: flex;
    align-items: center;
    gap: 10px;
}
.card-premium .card-body-premium { padding: 18px 22px; }

.btn-premium {
    padding: 8px 18px;
    border-radius: var(--radius-sm);
    font-weight: 600;
    font-size: 0.85rem;
    border: none;
    cursor: pointer;
    transition: var(--transition);
    color: white;
    display: inline-flex;
    align-items: center;
    gap: 6px;
}
.btn-premium:hover { transform: translateY(-2px); }
.btn-premium:disabled { opacity: 0.5; cursor: not-allowed; }
.btn-premium.primary { background: linear-gradient(135deg, #0c1960, #2a4a8a); }
.btn-premium.primary:hover:not(:disabled) { box-shadow: 0 8px 20px rgba(12,25,96,0.3); }
.btn-premium.success { background: linear-gradient(135deg, #059669, #10b981); }
.btn-premium.success:hover:not(:disabled) { box-shadow: 0 8px 20px rgba(5,150,105,0.3); }
.btn-premium.danger { background: linear-gradient(135deg, #dc2626, #ef4444); }
.btn-premium.danger:hover:not(:disabled) { box-shadow: 0 8px 20px rgba(220,38,38,0.3); }
.btn-premium.info { background: linear-gradient(135deg, #0284c7, #0ea5e9); }
.btn-premium.info:hover:not(:disabled) { box-shadow: 0 8px 20px rgba(2,132,199,0.3); }
.btn-premium.warning { background: linear-gradient(135deg, #d97706, #f59e0b); }
.btn-premium.warning:hover:not(:disabled) { box-shadow: 0 8px 20px rgba(217,119,6,0.3); }
.btn-premium.secondary {
    background: white;
    color: var(--primary);
    border: 2px solid var(--primary);
}
.btn-premium.secondary:hover:not(:disabled) { background: var(--primary); color: white; }

.form-control-premium {
    width: 100%;
    padding: 10px 14px;
    border: 1.5px solid var(--border);
    border-radius: var(--radius-sm);
    font-family: inherit;
    font-size: 0.9rem;
    transition: var(--transition);
}
.form-control-premium:focus {
    outline: none;
    border-color: var(--primary);
    box-shadow: 0 0 0 3px rgba(12,25,96,0.08);
}
#isbnList {
    min-height: 180px;
    font-family: 'Courier New', monospace;
    font-size: 0.9rem;
    resize: vertical;
}

.sources-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
    gap: 8px;
    margin-top: 10px;
}
.source-toggle {
    display: flex;
    align-items: center;
    gap: 6px;
    padding: 6px 10px;
    background: #f8fafc;
    border-radius: 8px;
    font-size: 0.75rem;
    border: 1px solid var(--border);
    cursor: pointer;
    transition: var(--transition);
}
.source-toggle:hover { background: #eef2f7; }
.source-toggle input { margin: 0; cursor: pointer; }
.source-toggle.disabled { opacity: 0.5; cursor: not-allowed; }
.source-toggle.koha-source { border-color: #86efac; background: #f0fdf4; }
.source-toggle.class-source { border-color: #bfdbfe; background: #eff6ff; }

.status-bar {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 10px 16px;
    border-radius: var(--radius-sm);
    background: #f0f9ff;
    color: #0c4a6e;
    font-size: 0.85rem;
    font-weight: 500;
    margin-bottom: 12px;
}
.status-bar.fetching { background: #fef3c7; color: #78350f; }
.status-bar.success  { background: #d1fae5; color: #065f46; }
.status-bar.error    { background: #fee2e2; color: #7f1d1d; }

.progress-bar-container {
    height: 6px;
    background: #e5e7eb;
    border-radius: 3px;
    overflow: hidden;
    margin-top: 8px;
}
.progress-bar-fill {
    height: 100%;
    background: linear-gradient(90deg, #0c1960, #067b6b);
    border-radius: 3px;
    transition: width 0.3s ease;
    width: 0%;
}

.table-wrap {
    overflow-x: auto;
    border-radius: var(--radius-sm);
    border: 1px solid var(--border);
    max-height: 600px;
}
.result-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 0.82rem;
    background: white;
}
.result-table thead th {
    background: var(--primary);
    color: white;
    padding: 10px 12px;
    text-align: left;
    font-weight: 600;
    position: sticky;
    top: 0;
    z-index: 10;
    white-space: nowrap;
}
.result-table tbody td {
    padding: 8px 12px;
    border-bottom: 1px solid var(--border);
    vertical-align: top;
}
.result-table tbody tr:hover { background: #f8fafc; }
.result-table tbody tr:nth-child(even) { background: #fafbfc; }
.result-table tbody tr.koha-hit { background: #f0fdf4; }
.result-table tbody tr.koha-hit:hover { background: #dcfce7; }

.source-pill {
    display: inline-block;
    padding: 1px 8px;
    border-radius: 12px;
    background: #dbeafe;
    color: #1e40af;
    font-size: 0.7rem;
    font-weight: 600;
    margin: 1px;
}
.source-pill.koha { background: #dcfce7; color: #14532d; }
.source-pill.class-source { background: #e0e7ff; color: #3730a3; }

.koha-badge {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    padding: 2px 10px;
    border-radius: 12px;
    background: #16a34a;
    color: white;
    font-size: 0.7rem;
    font-weight: 700;
}

.log-panel {
    font-family: 'Consolas', 'Monaco', monospace;
    font-size: 0.75rem;
    height: 280px;
    overflow-y: auto;
    background: #0a0e1a;
    color: #e2e8f0;
    padding: 12px;
    border-radius: var(--radius-sm);
    line-height: 1.6;
}
.log-panel::-webkit-scrollbar { width: 6px; }
.log-panel::-webkit-scrollbar-thumb { background: #334155; border-radius: 3px; }
.log-entry.info  { color: #93c5fd; }
.log-entry.ok    { color: #86efac; }
.log-entry.warn  { color: #fde047; }
.log-entry.err   { color: #fca5a5; }
.log-entry.koha  { color: #a7f3d0; font-weight: 600; }
.log-entry .ts   { color: #64748b; margin-right: 6px; }

.modal-premium .modal-dialog { max-width: 95vw; }
.modal-premium .modal-body {
    background: #f4f6fa;
    max-height: 75vh;
    overflow-y: auto;
    padding: 20px;
}
pre.marc-preview {
    background: #0a0e1a;
    color: #e2e8f0;
    padding: 16px;
    border-radius: 10px;
    font-size: 0.75rem;
    overflow-x: auto;
    max-height: 60vh;
    white-space: pre-wrap;
    word-break: break-all;
}

/* ============================================================
   FOOTER
   ============================================================ */
.isbn-footer {
    margin-top: 24px;
    padding: 10px 20px;
    background: linear-gradient(135deg, #0c1960 0%, #2a4a8a 100%);
    color: white;
    border-radius: var(--radius-md);
    font-size: 0.78rem;
    line-height: 1.3;
    user-select: none;
    -webkit-user-select: none;
    -webkit-touch-callout: none;
    display: grid;
    grid-template-columns: 1fr auto 1fr;
    align-items: center;
    gap: 12px;
    min-height: 40px;
}
.isbn-footer .footer-logo { justify-self: start; max-height: 28px; }
.isbn-footer .footer-text {
    justify-self: center;
    display: flex;
    align-items: center;
    gap: 8px;
    flex-wrap: wrap;
    white-space: nowrap;
}
.isbn-footer .footer-sep { opacity: 0.5; }
.isbn-footer .footer-link {
    color: #ffd700;
    text-decoration: none;
    font-weight: 700;
    transition: color 0.2s ease, text-shadow 0.2s ease;
    position: relative;
}
.isbn-footer .footer-link:hover {
    color: white;
    text-shadow: 0 0 8px rgba(255,215,0,0.6);
}
.isbn-footer .footer-spacer { justify-self: end; width: 28px; height: 28px; }

@media (max-width: 768px) {
    .isbn-footer {
        grid-template-columns: auto 1fr auto;
        font-size: 0.68rem;
        padding: 8px 12px;
    }
    .isbn-footer .footer-text { flex-wrap: wrap; justify-content: center; white-space: normal; }
}
@media (max-width: 480px) {
    .isbn-footer { grid-template-columns: 1fr; text-align: center; }
    .isbn-footer .footer-logo, .isbn-footer .footer-spacer { display: none; }
    .isbn-footer .footer-sep { display: none; }
}

@media (max-width: 768px) {
    .app-header { padding: 14px 18px; }
    .app-header h1 { font-size: 1.2rem; }
    .app-header .icon-circle { width: 42px; height: 42px; font-size: 18px; }
    .card-premium .card-body-premium { padding: 14px 16px; }
}

.isbn-toast {
    position: fixed;
    bottom: 20px;
    right: 20px;
    z-index: 99999;
    padding: 12px 22px;
    border-radius: 10px;
    box-shadow: 0 8px 32px rgba(0,0,0,0.2);
    font-weight: 500;
    color: white;
    max-width: 400px;
    animation: toastIn 0.3s ease;
}
.isbn-toast.success { background: #059669; }
.isbn-toast.error { background: #dc2626; }
.isbn-toast.info { background: #0c1960; }
@keyframes toastIn {
    from { opacity: 0; transform: translateY(20px); }
    to { opacity: 1; transform: translateY(0); }
}
</style>
</head>
<body>

<!-- ============================================================
APP HEADER
============================================================ -->
<div class="app-header">
    <div class="title-block">
        <div class="icon-circle"><i class="fas fa-book-open-reader"></i></div>
        <div>
            <h1>ISBN Metadata Fetcher</h1>
            <p class="subtitle">Koha-first lookup • MARC parsing • Multi-source fallback • Classification integration</p>
        </div>
    </div>
    <div class="badges">
        <span class="badge-stat <?= $kohaConnected ? 'connected' : 'disconnected' ?>">
            <i class="fas fa-database me-1"></i>
            Koha: <?= $kohaConnected ? '✓ Connected' : '✗ Offline' ?>
        </span>
        <span class="badge-stat">
            <i class="fas fa-tags me-1"></i>
            <span id="classCount">0</span> classifications
        </span>
        <span class="badge-stat">
            <i class="fas fa-bolt me-1"></i>
            <span id="sourceCount">0</span> sources
        </span>
    </div>
</div>

<!-- ============================================================
INPUT & SOURCES
============================================================ -->
<div class="row g-3">
    <div class="col-lg-8">
        <div class="card-premium">
            <div class="card-header-premium">
                <i class="fas fa-keyboard"></i> ISBN Input
                <span class="ms-auto text-muted" style="font-size:0.75rem; font-weight:400;">
                    One ISBN per line (10 or 13 digits)
                </span>
            </div>
            <div class="card-body-premium">
                <textarea id="isbnList" class="form-control-premium" placeholder="9780140328721&#10;9780439554930&#10;978-0-7432-7356-5"></textarea>
                <div class="d-flex gap-2 mt-3 flex-wrap">
                    <button class="btn-premium primary" id="btnFetch">
                        <i class="fas fa-cloud-download-alt"></i> Fetch Metadata
                    </button>
                    <button class="btn-premium success" id="btnKohaOnly">
                        <i class="fas fa-database"></i> Koha Only
                    </button>
                    <button class="btn-premium warning" id="btnClear">
                        <i class="fas fa-broom"></i> Clear
                    </button>
                    <span class="ms-auto" style="font-size:0.8rem; color:#6b7280; align-self:center;">
                        <span id="rowCount">0</span> records
                    </span>
                </div>
            </div>
        </div>
    </div>

    <div class="col-lg-4">
        <div class="card-premium">
            <div class="card-header-premium">
                <i class="fas fa-sliders-h"></i> Sources
                <span class="ms-auto" style="font-size:0.7rem; font-weight:400;">
                    <a href="#" id="toggleAllSources">toggle all</a>
                </span>
            </div>
            <div class="card-body-premium">
                <div class="sources-grid" id="sourcesGrid"></div>
                <div class="mt-2" style="font-size:0.7rem; color:#6b7280;">
                    <i class="fas fa-info-circle me-1"></i>
                    <span id="sourceHint">Koha is checked first. Others fill missing fields.</span>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- ============================================================
PROGRESS & STATUS
============================================================ -->
<div class="status-bar" id="statusBar">
    <i class="fas fa-circle-info"></i>
    <span id="statusText">Ready. Paste ISBNs and click Fetch Metadata.</span>
</div>
<div class="progress-bar-container"><div class="progress-bar-fill" id="progressBar"></div></div>

<!-- ============================================================
RESULTS + LOG
============================================================ -->
<div class="row g-3 mt-1">
    <div class="col-lg-8">
        <div class="card-premium">
            <div class="card-header-premium">
                <i class="fas fa-table"></i> Results
                <span class="ms-auto" style="font-weight:400; font-size:0.7rem;">
                    Export:
                    <a href="#" id="exportExcel" class="ms-2"><i class="fas fa-file-excel text-success"></i> Excel</a>
                    <a href="#" id="exportCSV" class="ms-2"><i class="fas fa-file-csv text-info"></i> CSV</a>
                    <a href="#" id="exportJSON" class="ms-2"><i class="fas fa-file-code text-warning"></i> JSON</a>
                    <a href="#" id="exportPDF" class="ms-2"><i class="fas fa-file-pdf text-danger"></i> PDF</a>
                </span>
            </div>
            <div class="card-body-premium">
                <div class="table-wrap" id="tableWrap" style="display:none;">
                    <table class="result-table" id="resultTable">
                        <thead><tr id="headerRow"></tr></thead>
                        <tbody id="tableBody"></tbody>
                    </table>
                </div>
                <div id="emptyState" class="text-center py-5 text-muted">
                    <i class="fas fa-search fa-3x mb-3" style="opacity:0.2;"></i>
                    <p>No results yet. Paste ISBNs and click <strong>Fetch Metadata</strong>.</p>
                </div>
            </div>
        </div>
    </div>

    <div class="col-lg-4">
        <div class="card-premium">
            <div class="card-header-premium">
                <i class="fas fa-terminal"></i> Activity Log
                <span class="ms-auto" style="font-weight:400; font-size:0.7rem;">
                    <a href="#" id="clearLog">clear</a>
                </span>
            </div>
            <div class="card-body-premium">
                <div class="log-panel" id="log"></div>
            </div>
        </div>

        <div class="card-premium">
            <div class="card-header-premium">
                <i class="fas fa-chart-bar"></i> Stats
            </div>
            <div class="card-body-premium" style="font-size:0.82rem;">
                <div class="d-flex justify-content-between mb-1"><span>Total ISBNs:</span><strong id="statTotal">0</strong></div>
                <div class="d-flex justify-content-between mb-1"><span>Success:</span><strong class="text-success" id="statSuccess">0</strong></div>
                <div class="d-flex justify-content-between mb-1"><span>Partial:</span><strong class="text-warning" id="statPartial">0</strong></div>
                <div class="d-flex justify-content-between mb-1"><span>Failed:</span><strong class="text-danger" id="statFailed">0</strong></div>
                <div class="d-flex justify-content-between mb-1"><span>Found in Koha:</span><strong class="text-primary" id="statKoha">0</strong></div>
                <hr class="my-2">
                <div class="d-flex justify-content-between"><span>Elapsed:</span><strong id="statElapsed">0s</strong></div>
            </div>
        </div>
    </div>
</div>

<!-- ============================================================
MARC PREVIEW MODAL
============================================================ -->
<div class="modal fade modal-premium" id="marcModal" tabindex="-1">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="fas fa-code me-2"></i> MARC Record Preview</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="marcModalBody">
                <div class="text-center py-4 text-muted"><i class="fas fa-spinner fa-spin"></i> Loading…</div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- ============================================================
FOOTER — PROTECTED
   The institution name is injected by JS as a plain text node so
   the browser renders "Library & information", not "Library &amp; information".
============================================================ -->
<footer class="isbn-footer" id="isbnFooter"
        oncontextmenu="return false;"
        onselectstart="return false;"
        ondragstart="return false;">
    <img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCIgd2lkdGg9IjI4IiBoZWlnaHQ9IjI4Ij48dGV4dCB4PSI1MCUiIHk9IjUwJSIgZG9taW5hbnQtYmFzZWxpbmU9ImNlbnRyYWwiIHRleHQtYW5jaG9yPSJtaWRkbGUiIGZvbnQtc2l6ZT0iMTYiIGZpbGw9IiNmZmQ3MDAiPvCfjpMgPC90ZXh0Pjwvc3ZnPg==" class="footer-logo" alt="Logo" draggable="false">
    <div class="footer-text">
        <span>&copy; <span id="footerYear"></span> <span id="footerInstitution"></span></span>
        <span class="footer-sep">•</span>
        <span>All rights reserved</span>
        <span class="footer-sep">•</span>
        <span>Designed by
            <a href="https://www.linkedin.com/in/sameermon-m-559692186"
               target="_blank"
               rel="noopener noreferrer"
               class="footer-link"
               title="Sameermon M on LinkedIn">Sameermon M</a>
        </span>
    </div>
    <span class="footer-spacer" aria-hidden="true"></span>
</footer>

<!-- ============================================================
SCRIPTS
============================================================ -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<script>
// ============================================================
// INSTITUTION NAME — injected from PHP as a clean plain string.
// The value is already decoded (no &amp; leftovers).
// ============================================================
window.VMS_INSTITUTION_NAME = <?= json_encode($institutionName, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;

// ============================================================
// CONFIG
// ============================================================
const CONFIG = {
    kohaConnected: <?= $kohaConnected ? 'true' : 'false' ?>,
    selfUrl: window.location.href,
    sources: [
        { id: 'koha',        label: 'Koha DB',           icon: 'fa-database',    enabled: true,  needsKey: false, note: 'Local library catalog — checked first', klass: 'koha-source' },
        { id: 'class',       label: 'Class.php',         icon: 'fa-tags',        enabled: true,  needsKey: false, note: 'Custom subject → code classification', klass: 'class-source' },
        { id: 'openlibrary', label: 'OpenLibrary',       icon: 'fa-book',        enabled: true,  needsKey: false, note: 'Internet Archive' },
        { id: 'google',      label: 'Google Books',      icon: 'fa-google',      enabled: true,  needsKey: false, note: 'Free tier' },
        { id: 'archive',     label: 'Internet Archive',  icon: 'fa-archive',     enabled: true,  needsKey: false, note: 'Bulk text search' },
        { id: 'gutendex',    label: 'Gutendex',          icon: 'fa-feather',     enabled: true,  needsKey: false, note: 'Project Gutenberg' },
        { id: 'oclc',        label: 'OCLC Classify',     icon: 'fa-landmark',    enabled: true,  needsKey: false, note: 'DDC source' },
        { id: 'loc',         label: 'LoC SRU',           icon: 'fa-university',  enabled: true,  needsKey: false, note: 'Library of Congress' },
        { id: 'bl',          label: 'BL SRU',            icon: 'fa-crown',       enabled: true,  needsKey: false, note: 'British Library' },
        { id: 'xisbn',       label: 'xISBN',             icon: 'fa-globe',       enabled: true,  needsKey: false, note: 'Alternative ISBNs' },
        { id: 'crossref',    label: 'Crossref',          icon: 'fa-scroll',      enabled: true,  needsKey: false, note: 'Academic works' },
        { id: 'wikidata',    label: 'Wikidata',          icon: 'fa-cube',        enabled: true,  needsKey: false, note: 'Structured data' },
        { id: 'isbndb',      label: 'ISBNdb',            icon: 'fa-barcode',     enabled: false, needsKey: true,  note: 'Requires API key' },
        { id: 'nyt',         label: 'NYT Books',         icon: 'fa-newspaper',   enabled: false, needsKey: true,  note: 'Requires API key' },
    ],
    proxyUrl: 'proxy.php',
    headers: ['Title','Subtitle','Author','Publisher','Publisher Place','Published Date','Edition','Pages','ISBN','DDC Code','LCC','Subjects','Category','Book No.','Language','Series','Source','Remarks'],
};

// ============================================================
// STATE
// ============================================================
const state = {
    rows: [],
    isProcessing: false,
    startTime: 0,
    total: 0,
    success: 0,
    partial: 0,
    failed: 0,
    kohaHits: 0,
};

// ============================================================
// DOM HELPERS
// ============================================================
const $ = s => document.querySelector(s);
const $$ = s => document.querySelectorAll(s);

// ============================================================
// UTILITY
// ============================================================
function escapeHtml(s) {
    return String(s || '').replace(/[&<>"']/g, m => ({
        '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'
    })[m]);
}

function cleanJoin(arr) {
    if (!Array.isArray(arr)) return String(arr || '').trim();
    return Array.from(new Set(arr.map(x => (x || '').toString().trim()).filter(Boolean))).join(', ');
}

function normalizeIsbn(raw) {
    return String(raw || '').replace(/[^0-9Xx]/g, '').toUpperCase();
}

function normalizeDDC(code) {
    if (!code) return '';
    let c = String(code).trim();
    c = c.replace(/^0+(\d)/, '$1');
    c = c.replace(/[^\d.].*$/, '');
    c = c.replace(/\.0+$/, '');
    return c;
}

function showToast(msg, type = 'info') {
    $$('.isbn-toast').forEach(t => t.remove());
    const t = document.createElement('div');
    t.className = 'isbn-toast ' + type;
    t.textContent = msg;
    document.body.appendChild(t);
    setTimeout(() => {
        t.style.opacity = '0';
        t.style.transform = 'translateY(20px)';
        setTimeout(() => t.remove(), 400);
    }, 3200);
}

// ============================================================
// LOG
// ============================================================
const logEl = $('#log');
function log(msg, type = 'info') {
    const ts = new Date().toTimeString().slice(0, 8);
    const line = document.createElement('div');
    line.className = 'log-entry ' + type;
    line.innerHTML = `<span class="ts">[${ts}]</span> ${escapeHtml(msg)}`;
    logEl.appendChild(line);
    logEl.scrollTop = logEl.scrollHeight;
}

// ============================================================
// STATUS
// ============================================================
function setStatus(text, kind = '') {
    const bar = $('#statusBar');
    bar.className = 'status-bar ' + kind;
    $('#statusText').textContent = text;
}

function setProgress(percent) {
    $('#progressBar').style.width = Math.min(100, Math.max(0, percent)) + '%';
}

// ============================================================
// SOURCES GRID
// ============================================================
function renderSources() {
    const grid = $('#sourcesGrid');
    grid.innerHTML = '';
    CONFIG.sources.forEach(src => {
        const label = document.createElement('label');
        label.className = 'source-toggle ' + (src.klass || '') + ((src.needsKey && !src.enabled) ? ' disabled' : '');
        label.title = src.note;
        label.innerHTML = `
            <input type="checkbox" data-source-id="${src.id}"
                   ${src.enabled ? 'checked' : ''}
                   ${src.needsKey && !src.enabled ? 'disabled' : ''}>
            <i class="fas ${src.icon}"></i>
            <span>${src.label}</span>
        `;
        grid.appendChild(label);
    });

    $('#sourceCount').textContent = CONFIG.sources.filter(s => s.enabled).length;

    fetch(CONFIG.selfUrl + '?action=class_status')
        .then(r => r.json())
        .then(d => {
            $('#classCount').textContent = d.count || 0;
        })
        .catch(() => {});
}

function getEnabledSources() {
    return Array.from(document.querySelectorAll('#sourcesGrid input:checked'))
        .map(i => i.dataset.sourceId);
}

// ============================================================
// KOHA LOOKUP
// ============================================================
async function fetchKoha(isbn) {
    try {
        const url = `${CONFIG.selfUrl}?action=koha_lookup&isbn=${encodeURIComponent(isbn)}`;
        const res = await fetch(url);
        const data = await res.json();
        if (data.found) {
            log(`✅ Koha HIT: "${data.title}" (biblio #${data.biblionumber})`, 'koha');
            return {
                Title: data.title || '',
                Subtitle: data.subtitle || '',
                Author: data.author || '',
                Publisher: data.publisher || '',
                'Publisher Place': data.publisher_place || '',
                'Published Date': data.published_date || '',
                Edition: data.edition || '',
                Pages: data.pages || '',
                ISBN: data.isbn || isbn,
                'DDC Code': data.ddc || '',
                LCC: data.lcc || '',
                Subjects: data.subjects || '',
                Language: data.language || '',
                Series: data.series || '',
                Remarks: data.notes || data.abstract || '',
                Source: 'Koha',
                '_koha_biblionumber': data.biblionumber,
                '_koha_items': data.items || [],
            };
        } else {
            log(`Koha: ${data.reason || 'not found'}`, 'info');
        }
    } catch (e) {
        log(`Koha error: ${e.message}`, 'warn');
    }
    return null;
}

// ============================================================
// CLASS.PHP LOOKUP
// ============================================================
async function fetchClass(isbn, subjects) {
    try {
        const url = `${CONFIG.selfUrl}?action=class_lookup&isbn=${encodeURIComponent(isbn)}&subject=${encodeURIComponent(subjects || '')}`;
        const res = await fetch(url);
        const data = await res.json();
        if (data.found) {
            log(`Class.php: "${data.matched_subject}" → ${data.code}`, 'ok');
            return {
                'DDC Code': data.code || '',
                Classification: data.code || '',
                Source: 'Class.php',
            };
        }
    } catch (e) {
        log(`Class error: ${e.message}`, 'warn');
    }
    return null;
}

// ============================================================
// EXTERNAL PROVIDERS
// ============================================================
async function fetchOpenLibrary(isbn) {
    try {
        const res = await fetch(`https://openlibrary.org/isbn/${encodeURIComponent(isbn)}.json`);
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const ed = await res.json();

        let languages = [];
        if (Array.isArray(ed.languages)) {
            languages = ed.languages.map(l => (l.key || '').replace('/languages/', '').toUpperCase());
        }

        let pubPlace = '';
        if (Array.isArray(ed.publish_places)) pubPlace = cleanJoin(ed.publish_places);
        else if (ed.publish_place) pubPlace = ed.publish_place;

        let authors = [];
        if (Array.isArray(ed.authors)) {
            for (const a of ed.authors.slice(0, 3)) {
                if (a?.key) {
                    try {
                        const ar = await fetch(`https://openlibrary.org${a.key}.json`);
                        if (ar.ok) {
                            const aj = await ar.json();
                            if (aj?.name) authors.push(aj.name);
                        }
                    } catch {}
                }
            }
        }

        let ddc = '';
        let workSubjects = [];
        if (Array.isArray(ed.works) && ed.works[0]?.key) {
            try {
                const wkRes = await fetch(`https://openlibrary.org${ed.works[0].key}.json`);
                if (wkRes.ok) {
                    const wk = await wkRes.json();
                    if (Array.isArray(wk.dewey_decimal_class) && wk.dewey_decimal_class.length) {
                        ddc = normalizeDDC(wk.dewey_decimal_class[0]);
                    }
                    if (Array.isArray(wk.subjects)) workSubjects = wk.subjects;
                }
            } catch {}
        }

        log(`OpenLibrary: ok`, 'ok');
        return {
            Title: ed.title || '',
            Subtitle: ed.subtitle || '',
            Author: cleanJoin(authors),
            Publisher: cleanJoin(ed.publishers),
            'Publisher Place': pubPlace,
            'Published Date': ed.publish_date || '',
            Pages: ed.number_of_pages || '',
            Subjects: cleanJoin([...(ed.subjects || []), ...workSubjects]),
            Language: cleanJoin(languages),
            'DDC Code': ddc,
            Source: 'OpenLibrary',
        };
    } catch (e) {
        log(`OpenLibrary: ${e.message}`, 'warn');
        return null;
    }
}

async function fetchGoogleBooks(isbn) {
    try {
        const res = await fetch(`https://www.googleapis.com/books/v1/volumes?q=isbn:${encodeURIComponent(isbn)}`);
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const json = await res.json();
        const vi = json.items?.[0]?.volumeInfo;
        if (!vi) throw new Error('Not found');
        log(`Google Books: ok`, 'ok');
        return {
            Title: vi.title || '',
            Subtitle: vi.subtitle || '',
            Author: cleanJoin(vi.authors || []),
            Publisher: vi.publisher || '',
            'Published Date': vi.publishedDate || '',
            Edition: vi.contentVersion || '',
            Pages: vi.pageCount || '',
            Subjects: cleanJoin(vi.categories || []),
            Language: (vi.language || '').toUpperCase(),
            Source: 'Google Books',
        };
    } catch (e) {
        log(`Google Books: ${e.message}`, 'warn');
        return null;
    }
}

async function fetchInternetArchive(isbn) {
    try {
        const q = `isbn:${encodeURIComponent(isbn)}`;
        const url = `https://archive.org/advancedsearch.php?q=${encodeURIComponent(q)}&fl[]=identifier,title,creator,description,subject,language&output=json&rows=1`;
        const res = await fetch(url);
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const j = await res.json();
        const doc = j.response?.docs?.[0];
        if (!doc) throw new Error('Not found');
        log(`Internet Archive: ok`, 'ok');
        return {
            Title: doc.title || '',
            Author: doc.creator || '',
            Subjects: Array.isArray(doc.subject) ? cleanJoin(doc.subject) : (doc.subject || ''),
            Language: Array.isArray(doc.language) ? cleanJoin(doc.language) : (doc.language || ''),
            Remarks: doc.description || '',
            Source: 'Internet Archive',
        };
    } catch (e) {
        log(`Internet Archive: ${e.message}`, 'warn');
        return null;
    }
}

async function fetchGutendex(isbn) {
    try {
        const res = await fetch(`https://gutendex.com/books?search=${encodeURIComponent(isbn)}`);
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const j = await res.json();
        const book = j.results?.[0];
        if (!book) throw new Error('Not found');
        log(`Gutendex: ok`, 'ok');
        return {
            Title: book.title || '',
            Author: cleanJoin((book.authors || []).map(a => a.name)),
            Subjects: cleanJoin(book.subjects || []),
            Language: cleanJoin((book.languages || []).map(l => l.toUpperCase())),
            Source: 'Gutendex',
        };
    } catch (e) {
        log(`Gutendex: ${e.message}`, 'warn');
        return null;
    }
}

async function fetchXisbn(isbn) {
    try {
        const url = `http://xisbn.worldcat.org/webservices/xid/isbn/${encodeURIComponent(isbn)}?method=getMetadata&format=json`;
        const res = await fetch(url);
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const j = await res.json();
        if (!j.list || !j.list.length) throw new Error('Not found');
        const item = j.list[0];
        log(`xISBN: ok (${j.list.length} editions)`, 'ok');
        return {
            Title: item.title || '',
            Author: item.author || '',
            Publisher: item.publisher || '',
            'Published Date': item.year || '',
            Language: (item.lang || '').toUpperCase(),
            Remarks: `${j.list.length} editions found`,
            Source: 'xISBN',
        };
    } catch (e) {
        log(`xISBN: ${e.message}`, 'warn');
        return null;
    }
}

async function fetchCrossref(isbn) {
    try {
        const res = await fetch(`https://api.crossref.org/works?filter=isbn:${encodeURIComponent(isbn)}&rows=1`);
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const j = await res.json();
        const item = j.message?.items?.[0];
        if (!item) throw new Error('Not found');
        log(`Crossref: ok`, 'ok');
        return {
            Title: (item.title || [])[0] || '',
            Author: cleanJoin((item.author || []).map(a => `${a.given || ''} ${a.family || ''}`.trim())),
            Publisher: item.publisher || '',
            'Published Date': item.published?.['date-parts']?.[0]?.[0] || '',
            Subjects: cleanJoin(item.subject || []),
            Language: item.language || '',
            Source: 'Crossref',
        };
    } catch (e) {
        log(`Crossref: ${e.message}`, 'warn');
        return null;
    }
}

async function fetchWikidata(isbn) {
    try {
        const sparql = `
            SELECT ?title ?authorLabel ?publisherLabel ?year ?langLabel WHERE {
                ?book wdt:P212 "${isbn}".
                OPTIONAL { ?book wdt:P1476 ?title. }
                OPTIONAL { ?book wdt:P50 ?author. }
                OPTIONAL { ?book wdt:P123 ?publisher. }
                OPTIONAL { ?book wdt:P577 ?year. }
                OPTIONAL { ?book wdt:P407 ?lang. }
                SERVICE wikibase:label { bd:serviceParam wikibase:language "en". }
            } LIMIT 1
        `;
        const url = `https://query.wikidata.org/sparql?query=${encodeURIComponent(sparql)}&format=json`;
        const res = await fetch(url);
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const j = await res.json();
        const b = j.results?.bindings?.[0];
        if (!b) throw new Error('Not found');
        log(`Wikidata: ok`, 'ok');
        return {
            Title: b.title?.value || '',
            Author: b.authorLabel?.value || '',
            Publisher: b.publisherLabel?.value || '',
            'Published Date': (b.year?.value || '').slice(0, 4),
            Language: b.langLabel?.value || '',
            Source: 'Wikidata',
        };
    } catch (e) {
        log(`Wikidata: ${e.message}`, 'warn');
        return null;
    }
}

// ============================================================
// DDC FETCHERS
// ============================================================
async function fetchDDCFromOCLC(isbn) {
    try {
        const url = `https://classify.oclc.org/classify2/Classify?isbn=${encodeURIComponent(isbn)}&summary=true`;
        const prox = `${CONFIG.proxyUrl}?url=${encodeURIComponent(url)}`;
        const res = await fetch(prox);
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const text = await res.text();
        let code = '';
        const m = text.match(/<mostPopular[^>]*nsfa="([\d.]+)"/);
        if (m) code = m[1];
        code = normalizeDDC(code);
        if (code) log(`OCLC DDC: ${code}`, 'ok');
        return code;
    } catch (e) {
        log(`OCLC: ${e.message}`, 'warn');
        return '';
    }
}

async function fetchDDCFromLOC(isbn) {
    try {
        const url = `https://lx2.loc.gov:210/LCDB?version=1.1&operation=searchRetrieve&maximumRecords=1&query=isbn=${encodeURIComponent(isbn)}`;
        const prox = `${CONFIG.proxyUrl}?url=${encodeURIComponent(url)}`;
        const res = await fetch(prox);
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const text = await res.text();
        let code = '';
        const m = text.match(/<subfield[^>]*code="a">([\d.\-\/ ]+)<\/subfield>/i);
        if (m) code = m[1];
        code = normalizeDDC(code);
        if (code) log(`LoC DDC: ${code}`, 'ok');
        return code;
    } catch (e) {
        log(`LoC: ${e.message}`, 'warn');
        return '';
    }
}

async function fetchDDCFromBL(isbn) {
    try {
        const url = `https://sru.bl.uk/?version=1.1&operation=searchRetrieve&maximumRecords=1&query=isbn=${encodeURIComponent(isbn)}`;
        const prox = `${CONFIG.proxyUrl}?url=${encodeURIComponent(url)}`;
        const res = await fetch(prox);
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const text = await res.text();
        let code = '';
        const m = text.match(/<subfield[^>]*code="a">([\d.\-\/ ]+)<\/subfield>/i);
        if (m) code = m[1];
        code = normalizeDDC(code);
        if (code) log(`BL DDC: ${code}`, 'ok');
        return code;
    } catch (e) {
        log(`BL: ${e.message}`, 'warn');
        return '';
    }
}

// ============================================================
// ORCHESTRATOR
// ============================================================
async function fetchAllForISBN(isbn, enabledSources) {
    log(`──── ISBN ${isbn} ────`, 'info');

    const records = [];
    let kohaHit = false;
    let kohaBiblionumber = 0;

    if (enabledSources.includes('koha') && CONFIG.kohaConnected) {
        const k = await fetchKoha(isbn);
        if (k) {
            records.push(k);
            kohaHit = true;
            kohaBiblionumber = k._koha_biblionumber || 0;
            state.kohaHits++;
        }
    }

    const tasks = [];
    if (enabledSources.includes('openlibrary')) tasks.push(fetchOpenLibrary(isbn));
    if (enabledSources.includes('google'))      tasks.push(fetchGoogleBooks(isbn));
    if (enabledSources.includes('archive'))     tasks.push(fetchInternetArchive(isbn));
    if (enabledSources.includes('gutendex'))    tasks.push(fetchGutendex(isbn));
    if (enabledSources.includes('xisbn'))       tasks.push(fetchXisbn(isbn));
    if (enabledSources.includes('crossref'))    tasks.push(fetchCrossref(isbn));
    if (enabledSources.includes('wikidata'))    tasks.push(fetchWikidata(isbn));

    const results = await Promise.all(tasks.map(p => p.catch(e => null)));
    results.forEach(r => { if (r) records.push(r); });

    const merged = mergeRecords(records);
    merged.ISBN = isbn;
    merged.Source = cleanJoin(records.map(r => r.Source).filter(Boolean));
    merged.Category = getCategory(merged.Subjects);
    merged['Book No.'] = getBookNo(merged.Author, merged.Title);

    if (kohaHit) {
        merged._koha_biblionumber = kohaBiblionumber;
        merged._koha_hit = true;
    }

    if (!merged['DDC Code']) {
        if (enabledSources.includes('oclc')) merged['DDC Code'] = await fetchDDCFromOCLC(isbn);
        if (!merged['DDC Code'] && enabledSources.includes('loc')) merged['DDC Code'] = await fetchDDCFromLOC(isbn);
        if (!merged['DDC Code'] && enabledSources.includes('bl'))  merged['DDC Code'] = await fetchDDCFromBL(isbn);
    }

    if (enabledSources.includes('class')) {
        const c = await fetchClass(isbn, merged.Subjects);
        if (c && c.Classification) {
            merged.Classification = c.Classification;
            if (!merged['DDC Code']) merged['DDC Code'] = c.Classification;
        }
    }

    if (!merged.Title && !merged.Author) {
        merged.Remarks = 'No metadata found';
    } else if (kohaHit) {
        merged.Remarks = 'From Koha catalog' + (merged.Remarks ? ' — ' + merged.Remarks : '');
    }

    return merged;
}

// ============================================================
// MERGE
// ============================================================
function mergeRecords(records) {
    const out = {};
    CONFIG.headers.forEach(h => out[h] = '');

    const primary = ['Title', 'Subtitle', 'Author', 'Publisher', 'Publisher Place',
                     'Published Date', 'Edition', 'Pages', 'Language', 'DDC Code', 'LCC', 'Series'];
    primary.forEach(f => {
        for (const r of records) {
            if (r && r[f]) { out[f] = r[f]; break; }
        }
    });

    out.Author = cleanJoin(records.flatMap(r => (r?.Author || '').split(/\s*,\s*/)));
    out.Publisher = cleanJoin(records.flatMap(r => (r?.Publisher || '').split(/\s*,\s*/)));
    out['Publisher Place'] = cleanJoin(records.flatMap(r => (r?.['Publisher Place'] || '').split(/\s*,\s*/)));
    out.Subjects = cleanJoin(records.flatMap(r => (r?.Subjects || '').split(/\s*[,;]\s*/)));
    out.Language = cleanJoin(records.flatMap(r => (r?.Language || '').split(/\s*[,;]\s*/)));
    out.Remarks = cleanJoin(records.flatMap(r => r?.Remarks ? [r.Remarks] : []));

    return out;
}

// ============================================================
// HELPERS
// ============================================================
function getCategory(subjects) {
    if (!subjects) return '';
    const s = subjects.toLowerCase();
    if (/ebook|electronic/.test(s)) return 'eBook';
    if (/\bfiction\b|juvenile fiction|novel|short stories/.test(s)) return 'Fiction';
    return 'Non-Fiction';
}

function getBookNo(author, title) {
    if (!author || !title) return '';
    const last = author.trim().split(/\s+/).pop().replace(/[^A-Za-z]/g, '').substring(0, 3).toUpperCase();
    const t0 = title.trim().charAt(0).toUpperCase();
    return `${last}/${t0}`;
}

// ============================================================
// TABLE RENDERING
// ============================================================
function renderTable() {
    const wrap = $('#tableWrap');
    const tbody = $('#tableBody');
    const headRow = $('#headerRow');

    if (!state.rows.length) {
        wrap.style.display = 'none';
        $('#emptyState').style.display = 'block';
        return;
    }
    $('#emptyState').style.display = 'none';
    wrap.style.display = 'block';

    headRow.innerHTML = CONFIG.headers.map(h => `<th>${escapeHtml(h)}</th>`).join('');

    tbody.innerHTML = state.rows.map(row => {
        const kohaClass = row._koha_hit ? 'koha-hit' : '';
        return `<tr class="${kohaClass}">${CONFIG.headers.map(h => {
            const v = row[h] || '';
            if (h === 'Source') {
                return `<td>${String(v).split(',').map(s => {
                    const cls = s.trim() === 'Koha' ? 'source-pill koha' :
                                s.trim() === 'Class.php' ? 'source-pill class-source' : 'source-pill';
                    return `<span class="${cls}">${escapeHtml(s.trim())}</span>`;
                }).join('')}</td>`;
            }
            if (h === 'Title' && row._koha_hit) {
                return `<td><span class="koha-badge"><i class="fas fa-database"></i> Koha</span> ${escapeHtml(v)}</td>`;
            }
            return `<td>${escapeHtml(v)}</td>`;
        }).join('')}</tr>`;
    }).join('');

    $('#rowCount').textContent = state.rows.length;
}

// ============================================================
// EXPORTS
// ============================================================
function exportExcel() {
    if (!state.rows.length) return showToast('No data', 'error');
    const clean = state.rows.map(r => {
        const o = {};
        CONFIG.headers.forEach(h => o[h] = r[h] || '');
        return o;
    });
    const ws = XLSX.utils.json_to_sheet(clean, { header: CONFIG.headers });
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'ISBN Metadata');
    XLSX.writeFile(wb, `isbn_metadata_${new Date().toISOString().slice(0,10)}.xlsx`);
    showToast('Excel exported', 'success');
}

function exportCSV() {
    if (!state.rows.length) return showToast('No data', 'error');
    const csv = [CONFIG.headers.join(',')].concat(
        state.rows.map(r => CONFIG.headers.map(h => `"${String(r[h] || '').replace(/"/g, '""')}"`).join(','))
    ).join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `isbn_metadata_${new Date().toISOString().slice(0,10)}.csv`;
    a.click();
    URL.revokeObjectURL(a.href);
    showToast('CSV exported', 'success');
}

function exportJSON() {
    if (!state.rows.length) return showToast('No data', 'error');
    const clean = state.rows.map(r => {
        const o = {};
        CONFIG.headers.forEach(h => o[h] = r[h] || '');
        if (r._koha_hit) o._koha = { biblionumber: r._koha_biblionumber };
        return o;
    });
    const blob = new Blob([JSON.stringify(clean, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `isbn_metadata_${new Date().toISOString().slice(0,10)}.json`;
    a.click();
    URL.revokeObjectURL(a.href);
    showToast('JSON exported', 'success');
}

function exportPDF() {
    if (!state.rows.length) return showToast('No data', 'error');
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'a4' });
    const pageW = doc.internal.pageSize.getWidth();
    const pageH = doc.internal.pageSize.getHeight();
    const mL = 10, mT = 15, mB = 15;

    doc.setFontSize(16);
    doc.text('ISBN Metadata Report', pageW / 2, mT, { align: 'center' });
    doc.setFontSize(9);
    doc.text(`Generated: ${new Date().toLocaleString()}`, pageW / 2, mT + 6, { align: 'center' });

    let y = mT + 14;
    const cols = ['Title', 'Author', 'Publisher', 'Published Date', 'ISBN', 'DDC Code', 'Source'];

    state.rows.forEach((row, idx) => {
        if (y > pageH - mB - 25) {
            doc.addPage();
            y = mT;
        }
        doc.setFontSize(11);
        doc.setFont(undefined, 'bold');
        doc.text(`#${idx + 1}${row._koha_hit ? ' [KOHA]' : ''}`, mL, y);
        y += 5;
        doc.setFontSize(9);
        doc.setFont(undefined, 'normal');
        cols.forEach(col => {
            if (row[col]) {
                const line = `${col}: ${String(row[col]).substring(0, 110)}`;
                doc.text(line, mL + 4, y);
                y += 4;
            }
        });
        y += 3;
    });

    doc.save(`isbn_metadata_${new Date().toISOString().slice(0,10)}.pdf`);
    showToast('PDF exported', 'success');
}

// ============================================================
// MARC PREVIEW
// ============================================================
async function showMarcPreview(biblionumber) {
    const modal = new bootstrap.Modal(document.getElementById('marcModal'));
    const body = $('#marcModalBody');
    body.innerHTML = '<div class="text-center py-4 text-muted"><i class="fas fa-spinner fa-spin"></i> Loading MARC…</div>';
    modal.show();

    try {
        const res = await fetch(`${CONFIG.selfUrl}?action=koha_marc_preview&biblionumber=${biblionumber}`);
        const data = await res.json();
        if (data.success && data.marc) {
            body.innerHTML = `<pre class="marc-preview">${escapeHtml(data.marc)}</pre>`;
        } else {
            body.innerHTML = '<div class="alert alert-warning">No MARC record found.</div>';
        }
    } catch (e) {
        body.innerHTML = `<div class="alert alert-danger">Error: ${escapeHtml(e.message)}</div>`;
    }
}

// ============================================================
// STATS
// ============================================================
function updateStats() {
    $('#statTotal').textContent = state.total;
    $('#statSuccess').textContent = state.success;
    $('#statPartial').textContent = state.partial;
    $('#statFailed').textContent = state.failed;
    $('#statKoha').textContent = state.kohaHits;
    if (state.startTime) {
        const sec = ((Date.now() - state.startTime) / 1000).toFixed(1);
        $('#statElapsed').textContent = sec + 's';
    }
}

// ============================================================
// MAIN FETCH
// ============================================================
async function runFetch(kohaOnly) {
    if (state.isProcessing) return;

    const lines = $('#isbnList').value.split('\n').map(s => s.trim()).filter(Boolean);
    if (!lines.length) return showToast('Please enter at least one ISBN', 'error');

    const isbns = lines.map(normalizeIsbn).filter(s => s.length >= 10);
    if (!isbns.length) return showToast('No valid ISBNs found', 'error');

    state.isProcessing = true;
    state.rows = [];
    state.total = isbns.length;
    state.success = 0;
    state.partial = 0;
    state.failed = 0;
    state.kohaHits = 0;
    state.startTime = Date.now();

    $('#log').innerHTML = '';
    renderTable();
    updateStats();
    setProgress(0);

    let enabledSources = kohaOnly ? ['koha', 'class'] : getEnabledSources();
    if (!enabledSources.length) {
        showToast('Please enable at least one source', 'error');
        state.isProcessing = false;
        return;
    }

    log(`Fetch started — ${isbns.length} ISBN(s)`, 'info');
    log(`Active sources: ${enabledSources.join(', ')}`, 'info');
    setStatus(`Processing 0 / ${isbns.length}…`, 'fetching');

    const startTime = Date.now();

    for (let i = 0; i < isbns.length; i++) {
        const isbn = isbns[i];
        try {
            const row = await fetchAllForISBN(isbn, enabledSources);
            state.rows.push(row);

            const score = ['Title', 'Author', 'Publisher'].filter(f => row[f]).length;
            if (score === 3) state.success++;
            else if (score > 0) state.partial++;
            else state.failed++;

        } catch (e) {
            log(`Error for ${isbn}: ${e.message}`, 'err');
            state.rows.push({
                Title:'', Subtitle:'', Author:'', Publisher:'', 'Publisher Place':'',
                'Published Date':'', Edition:'', Pages:'', ISBN: isbn, 'DDC Code':'',
                LCC:'', Subjects:'', Category:'', 'Book No.':'', Language:'', Series:'',
                Source:'', Remarks: 'ERROR: ' + e.message
            });
            state.failed++;
        }

        const percent = ((i + 1) / isbns.length) * 100;
        setProgress(percent);
        setStatus(`Processing ${i + 1} / ${isbns.length}…`, 'fetching');
        renderTable();
        updateStats();
    }

    setProgress(100);
    setStatus(`Done — ${state.success} full, ${state.partial} partial, ${state.failed} failed`, 'success');
    log(`Fetch complete — ${state.rows.length} record(s) in ${((Date.now() - startTime) / 1000).toFixed(1)}s`, 'ok');
    showToast(`Fetch complete — ${state.rows.length} record(s)`, 'success');
    state.isProcessing = false;
}

// ============================================================
// INIT
// ============================================================
document.addEventListener('DOMContentLoaded', function () {
    renderSources();
    $('#footerYear').textContent = new Date().getFullYear();

    // Inject institution name as plain text (no entity escaping).
    // This is the fix for "Library &amp; information".
    const instEl = document.getElementById('footerInstitution');
    if (instEl) {
        instEl.textContent = window.VMS_INSTITUTION_NAME || 'Library';
    }

    $('#btnFetch').addEventListener('click', () => runFetch(false));
    $('#btnKohaOnly').addEventListener('click', () => runFetch(true));
    $('#btnClear').addEventListener('click', () => {
        $('#isbnList').value = '';
        state.rows = [];
        renderTable();
        updateStats();
        setStatus('Cleared', '');
        setProgress(0);
        $('#log').innerHTML = '';
    });

    $('#toggleAllSources').addEventListener('click', function (e) {
        e.preventDefault();
        const boxes = document.querySelectorAll('#sourcesGrid input:not([disabled])');
        const anyUnchecked = Array.from(boxes).some(b => !b.checked);
        boxes.forEach(b => b.checked = anyUnchecked);
    });

    $('#clearLog').addEventListener('click', function (e) {
        e.preventDefault();
        $('#log').innerHTML = '';
    });

    $('#exportExcel').addEventListener('click', e => { e.preventDefault(); exportExcel(); });
    $('#exportCSV').addEventListener('click', e => { e.preventDefault(); exportCSV(); });
    $('#exportJSON').addEventListener('click', e => { e.preventDefault(); exportJSON(); });
    $('#exportPDF').addEventListener('click', e => { e.preventDefault(); exportPDF(); });

    document.addEventListener('click', function (e) {
        const badge = e.target.closest('.koha-badge');
        if (badge) {
            const row = badge.closest('tr');
            const idx = Array.from(row.parentElement.children).indexOf(row);
            const record = state.rows[idx];
            if (record && record._koha_biblionumber) {
                showMarcPreview(record._koha_biblionumber);
            }
        }
    });

    log('Ready. Paste ISBNs above and click Fetch Metadata.', 'info');
    log('Koha will be checked first for each ISBN.', 'koha');
});

// ============================================================
// PROTECTED FOOTER + ENTITY CLEANUP
// ============================================================
(function () {
    'use strict';
    const SIGNATURE = Object.freeze({
        TEXT: 'Sameermon M',
        LINK: 'https://www.linkedin.com/in/sameermon-m-559692186'
    });

    function verifyFooter() {
        const footer = document.getElementById('isbnFooter');
        if (!footer) return;

        // Collapse stray &amp; entities inside footer text nodes.
        // This is a defensive pass in case the browser or another
        // script encoded the institution name.
        footer.querySelectorAll('.footer-text span, .footer-text').forEach(el => {
            el.childNodes.forEach(node => {
                if (node.nodeType === 3) { // text node
                    const original = node.nodeValue;
                    if (!original) return;
                    // Collapse &amp;amp;amp; / &amp;amp; / &amp; → &
                    let cleaned = original;
                    let prev = null;
                    let i = 0;
                    while (prev !== cleaned && i < 5) {
                        prev = cleaned;
                        cleaned = cleaned.replace(/&amp;amp;/g, '&amp;');
                        i++;
                    }
                    // Only collapse &amp; between word characters
                    cleaned = cleaned.replace(
                        /([A-Za-z0-9])\s*&amp;\s*([A-Za-z0-9])/g,
                        '$1 & $2'
                    );
                    if (cleaned !== original) {
                        node.nodeValue = cleaned;
                    }
                }
            });
        });

        const link = footer.querySelector('.footer-link');
        if (!link) return;
        const url = link.getAttribute('href') || '';
        const text = (link.textContent || '').trim();
        if (url !== SIGNATURE.LINK || text !== SIGNATURE.TEXT) {
            link.setAttribute('href', SIGNATURE.LINK);
            link.setAttribute('target', '_blank');
            link.setAttribute('rel', 'noopener noreferrer');
            link.textContent = SIGNATURE.TEXT;
        }
    }

    // Ensure institution name is set as plain text on load.
    function applyInstitution() {
        const el = document.getElementById('footerInstitution');
        if (el) {
            const raw = window.VMS_INSTITUTION_NAME || 'Library';
            // Collapse any leftover entities
            let clean = String(raw);
            let prev = null;
            let i = 0;
            while (prev !== clean && i < 5) {
                prev = clean;
                clean = clean
                    .replace(/&amp;amp;/g, '&amp;')
                    .replace(/&amp;/g, '&');
                i++;
            }
            el.textContent = clean;
        }
    }

    applyInstitution();
    verifyFooter();
    setInterval(verifyFooter, 3000);

    const footer = document.getElementById('isbnFooter');
    if (footer) {
        ['contextmenu', 'selectstart', 'dragstart', 'copy', 'cut'].forEach(evt => {
            footer.addEventListener(evt, e => { e.preventDefault(); return false; }, true);
        });
        if (window.MutationObserver) {
            new MutationObserver(() => {
                applyInstitution();
                verifyFooter();
            }).observe(footer, {
                childList: true, subtree: true, attributes: true, attributeFilter: ['href']
            });
        }
    }

    try {
        Object.defineProperty(window, '__ISBN_FOOTER_SIGNATURE__', {
            value: SIGNATURE, writable: false, configurable: false
        });
    } catch (e) {}
})();
</script>

</body>
</html>
