<?php
/**
 * Barcode & Label Generator – Professional Advanced Edition
 * Version: 5.2 ADVANCED — Institution Name Entity Fix
 *
 * FIX (v5.2):
 *   • Aggressive institution-name normalization (multi-level entity decode).
 *   • Publishes clean plain string to JS as window.VMS_INSTITUTION_NAME.
 *   • Shared footer output buffered + post-processed to collapse &amp; chains.
 *   • Institution name in HTML uses ENT_QUOTES with double_encode=false.
 *   • Spine library-name input defaults to the clean value.
 *
 * RETAINED from v5.1:
 *   • Spine Labels reordered: Classification → Author/Title Code → Barcode
 *   • Classification Number with 3 sources (Online / Koha Call No / Manual)
 *   • Library Logo + Library Name with independent positioning
 *   • Templates, QR codes, rich barcode options, layout presets
 *   • Live preview, print scaling + offset, undo/redo
 *   • Multi-format export (PDF/Excel/CSV/JSON/XML/PNG)
 *   • Advanced Koha fetch, dark mode, collapsible sections
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

// ============================================================
// SESSION + CSRF
// ============================================================
if (session_status() === PHP_SESSION_NONE) {
    session_name('CGISESSID');
    if (isset($_COOKIE['CGISESSID'])) session_id($_COOKIE['CGISESSID']);
    session_start();
}
if (empty($_SESSION['labels_csrf'])) {
    $_SESSION['labels_csrf'] = bin2hex(random_bytes(32));
}
$CSRF = $_SESSION['labels_csrf'];

function labels_csrf_check(?string $t): bool {
    return !empty($t) && !empty($_SESSION['labels_csrf']) && hash_equals($_SESSION['labels_csrf'], $t);
}

// ============================================================
// BOOTSTRAP – Load main VMS config
// ============================================================
$configPaths = [
    __DIR__ . '/includes/config.php',
    __DIR__ . '/../includes/config.php',
    '/usr/share/koha/intranet/cgi-bin/visitor/includes/config.php',
    '/usr/share/koha/intranet/cgi-bin/koha/visitor/includes/config.php',
];
$mainConfigLoaded = false;
foreach ($configPaths as $path) {
    if (file_exists($path)) { require_once $path; $mainConfigLoaded = true; break; }
}

// ============================================================
// LOAD SHARED FOOTER PARTIAL
// ============================================================
$footerPartialPaths = [
    __DIR__ . '/includes/footer_partial.php',
    __DIR__ . '/../includes/footer_partial.php',
    '/usr/share/koha/intranet/cgi-bin/visitor/includes/footer_partial.php',
    '/usr/share/koha/intranet/cgi-bin/koha/visitor/includes/footer_partial.php',
];
foreach ($footerPartialPaths as $p) {
    if (file_exists($p)) { require_once $p; break; }
}

// ============================================================
// ROBUST KOHA CONNECTION
// ============================================================
$kohaConnected = false;
$koha = null;
$kohaError = '';

if (function_exists('getKoha')) {
    $koha = getKoha();
    if ($koha) $kohaConnected = true;
}
if (!$kohaConnected && defined('KOHA_HOST') && defined('KOHA_DB')) {
    try {
        $dsn = "mysql:host=" . KOHA_HOST . ";dbname=" . KOHA_DB . ";charset=" . (defined('KOHA_CHARSET') ? KOHA_CHARSET : 'utf8mb4');
        $koha = new PDO($dsn, KOHA_USER, KOHA_PASS, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
            PDO::ATTR_TIMEOUT => 5
        ]);
        $kohaConnected = true;
    } catch (PDOException $e) {
        $kohaError = $e->getMessage();
        error_log("labels.php: Koha fallback connection failed: " . $e->getMessage());
    }
}
if (!$kohaConnected && !defined('KOHA_HOST')) {
    try {
        $koha = new PDO("mysql:host=localhost;dbname=koha_library;charset=utf8mb4", 'koha_library', 'mysqlroot', [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_TIMEOUT => 5
        ]);
        $kohaConnected = true;
    } catch (PDOException $e) {
        $kohaError = $e->getMessage();
        error_log("labels.php: Hardcoded connection failed: " . $e->getMessage());
    }
}

// ============================================================
// LOAD SETTINGS
// ============================================================
$institutionName = 'My Library';
$institutionLogo = '';
if ($mainConfigLoaded && function_exists('getSettings')) {
    $settings = getSettings();
    $institutionName = $settings['institution_name'] ?? 'My Library';
    $institutionLogo = $settings['institution_logo'] ?? '';
}

// ============================================================
// INSTITUTION NAME — deeply normalized to plain text  [CHANGED v5.2]
// ============================================================
/**
 * Aggressively normalize an institution name to plain text.
 *
 * "Library & information"          → "Library & information"
 * "Library &amp; information"       → "Library & information"
 * "Library &amp;amp; information"   → "Library & information"
 * "Library &amp;amp;amp; info"      → "Library & information"
 */
function labels_clean_institution(string $raw): string {
    $raw = trim($raw);
    if ($raw === '') return 'My Library';

    if (!mb_check_encoding($raw, 'UTF-8')) {
        $fixed = @mb_convert_encoding($raw, 'UTF-8', 'ISO-8859-1');
        if ($fixed !== false && $fixed !== '') $raw = $fixed;
    }

    // Loop-decode until stable (max 5 passes)
    $prev = null; $out = $raw; $i = 0;
    while ($prev !== $out && $i < 5) {
        $prev = $out;
        $out  = html_entity_decode($out, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $i++;
    }

    // Defensive collapse of residual literal entity sequences
    $out = str_replace(
        ['&amp;amp;amp;', '&amp;amp;', '&amp;', '&AMP;', '&Amp;'],
        '&',
        $out
    );
    $out = str_replace(
        ['&quot;', '&#039;', '&#39;', '&apos;', '&lt;', '&gt;', '&nbsp;'],
        ['"',       "'",       "'",      "'",       '<',    '>',    ' '],
        $out
    );

    $out = preg_replace('/\s+/u', ' ', $out);
    $out = trim($out);

    return $out !== '' ? $out : 'My Library';
}

$institutionName = labels_clean_institution((string)$institutionName);

// If config.php defines INSTITUTION_NAME, prefer that (normalized)
if (defined('INSTITUTION_NAME') && trim((string)INSTITUTION_NAME) !== '') {
    $institutionName = labels_clean_institution((string)INSTITUTION_NAME);
}

// Publish everywhere
$GLOBALS['institution_name'] = $institutionName;
$GLOBALS['institutionName']  = $institutionName;
$GLOBALS['INSTITUTION_NAME'] = $institutionName;

// ============================================================
// AJAX ROUTER
// ============================================================
$ajaxAction = $_GET['ajax_action'] ?? $_POST['ajax_action'] ?? '';

if ($ajaxAction) {
    header('Content-Type: application/json');
    $mutating = ['fetch_advanced', 'online_classification'];
    if (in_array($ajaxAction, $mutating, true)) {
        if (!labels_csrf_check($_POST['csrf'] ?? $_GET['csrf'] ?? '')) {
            echo json_encode(['success' => false, 'error' => 'CSRF token mismatch']);
            exit;
        }
    }
    handleAjax($ajaxAction, $koha, $kohaConnected);
    exit;
}

// ============================================================
// AJAX HANDLER
// ============================================================
function handleAjax($action, $koha, $kohaConnected) {
    switch ($action) {
        case 'all_books':
            echo json_encode(fetchAllBooks($koha, $kohaConnected));
            return;

        case 'books_by_barcode':
            $barcodes = json_decode($_POST['barcodes'] ?? '[]', true);
            echo json_encode(fetchBooksByBarcode($koha, $kohaConnected, $barcodes));
            return;

        case 'books_by_date':
            $from = $_GET['from'] ?? date('Y-m-d', strtotime('-30 days'));
            $to = $_GET['to'] ?? date('Y-m-d');
            echo json_encode(fetchBooksByDate($koha, $kohaConnected, $from, $to));
            return;

        case 'books_by_category':
            $category = $_GET['category'] ?? '';
            echo json_encode(fetchBooksByCategory($koha, $kohaConnected, $category));
            return;

        case 'search_books':
            $term = $_GET['q'] ?? '';
            echo json_encode(searchBooks($koha, $kohaConnected, $term));
            return;

        case 'categories':
            echo json_encode(fetchCategories($koha, $kohaConnected));
            return;

        case 'item_types':
            echo json_encode(fetchItemTypes($koha, $kohaConnected));
            return;

        case 'branches':
            echo json_encode(fetchBranches($koha, $kohaConnected));
            return;

        case 'koha_status':
            echo json_encode([
                'connected' => $kohaConnected,
                'message' => $kohaConnected ? 'Connected' : 'Not connected'
            ]);
            return;

        case 'fetch_advanced':
            $params = [
                'itype'      => $_POST['itype']      ?? '',
                'homebranch' => $_POST['homebranch'] ?? '',
                'location'   => $_POST['location']   ?? '',
                'bc_from'    => $_POST['bc_from']    ?? '',
                'bc_to'      => $_POST['bc_to']      ?? '',
                'acc_from'   => $_POST['acc_from']   ?? '',
                'acc_to'     => $_POST['acc_to']     ?? '',
                'limit'      => (int)($_POST['limit'] ?? 500),
            ];
            echo json_encode(fetchAdvanced($koha, $kohaConnected, $params));
            return;

        case 'online_classification':
            $isbn = trim($_POST['isbn'] ?? '');
            $callNumber = trim($_POST['call_number'] ?? '');
            echo json_encode(fetchOnlineClassification($isbn, $callNumber));
            return;

        default:
            echo json_encode(['success' => false, 'error' => 'Invalid action']);
            return;
    }
}

// ============================================================
// KOHA DATA FETCHERS
// ============================================================
function fetchAllBooks($koha, $kohaConnected, $limit = 500) {
    if (!$kohaConnected || !$koha) return getSampleBooks();
    try {
        $stmt = $koha->prepare("
            SELECT
                i.barcode,
                b.title,
                b.author,
                i.itemcallnumber AS call_number,
                i.itype AS category,
                b.isbn,
                b.publishercode AS publisher,
                b.copyrightdate AS year,
                i.homebranch,
                i.location,
                i.itemnumber,
                i.biblionumber
            FROM items i
            JOIN biblio b ON i.biblionumber = b.biblionumber
            WHERE i.notforloan = 0
              AND (i.damaged IS NULL OR i.damaged = 0)
              AND (i.itemlost IS NULL OR i.itemlost = 0)
              AND (i.withdrawn IS NULL OR i.withdrawn = 0)
            ORDER BY b.title
            LIMIT ?
        ");
        $stmt->execute([$limit]);
        $books = $stmt->fetchAll();
        return $books ?: getSampleBooks();
    } catch (PDOException $e) {
        error_log("fetchAllBooks: " . $e->getMessage());
        return getSampleBooks();
    }
}

function fetchBooksByBarcode($koha, $kohaConnected, $barcodes) {
    if (!$kohaConnected || !$koha || empty($barcodes) || !is_array($barcodes)) {
        return ['success' => false, 'books' => []];
    }
    try {
        $placeholders = implode(',', array_fill(0, count($barcodes), '?'));
        $stmt = $koha->prepare("
            SELECT i.barcode, b.title, b.author, i.itemcallnumber AS call_number,
                   i.itype AS category, b.isbn, b.publishercode AS publisher, b.copyrightdate AS year
            FROM items i
            JOIN biblio b ON i.biblionumber = b.biblionumber
            WHERE i.barcode IN ($placeholders)
        ");
        $stmt->execute($barcodes);
        return ['success' => true, 'books' => $stmt->fetchAll()];
    } catch (PDOException $e) {
        error_log("fetchBooksByBarcode: " . $e->getMessage());
        return ['success' => false, 'error' => $e->getMessage(), 'books' => []];
    }
}

function fetchBooksByDate($koha, $kohaConnected, $from, $to) {
    if (!$kohaConnected || !$koha) return ['success' => false, 'error' => 'Koha not connected', 'books' => []];
    try {
        $stmt = $koha->prepare("
            SELECT i.barcode, b.title, b.author, i.itemcallnumber AS call_number,
                   i.itype AS category, b.isbn, b.publishercode AS publisher, b.copyrightdate AS year,
                   b.datecreated
            FROM items i
            JOIN biblio b ON i.biblionumber = b.biblionumber
            WHERE b.datecreated BETWEEN ? AND ?
            ORDER BY b.datecreated DESC
            LIMIT 500
        ");
        $stmt->execute([$from . ' 00:00:00', $to . ' 23:59:59']);
        return ['success' => true, 'books' => $stmt->fetchAll()];
    } catch (PDOException $e) {
        return ['success' => false, 'error' => $e->getMessage(), 'books' => []];
    }
}

function fetchBooksByCategory($koha, $kohaConnected, $category) {
    if (!$kohaConnected || !$koha) return ['success' => false, 'books' => []];
    try {
        $stmt = $koha->prepare("
            SELECT i.barcode, b.title, b.author, i.itemcallnumber AS call_number,
                   i.itype AS category, b.isbn, b.publishercode AS publisher, b.copyrightdate AS year
            FROM items i
            JOIN biblio b ON i.biblionumber = b.biblionumber
            WHERE i.itype = ?
            ORDER BY b.title
            LIMIT 500
        ");
        $stmt->execute([$category]);
        return ['success' => true, 'books' => $stmt->fetchAll()];
    } catch (PDOException $e) {
        return ['success' => false, 'error' => $e->getMessage(), 'books' => []];
    }
}

function searchBooks($koha, $kohaConnected, $term) {
    if (!$kohaConnected || !$koha || empty($term)) return ['success' => false, 'books' => []];
    try {
        $searchTerm = '%' . $term . '%';
        $stmt = $koha->prepare("
            SELECT i.barcode, b.title, b.author, i.itemcallnumber AS call_number,
                   i.itype AS category, b.isbn, b.publishercode AS publisher, b.copyrightdate AS year
            FROM items i
            JOIN biblio b ON i.biblionumber = b.biblionumber
            WHERE b.title LIKE ? OR b.author LIKE ? OR i.barcode LIKE ? OR b.isbn LIKE ?
            ORDER BY b.title
            LIMIT 100
        ");
        $stmt->execute([$searchTerm, $searchTerm, $searchTerm, $searchTerm]);
        return ['success' => true, 'books' => $stmt->fetchAll()];
    } catch (PDOException $e) {
        return ['success' => false, 'error' => $e->getMessage(), 'books' => []];
    }
}

function fetchCategories($koha, $kohaConnected) {
    if (!$kohaConnected || !$koha) {
        return ['success' => true, 'categories' => ['Fiction', 'Non-Fiction', 'Science', 'Fantasy', 'Classic']];
    }
    try {
        $stmt = $koha->query("SELECT DISTINCT itype FROM items WHERE itype IS NOT NULL AND itype != '' ORDER BY itype");
        return ['success' => true, 'categories' => $stmt->fetchAll(PDO::FETCH_COLUMN)];
    } catch (PDOException $e) {
        return ['success' => true, 'categories' => []];
    }
}

function fetchItemTypes($koha, $kohaConnected) {
    if (!$kohaConnected || !$koha) return ['success' => true, 'itemtypes' => []];
    try {
        $stmt = $koha->query("SELECT itemtype, description FROM itemtypes ORDER BY description");
        return ['success' => true, 'itemtypes' => $stmt->fetchAll()];
    } catch (PDOException $e) {
        return ['success' => true, 'itemtypes' => []];
    }
}

function fetchBranches($koha, $kohaConnected) {
    if (!$kohaConnected || !$koha) return ['success' => true, 'branches' => []];
    try {
        $stmt = $koha->query("SELECT branchcode, branchname FROM branches ORDER BY branchname");
        return ['success' => true, 'branches' => $stmt->fetchAll()];
    } catch (PDOException $e) {
        return ['success' => true, 'branches' => []];
    }
}

function fetchAdvanced($koha, $kohaConnected, $params) {
    if (!$kohaConnected || !$koha) return ['success' => false, 'error' => 'Koha not connected', 'books' => []];
    try {
        $where = [
            "i.notforloan = 0",
            "(i.damaged IS NULL OR i.damaged = 0)",
            "(i.itemlost IS NULL OR i.itemlost = 0)",
            "(i.withdrawn IS NULL OR i.withdrawn = 0)"
        ];
        $bind = [];
        if (!empty($params['itype']))      { $where[] = "i.itype = ?";      $bind[] = $params['itype']; }
        if (!empty($params['homebranch'])) { $where[] = "i.homebranch = ?"; $bind[] = $params['homebranch']; }
        if (!empty($params['location']))   { $where[] = "i.location = ?";   $bind[] = $params['location']; }
        if (!empty($params['bc_from']))    { $where[] = "i.barcode >= ?";   $bind[] = $params['bc_from']; }
        if (!empty($params['bc_to']))      { $where[] = "i.barcode <= ?";   $bind[] = $params['bc_to']; }
        if (!empty($params['acc_from']))   { $where[] = "i.dateaccessioned >= ?"; $bind[] = $params['acc_from'] . ' 00:00:00'; }
        if (!empty($params['acc_to']))     { $where[] = "i.dateaccessioned <= ?"; $bind[] = $params['acc_to'] . ' 23:59:59'; }
        $limit = max(1, min(2000, (int)$params['limit']));
        $sql = "
            SELECT i.barcode, b.title, b.author, i.itemcallnumber AS call_number,
                   i.itype AS category, b.isbn, b.publishercode AS publisher, b.copyrightdate AS year,
                   i.homebranch, i.location
            FROM items i
            JOIN biblio b ON i.biblionumber = b.biblionumber
            WHERE " . implode(' AND ', $where) . "
            ORDER BY b.title
            LIMIT $limit
        ";
        $stmt = $koha->prepare($sql);
        $stmt->execute($bind);
        return ['success' => true, 'books' => $stmt->fetchAll()];
    } catch (PDOException $e) {
        return ['success' => false, 'error' => $e->getMessage(), 'books' => []];
    }
}

function fetchOnlineClassification($isbn, $callNumber) {
    $isbn = preg_replace('/[^0-9Xx]/', '', $isbn);
    if (!$isbn) {
        return ['success' => false, 'error' => 'No ISBN provided', 'classification' => ''];
    }
    $url = 'https://openlibrary.org/api/books?bibkeys=ISBN:' . urlencode($isbn) . '&format=json&jscmd=data';
    $ctx = stream_context_create([
        'http' => ['timeout' => 4, 'header' => "User-Agent: Koha-Labels/5.2\r\n"]
    ]);
    $raw = @file_get_contents($url, false, $ctx);
    if ($raw === false) {
        return ['success' => false, 'error' => 'Network error', 'classification' => extractFromCallNumber($callNumber)];
    }
    $json = json_decode($raw, true);
    $info = $json['ISBN:' . $isbn] ?? null;
    $cls = '';
    if ($info) {
        if (!empty($info['dewey_decimal_class'])) {
            $cls = is_array($info['dewey_decimal_class']) ? ($info['dewey_decimal_class'][0] ?? '') : $info['dewey_decimal_class'];
        }
        if (!$cls && !empty($info['lc_classification'])) {
            $cls = is_array($info['lc_classification']) ? ($info['lc_classification'][0] ?? '') : $info['lc_classification'];
        }
        if (!$cls && !empty($info['classifications'])) {
            $c = $info['classifications'];
            if (!empty($c['dewey_decimal_class'])) $cls = $c['dewey_decimal_class'][0] ?? '';
            elseif (!empty($c['lc_classification'])) $cls = $c['lc_classification'][0] ?? '';
        }
    }
    if (!$cls) {
        return ['success' => false, 'error' => 'No classification found', 'classification' => extractFromCallNumber($callNumber)];
    }
    return ['success' => true, 'classification' => $cls];
}

function extractFromCallNumber($call) {
    $call = trim((string)$call);
    if (!$call) return '';
    return preg_replace('/\s+.*$/', '', $call);
}

function getSampleBooks() {
    return [
        ['barcode' => 'BK001', 'title' => 'The Great Gatsby', 'author' => 'F. Scott Fitzgerald', 'call_number' => 'FIC FIT', 'category' => 'Fiction', 'isbn' => '978-0-7432-7356-5', 'publisher' => 'Scribner', 'year' => '1925'],
        ['barcode' => 'BK002', 'title' => '1984', 'author' => 'George Orwell', 'call_number' => 'FIC ORW', 'category' => 'Fiction', 'isbn' => '978-0-452-28423-4', 'publisher' => 'Signet', 'year' => '1949'],
        ['barcode' => 'BK003', 'title' => 'To Kill a Mockingbird', 'author' => 'Harper Lee', 'call_number' => 'FIC LEE', 'category' => 'Fiction', 'isbn' => '978-0-06-112008-4', 'publisher' => 'Harper', 'year' => '1960'],
        ['barcode' => 'BK004', 'title' => 'Pride and Prejudice', 'author' => 'Jane Austen', 'call_number' => 'FIC AUS', 'category' => 'Classic', 'isbn' => '978-0-14-143951-8', 'publisher' => 'Penguin', 'year' => '1813'],
        ['barcode' => 'BK005', 'title' => 'The Hobbit', 'author' => 'J.R.R. Tolkien', 'call_number' => 'FIC TOL', 'category' => 'Fantasy', 'isbn' => '978-0-547-92822-7', 'publisher' => 'HMH', 'year' => '1937'],
        ['barcode' => 'BK006', 'title' => 'A Brief History of Time', 'author' => 'Stephen Hawking', 'call_number' => '530.1 HAW', 'category' => 'Science', 'isbn' => '978-0-553-38016-3', 'publisher' => 'Bantam', 'year' => '1988'],
        ['barcode' => 'BK007', 'title' => 'The Lord of the Rings', 'author' => 'J.R.R. Tolkien', 'call_number' => 'FIC TOL', 'category' => 'Fantasy', 'isbn' => '978-0-618-57498-9', 'publisher' => 'HMH', 'year' => '1954'],
        ['barcode' => 'BK008', 'title' => "Harry Potter and the Philosopher's Stone", 'author' => 'J.K. Rowling', 'call_number' => 'FIC ROW', 'category' => 'Fantasy', 'isbn' => '978-0-7475-3269-9', 'publisher' => 'Bloomsbury', 'year' => '1997'],
    ];
}

// ============================================================
// FETCH DATA FOR RENDER
// ============================================================
$books = fetchAllBooks($koha, $kohaConnected);
$categoriesResult = fetchCategories($koha, $kohaConnected);
$categories = $categoriesResult['categories'] ?? [];
$itemTypesResult = fetchItemTypes($koha, $kohaConnected);
$itemTypes = $itemTypesResult['itemtypes'] ?? [];
$branchesResult = fetchBranches($koha, $kohaConnected);
$branches = $branchesResult['branches'] ?? [];

// ============================================================
// SESSION-PERSISTED PRINT SETTINGS
// ============================================================
$defaultPrintSettings = [
    'page_size'      => 'A4',
    'orientation'    => 'portrait',
    'margin_top'     => 10,
    'margin_bottom'  => 10,
    'margin_left'    => 10,
    'margin_right'   => 10,
    'gap_x'          => 2,
    'gap_y'          => 2,
    'col_gap'        => 5,
    'row_gap'        => 5,
    'columns'        => 3,
    'font_family'    => 'Arial',
    'font_size'      => 8,
    'font_color'     => '#000000',
    'bg_color'       => '#ffffff',
    'border_color'   => '#cccccc',
    'border_width'   => 0.3,
    'show_border'    => 1,
    'show_cut_lines' => 0,
    'print_header'   => 1,
    'header_text'    => '',
    'scale'          => 100,
    'offset_x'       => 0,
    'offset_y'       => 0,
];
if (isset($_SESSION['label_print_settings'])) {
    $defaultPrintSettings = array_merge($defaultPrintSettings, $_SESSION['label_print_settings']);
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_print_settings'])) {
    if (labels_csrf_check($_POST['csrf_token'] ?? '')) {
        $newSettings = [];
        foreach ($defaultPrintSettings as $key => $val) {
            if (isset($_POST['print_' . $key])) {
                $newSettings[$key] = is_numeric($_POST['print_' . $key]) ? $_POST['print_' . $key] + 0 : $_POST['print_' . $key];
            }
        }
        $_SESSION['label_print_settings'] = $newSettings;
        $defaultPrintSettings = array_merge($defaultPrintSettings, $newSettings);
    }
}
$p = $defaultPrintSettings;

// ============================================================
// RENDER PAGE
// ============================================================
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Barcode &amp; Label Generator – v5.2</title>
<meta name="csrf-token" content="<?= htmlspecialchars($CSRF) ?>">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<style>
:root {
    --primary: #1a2a6c;
    --secondary: #2a4a8a;
    --accent: #fdbb2d;
    --bg: #eef2f7;
    --fg: #1e293b;
    --card: #ffffff;
    --card-border: #e9ecef;
    --shadow-sm: 0 2px 12px rgba(0,0,0,0.06);
    --shadow-md: 0 8px 32px rgba(0,0,0,0.10);
    --shadow-lg: 0 16px 48px rgba(0,0,0,0.14);
    --radius-lg: 24px;
    --radius-md: 16px;
    --radius-sm: 12px;
    --transition: all 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94);
}
[data-theme="dark"] {
    --bg: #0f172a;
    --fg: #e2e8f0;
    --card: #1e293b;
    --card-border: #334155;
}
* { box-sizing: border-box; }
body {
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
    background: var(--bg);
    color: var(--fg);
    padding: 20px;
    min-height: 100vh;
    transition: background .3s, color .3s;
}
.app-header {
    background: linear-gradient(135deg, #1a2a6c 0%, #2a4a8a 50%, #3a6aaa 100%);
    padding: 20px 30px;
    border-radius: var(--radius-lg);
    margin-bottom: 28px;
    box-shadow: var(--shadow-lg);
    position: relative;
    overflow: hidden;
}
.app-header::before {
    content: '';
    position: absolute;
    top: -50%; right: -20%;
    width: 300px; height: 300px;
    border-radius: 50%;
    background: rgba(255,215,0,0.08);
    pointer-events: none;
}
.app-header .header-content {
    position: relative;
    z-index: 1;
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 15px;
}
.app-header .header-left { display: flex; align-items: center; gap: 18px; }
.app-header .header-left .icon-wrapper {
    width: 56px; height: 56px;
    border-radius: var(--radius-md);
    background: rgba(255,255,255,0.15);
    backdrop-filter: blur(10px);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 28px;
    color: #ffd700;
}
.app-header h1 {
    color: white;
    font-weight: 800;
    font-size: 1.8rem;
    margin: 0;
    letter-spacing: -0.5px;
}
.app-header p { color: rgba(255,255,255,0.7); margin: 0; font-size: 0.85rem; }
.app-header .badge-version {
    background: rgba(255,215,0,0.2);
    color: #ffd700;
    padding: 6px 16px;
    border-radius: 30px;
    font-size: 0.7rem;
    font-weight: 600;
    border: 1px solid rgba(255,215,0,0.15);
}
.koha-status {
    background: rgba(255,255,255,0.1);
    padding: 4px 12px;
    border-radius: 20px;
    font-size: 0.7rem;
    color: rgba(255,255,255,0.8);
}
.koha-status .connected { color: #7dffb3; }
.koha-status .disconnected { color: #ff7d7d; }
.label-tabs {
    border: none;
    gap: 6px;
    background: rgba(255,255,255,0.5);
    padding: 6px;
    border-radius: var(--radius-md);
    backdrop-filter: blur(10px);
    margin-bottom: 24px;
    display: flex;
    flex-wrap: wrap;
}
[data-theme="dark"] .label-tabs { background: rgba(30,41,59,0.6); }
.label-tabs .nav-link {
    border: none;
    border-radius: var(--radius-sm);
    padding: 10px 24px;
    font-weight: 600;
    color: #6c757d;
    transition: var(--transition);
    background: transparent;
}
.label-tabs .nav-link:hover { color: var(--primary); background: rgba(26,42,108,0.06); }
.label-tabs .nav-link.active {
    background: var(--card);
    color: var(--primary);
    box-shadow: var(--shadow-sm);
}
[data-theme="dark"] .label-tabs .nav-link.active { color: #93c5fd; }
.label-tabs .nav-link i { margin-right: 10px; }
.card-premium {
    background: var(--card);
    backdrop-filter: blur(20px);
    border-radius: var(--radius-lg);
    border: 1px solid var(--card-border);
    box-shadow: var(--shadow-sm);
    transition: var(--transition);
    overflow: hidden;
    margin-bottom: 20px;
}
.card-premium:hover { box-shadow: var(--shadow-md); }
.card-premium .card-header-premium {
    padding: 16px 24px;
    background: rgba(0,0,0,0.02);
    border-bottom: 1px solid var(--card-border);
    font-weight: 700;
    font-size: 0.95rem;
    color: var(--primary);
    display: flex;
    align-items: center;
    gap: 10px;
}
[data-theme="dark"] .card-premium .card-header-premium { color: #93c5fd; }
.card-premium .card-body-premium { padding: 20px 24px; }
.book-list {
    max-height: 400px;
    overflow-y: auto;
    border-radius: var(--radius-sm);
    border: 1px solid var(--card-border);
}
.book-list::-webkit-scrollbar { width: 4px; }
.book-list::-webkit-scrollbar-thumb { background: #dce4ed; border-radius: 4px; }
.book-item {
    padding: 8px 14px;
    border-bottom: 1px solid rgba(0,0,0,0.04);
    transition: var(--transition);
    cursor: pointer;
}
.book-item:hover { background: rgba(26,42,108,0.04); }
.book-item.selected {
    background: rgba(26,42,108,0.08);
    border-left: 3px solid var(--primary);
}
.book-item .book-title { font-weight: 600; font-size: 0.9rem; }
.book-item .book-meta { font-size: 0.75rem; color: #6c757d; }
.label-preview-container {
    background: var(--card);
    border-radius: var(--radius-sm);
    border: 1px solid var(--card-border);
    padding: 16px;
    min-height: 300px;
    display: flex;
    flex-wrap: wrap;
    gap: 12px;
    justify-content: center;
    max-height: 600px;
    overflow-y: auto;
}
.label-item {
    border: 1px solid var(--card-border);
    border-radius: 6px;
    padding: 8px 12px;
    background: #fafafa;
    min-width: 120px;
    text-align: center;
    transition: var(--transition);
    color: #1e293b;
}
[data-theme="dark"] .label-item { background: #f8fafc; color: #1e293b; }
.label-item:hover { box-shadow: var(--shadow-sm); border-color: var(--primary); }
.label-item .label-barcode svg { height: 30px; }
.label-item .label-text { font-size: 8px; color: #2c3e50; margin-top: 2px; word-break: break-all; }
.label-item .label-call { font-size: 9px; font-weight: 700; color: var(--primary); }
.btn-premium {
    padding: 8px 20px;
    border-radius: var(--radius-sm);
    font-weight: 600;
    font-size: 0.85rem;
    transition: var(--transition);
    border: none;
}
.btn-premium-primary { background: linear-gradient(135deg, #1a2a6c, #2a4a8a); color: white; }
.btn-premium-primary:hover { transform: translateY(-2px); box-shadow: 0 8px 25px rgba(26,42,108,0.3); color: white; }
.btn-premium-success { background: linear-gradient(135deg, #11998e, #38ef7d); color: white; }
.btn-premium-success:hover { transform: translateY(-2px); box-shadow: 0 8px 25px rgba(17,153,142,0.3); color: white; }
.btn-premium-danger { background: linear-gradient(135deg, #c0392b, #e74c3c); color: white; }
.btn-premium-danger:hover { transform: translateY(-2px); box-shadow: 0 8px 25px rgba(192,57,43,0.3); color: white; }
.btn-premium-warning { background: linear-gradient(135deg, #d97706, #f59e0b); color: white; }
.btn-premium-warning:hover { transform: translateY(-2px); box-shadow: 0 8px 25px rgba(217,119,6,0.3); color: white; }
.btn-premium-info { background: linear-gradient(135deg, #0284c7, #0ea5e9); color: white; }
.btn-premium-info:hover { transform: translateY(-2px); box-shadow: 0 8px 25px rgba(2,132,199,0.3); color: white; }
.status-bar {
    background: #f8f9fa;
    border-radius: var(--radius-sm);
    padding: 8px 16px;
    font-size: 0.85rem;
    color: #6c757d;
    margin-top: 10px;
}
[data-theme="dark"] .status-bar { background: #334155; color: #cbd5e1; }
.status-bar.success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
.status-bar.error { background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
.export-toolbar {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
    padding: 12px 16px;
    background: rgba(0,0,0,0.02);
    border-radius: var(--radius-sm);
    margin-bottom: 12px;
    border: 1px solid var(--card-border);
}
[data-theme="dark"] .export-toolbar { background: rgba(255,255,255,0.03); }
.export-toolbar .btn { font-size: 0.78rem; font-weight: 600; }
.print-settings-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
    gap: 10px;
}
.print-settings-grid label {
    font-size: 0.65rem;
    font-weight: 600;
    color: #6c757d;
    text-transform: uppercase;
    margin-bottom: 2px;
    display: block;
}
.print-settings-grid input,
.print-settings-grid select { font-size: 0.8rem; }
.form-control, .form-select {
    background: var(--card);
    color: var(--fg);
    border-color: var(--card-border);
}
[data-theme="dark"] .form-control, [data-theme="dark"] .form-select {
    background: #0f172a;
    color: #e2e8f0;
    border-color: #334155;
}
[data-theme="dark"] .modal-content { background: var(--card); color: var(--fg); }
[data-theme="dark"] .list-group-item { background: var(--card); color: var(--fg); border-color: var(--card-border); }
.toast-container { position: fixed; bottom: 20px; right: 20px; z-index: 99999; }
.label-toast {
    background: var(--card);
    color: var(--fg);
    padding: 12px 18px;
    border-radius: 10px;
    box-shadow: 0 6px 24px rgba(0,0,0,.15);
    border-left: 4px solid var(--primary);
    margin-top: 8px;
    animation: slideIn .3s ease;
    max-width: 380px;
}
@keyframes slideIn { from { transform: translateX(120%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
.collapse-toggle { cursor: pointer; user-select: none; transition: var(--transition); }
.collapse-toggle .toggle-icon { transition: transform .3s; }
.collapse-toggle.collapsed .toggle-icon { transform: rotate(-90deg); }
.collapse-body { transition: max-height .3s ease; overflow: hidden; }
.collapse-body.collapsed { max-height: 0 !important; padding: 0 !important; margin: 0 !important; }
.preset-chip {
    display: inline-block;
    padding: 4px 12px;
    border-radius: 20px;
    background: rgba(26,42,108,0.08);
    color: var(--primary);
    font-size: .72rem;
    font-weight: 600;
    cursor: pointer;
    margin: 2px;
    transition: var(--transition);
}
.preset-chip:hover { background: rgba(26,42,108,0.15); }
.spine-block-badge {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 22px; height: 22px;
    border-radius: 50%;
    background: var(--primary);
    color: white;
    font-size: .7rem;
    font-weight: 700;
}
@media (max-width: 768px) {
    .app-header { padding: 16px 20px; }
    .app-header h1 { font-size: 1.3rem; }
    .app-header .header-left .icon-wrapper { width: 44px; height: 44px; font-size: 20px; }
    .label-tabs .nav-link { padding: 8px 14px; font-size: 0.8rem; }
    .card-premium .card-body-premium { padding: 14px 16px; }
}
@media (max-width: 480px) {
    body { padding: 10px; }
    .label-tabs .nav-link { padding: 6px 10px; font-size: 0.7rem; }
    .label-tabs .nav-link i { margin-right: 4px; }
}
#printPreviewModal .modal-dialog { max-width: 95vw; }
#printPreviewModal .modal-body {
    background: #f0f2f5;
    padding: 20px;
    max-height: 75vh;
    overflow-y: auto;
}
#printPreviewModal .preview-page {
    background: white;
    box-shadow: 0 4px 20px rgba(0,0,0,0.15);
    margin: 0 auto 20px;
    position: relative;
}
@media print {
    .no-print { display: none !important; }
    body { background: white !important; padding: 0 !important; }
    .app-header, .label-tabs, .export-toolbar,
    .print-settings-grid, .status-bar, .card-premium:not(.print-keep) {
        display: none !important;
    }
    .label-preview-container { border: none !important; padding: 0 !important; max-height: none !important; }
    .label-item { break-inside: avoid; }
}
</style>
</head>
<body>

<!-- ============================================================
HEADER
============================================================ -->
<div class="app-header no-print">
    <div class="header-content">
        <div class="header-left">
            <div class="icon-wrapper"><i class="fas fa-tags"></i></div>
            <div>
                <h1>Barcode &amp; Label Generator</h1>
                <p>Professional Library Label Management — v5.2</p>
            </div>
        </div>
        <div class="d-flex align-items-center gap-3 flex-wrap">
            <span class="badge-version"><i class="fas fa-code-branch me-1"></i> v5.2</span>
            <span class="koha-status">
                <i class="fas fa-database me-1"></i>
                Koha: <span id="kohaStatus" class="<?= $kohaConnected ? 'connected' : 'disconnected' ?>">
                    <?= $kohaConnected ? '✓ Connected' : '✗ Offline' ?>
                </span>
            </span>
            <span class="badge-version" style="background:rgba(255,255,255,0.1);color:white;border-color:rgba(255,255,255,0.2);">
                <i class="fas fa-book me-1"></i> <span id="bookCount"><?= count($books) ?></span> books
            </span>
            <button class="btn btn-light btn-sm" style="background:rgba(255,255,255,0.1);color:white;border-color:rgba(255,255,255,0.2);" onclick="toggleTheme()" title="Toggle dark mode">
                <i class="fas fa-moon" id="themeIcon"></i>
            </button>
            <a href="../index.php" class="btn btn-light btn-sm" style="background:rgba(255,255,255,0.1);color:white;border-color:rgba(255,255,255,0.2);">
                <i class="fas fa-home me-1"></i> Home
            </a>
        </div>
    </div>
</div>

<?php if (!$kohaConnected): ?>
<div class="alert alert-warning no-print">
    <i class="fas fa-exclamation-triangle me-2"></i>
    <strong>Koha not connected.</strong> Using sample data.
    <?php if (!empty($kohaError)): ?><br><small>Error: <?= htmlspecialchars($kohaError) ?></small><?php endif; ?>
</div>
<?php endif; ?>

<!-- ============================================================
LABEL TYPE TABS
============================================================ -->
<ul class="nav label-tabs no-print" role="tablist">
    <li class="nav-item">
        <button class="nav-link active" data-bs-toggle="tab" data-bs-target="#barcode-labels" data-labeltype="barcode">
            <i class="fas fa-barcode"></i> Barcode Labels
        </button>
    </li>
    <li class="nav-item">
        <button class="nav-link" data-bs-toggle="tab" data-bs-target="#qrcode-labels" data-labeltype="qrcode">
            <i class="fas fa-qrcode"></i> QR Codes
        </button>
    </li>
    <li class="nav-item">
        <button class="nav-link" data-bs-toggle="tab" data-bs-target="#spine-labels" data-labeltype="spine">
            <i class="fas fa-book"></i> Spine Labels
        </button>
    </li>
    <li class="nav-item">
        <button class="nav-link" data-bs-toggle="tab" data-bs-target="#shelf-labels" data-labeltype="shelf">
            <i class="fas fa-tag"></i> Shelf Labels
        </button>
    </li>
    <li class="nav-item">
        <button class="nav-link" data-bs-toggle="tab" data-bs-target="#category-labels" data-labeltype="category">
            <i class="fas fa-folder"></i> Category Labels
        </button>
    </li>
</ul>

<!-- ============================================================
GLOBAL PRINT SETTINGS PANEL
============================================================ -->
<div class="card-premium no-print">
    <div class="card-header-premium collapse-toggle" onclick="toggleCollapse('printSettingsBody', this)">
        <i class="fas fa-chevron-down toggle-icon"></i>
        <i class="fas fa-sliders-h"></i> Print Settings
        <span class="ms-auto d-flex gap-2 align-items-center" style="font-size:0.7rem;font-weight:400;color:#6c757d;">
            <span class="preset-chip" onclick="event.stopPropagation(); applyPreset('avery5160')">Avery 5160</span>
            <span class="preset-chip" onclick="event.stopPropagation(); applyPreset('avery5163')">Avery 5163</span>
            <span class="preset-chip" onclick="event.stopPropagation(); applyPreset('avery5167')">Avery 5167</span>
            <span><i class="fas fa-save"></i> Saved to session</span>
        </span>
    </div>
    <div class="card-body-premium collapse-body" id="printSettingsBody">
        <form method="POST" id="printSettingsForm">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($CSRF) ?>">
            <div class="print-settings-grid">
                <div>
                    <label>Page Size</label>
                    <select name="print_page_size" class="form-select form-select-sm">
                        <?php foreach (['A4','Letter','Legal','A3'] as $ps): ?>
                            <option value="<?= $ps ?>" <?= $p['page_size']==$ps?'selected':'' ?>><?= $ps ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div>
                    <label>Orientation</label>
                    <select name="print_orientation" class="form-select form-select-sm">
                        <option value="portrait" <?= $p['orientation']=='portrait'?'selected':'' ?>>Portrait</option>
                        <option value="landscape" <?= $p['orientation']=='landscape'?'selected':'' ?>>Landscape</option>
                    </select>
                </div>
                <div><label>Margin Top (mm)</label>
                    <input type="number" name="print_margin_top" class="form-control form-control-sm" value="<?= $p['margin_top'] ?>" min="0" max="50"></div>
                <div><label>Margin Bottom (mm)</label>
                    <input type="number" name="print_margin_bottom" class="form-control form-control-sm" value="<?= $p['margin_bottom'] ?>" min="0" max="50"></div>
                <div><label>Margin Left (mm)</label>
                    <input type="number" name="print_margin_left" class="form-control form-control-sm" value="<?= $p['margin_left'] ?>" min="0" max="50"></div>
                <div><label>Margin Right (mm)</label>
                    <input type="number" name="print_margin_right" class="form-control form-control-sm" value="<?= $p['margin_right'] ?>" min="0" max="50"></div>
                <div><label>Columns</label>
                    <input type="number" name="print_columns" class="form-control form-control-sm" value="<?= $p['columns'] ?>" min="1" max="10"></div>
                <div><label>Column Gap (mm)</label>
                    <input type="number" name="print_col_gap" class="form-control form-control-sm" value="<?= $p['col_gap'] ?>" min="0" max="30"></div>
                <div><label>Row Gap (mm)</label>
                    <input type="number" name="print_row_gap" class="form-control form-control-sm" value="<?= $p['row_gap'] ?>" min="0" max="30"></div>
                <div><label>Font Family</label>
                    <select name="print_font_family" class="form-select form-select-sm">
                        <?php foreach (['Arial','Helvetica','Times New Roman','Courier New','Georgia','Verdana'] as $f): ?>
                            <option value="<?= $f ?>" <?= $p['font_family']==$f?'selected':'' ?>><?= $f ?></option>
                        <?php endforeach; ?>
                    </select></div>
                <div><label>Font Size (pt)</label>
                    <input type="number" name="print_font_size" class="form-control form-control-sm" value="<?= $p['font_size'] ?>" min="6" max="24"></div>
                <div><label>Font Color</label>
                    <input type="color" name="print_font_color" class="form-control form-control-color form-control-sm" value="<?= $p['font_color'] ?>"></div>
                <div><label>Background</label>
                    <input type="color" name="print_bg_color" class="form-control form-control-color form-control-sm" value="<?= $p['bg_color'] ?>"></div>
                <div><label>Border Color</label>
                    <input type="color" name="print_border_color" class="form-control form-control-color form-control-sm" value="<?= $p['border_color'] ?>"></div>
                <div><label>Border Width (mm)</label>
                    <input type="number" name="print_border_width" class="form-control form-control-sm" value="<?= $p['border_width'] ?>" min="0" max="3" step="0.1"></div>
                <div><label>Show Border</label>
                    <select name="print_show_border" class="form-select form-select-sm">
                        <option value="1" <?= $p['show_border']?'selected':'' ?>>Yes</option>
                        <option value="0" <?= !$p['show_border']?'selected':'' ?>>No</option>
                    </select></div>
                <div><label>Cut Lines</label>
                    <select name="print_show_cut_lines" class="form-select form-select-sm">
                        <option value="1" <?= $p['show_cut_lines']?'selected':'' ?>>Show</option>
                        <option value="0" <?= !$p['show_cut_lines']?'selected':'' ?>>Hide</option>
                    </select></div>
                <div><label>Print Header</label>
                    <select name="print_print_header" class="form-select form-select-sm">
                        <option value="1" <?= $p['print_header']?'selected':'' ?>>Yes</option>
                        <option value="0" <?= !$p['print_header']?'selected':'' ?>>No</option>
                    </select></div>
                <div style="grid-column: span 2;">
                    <label>Header Text (optional)</label>
                    <input type="text" name="print_header_text"
                           class="form-control form-control-sm"
                           value="<?= htmlspecialchars($p['header_text'], ENT_QUOTES, 'UTF-8', false) ?>"
                           placeholder="e.g., <?= htmlspecialchars($institutionName, ENT_QUOTES, 'UTF-8', false) ?>">
                </div>
                <div><label>Scale (%)</label>
                    <input type="number" name="print_scale" class="form-control form-control-sm" value="<?= $p['scale'] ?>" min="50" max="150" step="5"></div>
                <div><label>Offset X (mm)</label>
                    <input type="number" name="print_offset_x" class="form-control form-control-sm" value="<?= $p['offset_x'] ?>" min="-20" max="20" step="0.5"></div>
                <div><label>Offset Y (mm)</label>
                    <input type="number" name="print_offset_y" class="form-control form-control-sm" value="<?= $p['offset_y'] ?>" min="-20" max="20" step="0.5"></div>
            </div>
            <div class="mt-3 d-flex gap-2 flex-wrap">
                <button type="submit" name="save_print_settings" value="1" class="btn-premium btn-premium-primary btn-sm">
                    <i class="fas fa-save me-1"></i> Save Print Settings
                </button>
                <button type="button" class="btn-premium btn-premium-warning btn-sm" onclick="resetPrintSettings()">
                    <i class="fas fa-undo me-1"></i> Reset to Defaults
                </button>
                <button type="button" class="btn-premium btn-premium-info btn-sm" onclick="openTemplates()">
                    <i class="fas fa-bookmark me-1"></i> Templates
                </button>
            </div>
        </form>
    </div>
</div>

<!-- ============================================================
TAB CONTENT
============================================================ -->
<div class="tab-content">

    <!-- ============================================================
    BARCODE LABELS TAB
    ============================================================ -->
    <div class="tab-pane fade show active" id="barcode-labels">
        <div class="row g-4">
            <div class="col-lg-4">
                <div class="card-premium">
                    <div class="card-header-premium">
                        <i class="fas fa-database"></i> Data Source
                    </div>
                    <div class="card-body-premium">
                        <div class="btn-group w-100 mb-2" role="group">
                            <button type="button" class="btn btn-outline-primary btn-sm active source-btn" data-source="koha">Koha</button>
                            <button type="button" class="btn btn-outline-primary btn-sm source-btn" data-source="advanced">Advanced</button>
                            <button type="button" class="btn btn-outline-primary btn-sm source-btn" data-source="csv">Import</button>
                            <button type="button" class="btn btn-outline-primary btn-sm source-btn" data-source="manual">Manual</button>
                            <button type="button" class="btn btn-outline-primary btn-sm source-btn" data-source="paste">Paste</button>
                        </div>

                        <div id="source-koha">
                            <div class="input-group input-group-sm mb-2">
                                <input type="text" id="kohaSearch" class="form-control form-control-sm" placeholder="Search books..." onkeyup="filterBooks()">
                                <button class="btn btn-outline-secondary btn-sm" onclick="filterBooks()"><i class="fas fa-search"></i></button>
                            </div>
                            <div class="mb-2 d-flex gap-2">
                                <button class="btn btn-sm btn-outline-primary" onclick="loadBooksFromKoha()">
                                    <i class="fas fa-sync me-1"></i> Refresh
                                </button>
                                <select id="categoryFilter" class="form-select form-select-sm" onchange="filterBooks()">
                                    <option value="">All Categories</option>
                                    <?php foreach ($categories as $cat): ?>
                                        <option value="<?= htmlspecialchars($cat) ?>"><?= htmlspecialchars($cat) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div id="kohaBookList" class="book-list">
                                <?php foreach ($books as $book): ?>
                                <div class="book-item" data-barcode="<?= htmlspecialchars($book['barcode']) ?>"
                                     data-title="<?= htmlspecialchars($book['title'] ?? '') ?>"
                                     data-author="<?= htmlspecialchars($book['author'] ?? '') ?>"
                                     data-call="<?= htmlspecialchars($book['call_number'] ?? '') ?>"
                                     data-category="<?= htmlspecialchars($book['category'] ?? '') ?>"
                                     data-isbn="<?= htmlspecialchars($book['isbn'] ?? '') ?>"
                                     onclick="toggleBook(this)">
                                    <div class="book-title"><?= htmlspecialchars($book['title'] ?? 'Untitled') ?></div>
                                    <div class="book-meta">
                                        <?= htmlspecialchars($book['barcode']) ?>
                                        <?php if (!empty($book['call_number'])): ?> | <?= htmlspecialchars($book['call_number']) ?><?php endif; ?>
                                        <?php if (!empty($book['author'])): ?> | <?= htmlspecialchars($book['author']) ?><?php endif; ?>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            </div>
                            <div class="mt-2 d-flex gap-1 flex-wrap">
                                <button class="btn btn-sm btn-outline-primary" onclick="selectAllBooks()">Select All</button>
                                <button class="btn btn-sm btn-outline-secondary" onclick="deselectAllBooks()">Deselect</button>
                                <button class="btn btn-sm btn-outline-info" onclick="invertBookSelection()">Invert</button>
                                <button class="btn btn-sm btn-outline-warning" onclick="undoSelection()" id="undoBtn" disabled><i class="fas fa-undo"></i> Undo</button>
                                <button class="btn btn-sm btn-outline-warning" onclick="redoSelection()" id="redoBtn" disabled><i class="fas fa-redo"></i> Redo</button>
                            </div>
                        </div>

                        <div id="source-advanced" style="display:none;">
                            <label class="form-label" style="font-size:0.7rem;font-weight:600;">Advanced Koha Fetch</label>
                            <div class="row g-1">
                                <div class="col-6">
                                    <select id="advItype" class="form-select form-select-sm">
                                        <option value="">All Item Types</option>
                                        <?php foreach ($itemTypes as $it): ?>
                                            <option value="<?= htmlspecialchars($it['itemtype'] ?? '') ?>"><?= htmlspecialchars($it['description'] ?? $it['itemtype'] ?? '') ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-6">
                                    <select id="advBranch" class="form-select form-select-sm">
                                        <option value="">All Branches</option>
                                        <?php foreach ($branches as $b): ?>
                                            <option value="<?= htmlspecialchars($b['branchcode'] ?? '') ?>"><?= htmlspecialchars($b['branchname'] ?? $b['branchcode'] ?? '') ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-6">
                                    <label style="font-size:0.6rem;">Barcode From</label>
                                    <input type="text" id="advBcFrom" class="form-control form-control-sm">
                                </div>
                                <div class="col-6">
                                    <label style="font-size:0.6rem;">Barcode To</label>
                                    <input type="text" id="advBcTo" class="form-control form-control-sm">
                                </div>
                                <div class="col-6">
                                    <label style="font-size:0.6rem;">Accession From</label>
                                    <input type="date" id="advAccFrom" class="form-control form-control-sm">
                                </div>
                                <div class="col-6">
                                    <label style="font-size:0.6rem;">Accession To</label>
                                    <input type="date" id="advAccTo" class="form-control form-control-sm">
                                </div>
                                <div class="col-6">
                                    <label style="font-size:0.6rem;">Limit</label>
                                    <input type="number" id="advLimit" class="form-control form-control-sm" value="500" min="1" max="2000">
                                </div>
                            </div>
                            <button class="btn btn-sm btn-primary mt-2 w-100" onclick="loadAdvancedFetch()">
                                <i class="fas fa-filter me-1"></i> Fetch
                            </button>
                        </div>

                        <div id="source-csv" style="display:none;">
                            <label class="form-label" style="font-size:0.7rem;font-weight:600;">Upload CSV / Excel / JSON / XML / TSV</label>
                            <input type="file" id="csvFile" class="form-control form-control-sm" accept=".csv,.xlsx,.xls,.json,.xml,.tsv,.txt">
                            <button class="btn btn-sm btn-primary mt-2 w-100" onclick="loadImportFile()"><i class="fas fa-upload me-1"></i> Load File</button>
                            <div id="csvStatus" class="status-bar mt-2"></div>
                        </div>

                        <div id="source-manual" style="display:none;">
                            <label style="font-size:0.7rem;font-weight:600;">Manual Entry</label>
                            <div class="row g-1">
                                <div class="col-12"><input type="text" id="manualBarcode" class="form-control form-control-sm" placeholder="Barcode"></div>
                                <div class="col-12"><input type="text" id="manualCall" class="form-control form-control-sm" placeholder="Call Number"></div>
                                <div class="col-12"><input type="text" id="manualTitle" class="form-control form-control-sm" placeholder="Title"></div>
                                <div class="col-12"><input type="text" id="manualAuthor" class="form-control form-control-sm" placeholder="Author"></div>
                                <div class="col-6"><input type="text" id="manualCategory" class="form-control form-control-sm" placeholder="Category"></div>
                                <div class="col-6"><input type="number" id="manualQty" class="form-control form-control-sm" placeholder="Qty" value="1" min="1"></div>
                            </div>
                            <button class="btn btn-sm btn-success mt-2 w-100" onclick="addManualItem()"><i class="fas fa-plus me-1"></i> Add Item</button>
                            <div id="manualList" class="mt-2"></div>
                        </div>

                        <div id="source-paste" style="display:none;">
                            <label style="font-size:0.7rem;font-weight:600;">Paste Values</label>
                            <textarea id="pasteArea" class="form-control form-control-sm" rows="4" placeholder="Barcode, Call Number, Title, Author, Category (one per line)"></textarea>
                            <button class="btn btn-sm btn-primary mt-2 w-100" onclick="loadPaste()"><i class="fas fa-file-import me-1"></i> Load Paste</button>
                        </div>
                    </div>
                </div>

                <div class="card-premium">
                    <div class="card-header-premium collapse-toggle" onclick="toggleCollapse('bcOptionsBody', this)">
                        <i class="fas fa-chevron-down toggle-icon"></i>
                        <i class="fas fa-barcode"></i> Barcode Options
                    </div>
                    <div class="card-body-premium collapse-body" id="bcOptionsBody">
                        <div class="row g-2">
                            <div class="col-6">
                                <label style="font-size:0.65rem;">Height (px)</label>
                                <input type="number" id="bcHeight" class="form-control form-control-sm" value="40" min="20" max="80">
                            </div>
                            <div class="col-6">
                                <label style="font-size:0.65rem;">Width (px)</label>
                                <input type="number" id="bcWidth" class="form-control form-control-sm" value="1.2" step="0.1" min="0.5" max="3">
                            </div>
                            <div class="col-6">
                                <label style="font-size:0.65rem;">Format</label>
                                <select id="bcFormat" class="form-select form-select-sm">
                                    <option value="CODE128">CODE128</option>
                                    <option value="CODE39">CODE39</option>
                                    <option value="EAN13">EAN13</option>
                                    <option value="UPC">UPC</option>
                                    <option value="ITF14">ITF14</option>
                                    <option value="MSI">MSI</option>
                                    <option value="pharmacode">Pharmacode</option>
                                </select>
                            </div>
                            <div class="col-6">
                                <label style="font-size:0.65rem;">Show Value</label>
                                <select id="showValue" class="form-select form-select-sm">
                                    <option value="true">Yes</option>
                                    <option value="false">No</option>
                                </select>
                            </div>
                            <div class="col-6">
                                <label style="font-size:0.65rem;">Quiet Zone</label>
                                <input type="number" id="bcQuiet" class="form-control form-control-sm" value="10" min="0" max="40">
                            </div>
                            <div class="col-6">
                                <label style="font-size:0.65rem;">Text Position</label>
                                <select id="bcTextPos" class="form-select form-select-sm">
                                    <option value="bottom">Bottom</option>
                                    <option value="top">Top</option>
                                </select>
                            </div>
                            <div class="col-6">
                                <label style="font-size:0.65rem;">Text Size (px)</label>
                                <input type="number" id="bcTextSize" class="form-control form-control-sm" value="10" min="6" max="20">
                            </div>
                            <div class="col-6">
                                <label style="font-size:0.65rem;">Line Color</label>
                                <input type="color" id="bcLineColor" class="form-control form-control-color form-control-sm" value="#000000">
                            </div>
                        </div>
                        <hr class="my-2">
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" id="showCall" checked onchange="refreshActivePreview()">
                            <label class="form-check-label" style="font-size:0.8rem;">Show Call Number</label>
                        </div>
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" id="showTitle" checked onchange="refreshActivePreview()">
                            <label class="form-check-label" style="font-size:0.8rem;">Show Title</label>
                        </div>
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" id="showAuthor" onchange="refreshActivePreview()">
                            <label class="form-check-label" style="font-size:0.8rem;">Show Author</label>
                        </div>
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" id="showCategory" onchange="refreshActivePreview()">
                            <label class="form-check-label" style="font-size:0.8rem;">Show Category</label>
                        </div>
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" id="livePreview" checked>
                            <label class="form-check-label" style="font-size:0.8rem;">Live preview (auto-refresh)</label>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-8">
                <div class="card-premium">
                    <div class="card-header-premium">
                        <i class="fas fa-eye"></i> Barcode Label Preview
                        <span class="ms-auto" style="font-size:0.7rem;font-weight:400;color:#6c757d;">
                            <span id="selectedCount">0</span> items selected
                        </span>
                    </div>
                    <div class="card-body-premium">
                        <div class="export-toolbar">
                            <button class="btn-premium btn-premium-primary btn-sm" onclick="generateBarcodePreview()">
                                <i class="fas fa-eye me-1"></i> Generate
                            </button>
                            <button class="btn-premium btn-premium-danger btn-sm" onclick="exportPDF('barcode')">
                                <i class="fas fa-file-pdf me-1"></i> PDF
                            </button>
                            <button class="btn-premium btn-premium-success btn-sm" onclick="exportExcel('barcode')">
                                <i class="fas fa-file-excel me-1"></i> Excel
                            </button>
                            <button class="btn-premium btn-premium-info btn-sm" onclick="exportCSV('barcode')">
                                <i class="fas fa-file-csv me-1"></i> CSV
                            </button>
                            <button class="btn btn-outline-secondary btn-sm" onclick="exportJSON('barcode')">
                                <i class="fas fa-file-code me-1"></i> JSON
                            </button>
                            <button class="btn btn-outline-secondary btn-sm" onclick="exportXML('barcode')">
                                <i class="fas fa-file-code me-1"></i> XML
                            </button>
                            <button class="btn-premium btn-premium-warning btn-sm" onclick="exportPNG('barcode')">
                                <i class="fas fa-image me-1"></i> PNG
                            </button>
                            <button class="btn btn-outline-secondary btn-sm" onclick="showPrintPreview('barcode')">
                                <i class="fas fa-print me-1"></i> Print Preview
                            </button>
                            <button class="btn btn-outline-danger btn-sm" onclick="clearBarcodeSelection()">
                                <i class="fas fa-trash me-1"></i> Clear
                            </button>
                        </div>
                        <div class="label-preview-container" id="barcodePreview">
                            <div class="text-center text-muted py-5" style="width:100%;">
                                <i class="fas fa-barcode fa-3x mb-3 d-block" style="opacity:0.2;"></i>
                                Select books and click Generate
                            </div>
                        </div>
                        <div id="barcodeStatus" class="status-bar mt-2">Ready.</div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ============================================================
    QR CODE LABELS TAB
    ============================================================ -->
    <div class="tab-pane fade" id="qrcode-labels">
        <div class="row g-4">
            <div class="col-lg-4">
                <div class="card-premium">
                    <div class="card-header-premium">
                        <i class="fas fa-qrcode"></i> QR Options
                    </div>
                    <div class="card-body-premium">
                        <div class="row g-2">
                            <div class="col-6">
                                <label style="font-size:0.65rem;">QR Size (px)</label>
                                <input type="number" id="qrSize" class="form-control form-control-sm" value="120" min="60" max="300">
                            </div>
                            <div class="col-6">
                                <label style="font-size:0.65rem;">Error Correction</label>
                                <select id="qrEcc" class="form-select form-select-sm">
                                    <option value="L">L (7%)</option>
                                    <option value="M" selected>M (15%)</option>
                                    <option value="Q">Q (25%)</option>
                                    <option value="H">H (30%)</option>
                                </select>
                            </div>
                            <div class="col-6">
                                <label style="font-size:0.65rem;">QR Color</label>
                                <input type="color" id="qrColor" class="form-control form-control-color form-control-sm" value="#000000">
                            </div>
                            <div class="col-6">
                                <label style="font-size:0.65rem;">BG Color</label>
                                <input type="color" id="qrBg" class="form-control form-control-color form-control-sm" value="#ffffff">
                            </div>
                        </div>
                        <div class="form-check form-switch mt-2">
                            <input class="form-check-input" type="checkbox" id="qrShowValue" checked onchange="refreshActivePreview()">
                            <label class="form-check-label" style="font-size:0.8rem;">Show Value Below</label>
                        </div>
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" id="qrShowTitle" checked onchange="refreshActivePreview()">
                            <label class="form-check-label" style="font-size:0.8rem;">Show Title</label>
                        </div>
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" id="qrShowCall" checked onchange="refreshActivePreview()">
                            <label class="form-check-label" style="font-size:0.8rem;">Show Call Number</label>
                        </div>

                        <hr>
                        <label style="font-size:0.7rem;font-weight:600;">Select Books</label>
                        <div id="qrBookList" class="book-list" style="max-height:240px;">
                            <?php foreach ($books as $book): ?>
                            <div class="book-item" data-barcode="<?= htmlspecialchars($book['barcode']) ?>"
                                 data-title="<?= htmlspecialchars($book['title'] ?? '') ?>"
                                 data-author="<?= htmlspecialchars($book['author'] ?? '') ?>"
                                 data-call="<?= htmlspecialchars($book['call_number'] ?? '') ?>"
                                 onclick="toggleQRBook(this)">
                                <div class="book-title"><?= htmlspecialchars($book['title'] ?? 'Untitled') ?></div>
                                <div class="book-meta"><?= htmlspecialchars($book['barcode']) ?></div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        <div class="mt-2 d-flex gap-1">
                            <button class="btn btn-sm btn-outline-primary" onclick="selectAllQRBooks()">Select All</button>
                            <button class="btn btn-sm btn-outline-secondary" onclick="deselectAllQRBooks()">Deselect</button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-8">
                <div class="card-premium">
                    <div class="card-header-premium">
                        <i class="fas fa-eye"></i> QR Preview
                        <span class="ms-auto small text-muted"><span id="qrCount">0</span> items</span>
                    </div>
                    <div class="card-body-premium">
                        <div class="export-toolbar">
                            <button class="btn-premium btn-premium-primary btn-sm" onclick="generateQRPreview()">
                                <i class="fas fa-eye me-1"></i> Generate
                            </button>
                            <button class="btn-premium btn-premium-danger btn-sm" onclick="exportPDF('qrcode')">
                                <i class="fas fa-file-pdf me-1"></i> PDF
                            </button>
                            <button class="btn-premium btn-premium-success btn-sm" onclick="exportExcel('qrcode')">
                                <i class="fas fa-file-excel me-1"></i> Excel
                            </button>
                            <button class="btn-premium btn-premium-info btn-sm" onclick="exportCSV('qrcode')">
                                <i class="fas fa-file-csv me-1"></i> CSV
                            </button>
                            <button class="btn-premium btn-premium-warning btn-sm" onclick="exportPNG('qrcode')">
                                <i class="fas fa-image me-1"></i> PNG
                            </button>
                        </div>
                        <div class="label-preview-container" id="qrPreview">
                            <div class="text-center text-muted py-5" style="width:100%;">
                                <i class="fas fa-qrcode fa-3x mb-3 d-block" style="opacity:0.2;"></i>
                                Select books and click Generate
                            </div>
                        </div>
                        <div id="qrcodeStatus" class="status-bar mt-2">Ready.</div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ============================================================
    SPINE LABELS TAB
    ============================================================ -->
    <div class="tab-pane fade" id="spine-labels">
        <div class="row g-4">
            <div class="col-lg-4">
                <div class="card-premium">
                    <div class="card-header-premium">
                        <i class="fas fa-book"></i> Select Books
                        <span class="ms-auto small text-muted"><span id="spineCount">0</span> selected</span>
                    </div>
                    <div class="card-body-premium">
                        <div class="input-group input-group-sm mb-2">
                            <input type="text" id="spineSearch" class="form-control form-control-sm"
                                   placeholder="Search title / barcode / call number…"
                                   onkeyup="filterSpineBooks()">
                            <button class="btn btn-outline-secondary btn-sm" onclick="filterSpineBooks()">
                                <i class="fas fa-search"></i>
                            </button>
                        </div>
                        <div id="spineBookList" class="book-list" style="max-height:280px;">
                            <?php foreach ($books as $book): ?>
                            <div class="book-item"
                                 data-barcode="<?= htmlspecialchars($book['barcode']) ?>"
                                 data-title="<?= htmlspecialchars($book['title'] ?? '') ?>"
                                 data-author="<?= htmlspecialchars($book['author'] ?? '') ?>"
                                 data-call="<?= htmlspecialchars($book['call_number'] ?? '') ?>"
                                 data-isbn="<?= htmlspecialchars($book['isbn'] ?? '') ?>"
                                 onclick="toggleSpineBook(this)">
                                <div class="book-title"><?= htmlspecialchars($book['title'] ?? 'Untitled') ?></div>
                                <div class="book-meta">
                                    <?= htmlspecialchars($book['barcode']) ?>
                                    <?php if (!empty($book['call_number'])): ?>
                                        | Call: <?= htmlspecialchars($book['call_number']) ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        <div class="mt-2 d-flex gap-1 flex-wrap">
                            <button class="btn btn-sm btn-outline-primary" onclick="selectAllSpineBooks()">Select All</button>
                            <button class="btn btn-sm btn-outline-secondary" onclick="deselectAllSpineBooks()">Deselect</button>
                            <button class="btn btn-sm btn-outline-info" onclick="invertSpineSelection()">Invert</button>
                        </div>
                    </div>
                </div>

                <div class="card-premium">
                    <div class="card-header-premium collapse-toggle" onclick="toggleCollapse('spineDimsBody', this)">
                        <i class="fas fa-chevron-down toggle-icon"></i>
                        <i class="fas fa-ruler-combined"></i> Spine Dimensions
                    </div>
                    <div class="card-body-premium collapse-body" id="spineDimsBody">
                        <div class="row g-2">
                            <div class="col-6">
                                <label style="font-size:0.65rem;">Width (mm)</label>
                                <input type="number" id="spineWidth" class="form-control form-control-sm"
                                       value="40" min="10" max="120" step="1" oninput="refreshActivePreview()">
                            </div>
                            <div class="col-6">
                                <label style="font-size:0.65rem;">Height (mm)</label>
                                <input type="number" id="spineHeight" class="form-control form-control-sm"
                                       value="180" min="20" max="300" step="1" oninput="refreshActivePreview()">
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card-premium">
                    <div class="card-header-premium collapse-toggle" onclick="toggleCollapse('spineClassBody', this)">
                        <i class="fas fa-chevron-down toggle-icon"></i>
                        <span class="spine-block-badge">1</span>
                        <i class="fas fa-layer-group"></i> Classification Number
                    </div>
                    <div class="card-body-premium collapse-body" id="spineClassBody">
                        <label style="font-size:0.7rem;font-weight:600;">Source</label>
                        <select id="spineClassSource" class="form-select form-select-sm mb-2"
                                onchange="toggleSpineClassSource()">
                            <option value="call" selected>From Koha Call Number</option>
                            <option value="online">Fetch Online (by ISBN)</option>
                            <option value="manual">Manual Entry</option>
                        </select>

                        <div id="spineClassFromCallBox">
                            <label style="font-size:0.65rem;">Extract Rule</label>
                            <select id="spineClassAutoRule" class="form-select form-select-sm mb-2"
                                    onchange="refreshActivePreview()">
                                <option value="first_token" selected>First token (e.g. "005.74")</option>
                                <option value="before_first_space">Everything before first space</option>
                                <option value="first_letters_digits">First letters + digits</option>
                                <option value="full_call">Full call number</option>
                            </select>
                        </div>

                        <div id="spineClassOnlineBox" style="display:none;">
                            <button class="btn btn-sm btn-outline-primary w-100 mb-2"
                                    onclick="fetchClassificationOnline()">
                                <i class="fas fa-cloud-download-alt me-1"></i>
                                Fetch Classification for Selected
                            </button>
                            <div id="spineClassOnlineStatus" class="small text-muted mb-2"></div>
                            <label style="font-size:0.65rem;">Fallback Rule (if online fails)</label>
                            <select id="spineClassOnlineFallback" class="form-select form-select-sm mb-2"
                                    onchange="refreshActivePreview()">
                                <option value="first_token" selected>First token of call number</option>
                                <option value="before_first_space">Before first space</option>
                                <option value="full_call">Full call number</option>
                            </select>
                        </div>

                        <div id="spineClassManualBox" style="display:none;">
                            <label style="font-size:0.65rem;">Manual Classification Number</label>
                            <input type="text" id="spineClassManual" class="form-control form-control-sm mb-2"
                                   placeholder="e.g., 005.74"
                                   oninput="applyManualClassToAll()">
                            <button class="btn btn-sm btn-outline-secondary w-100"
                                    onclick="applyManualClassToAll(true)">
                                <i class="fas fa-check me-1"></i> Apply to All Selected
                            </button>
                        </div>

                        <div class="row g-2 mt-2">
                            <div class="col-6">
                                <label style="font-size:0.65rem;">Font Size (pt)</label>
                                <input type="number" id="spineClassSize" class="form-control form-control-sm"
                                       value="11" min="6" max="24" oninput="refreshActivePreview()">
                            </div>
                            <div class="col-6">
                                <label style="font-size:0.65rem;">Color</label>
                                <input type="color" id="spineClassColor" class="form-control form-control-color form-control-sm"
                                       value="#b91c1c" oninput="refreshActivePreview()">
                            </div>
                        </div>
                        <div class="form-check form-switch mt-2">
                            <input class="form-check-input" type="checkbox" id="spineShowClass"
                                   checked onchange="refreshActivePreview()">
                            <label class="form-check-label" style="font-size:0.8rem;">Show Classification Number</label>
                        </div>
                    </div>
                </div>

                <div class="card-premium">
                    <div class="card-header-premium collapse-toggle" onclick="toggleCollapse('spineAuthorBody', this)">
                        <i class="fas fa-chevron-down toggle-icon"></i>
                        <span class="spine-block-badge">2</span>
                        <i class="fas fa-user-edit"></i> Author / Title Code
                    </div>
                    <div class="card-body-premium collapse-body" id="spineAuthorBody">
                        <p class="small text-muted mb-2">
                            Format: <code>AAA/T</code> — first 3 letters of author (UPPERCASE) / first letter of title (UPPERCASE).
                        </p>

                        <div class="row g-2">
                            <div class="col-6">
                                <label style="font-size:0.65rem;">Author Letters</label>
                                <select id="spineAuthorLength" class="form-select form-select-sm"
                                        onchange="refreshActivePreview()">
                                    <option value="3" selected>3 letters (AAA)</option>
                                    <option value="2">2 letters</option>
                                    <option value="4">4 letters</option>
                                    <option value="1">1 letter</option>
                                </select>
                            </div>
                            <div class="col-6">
                                <label style="font-size:0.65rem;">Separator</label>
                                <input type="text" id="spineAuthorSeparator" class="form-control form-control-sm"
                                       value="/" maxlength="3" oninput="refreshActivePreview()">
                            </div>
                            <div class="col-6">
                                <label style="font-size:0.65rem;">Author Case</label>
                                <select id="spineAuthorCase" class="form-select form-select-sm"
                                        onchange="refreshActivePreview()">
                                    <option value="upper" selected>UPPER</option>
                                    <option value="title">Title</option>
                                    <option value="lower">lower</option>
                                </select>
                            </div>
                            <div class="col-6">
                                <label style="font-size:0.65rem;">Title Case</label>
                                <select id="spineTitleCase" class="form-select form-select-sm"
                                        onchange="refreshActivePreview()">
                                    <option value="upper" selected>UPPER</option>
                                    <option value="title">Title</option>
                                    <option value="lower">lower</option>
                                </select>
                            </div>
                            <div class="col-12">
                                <label style="font-size:0.65rem;">Font Size (pt)</label>
                                <input type="number" id="spineCodeSize" class="form-control form-control-sm"
                                       value="13" min="8" max="24" oninput="refreshActivePreview()">
                            </div>
                        </div>

                        <div class="form-check form-switch mt-2">
                            <input class="form-check-input" type="checkbox" id="spineShowAuthor"
                                   checked onchange="refreshActivePreview()">
                            <label class="form-check-label" style="font-size:0.8rem;">Show Author / Title Code</label>
                        </div>
                    </div>
                </div>

                <div class="card-premium">
                    <div class="card-header-premium collapse-toggle" onclick="toggleCollapse('spineBarcodeBody', this)">
                        <i class="fas fa-chevron-down toggle-icon"></i>
                        <span class="spine-block-badge">3</span>
                        <i class="fas fa-barcode"></i> Barcode
                    </div>
                    <div class="card-body-premium collapse-body" id="spineBarcodeBody">
                        <div class="row g-2">
                            <div class="col-6">
                                <label style="font-size:0.65rem;">Format</label>
                                <select id="spineBarcodeFormat" class="form-select form-select-sm"
                                        onchange="refreshActivePreview()">
                                    <option value="CODE128" selected>CODE128</option>
                                    <option value="CODE39">CODE39</option>
                                    <option value="EAN13">EAN13</option>
                                    <option value="ITF14">ITF14</option>
                                </select>
                            </div>
                            <div class="col-6">
                                <label style="font-size:0.65rem;">Width (% of spine)</label>
                                <input type="number" id="spineBarcodeWidth" class="form-control form-control-sm"
                                       value="85" min="30" max="100" step="5" oninput="refreshActivePreview()">
                            </div>
                            <div class="col-6">
                                <label style="font-size:0.65rem;">Height (px)</label>
                                <input type="number" id="spineBarcodeHeight" class="form-control form-control-sm"
                                       value="25" min="10" max="60" oninput="refreshActivePreview()">
                            </div>
                            <div class="col-6">
                                <label style="font-size:0.65rem;">Show Number</label>
                                <select id="spineBarcodeShowValue" class="form-select form-select-sm"
                                        onchange="refreshActivePreview()">
                                    <option value="true" selected>Yes</option>
                                    <option value="false">No</option>
                                </select>
                            </div>
                            <div class="col-6">
                                <label style="font-size:0.65rem;">Number Font (px)</label>
                                <input type="number" id="spineBarcodeValueSize" class="form-control form-control-sm"
                                       value="9" min="6" max="16" oninput="refreshActivePreview()">
                            </div>
                            <div class="col-6">
                                <label style="font-size:0.65rem;">Number Position</label>
                                <select id="spineBarcodeValuePos" class="form-select form-select-sm"
                                        onchange="refreshActivePreview()">
                                    <option value="below" selected>Below barcode</option>
                                    <option value="above">Above barcode</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-check form-switch mt-2">
                            <input class="form-check-input" type="checkbox" id="spineShowBarcode"
                                   checked onchange="refreshActivePreview()">
                            <label class="form-check-label" style="font-size:0.8rem;">Show Barcode</label>
                        </div>
                    </div>
                </div>

                <div class="card-premium">
                    <div class="card-header-premium collapse-toggle" onclick="toggleCollapse('spineBrandBody', this)">
                        <i class="fas fa-chevron-down toggle-icon"></i>
                        <i class="fas fa-image"></i> Library Branding
                    </div>
                    <div class="card-body-premium collapse-body" id="spineBrandBody">
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" id="spineShowLibraryName"
                                   checked onchange="refreshActivePreview()">
                            <label class="form-check-label" style="font-size:0.8rem;">Show Library Name</label>
                        </div>
                        <div class="row g-2 mt-1" id="spineLibraryNameOptions">
                            <div class="col-12">
                                <label style="font-size:0.65rem;">Library Name</label>
                                <input type="text" id="spineLibraryName" class="form-control form-control-sm"
                                       value="<?= htmlspecialchars($institutionName, ENT_QUOTES, 'UTF-8', false) ?>"
                                       oninput="refreshActivePreview()">
                            </div>
                            <div class="col-4">
                                <label style="font-size:0.65rem;">Font (pt)</label>
                                <input type="number" id="spineLibraryNameSize" class="form-control form-control-sm"
                                       value="9" min="5" max="18" oninput="refreshActivePreview()">
                            </div>
                            <div class="col-4">
                                <label style="font-size:0.65rem;">Color</label>
                                <input type="color" id="spineLibraryNameColor" class="form-control form-control-color form-control-sm"
                                       value="#1a2a6c" oninput="refreshActivePreview()">
                            </div>
                            <div class="col-4">
                                <label style="font-size:0.65rem;">Position</label>
                                <select id="spineLibraryNamePos" class="form-select form-select-sm"
                                        onchange="refreshActivePreview()">
                                    <option value="top" selected>Top</option>
                                    <option value="bottom">Bottom</option>
                                </select>
                            </div>
                        </div>

                        <hr class="my-2">

                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" id="spineShowLogo"
                                   onchange="toggleSpineLogoOptions(); refreshActivePreview();">
                            <label class="form-check-label" style="font-size:0.8rem;">Show Library Logo</label>
                        </div>
                        <div class="row g-2 mt-1" id="spineLogoOptions" style="display:none;">
                            <div class="col-12">
                                <label style="font-size:0.65rem;">Logo Image</label>
                                <input type="file" id="spineLogoFile" class="form-control form-control-sm"
                                       accept="image/*" onchange="loadSpineLogo(event)">
                                <?php if (!empty($institutionLogo)): ?>
                                <div class="mt-1 small text-muted">
                                    Institution logo detected.
                                    <button type="button" class="btn btn-sm btn-outline-primary py-0 px-2 ms-1"
                                            onclick="useInstitutionLogo()">Use it</button>
                                </div>
                                <?php endif; ?>
                            </div>
                            <div class="col-6">
                                <label style="font-size:0.65rem;">Width (mm)</label>
                                <input type="number" id="spineLogoWidth" class="form-control form-control-sm"
                                       value="10" min="4" max="40" step="1" oninput="refreshActivePreview()">
                            </div>
                            <div class="col-6">
                                <label style="font-size:0.65rem;">Position</label>
                                <select id="spineLogoPos" class="form-select form-select-sm"
                                        onchange="refreshActivePreview()">
                                    <option value="top" selected>Top</option>
                                    <option value="bottom">Bottom</option>
                                </select>
                            </div>
                        </div>
                        <div id="spineLogoPreview" class="mt-2 text-center" style="display:none;">
                            <img id="spineLogoPreviewImg"
                                 style="max-height:40px;border:1px solid #ddd;border-radius:4px;padding:2px;">
                            <button type="button" class="btn btn-sm btn-outline-danger ms-1 py-0 px-2"
                                    onclick="clearSpineLogo()">×</button>
                        </div>
                    </div>
                </div>

                <div class="form-check form-switch mt-2">
                    <input class="form-check-input" type="checkbox" id="livePreview" checked>
                    <label class="form-check-label" style="font-size:0.8rem;">Live preview</label>
                </div>
            </div>

            <div class="col-lg-8">
                <div class="card-premium">
                    <div class="card-header-premium">
                        <i class="fas fa-eye"></i> Spine Preview
                        <span class="ms-auto small text-muted"><span id="spineCountDisplay">0</span> items</span>
                    </div>
                    <div class="card-body-premium">
                        <div class="export-toolbar">
                            <button class="btn-premium btn-premium-primary btn-sm" onclick="generateSpineLabels()">
                                <i class="fas fa-eye me-1"></i> Generate
                            </button>
                            <button class="btn-premium btn-premium-danger btn-sm" onclick="exportPDF('spine')">
                                <i class="fas fa-file-pdf me-1"></i> PDF
                            </button>
                            <button class="btn-premium btn-premium-success btn-sm" onclick="exportExcel('spine')">
                                <i class="fas fa-file-excel me-1"></i> Excel
                            </button>
                            <button class="btn-premium btn-premium-info btn-sm" onclick="exportCSV('spine')">
                                <i class="fas fa-file-csv me-1"></i> CSV
                            </button>
                            <button class="btn btn-outline-secondary btn-sm" onclick="exportJSON('spine')">
                                <i class="fas fa-file-code me-1"></i> JSON
                            </button>
                            <button class="btn-premium btn-premium-warning btn-sm" onclick="exportPNG('spine')">
                                <i class="fas fa-image me-1"></i> PNG
                            </button>
                            <button class="btn btn-outline-secondary btn-sm" onclick="showPrintPreview('spine')">
                                <i class="fas fa-print me-1"></i> Print Preview
                            </button>
                        </div>
                        <div class="label-preview-container" id="spinePreview">
                            <div class="text-center text-muted py-5" style="width:100%;">
                                <i class="fas fa-book fa-3x mb-3 d-block" style="opacity:0.2;"></i>
                                Select books and click Generate
                            </div>
                        </div>
                        <div id="spineStatus" class="status-bar mt-2">Ready.</div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ============================================================
    SHELF LABELS TAB
    ============================================================ -->
    <div class="tab-pane fade" id="shelf-labels">
        <div class="row g-4">
            <div class="col-lg-4">
                <div class="card-premium">
                    <div class="card-header-premium">
                        <i class="fas fa-tag"></i> Shelf Label Settings
                    </div>
                    <div class="card-body-premium">
                        <div class="row g-2">
                            <div class="col-6">
                                <label style="font-size:0.65rem;">Width (mm)</label>
                                <input type="number" id="shelfWidth" class="form-control form-control-sm" value="50">
                            </div>
                            <div class="col-6">
                                <label style="font-size:0.65rem;">Height (mm)</label>
                                <input type="number" id="shelfHeight" class="form-control form-control-sm" value="30">
                            </div>
                            <div class="col-6">
                                <label style="font-size:0.65rem;">Font Size (pt)</label>
                                <input type="number" id="shelfFontSize" class="form-control form-control-sm" value="12">
                            </div>
                            <div class="col-6">
                                <label style="font-size:0.65rem;">Quantity</label>
                                <input type="number" id="shelfQty" class="form-control form-control-sm" value="1" min="1">
                            </div>
                        </div>
                        <div class="mt-2">
                            <label style="font-size:0.7rem;font-weight:600;">Call Number *</label>
                            <input type="text" id="shelfCallNumber" class="form-control form-control-sm" placeholder="e.g., QA76.73.P98">
                            <label style="font-size:0.7rem;font-weight:600;margin-top:6px;">Title (optional)</label>
                            <input type="text" id="shelfTitle" class="form-control form-control-sm" placeholder="Title">
                            <label style="font-size:0.7rem;font-weight:600;margin-top:6px;">Subtitle (optional)</label>
                            <input type="text" id="shelfSubtitle" class="form-control form-control-sm" placeholder="Subtitle">
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-8">
                <div class="card-premium">
                    <div class="card-header-premium">
                        <i class="fas fa-eye"></i> Shelf Preview
                    </div>
                    <div class="card-body-premium">
                        <div class="export-toolbar">
                            <button class="btn-premium btn-premium-primary btn-sm" onclick="generateShelfLabels()">
                                <i class="fas fa-eye me-1"></i> Generate
                            </button>
                            <button class="btn-premium btn-premium-danger btn-sm" onclick="exportPDF('shelf')">
                                <i class="fas fa-file-pdf me-1"></i> PDF
                            </button>
                            <button class="btn-premium btn-premium-success btn-sm" onclick="exportExcel('shelf')">
                                <i class="fas fa-file-excel me-1"></i> Excel
                            </button>
                            <button class="btn-premium btn-premium-info btn-sm" onclick="exportCSV('shelf')">
                                <i class="fas fa-file-csv me-1"></i> CSV
                            </button>
                            <button class="btn-premium btn-premium-warning btn-sm" onclick="exportPNG('shelf')">
                                <i class="fas fa-image me-1"></i> PNG
                            </button>
                        </div>
                        <div class="label-preview-container" id="shelfPreview">
                            <div class="text-center text-muted py-5" style="width:100%;">
                                <i class="fas fa-tag fa-3x mb-3 d-block" style="opacity:0.2;"></i>
                                Enter call number and click Generate
                            </div>
                        </div>
                        <div id="shelfStatus" class="status-bar mt-2">Ready.</div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ============================================================
    CATEGORY LABELS TAB
    ============================================================ -->
    <div class="tab-pane fade" id="category-labels">
        <div class="row g-4">
            <div class="col-lg-4">
                <div class="card-premium">
                    <div class="card-header-premium">
                        <i class="fas fa-folder"></i> Category Label Settings
                    </div>
                    <div class="card-body-premium">
                        <div class="row g-2">
                            <div class="col-12">
                                <label style="font-size:0.7rem;font-weight:600;">Select Category</label>
                                <select id="categorySelect" class="form-select form-select-sm">
                                    <option value="">— All Categories —</option>
                                    <?php foreach ($categories as $cat): ?>
                                    <option value="<?= htmlspecialchars($cat) ?>"><?= htmlspecialchars($cat) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-12">
                                <label style="font-size:0.7rem;font-weight:600;">Custom Label (optional)</label>
                                <input type="text" id="categoryLabel" class="form-control form-control-sm" placeholder="Custom label text">
                            </div>
                            <div class="col-6">
                                <label style="font-size:0.65rem;">Width (mm)</label>
                                <input type="number" id="catWidth" class="form-control form-control-sm" value="60">
                            </div>
                            <div class="col-6">
                                <label style="font-size:0.65rem;">Height (mm)</label>
                                <input type="number" id="catHeight" class="form-control form-control-sm" value="40">
                            </div>
                            <div class="col-6">
                                <label style="font-size:0.65rem;">Font Size (pt)</label>
                                <input type="number" id="catFontSize" class="form-control form-control-sm" value="14">
                            </div>
                            <div class="col-6">
                                <label style="font-size:0.65rem;">Font Color</label>
                                <input type="color" id="catFontColor" class="form-control form-control-color form-control-sm" value="#1a2a6c">
                            </div>
                            <div class="col-12">
                                <label style="font-size:0.65rem;">Background Color</label>
                                <input type="color" id="catBgColor" class="form-control form-control-color form-control-sm" value="#f0f2f7">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-8">
                <div class="card-premium">
                    <div class="card-header-premium">
                        <i class="fas fa-eye"></i> Category Preview
                    </div>
                    <div class="card-body-premium">
                        <div class="export-toolbar">
                            <button class="btn-premium btn-premium-primary btn-sm" onclick="generateCategoryLabels()">
                                <i class="fas fa-eye me-1"></i> Generate
                            </button>
                            <button class="btn-premium btn-premium-danger btn-sm" onclick="exportPDF('category')">
                                <i class="fas fa-file-pdf me-1"></i> PDF
                            </button>
                            <button class="btn-premium btn-premium-success btn-sm" onclick="exportExcel('category')">
                                <i class="fas fa-file-excel me-1"></i> Excel
                            </button>
                            <button class="btn-premium btn-premium-info btn-sm" onclick="exportCSV('category')">
                                <i class="fas fa-file-csv me-1"></i> CSV
                            </button>
                            <button class="btn-premium btn-premium-warning btn-sm" onclick="exportPNG('category')">
                                <i class="fas fa-image me-1"></i> PNG
                            </button>
                        </div>
                        <div class="label-preview-container" id="categoryPreview">
                            <div class="text-center text-muted py-5" style="width:100%;">
                                <i class="fas fa-folder fa-3x mb-3 d-block" style="opacity:0.2;"></i>
                                Select category and click Generate
                            </div>
                        </div>
                        <div id="categoryStatus" class="status-bar mt-2">Ready.</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- ============================================================
TEMPLATES MODAL
============================================================ -->
<div class="modal fade" id="templatesModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="fas fa-bookmark me-1"></i> Templates</h5>
                <button class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="mb-2">
                    <label class="form-label">Template Name</label>
                    <div class="input-group">
                        <input type="text" id="templateName" class="form-control" placeholder="e.g., A4 Avery 5160">
                        <button class="btn btn-primary" onclick="saveTemplate()"><i class="fas fa-save"></i> Save</button>
                    </div>
                </div>
                <hr>
                <h6>Saved Templates</h6>
                <div id="templateList" class="list-group"></div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- ============================================================
PRINT PREVIEW MODAL
============================================================ -->
<div class="modal fade" id="printPreviewModal" tabindex="-1">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="fas fa-print me-2"></i> Print Preview</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="printPreviewBody"></div>
            <div class="modal-footer">
                <button class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button class="btn btn-primary" onclick="window.print()"><i class="fas fa-print me-1"></i> Print Now</button>
            </div>
        </div>
    </div>
</div>

<div class="toast-container" id="toastContainer"></div>

<!-- ============================================================
SCRIPTS
============================================================ -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/jsbarcode@3.11.6/dist/JsBarcode.all.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/PapaParse/5.4.1/papaparse.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>

<script>
// ============================================================
// INSTITUTION NAME — injected from PHP as a CLEAN plain string  [CHANGED v5.2]
// ============================================================
window.VMS_INSTITUTION_NAME = <?= json_encode($institutionName, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;

// ============================================================
// GLOBAL STATE
// ============================================================
const CSRF = document.querySelector('meta[name="csrf-token"]').content;
const PRINT_SETTINGS = <?= json_encode($p) ?>;
const INSTITUTION_LOGO = "<?= !empty($institutionLogo) ? $institutionLogo : '' ?>";
const INSTITUTION_NAME = window.VMS_INSTITUTION_NAME;
let manualItems = [];
let kohaBooks = <?= json_encode($books) ?>;
let currentTab = 'barcode';
let undoStack = [];
let redoStack = [];
let spineLogoData = null;
let spineOnlineClassCache = {};

// ============================================================
// UTILITY
// ============================================================
function escapeHtml(s) {
    return String(s || '').replace(/[&<>"']/g, m => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[m]));
}
function showToast(message, type = 'success') {
    const c = document.getElementById('toastContainer');
    const t = document.createElement('div');
    t.className = 'label-toast';
    t.style.borderLeftColor = type === 'error' ? '#ef4444' : (type === 'warning' ? '#f59e0b' : '#10b981');
    t.innerHTML = `<i class="fas ${type === 'error' ? 'fa-exclamation-circle' : (type === 'warning' ? 'fa-exclamation-triangle' : 'fa-check-circle')} me-2"></i>${escapeHtml(message)}`;
    c.appendChild(t);
    setTimeout(() => { t.style.opacity = '0'; t.style.transform = 'translateX(120%)'; setTimeout(() => t.remove(), 300); }, 3500);
}
function setStatus(tabId, msg, isError = false) {
    const el = document.getElementById(tabId + 'Status');
    if (el) { el.textContent = msg; el.className = 'status-bar mt-2 ' + (isError ? 'error' : ''); }
}
function toggleTheme() {
    const cur = document.documentElement.getAttribute('data-theme') || 'light';
    const next = cur === 'dark' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', next);
    localStorage.setItem('labels_theme', next);
    const icon = document.getElementById('themeIcon');
    if (icon) icon.className = next === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
}
(function () {
    const saved = localStorage.getItem('labels_theme') || 'light';
    document.documentElement.setAttribute('data-theme', saved);
    document.addEventListener('DOMContentLoaded', () => {
        const icon = document.getElementById('themeIcon');
        if (icon) icon.className = saved === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
    });
})();
function toggleCollapse(id, header) {
    const el = document.getElementById(id);
    if (!el) return;
    if (el.classList.contains('collapsed')) {
        el.classList.remove('collapsed');
        el.style.maxHeight = el.scrollHeight + 'px';
        header.classList.remove('collapsed');
    } else {
        el.classList.add('collapsed');
        el.style.maxHeight = '0';
        header.classList.add('collapsed');
    }
}

// ============================================================
// SOURCE TOGGLE
// ============================================================
document.querySelectorAll('.source-btn').forEach(btn => {
    btn.addEventListener('click', function () {
        document.querySelectorAll('.source-btn').forEach(b => b.classList.remove('active'));
        this.classList.add('active');
        const source = this.dataset.source;
        ['koha','advanced','csv','manual','paste'].forEach(s => {
            const el = document.getElementById('source-' + s);
            if (el) el.style.display = (s === source) ? 'block' : 'none';
        });
    });
});

// ============================================================
// TAB SWITCHING
// ============================================================
document.querySelectorAll('.label-tabs .nav-link').forEach(btn => {
    btn.addEventListener('shown.bs.tab', function () {
        currentTab = this.dataset.labeltype || 'barcode';
    });
});

// ============================================================
// SELECTION + UNDO/REDO
// ============================================================
function pushSelectionSnapshot() {
    const list = document.querySelectorAll('#kohaBookList .book-item');
    undoStack.push(Array.from(list).map(el => el.classList.contains('selected')));
    if (undoStack.length > 50) undoStack.shift();
    redoStack = [];
    updateUndoRedoBtns();
}
function applySelectionSnapshot(snap) {
    const list = document.querySelectorAll('#kohaBookList .book-item');
    snap.forEach((sel, i) => { if (list[i]) list[i].classList.toggle('selected', sel); });
    updateSelectedCount();
}
function undoSelection() {
    if (!undoStack.length) return;
    const cur = Array.from(document.querySelectorAll('#kohaBookList .book-item')).map(el => el.classList.contains('selected'));
    redoStack.push(cur);
    applySelectionSnapshot(undoStack.pop());
    updateUndoRedoBtns();
}
function redoSelection() {
    if (!redoStack.length) return;
    const cur = Array.from(document.querySelectorAll('#kohaBookList .book-item')).map(el => el.classList.contains('selected'));
    undoStack.push(cur);
    applySelectionSnapshot(redoStack.pop());
    updateUndoRedoBtns();
}
function updateUndoRedoBtns() {
    const u = document.getElementById('undoBtn'), r = document.getElementById('redoBtn');
    if (u) u.disabled = !undoStack.length;
    if (r) r.disabled = !redoStack.length;
}

function toggleBook(el) {
    pushSelectionSnapshot();
    el.classList.toggle('selected');
    updateSelectedCount();
    refreshActivePreview();
}
function toggleSpineBook(el) { el.classList.toggle('selected'); updateSpineCount(); refreshActivePreview(); }
function toggleQRBook(el) { el.classList.toggle('selected'); updateQRCount(); refreshActivePreview(); }

function filterBooks() {
    const term = document.getElementById('kohaSearch').value.toLowerCase();
    const cat = document.getElementById('categoryFilter')?.value || '';
    document.querySelectorAll('#kohaBookList .book-item').forEach(item => {
        const text = item.textContent.toLowerCase();
        const itemCat = item.dataset.category || '';
        const ok = text.includes(term) && (!cat || itemCat === cat);
        item.style.display = ok ? '' : 'none';
    });
}

function selectAllBooks() {
    pushSelectionSnapshot();
    document.querySelectorAll('#kohaBookList .book-item').forEach(i => { if (i.style.display !== 'none') i.classList.add('selected'); });
    updateSelectedCount(); refreshActivePreview();
}
function deselectAllBooks() {
    pushSelectionSnapshot();
    document.querySelectorAll('#kohaBookList .book-item').forEach(i => i.classList.remove('selected'));
    updateSelectedCount(); refreshActivePreview();
}
function invertBookSelection() {
    pushSelectionSnapshot();
    document.querySelectorAll('#kohaBookList .book-item').forEach(i => { if (i.style.display !== 'none') i.classList.toggle('selected'); });
    updateSelectedCount(); refreshActivePreview();
}
function selectAllSpineBooks() { document.querySelectorAll('#spineBookList .book-item').forEach(i => i.classList.add('selected')); updateSpineCount(); refreshActivePreview(); }
function deselectAllSpineBooks() { document.querySelectorAll('#spineBookList .book-item').forEach(i => i.classList.remove('selected')); updateSpineCount(); refreshActivePreview(); }
function selectAllQRBooks() { document.querySelectorAll('#qrBookList .book-item').forEach(i => i.classList.add('selected')); updateQRCount(); refreshActivePreview(); }
function deselectAllQRBooks() { document.querySelectorAll('#qrBookList .book-item').forEach(i => i.classList.remove('selected')); updateQRCount(); refreshActivePreview(); }

function updateSelectedCount() { const n = document.querySelectorAll('#kohaBookList .book-item.selected').length; const el = document.getElementById('selectedCount'); if (el) el.textContent = n; }
function updateSpineCount() {
    const n = document.querySelectorAll('#spineBookList .book-item.selected').length;
    const a = document.getElementById('spineCount'); if (a) a.textContent = n;
    const b = document.getElementById('spineCountDisplay'); if (b) b.textContent = n;
}
function updateQRCount() { const el = document.getElementById('qrCount'); if (el) el.textContent = document.querySelectorAll('#qrBookList .book-item.selected').length; }

function getSelectedBooks() {
    return Array.from(document.querySelectorAll('#kohaBookList .book-item.selected')).map(item => ({
        barcode: item.dataset.barcode, title: item.dataset.title, author: item.dataset.author,
        call_number: item.dataset.call, category: item.dataset.category, isbn: item.dataset.isbn || ''
    }));
}
function getSelectedSpineBooks() {
    return Array.from(document.querySelectorAll('#spineBookList .book-item.selected')).map(item => ({
        barcode: item.dataset.barcode, title: item.dataset.title, author: item.dataset.author,
        call_number: item.dataset.call, isbn: item.dataset.isbn || ''
    }));
}
function getSelectedQRBooks() {
    return Array.from(document.querySelectorAll('#qrBookList .book-item.selected')).map(item => ({
        barcode: item.dataset.barcode, title: item.dataset.title, author: item.dataset.author,
        call_number: item.dataset.call
    }));
}

// ============================================================
// LOAD FROM KOHA
// ============================================================
async function loadBooksFromKoha() {
    try {
        const res = await fetch(window.location.href + '?ajax_action=all_books');
        const data = await res.json();
        kohaBooks = data;
        renderKohaBooks();
        document.getElementById('bookCount').textContent = data.length;
        showToast(`Loaded ${data.length} books from Koha`);
    } catch (e) { showToast('Failed to load books: ' + e.message, 'error'); }
}
function renderKohaBooks() {
    const container = document.getElementById('kohaBookList');
    if (!kohaBooks.length) { container.innerHTML = '<div class="text-center text-muted py-3">No books available</div>'; return; }
    container.innerHTML = kohaBooks.map(book => `
        <div class="book-item"
             data-barcode="${escapeHtml(book.barcode)}"
             data-title="${escapeHtml(book.title || '')}"
             data-author="${escapeHtml(book.author || '')}"
             data-call="${escapeHtml(book.call_number || '')}"
             data-category="${escapeHtml(book.category || '')}"
             data-isbn="${escapeHtml(book.isbn || '')}"
             onclick="toggleBook(this)">
            <div class="book-title">${escapeHtml(book.title || 'Untitled')}</div>
            <div class="book-meta">
                ${escapeHtml(book.barcode)}
                ${book.call_number ? ' | ' + escapeHtml(book.call_number) : ''}
                ${book.author ? ' | ' + escapeHtml(book.author) : ''}
            </div>
        </div>
    `).join('');
}

async function loadAdvancedFetch() {
    const formData = new FormData();
    formData.append('ajax_action', 'fetch_advanced');
    formData.append('csrf', CSRF);
    formData.append('itype', document.getElementById('advItype').value);
    formData.append('homebranch', document.getElementById('advBranch').value);
    formData.append('bc_from', document.getElementById('advBcFrom').value);
    formData.append('bc_to', document.getElementById('advBcTo').value);
    formData.append('acc_from', document.getElementById('advAccFrom').value);
    formData.append('acc_to', document.getElementById('advAccTo').value);
    formData.append('limit', document.getElementById('advLimit').value);
    try {
        const res = await fetch(window.location.href, { method: 'POST', body: formData });
        const data = await res.json();
        if (data.success) {
            kohaBooks = data.books;
            renderKohaBooks();
            document.getElementById('bookCount').textContent = data.books.length;
            showToast(`Fetched ${data.books.length} books`);
        } else {
            showToast('Fetch failed: ' + (data.error || ''), 'error');
        }
    } catch (e) { showToast('Fetch failed: ' + e.message, 'error'); }
}

// ============================================================
// MANUAL ENTRY
// ============================================================
function addManualItem() {
    const barcode = document.getElementById('manualBarcode').value.trim();
    const call = document.getElementById('manualCall').value.trim();
    const title = document.getElementById('manualTitle').value.trim();
    const author = document.getElementById('manualAuthor').value.trim();
    const category = document.getElementById('manualCategory').value.trim();
    const qty = parseInt(document.getElementById('manualQty').value) || 1;
    if (!barcode && !title) { showToast('Enter barcode or title', 'error'); return; }
    for (let i = 0; i < qty; i++) {
        manualItems.push({
            barcode: barcode || `MANUAL-${Date.now()}-${i}`,
            call_number: call, title: title || 'Manual Entry', author, category
        });
    }
    renderManualList();
    ['manualBarcode','manualCall','manualTitle','manualAuthor','manualCategory'].forEach(id => document.getElementById(id).value = '');
    setStatus('barcode', `Added ${qty} manual item(s)`);
    refreshActivePreview();
}
function renderManualList() {
    const container = document.getElementById('manualList');
    if (!container) return;
    if (!manualItems.length) { container.innerHTML = '<div class="text-muted small">No manual items added.</div>'; return; }
    container.innerHTML = manualItems.map((item, i) => `
        <div class="d-flex justify-content-between align-items-center border-bottom py-1">
            <span class="small">${escapeHtml(item.barcode)} - ${escapeHtml(item.title)}</span>
            <button class="btn btn-sm btn-outline-danger" onclick="removeManualItem(${i})"><i class="fas fa-times"></i></button>
        </div>
    `).join('');
}
function removeManualItem(i) { manualItems.splice(i, 1); renderManualList(); refreshActivePreview(); }

// ============================================================
// IMPORT
// ============================================================
async function loadImportFile() {
    const file = document.getElementById('csvFile').files[0];
    if (!file) { showToast('Select a file', 'error'); return; }
    const name = file.name.toLowerCase();
    let data = [];
    try {
        if (name.endsWith('.csv') || name.endsWith('.tsv') || name.endsWith('.txt')) {
            const result = await new Promise(resolve => Papa.parse(file, { header: true, skipEmptyLines: true, complete: resolve }));
            data = result.data;
        } else if (name.endsWith('.xlsx') || name.endsWith('.xls')) {
            const reader = new FileReader();
            data = await new Promise(resolve => {
                reader.onload = e => {
                    const wb = XLSX.read(e.target.result, { type: 'array' });
                    const sheet = wb.Sheets[wb.SheetNames[0]];
                    resolve(XLSX.utils.sheet_to_json(sheet, { defval: '' }));
                };
                reader.readAsArrayBuffer(file);
            });
        } else if (name.endsWith('.json')) {
            const text = await file.text();
            const parsed = JSON.parse(text);
            data = Array.isArray(parsed) ? parsed : (parsed.books || parsed.items || []);
        } else if (name.endsWith('.xml')) {
            const text = await file.text();
            const parser = new DOMParser();
            const xml = parser.parseFromString(text, 'application/xml');
            xml.querySelectorAll('book, item, record, label').forEach(it => {
                const obj = {};
                ['barcode','title','author','call_number','category','isbn'].forEach(k => {
                    const el = it.querySelector(k);
                    if (el) obj[k] = el.textContent;
                });
                data.push(obj);
            });
        }
    } catch (e) { showToast('Parse error: ' + e.message, 'error'); return; }

    let count = 0;
    data.forEach(row => {
        const barcode = row.barcode || row.Barcode || row.id || row.ID || '';
        const title = row.title || row.Title || row.name || '';
        const author = row.author || row.Author || '';
        const call = row.call_number || row.callnumber || row['Call Number'] || '';
        const category = row.category || row.Category || '';
        const isbn = row.isbn || row.ISBN || '';
        if (barcode || title) {
            manualItems.push({
                barcode: String(barcode || `IMPORT-${Date.now()}-${count}`),
                call_number: String(call), title: String(title || 'Untitled'),
                author: String(author), category: String(category), isbn: String(isbn)
            });
            count++;
        }
    });
    renderManualList();
    setStatus('barcode', `Imported ${count} items`);
    document.getElementById('csvStatus').textContent = `✓ ${count} items imported`;
    showToast(`Imported ${count} items`);
    refreshActivePreview();
}

function loadPaste() {
    const text = document.getElementById('pasteArea').value.trim();
    if (!text) { showToast('Paste some data', 'error'); return; }
    let count = 0;
    text.split('\n').map(l => l.trim()).filter(Boolean).forEach(line => {
        const parts = line.split(',').map(p => p.trim());
        if (parts[0] || parts[2]) {
            manualItems.push({
                barcode: parts[0] || `PASTE-${Date.now()}-${count}`,
                call_number: parts[1] || '', title: parts[2] || 'Untitled',
                author: parts[3] || '', category: parts[4] || ''
            });
            count++;
        }
    });
    renderManualList();
    document.getElementById('pasteArea').value = '';
    setStatus('barcode', `Loaded ${count} items`);
    showToast(`Loaded ${count} items`);
    refreshActivePreview();
}

// ============================================================
// SPINE — classification helpers
// ============================================================
function applyClassRule(call, rule) {
    call = String(call || '').trim();
    if (!call) return '';
    switch (rule) {
        case 'first_token':          return call.split(/\s+/)[0] || '';
        case 'before_first_space':   { const i = call.indexOf(' '); return i === -1 ? call : call.substring(0, i); }
        case 'first_letters_digits': { const m = call.match(/^([A-Za-z]+[\d.]+)/); return m ? m[1] : (call.split(/\s+/)[0] || ''); }
        case 'full_call':
        default:                     return call;
    }
}
function getSpineClassification(book) {
    const src = document.getElementById('spineClassSource')?.value || 'call';
    const item = document.querySelector(`#spineBookList .book-item[data-barcode="${CSS.escape(book.barcode)}"]`);
    if (item && item.dataset.classOverride) return item.dataset.classOverride;

    if (src === 'manual') {
        return String(document.getElementById('spineClassManual').value || '').trim();
    }
    if (src === 'online') {
        const isbn = String(book.isbn || '').replace(/[^0-9Xx]/g, '');
        if (isbn && spineOnlineClassCache[isbn]) return spineOnlineClassCache[isbn];
        const fbRule = document.getElementById('spineClassOnlineFallback').value;
        return applyClassRule(book.call_number, fbRule);
    }
    const rule = document.getElementById('spineClassAutoRule').value;
    return applyClassRule(book.call_number, rule);
}
function applyManualClassToAll(explicit) {
    const val = document.getElementById('spineClassManual').value;
    if (explicit || val) {
        document.querySelectorAll('#spineBookList .book-item.selected').forEach(item => {
            item.dataset.classOverride = val;
        });
    }
    refreshActivePreview();
}

function toggleSpineClassSource() {
    const src = document.getElementById('spineClassSource').value;
    document.getElementById('spineClassFromCallBox').style.display = (src === 'call')   ? 'block' : 'none';
    document.getElementById('spineClassOnlineBox').style.display  = (src === 'online') ? 'block' : 'none';
    document.getElementById('spineClassManualBox').style.display  = (src === 'manual') ? 'block' : 'none';
    refreshActivePreview();
}

async function fetchClassificationOnline() {
    const books = getSelectedSpineBooks();
    if (!books.length) { showToast('Select books first', 'error'); return; }
    const status = document.getElementById('spineClassOnlineStatus');
    let done = 0, failed = 0;
    status.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Looking up…';
    for (const book of books) {
        const isbn = String(book.isbn || '').replace(/[^0-9Xx]/g, '');
        if (!isbn) { failed++; continue; }
        if (spineOnlineClassCache[isbn]) { done++; continue; }
        try {
            const fd = new FormData();
            fd.append('ajax_action', 'online_classification');
            fd.append('csrf', CSRF);
            fd.append('isbn', isbn);
            fd.append('call_number', book.call_number || '');
            const r = await fetch(window.location.href, { method: 'POST', body: fd });
            const j = await r.json();
            if (j.success && j.classification) {
                spineOnlineClassCache[isbn] = j.classification;
                done++;
            } else {
                spineOnlineClassCache[isbn] = applyClassRule(book.call_number, document.getElementById('spineClassOnlineFallback').value);
                failed++;
            }
        } catch (e) {
            spineOnlineClassCache[isbn] = applyClassRule(book.call_number, document.getElementById('spineClassOnlineFallback').value);
            failed++;
        }
    }
    status.innerHTML = `<i class="fas fa-check text-success"></i> ${done} fetched, ${failed} fell back to call number.`;
    refreshActivePreview();
}

// ============================================================
// SPINE — logo helpers
// ============================================================
function toggleSpineLogoOptions() {
    const on = document.getElementById('spineShowLogo').checked;
    document.getElementById('spineLogoOptions').style.display = on ? 'block' : 'none';
    document.getElementById('spineLogoPreview').style.display = (on && spineLogoData) ? 'block' : 'none';
}
function loadSpineLogo(evt) {
    const file = evt.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = e => {
        spineLogoData = e.target.result;
        const img = document.getElementById('spineLogoPreviewImg');
        img.src = spineLogoData;
        document.getElementById('spineLogoPreview').style.display = 'block';
        refreshActivePreview();
    };
    reader.readAsDataURL(file);
}
function useInstitutionLogo() {
    if (!INSTITUTION_LOGO) { showToast('No institution logo configured', 'error'); return; }
    spineLogoData = INSTITUTION_LOGO;
    const img = document.getElementById('spineLogoPreviewImg');
    img.src = spineLogoData;
    document.getElementById('spineLogoPreview').style.display = 'block';
    refreshActivePreview();
}
function clearSpineLogo() {
    spineLogoData = null;
    document.getElementById('spineLogoPreview').style.display = 'none';
    refreshActivePreview();
}

// ============================================================
// SPINE — code helpers
// ============================================================
function extractAuthorCode(author, length, caseStyle) {
    author = String(author || '').trim();
    if (!author) return 'XXX';
    const parts = author.split(/\s+/);
    const surname = parts[parts.length - 1] || parts[0] || '';
    let code = surname.substring(0, parseInt(length) || 3);
    if (caseStyle === 'upper') code = code.toUpperCase();
    else if (caseStyle === 'lower') code = code.toLowerCase();
    else if (caseStyle === 'title') code = code.charAt(0).toUpperCase() + code.slice(1).toLowerCase();
    return code || 'XXX';
}
function extractTitleFirstLetter(title, caseStyle) {
    title = String(title || '').trim();
    if (!title) return '?';
    title = title.replace(/^(the|a|an)\s+/i, '');
    let c = title.charAt(0);
    if (caseStyle === 'upper' || caseStyle === 'title') c = c.toUpperCase();
    else if (caseStyle === 'lower') c = c.toLowerCase();
    return c || '?';
}

// ============================================================
// SPINE — MAIN RENDERER
// ============================================================
function generateSpineLabels() {
    const books = getSelectedSpineBooks();
    const container = document.getElementById('spinePreview');
    if (!container) return;

    if (!books.length) {
        container.innerHTML = '<div class="text-center text-muted py-5" style="width:100%;"><i class="fas fa-book fa-3x mb-3 d-block" style="opacity:0.2;"></i>Select books and click Generate</div>';
        document.getElementById('spineCountDisplay').textContent = 0;
        return;
    }

    const width        = parseInt(document.getElementById('spineWidth').value) || 40;
    const height       = parseInt(document.getElementById('spineHeight').value) || 180;

    const showClass    = document.getElementById('spineShowClass').checked;
    const classSize    = parseInt(document.getElementById('spineClassSize').value) || 11;
    const classColor   = document.getElementById('spineClassColor').value || '#b91c1c';

    const showAuthor   = document.getElementById('spineShowAuthor').checked;
    const authorLength = document.getElementById('spineAuthorLength').value;
    const authorCase   = document.getElementById('spineAuthorCase').value;
    const titleCase    = document.getElementById('spineTitleCase').value;
    const separator    = document.getElementById('spineAuthorSeparator').value || '/';
    const codeSize     = parseInt(document.getElementById('spineCodeSize').value) || 13;

    const showBarcode  = document.getElementById('spineShowBarcode').checked;
    const bcFormat     = document.getElementById('spineBarcodeFormat').value;
    const bcWidthPct   = parseInt(document.getElementById('spineBarcodeWidth').value) || 85;
    const bcHeightPx   = parseInt(document.getElementById('spineBarcodeHeight').value) || 25;
    const bcShowValue  = document.getElementById('spineBarcodeShowValue').value === 'true';
    const bcValueSize  = parseInt(document.getElementById('spineBarcodeValueSize').value) || 9;
    const bcValuePos   = document.getElementById('spineBarcodeValuePos').value || 'below';

    const showLibName  = document.getElementById('spineShowLibraryName').checked;
    const libName      = document.getElementById('spineLibraryName').value.trim();
    const libNameSize  = parseInt(document.getElementById('spineLibraryNameSize').value) || 9;
    const libNameColor = document.getElementById('spineLibraryNameColor').value || '#1a2a6c';
    const libNamePos   = document.getElementById('spineLibraryNamePos').value || 'top';

    const showLogo     = document.getElementById('spineShowLogo').checked;
    const logoWidthMM  = parseInt(document.getElementById('spineLogoWidth').value) || 10;
    const logoPos      = document.getElementById('spineLogoPos').value || 'top';

    container.innerHTML = '';
    document.getElementById('spineCountDisplay').textContent = books.length;

    books.forEach((book, idx) => {
        const label = document.createElement('div');
        label.className = 'label-item spine-label';
        label.style.cssText = `
            width:${width}mm;
            height:${height}mm;
            padding:6px 6px 8px 6px;
            display:flex;
            flex-direction:column;
            align-items:center;
            justify-content:flex-start;
            background:${PRINT_SETTINGS.bg_color};
            border:${PRINT_SETTINGS.border_width}px solid ${PRINT_SETTINGS.border_color};
            font-family:${PRINT_SETTINGS.font_family};
            color:${PRINT_SETTINGS.font_color};
            overflow:hidden;
            position:relative;
            box-sizing:border-box;
        `;

        const topBlocks = [], bottomBlocks = [];

        if (showLogo && spineLogoData) {
            const el = document.createElement('img');
            el.src = spineLogoData;
            el.style.cssText = `max-width:${logoWidthMM}mm;max-height:${logoWidthMM}mm;width:auto;height:auto;object-fit:contain;margin:0 auto 3px auto;display:block;`;
            (logoPos === 'top' ? topBlocks : bottomBlocks).push(el);
        }
        if (showLibName && libName) {
            const el = document.createElement('div');
            el.textContent = libName;
            el.style.cssText = `font-size:${libNameSize}pt;font-weight:700;color:${libNameColor};text-align:center;line-height:1.1;margin:2px 0 3px 0;word-break:break-word;`;
            (libNamePos === 'top' ? topBlocks : bottomBlocks).push(el);
        }

        topBlocks.forEach(el => label.appendChild(el));

        const middle = document.createElement('div');
        middle.style.cssText = `flex:1 1 auto;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:6px;width:100%;text-align:center;`;

        if (showClass) {
            const classification = getSpineClassification(book);
            if (classification) {
                const el = document.createElement('div');
                el.className = 'spine-classification';
                el.textContent = classification;
                el.style.cssText = `font-size:${classSize}pt;font-weight:700;color:${classColor};line-height:1.1;text-align:center;word-break:break-word;`;
                middle.appendChild(el);
            }
        }

        if (showAuthor) {
            const a = extractAuthorCode(book.author, authorLength, authorCase);
            const t = extractTitleFirstLetter(book.title, titleCase);
            const el = document.createElement('div');
            el.className = 'spine-author-title';
            el.textContent = `${a}${separator}${t}`;
            el.style.cssText = `font-size:${codeSize}pt;font-weight:700;line-height:1.1;letter-spacing:.5px;text-align:center;word-break:break-word;`;
            middle.appendChild(el);
        }

        if (showBarcode && book.barcode) {
            const wrap = document.createElement('div');
            wrap.className = 'spine-barcode-wrap';
            wrap.style.cssText = `width:${bcWidthPct}%;display:flex;flex-direction:column;align-items:center;gap:2px;`;

            const svgId = 'spine-bc-' + Date.now() + '-' + idx;
            const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
            svg.setAttribute('id', svgId);
            svg.style.cssText = `width:100%;height:${bcHeightPx}px;display:block;`;

            const valueEl = document.createElement('div');
            valueEl.textContent = book.barcode;
            valueEl.style.cssText = `font-size:${bcValueSize}px;font-family:monospace;text-align:center;word-break:break-all;line-height:1.05;`;

            if (bcValuePos === 'above') { wrap.appendChild(valueEl); wrap.appendChild(svg); }
            else                        { wrap.appendChild(svg);       wrap.appendChild(valueEl); }
            if (!bcShowValue) valueEl.style.display = 'none';

            middle.appendChild(wrap);

            setTimeout(() => {
                try {
                    JsBarcode('#' + svgId, book.barcode, {
                        format: bcFormat,
                        width: 1.4,
                        height: bcHeightPx,
                        displayValue: false,
                        margin: 0
                    });
                } catch (e) {
                    svg.outerHTML = `<div style="font-size:8px;text-align:center;word-break:break-all;">${escapeHtml(book.barcode)}</div>`;
                }
            }, 10);
        }

        label.appendChild(middle);
        bottomBlocks.forEach(el => label.appendChild(el));

        container.appendChild(label);
    });

    setStatus('spine', `Generated ${books.length} spine labels`);
}

// ============================================================
// LIVE PREVIEW
// ============================================================
function refreshActivePreview() {
    if (!document.getElementById('livePreview')?.checked) return;
    if (currentTab === 'barcode') generateBarcodePreview();
    else if (currentTab === 'qrcode') generateQRPreview();
    else if (currentTab === 'spine') generateSpineLabels();
    else if (currentTab === 'shelf') generateShelfLabels();
    else if (currentTab === 'category') generateCategoryLabels();
}

// ============================================================
// OTHER PREVIEWS
// ============================================================
function generateBarcodePreview() {
    const books = getSelectedBooks();
    const all = [...books, ...manualItems];
    if (!all.length) {
        document.getElementById('barcodePreview').innerHTML = '<div class="text-center text-muted py-5" style="width:100%;"><i class="fas fa-barcode fa-3x mb-3 d-block" style="opacity:0.2;"></i>Select books and click Generate</div>';
        return;
    }
    const container = document.getElementById('barcodePreview');
    container.innerHTML = '';
    const showCall = document.getElementById('showCall').checked;
    const showTitle = document.getElementById('showTitle').checked;
    const showAuthor = document.getElementById('showAuthor').checked;
    const showCategory = document.getElementById('showCategory').checked;
    const bcHeight = parseInt(document.getElementById('bcHeight').value) || 40;
    const bcWidth = parseFloat(document.getElementById('bcWidth').value) || 1.2;
    const bcFormat = document.getElementById('bcFormat').value || 'CODE128';
    const bcQuiet = parseInt(document.getElementById('bcQuiet').value) || 0;
    const bcTextPos = document.getElementById('bcTextPos').value || 'bottom';
    const bcTextSize = parseInt(document.getElementById('bcTextSize').value) || 10;
    const bcLineColor = document.getElementById('bcLineColor').value || '#000000';
    const showValue = document.getElementById('showValue').value === 'true';

    all.forEach(item => {
        const label = document.createElement('div');
        label.className = 'label-item';
        label.style.cssText = `background:${PRINT_SETTINGS.bg_color};border-color:${PRINT_SETTINGS.border_color};border-width:${PRINT_SETTINGS.border_width}px;font-family:${PRINT_SETTINGS.font_family};color:${PRINT_SETTINGS.font_color};padding:6px 8px;`;

        if (item.barcode) {
            const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
            svg.style.width = '100%';
            svg.style.height = bcHeight + 'px';
            if (bcTextPos === 'top' && showValue) {
                const topVal = document.createElement('div'); topVal.className = 'label-text';
                topVal.textContent = item.barcode; topVal.style.fontSize = bcTextSize + 'px';
                topVal.style.color = PRINT_SETTINGS.font_color; topVal.style.marginBottom = '2px';
                label.appendChild(topVal);
            }
            label.appendChild(svg);
            try {
                JsBarcode(svg, item.barcode, { format: bcFormat, width: bcWidth, height: bcHeight, displayValue: false, margin: bcQuiet, lineColor: bcLineColor });
            } catch (e) { svg.outerHTML = `<div style="font-size:8px;">${escapeHtml(item.barcode)}</div>`; }
            if (bcTextPos === 'bottom' && showValue) {
                const botVal = document.createElement('div'); botVal.className = 'label-text';
                botVal.textContent = item.barcode; botVal.style.fontSize = bcTextSize + 'px';
                botVal.style.color = PRINT_SETTINGS.font_color;
                label.appendChild(botVal);
            }
        }
        if (showCall && item.call_number) { const c = document.createElement('div'); c.className='label-call'; c.textContent = item.call_number; c.style.color = PRINT_SETTINGS.font_color; label.appendChild(c); }
        if (showTitle && item.title) { const t = document.createElement('div'); t.className='label-text'; t.textContent = item.title; t.style.color = PRINT_SETTINGS.font_color; t.style.fontWeight='600'; label.appendChild(t); }
        if (showAuthor && item.author) { const a = document.createElement('div'); a.className='label-text'; a.textContent = item.author; a.style.color = PRINT_SETTINGS.font_color; a.style.fontStyle='italic'; label.appendChild(a); }
        if (showCategory && item.category) { const c = document.createElement('div'); c.className='label-text'; c.textContent = item.category; c.style.color = PRINT_SETTINGS.font_color; c.style.fontWeight='700'; label.appendChild(c); }
        container.appendChild(label);
    });
    setStatus('barcode', `Generated ${all.length} labels`);
}

function generateQRPreview() {
    const books = getSelectedQRBooks();
    if (!books.length) {
        document.getElementById('qrPreview').innerHTML = '<div class="text-center text-muted py-5" style="width:100%;"><i class="fas fa-qrcode fa-3x mb-3 d-block" style="opacity:0.2;"></i>Select books and click Generate</div>';
        return;
    }
    const container = document.getElementById('qrPreview');
    container.innerHTML = '';
    const size = parseInt(document.getElementById('qrSize').value) || 120;
    const color = document.getElementById('qrColor').value || '#000000';
    const bg = document.getElementById('qrBg').value || '#ffffff';
    const showValue = document.getElementById('qrShowValue').checked;
    const showTitle = document.getElementById('qrShowTitle').checked;
    const showCall = document.getElementById('qrShowCall').checked;
    const ecc = document.getElementById('qrEcc').value || 'M';

    books.forEach((book, idx) => {
        const label = document.createElement('div');
        label.className = 'label-item';
        label.style.cssText = `padding:8px;text-align:center;background:${PRINT_SETTINGS.bg_color};border:${PRINT_SETTINGS.border_width}px solid ${PRINT_SETTINGS.border_color};font-family:${PRINT_SETTINGS.font_family};color:${PRINT_SETTINGS.font_color};`;
        const qrDiv = document.createElement('div');
        qrDiv.id = 'qr-' + Date.now() + '-' + idx;
        qrDiv.style.cssText = `display:inline-block;padding:4px;background:${bg};border-radius:4px;`;
        label.appendChild(qrDiv);
        setTimeout(() => {
            try { new QRCode(document.getElementById(qrDiv.id), { text: book.barcode || '', width: size, height: size, colorDark: color, colorLight: bg, correctLevel: QRCode.CorrectLevel[ecc] || QRCode.CorrectLevel.M }); } catch (e) {}
        }, 10);
        if (showValue && book.barcode) { const v = document.createElement('div'); v.className='label-text'; v.textContent = book.barcode; v.style.fontWeight='600'; label.appendChild(v); }
        if (showCall && book.call_number) { const c = document.createElement('div'); c.className='label-call'; c.textContent = book.call_number; label.appendChild(c); }
        if (showTitle && book.title) { const t = document.createElement('div'); t.className='label-text'; t.textContent = book.title; label.appendChild(t); }
        container.appendChild(label);
    });
    setStatus('qrcode', `Generated ${books.length} QR labels`);
}

function generateShelfLabels() {
    const callNumber = document.getElementById('shelfCallNumber').value.trim();
    const title = document.getElementById('shelfTitle').value.trim();
    const subtitle = document.getElementById('shelfSubtitle').value.trim();
    const qty = parseInt(document.getElementById('shelfQty').value) || 1;
    const width = parseInt(document.getElementById('shelfWidth').value) || 50;
    const height = parseInt(document.getElementById('shelfHeight').value) || 30;
    const fontSize = parseInt(document.getElementById('shelfFontSize').value) || 12;
    if (!callNumber) {
        document.getElementById('shelfPreview').innerHTML = '<div class="text-center text-muted py-5" style="width:100%;"><i class="fas fa-tag fa-3x mb-3 d-block" style="opacity:0.2;"></i>Enter call number and click Generate</div>';
        return;
    }
    const container = document.getElementById('shelfPreview');
    container.innerHTML = '';
    for (let i = 0; i < Math.min(qty, 100); i++) {
        const label = document.createElement('div');
        label.className = 'label-item';
        label.style.cssText = `width:${width}mm;height:${height}mm;padding:6px;text-align:center;background:${PRINT_SETTINGS.bg_color};border:${PRINT_SETTINGS.border_width}px solid ${PRINT_SETTINGS.border_color};font-family:${PRINT_SETTINGS.font_family};display:flex;flex-direction:column;align-items:center;justify-content:center;`;
        const c = document.createElement('div'); c.textContent = callNumber;
        c.style.cssText = `font-size:${fontSize}pt;font-weight:bold;color:${PRINT_SETTINGS.font_color};`;
        label.appendChild(c);
        if (title) { const t = document.createElement('div'); t.textContent = title; t.style.cssText = `font-size:${Math.max(fontSize-2, 8)}pt;color:${PRINT_SETTINGS.font_color};margin-top:2px;`; label.appendChild(t); }
        if (subtitle) { const s = document.createElement('div'); s.textContent = subtitle; s.style.cssText = `font-size:${Math.max(fontSize-4, 7)}pt;color:${PRINT_SETTINGS.font_color};opacity:0.8;margin-top:1px;`; label.appendChild(s); }
        container.appendChild(label);
    }
    setStatus('shelf', `Generated ${Math.min(qty, 100)} shelf labels`);
}

function generateCategoryLabels() {
    const category = document.getElementById('categorySelect').value;
    const customLabel = document.getElementById('categoryLabel').value.trim();
    const width = parseInt(document.getElementById('catWidth').value) || 60;
    const height = parseInt(document.getElementById('catHeight').value) || 40;
    const fontSize = parseInt(document.getElementById('catFontSize').value) || 14;
    const fontColor = document.getElementById('catFontColor').value || '#1a2a6c';
    const bgColor = document.getElementById('catBgColor').value || '#f0f2f7';
    const cats = category ? [category] : ['Fiction', 'Non-Fiction', 'Science', 'Fantasy', 'Classic', 'Reference'];
    const container = document.getElementById('categoryPreview');
    container.innerHTML = '';
    cats.forEach(cat => {
        const label = document.createElement('div');
        label.className = 'label-item';
        label.style.cssText = `width:${width}mm;height:${height}mm;background:${bgColor};border:${PRINT_SETTINGS.border_width}px solid ${fontColor};border-radius:8px;display:flex;align-items:center;justify-content:center;padding:8px;font-family:${PRINT_SETTINGS.font_family};`;
        const text = document.createElement('div');
        text.textContent = customLabel || cat;
        text.style.cssText = `font-size:${fontSize}pt;font-weight:700;color:${fontColor};text-align:center;`;
        label.appendChild(text);
        container.appendChild(label);
    });
    setStatus('category', `Generated ${cats.length} category labels`);
}

// ============================================================
// EXPORT PDF
// ============================================================
async function exportPDF(tab) {
    const items = getItemsForTab(tab);
    if (!items.length) { showToast('No items to export', 'error'); return; }
    setStatus(tab, 'Generating PDF...');
    const { jsPDF } = window.jspdf;
    const settings = PRINT_SETTINGS;
    const pageSizes = { A4: [210, 297], Letter: [216, 279], Legal: [216, 356], A3: [297, 420] };
    const [pw, ph] = pageSizes[settings.page_size] || [210, 297];
    const isLandscape = settings.orientation === 'landscape';
    const pageW = isLandscape ? ph : pw;
    const pageH = isLandscape ? pw : ph;
    const doc = new jsPDF({ orientation: settings.orientation, unit: 'mm', format: settings.page_size.toLowerCase() });

    const marginTop = settings.margin_top + settings.offset_y;
    const marginBottom = settings.margin_bottom;
    const marginLeft = settings.margin_left + settings.offset_x;
    const marginRight = settings.margin_right;
    const usableW = pageW - marginLeft - marginRight;
    const usableH = pageH - marginTop - marginBottom;
    const cols = settings.columns;
    const colGap = settings.col_gap;
    const rowGap = settings.row_gap;
    const cellW = (usableW - (cols - 1) * colGap) / cols;

    let cellH = 25;
    if (tab === 'spine') cellH = parseInt(document.getElementById('spineHeight').value) || 180;
    else if (tab === 'shelf') cellH = parseInt(document.getElementById('shelfHeight').value) || 30;
    else if (tab === 'category') cellH = parseInt(document.getElementById('catHeight').value) || 40;
    else if (tab === 'qrcode') cellH = 40;

    const rows = Math.max(1, Math.floor((usableH + rowGap) / (cellH + rowGap)));
    const itemsPerPage = cols * rows;

    if (settings.print_header && settings.header_text) {
        doc.setFontSize(12);
        doc.setFont(settings.font_family.toLowerCase(), 'bold');
        doc.setTextColor(settings.font_color);
        doc.text(settings.header_text, pageW / 2, marginTop - 3, { align: 'center' });
    }

    let idx = 0;
    const total = items.length;
    const pages = Math.ceil(total / itemsPerPage);
    for (let p = 0; p < pages; p++) {
        if (p > 0) doc.addPage();
        for (let r = 0; r < rows; r++) {
            for (let c = 0; c < cols; c++) {
                if (idx >= total) break;
                const x = marginLeft + c * (cellW + colGap);
                const y = marginTop + r * (cellH + rowGap);
                if (tab === 'barcode') drawBarcodeLabel(doc, items[idx], x, y, cellW, cellH, settings);
                else if (tab === 'qrcode') drawQRLabel(doc, items[idx], x, y, cellW, cellH, settings);
                else if (tab === 'spine') drawSpineLabel(doc, items[idx], x, y, cellW, cellH, settings);
                else if (tab === 'shelf') drawShelfLabel(doc, items[idx], x, y, cellW, cellH, settings);
                else if (tab === 'category') drawCategoryLabel(doc, items[idx], x, y, cellW, cellH, settings);
                idx++;
            }
        }
    }
    doc.save(`${tab}_labels_${new Date().toISOString().slice(0,10)}.pdf`);
    setStatus(tab, `PDF exported (${total} labels, ${pages} page${pages>1?'s':''})`);
}

function drawBarcodeLabel(doc, item, x, y, w, h, settings) {
    doc.setFontSize(settings.font_size);
    doc.setFont(settings.font_family.toLowerCase(), 'normal');
    doc.setTextColor(settings.font_color);
    if (settings.show_border) { doc.setDrawColor(settings.border_color); doc.setLineWidth(settings.border_width); doc.rect(x, y, w, h); }
    let cy = y + 4;
    const showTitle = document.getElementById('showTitle').checked;
    const showCall = document.getElementById('showCall').checked;
    const showAuthor = document.getElementById('showAuthor').checked;
    const showCategory = document.getElementById('showCategory').checked;
    const showValue = document.getElementById('showValue').value === 'true';
    const bcFormat = document.getElementById('bcFormat').value || 'CODE128';
    const bcW = parseFloat(document.getElementById('bcWidth').value) || 1.2;
    const bcH = parseInt(document.getElementById('bcHeight').value) || 40;
    if (showTitle && item.title) { doc.text(String(item.title).substring(0, 30), x + 1, cy); cy += 4; }
    if (showCall && item.call_number) { doc.setFont(settings.font_family.toLowerCase(), 'bold'); doc.text(String(item.call_number), x + 1, cy); cy += 4; doc.setFont(settings.font_family.toLowerCase(), 'normal'); }
    if (showAuthor && item.author) { doc.text(String(item.author).substring(0, 25), x + 1, cy); cy += 4; }
    if (showCategory && item.category) { doc.setFont(settings.font_family.toLowerCase(), 'bold'); doc.text(String(item.category), x + w - 2, y + 4, { align: 'right' }); doc.setFont(settings.font_family.toLowerCase(), 'normal'); }
    if (item.barcode) {
        try {
            const canvas = document.createElement('canvas');
            JsBarcode(canvas, item.barcode, { format: bcFormat, width: bcW * 2, height: bcH, displayValue: false, margin: 0 });
            const img = canvas.toDataURL('image/png');
            doc.addImage(img, 'PNG', x + 2, y + h - (bcH / 2) * 0.35 - 3, w - 4, (bcH / 2) * 0.35);
        } catch (e) {}
    }
    if (showValue && item.barcode) { doc.setFontSize(settings.font_size - 1); doc.text(String(item.barcode), x + w / 2, y + h - 1, { align: 'center' }); }
}

function drawQRLabel(doc, item, x, y, w, h, settings) {
    if (settings.show_border) { doc.setDrawColor(settings.border_color); doc.setLineWidth(settings.border_width); doc.rect(x, y, w, h); }
    doc.setFontSize(settings.font_size);
    doc.setFont(settings.font_family.toLowerCase(), 'normal');
    doc.setTextColor(settings.font_color);
    if (item.barcode) {
        try {
            const qrDiv = document.createElement('div');
            qrDiv.style.cssText = 'position:absolute;left:-9999px;';
            document.body.appendChild(qrDiv);
            new QRCode(qrDiv, { text: item.barcode, width: 200, height: 200 });
            setTimeout(() => {
                const canvas = qrDiv.querySelector('canvas');
                const img = qrDiv.querySelector('img');
                const dataUrl = canvas ? canvas.toDataURL('image/png') : (img ? img.src : null);
                if (dataUrl) { const qrSize = Math.min(w - 4, h - 8); doc.addImage(dataUrl, 'PNG', x + (w - qrSize) / 2, y + 2, qrSize, qrSize); }
                document.body.removeChild(qrDiv);
            }, 50);
        } catch (e) {}
    }
    if (document.getElementById('qrShowValue').checked && item.barcode) { doc.text(String(item.barcode), x + w / 2, y + h - 2, { align: 'center' }); }
}

function drawSpineLabel(doc, item, x, y, w, h, settings) {
    if (settings.show_border) { doc.setDrawColor(settings.border_color); doc.setLineWidth(settings.border_width); doc.rect(x, y, w, h); }

    const showClass    = document.getElementById('spineShowClass').checked;
    const classSize    = parseInt(document.getElementById('spineClassSize').value) || 11;
    const classColor   = document.getElementById('spineClassColor').value || '#b91c1c';

    const showAuthor   = document.getElementById('spineShowAuthor').checked;
    const authorLength = document.getElementById('spineAuthorLength').value;
    const authorCase   = document.getElementById('spineAuthorCase').value;
    const titleCase    = document.getElementById('spineTitleCase').value;
    const separator    = document.getElementById('spineAuthorSeparator').value || '/';
    const codeSize     = parseInt(document.getElementById('spineCodeSize').value) || 13;

    const showBarcode  = document.getElementById('spineShowBarcode').checked;
    const bcFormat     = document.getElementById('spineBarcodeFormat').value;
    const bcWidthPct   = parseInt(document.getElementById('spineBarcodeWidth').value) || 85;
    const bcHeightPx   = parseInt(document.getElementById('spineBarcodeHeight').value) || 25;
    const bcShowValue  = document.getElementById('spineBarcodeShowValue').value === 'true';
    const bcValueSize  = parseInt(document.getElementById('spineBarcodeValueSize').value) || 9;
    const bcValuePos   = document.getElementById('spineBarcodeValuePos').value || 'below';

    const showLibName  = document.getElementById('spineShowLibraryName').checked;
    const libName      = document.getElementById('spineLibraryName').value.trim();
    const libNameSize  = parseInt(document.getElementById('spineLibraryNameSize').value) || 9;
    const libNameColor = document.getElementById('spineLibraryNameColor').value || '#1a2a6c';
    const libNamePos   = document.getElementById('spineLibraryNamePos').value || 'top';

    const showLogo     = document.getElementById('spineShowLogo').checked;
    const logoWidthMM  = parseInt(document.getElementById('spineLogoWidth').value) || 10;
    const logoPos      = document.getElementById('spineLogoPos').value || 'top';

    const cx = x + w / 2;

    let topY = y + 3;
    function drawLogoAt(cy) {
        if (!showLogo || !spineLogoData) return cy;
        try {
            const lh = logoWidthMM;
            doc.addImage(spineLogoData, 'PNG', cx - logoWidthMM / 2, cy, logoWidthMM, lh);
            return cy + lh + 2;
        } catch (e) { return cy; }
    }
    function drawLibNameAt(cy) {
        if (!showLibName || !libName) return cy;
        doc.setFontSize(libNameSize);
        doc.setFont(settings.font_family.toLowerCase(), 'bold');
        const hex = libNameColor.replace('#','');
        doc.setTextColor(parseInt(hex.substring(0,2),16), parseInt(hex.substring(2,4),16), parseInt(hex.substring(4,6),16));
        const lines = doc.splitTextToSize(libName, w - 4);
        lines.forEach(ln => {
            doc.text(ln, cx, cy + libNameSize * 0.4, { align: 'center' });
            cy += libNameSize * 0.4 + 1;
        });
        return cy + 1;
    }

    if (logoPos === 'top') topY = drawLogoAt(topY);
    if (libNamePos === 'top') topY = drawLibNameAt(topY);

    const blocks = [];
    if (showClass) {
        const cls = getSpineClassification(item);
        if (cls) blocks.push({ type:'class', text: cls, size: classSize, color: classColor });
    }
    if (showAuthor) {
        const a = extractAuthorCode(item.author, authorLength, authorCase);
        const t = extractTitleFirstLetter(item.title, titleCase);
        blocks.push({ type:'code', text: `${a}${separator}${t}`, size: codeSize, color: settings.font_color });
    }
    if (showBarcode && item.barcode) blocks.push({ type:'barcode', text: item.barcode });

    const bottomReserve = (libNamePos === 'bottom' && showLibName ? 8 : 0) + (logoPos === 'bottom' && showLogo && spineLogoData ? logoWidthMM + 2 : 0);
    const midTop = topY;
    const midBottom = y + h - bottomReserve - 3;
    const midH = Math.max(10, midBottom - midTop);

    const measure = (b) => {
        if (b.type === 'barcode') return bcHeightPx * 0.35 + (bcShowValue ? bcValueSize * 0.4 + 2 : 0) + 3;
        return b.size * 0.5 + 4;
    };
    const totalContentH = blocks.reduce((s, b) => s + measure(b), 0);
    let cy = midTop + Math.max(0, (midH - totalContentH) / 2);

    blocks.forEach(b => {
        if (b.type === 'class' || b.type === 'code') {
            doc.setFontSize(b.size);
            doc.setFont(settings.font_family.toLowerCase(), 'bold');
            const hex = (b.color || '#000000').replace('#','');
            doc.setTextColor(parseInt(hex.substring(0,2),16), parseInt(hex.substring(2,4),16), parseInt(hex.substring(4,6),16));
            const lines = doc.splitTextToSize(b.text, w - 4);
            lines.forEach(ln => {
                doc.text(ln, cx, cy + b.size * 0.35, { align: 'center' });
                cy += b.size * 0.45 + 1;
            });
            cy += 2;
        } else if (b.type === 'barcode') {
            try {
                const canvas = document.createElement('canvas');
                JsBarcode(canvas, b.text, { format: bcFormat, width: 1.6, height: bcHeightPx * 2, displayValue: false, margin: 0 });
                const img = canvas.toDataURL('image/png');
                const bcWmm = (w * bcWidthPct) / 100;
                const bcHmm = bcHeightPx * 0.35;
                const bx = cx - bcWmm / 2;

                if (bcValuePos === 'above' && bcShowValue) {
                    doc.setFontSize(bcValueSize * 0.7);
                    doc.setFont(settings.font_family.toLowerCase(), 'normal');
                    doc.setTextColor(settings.font_color);
                    doc.text(b.text, cx, cy + 2, { align: 'center' });
                    cy += bcValueSize * 0.4 + 2;
                }
                doc.addImage(img, 'PNG', bx, cy, bcWmm, bcHmm);
                cy += bcHmm;
                if (bcValuePos === 'below' && bcShowValue) {
                    cy += bcValueSize * 0.4 + 1;
                    doc.setFontSize(bcValueSize * 0.7);
                    doc.setFont(settings.font_family.toLowerCase(), 'normal');
                    doc.setTextColor(settings.font_color);
                    doc.text(b.text, cx, cy, { align: 'center' });
                }
                cy += 3;
            } catch (e) {}
        }
    });

    if (logoPos === 'bottom' && showLogo && spineLogoData) {
        try {
            const lh = logoWidthMM;
            doc.addImage(spineLogoData, 'PNG', cx - logoWidthMM / 2, y + h - lh - 1, logoWidthMM, lh);
        } catch (e) {}
    }
    if (libNamePos === 'bottom' && showLibName && libName) {
        doc.setFontSize(libNameSize);
        doc.setFont(settings.font_family.toLowerCase(), 'bold');
        const hex = libNameColor.replace('#','');
        doc.setTextColor(parseInt(hex.substring(0,2),16), parseInt(hex.substring(2,4),16), parseInt(hex.substring(4,6),16));
        const offset = (logoPos === 'bottom' && spineLogoData ? logoWidthMM + 1 : 0);
        doc.text(libName, cx, y + h - offset - 2, { align: 'center' });
    }
}

function drawShelfLabel(doc, item, x, y, w, h, settings) {
    doc.setFontSize(settings.font_size + 4);
    doc.setFont(settings.font_family.toLowerCase(), 'bold');
    doc.setTextColor(settings.font_color);
    if (settings.show_border) { doc.setDrawColor(settings.border_color); doc.setLineWidth(settings.border_width); doc.rect(x, y, w, h); }
    doc.text(String(item.call_number || ''), x + w / 2, y + h / 2 - 2, { align: 'center' });
    if (item.title) {
        doc.setFontSize(settings.font_size);
        doc.setFont(settings.font_family.toLowerCase(), 'normal');
        doc.text(String(item.title).substring(0, 30), x + w / 2, y + h / 2 + 4, { align: 'center' });
    }
}

function drawCategoryLabel(doc, item, x, y, w, h, settings) {
    if (settings.show_border) { doc.setDrawColor(settings.border_color); doc.setLineWidth(settings.border_width); doc.rect(x, y, w, h); }
    doc.setFontSize(settings.font_size + 6);
    doc.setFont(settings.font_family.toLowerCase(), 'bold');
    doc.setTextColor(settings.font_color);
    doc.text(String(item.label || item.category || ''), x + w / 2, y + h / 2 + 2, { align: 'center' });
}

// ============================================================
// EXPORT — Excel / CSV / JSON / XML / PNG
// ============================================================
function exportExcel(tab) {
    const items = getItemsForTab(tab);
    if (!items.length) { showToast('No items to export', 'error'); return; }
    let rows = [];
    if (tab === 'barcode') {
        rows = [['Barcode','Title','Author','Call Number','Category']];
        items.forEach(i => rows.push([i.barcode, i.title, i.author, i.call_number, i.category]));
    } else if (tab === 'qrcode') {
        rows = [['Barcode','Title','Call Number']];
        items.forEach(i => rows.push([i.barcode, i.title, i.call_number]));
    } else if (tab === 'spine') {
        rows = [['Barcode','Title','Author','Call Number','Classification','AuthorTitleCode']];
        items.forEach(i => {
            const cls = getSpineClassification(i);
            const a = extractAuthorCode(i.author, document.getElementById('spineAuthorLength').value, document.getElementById('spineAuthorCase').value);
            const t = extractTitleFirstLetter(i.title, document.getElementById('spineTitleCase').value);
            rows.push([i.barcode, i.title, i.author, i.call_number, cls, `${a}/${t}`]);
        });
    } else if (tab === 'shelf') {
        rows = [['Call Number','Title','Subtitle']];
        items.forEach(i => rows.push([i.call_number, i.title, i.subtitle]));
    } else if (tab === 'category') {
        rows = [['Category','Custom Label']];
        items.forEach(i => rows.push([i.category, i.label]));
    }
    const ws = XLSX.utils.aoa_to_sheet(rows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Labels');
    const settingsRows = [['Setting','Value']];
    Object.entries(PRINT_SETTINGS).forEach(([k, v]) => settingsRows.push([k, String(v)]));
    XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(settingsRows), 'Settings');
    XLSX.writeFile(wb, `${tab}_labels_${new Date().toISOString().slice(0,10)}.xlsx`);
    setStatus(tab, `Excel exported (${items.length} rows)`);
}

function exportCSV(tab) {
    const items = getItemsForTab(tab);
    if (!items.length) { showToast('No items to export', 'error'); return; }
    let csv = '';
    if (tab === 'barcode') { csv = 'Barcode,Title,Author,Call Number,Category\n'; items.forEach(i => csv += `"${i.barcode}","${i.title}","${i.author}","${i.call_number}","${i.category}"\n`); }
    else if (tab === 'qrcode') { csv = 'Barcode,Title,Call Number\n'; items.forEach(i => csv += `"${i.barcode}","${i.title}","${i.call_number}"\n`); }
    else if (tab === 'spine') {
        csv = 'Barcode,Title,Author,Call Number,Classification,AuthorTitleCode\n';
        items.forEach(i => {
            const cls = getSpineClassification(i);
            const a = extractAuthorCode(i.author, document.getElementById('spineAuthorLength').value, document.getElementById('spineAuthorCase').value);
            const t = extractTitleFirstLetter(i.title, document.getElementById('spineTitleCase').value);
            csv += `"${i.barcode}","${i.title}","${i.author}","${i.call_number}","${cls}","${a}/${t}"\n`;
        });
    }
    else if (tab === 'shelf') { csv = 'Call Number,Title,Subtitle\n'; items.forEach(i => csv += `"${i.call_number}","${i.title}","${i.subtitle}"\n`); }
    else if (tab === 'category') { csv = 'Category,Custom Label\n'; items.forEach(i => csv += `"${i.category}","${i.label}"\n`); }
    downloadBlob(csv, `${tab}_labels_${new Date().toISOString().slice(0,10)}.csv`, 'text/csv;charset=utf-8;');
    setStatus(tab, `CSV exported (${items.length} rows)`);
}

function exportJSON(tab) {
    const items = getItemsForTab(tab);
    if (!items.length) { showToast('No items to export', 'error'); return; }
    const enriched = items.map(i => {
        if (tab === 'spine') {
            return { ...i,
                classification: getSpineClassification(i),
                author_title_code: `${extractAuthorCode(i.author, document.getElementById('spineAuthorLength').value, document.getElementById('spineAuthorCase').value)}/${extractTitleFirstLetter(i.title, document.getElementById('spineTitleCase').value)}`
            };
        }
        return i;
    });
    const payload = { tab, exported: new Date().toISOString(), settings: PRINT_SETTINGS, items: enriched };
    downloadBlob(JSON.stringify(payload, null, 2), `${tab}_labels_${new Date().toISOString().slice(0,10)}.json`, 'application/json');
    setStatus(tab, `JSON exported (${items.length} rows)`);
}

function exportXML(tab) {
    const items = getItemsForTab(tab);
    if (!items.length) { showToast('No items to export', 'error'); return; }
    let xml = `<?xml version="1.0" encoding="UTF-8"?>\n<labels tab="${tab}" exported="${new Date().toISOString()}">\n`;
    items.forEach(i => {
        xml += '  <label>\n';
        Object.entries(i).forEach(([k, v]) => { xml += `    <${k}>${escapeHtml(v)}</${k}>\n`; });
        if (tab === 'spine') {
            xml += `    <classification>${escapeHtml(getSpineClassification(i))}</classification>\n`;
        }
        xml += '  </label>\n';
    });
    xml += '</labels>';
    downloadBlob(xml, `${tab}_labels_${new Date().toISOString().slice(0,10)}.xml`, 'application/xml');
    setStatus(tab, `XML exported (${items.length} rows)`);
}

async function exportPNG(tab) {
    const previewId = { barcode:'barcodePreview', qrcode:'qrPreview', spine:'spinePreview', shelf:'shelfPreview', category:'categoryPreview' }[tab];
    const el = document.getElementById(previewId);
    if (!el || !el.children.length) { showToast('Generate a preview first', 'error'); return; }
    setStatus(tab, 'Generating PNG...');
    try {
        const canvas = await html2canvas(el, { scale: 2, backgroundColor: '#ffffff', useCORS: true });
        const link = document.createElement('a');
        link.download = `${tab}_labels_${new Date().toISOString().slice(0,10)}.png`;
        link.href = canvas.toDataURL('image/png');
        link.click();
        setStatus(tab, 'PNG exported');
    } catch (e) { showToast('PNG export failed: ' + e.message, 'error'); }
}

function downloadBlob(content, filename, mime) {
    const blob = new Blob([content], { type: mime });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
}

// ============================================================
// PRINT PREVIEW
// ============================================================
function showPrintPreview(tab) {
    const items = getItemsForTab(tab);
    if (!items.length) { showToast('Generate a preview first', 'error'); return; }
    const settings = PRINT_SETTINGS;
    const pageSizes = { A4:[210,297], Letter:[216,279], Legal:[216,356], A3:[297,420] };
    const [pw, ph] = pageSizes[settings.page_size] || [210, 297];
    const isLandscape = settings.orientation === 'landscape';
    const pageW = isLandscape ? ph : pw;
    const pageH = isLandscape ? pw : ph;
    const mmToPx = 3.78;

    const modal = new bootstrap.Modal(document.getElementById('printPreviewModal'));
    const body = document.getElementById('printPreviewBody');
    body.innerHTML = '';

    const page = document.createElement('div');
    page.className = 'preview-page';
    page.style.width = (pageW * mmToPx) + 'px';
    page.style.height = (pageH * mmToPx) + 'px';
    page.style.padding = `${(settings.margin_top + settings.offset_y) * mmToPx}px ${settings.margin_right * mmToPx}px ${settings.margin_bottom * mmToPx}px ${(settings.margin_left + settings.offset_x) * mmToPx}px`;

    if (settings.print_header && settings.header_text) {
        const header = document.createElement('div');
        header.style.cssText = `font-family:${settings.font_family};font-size:${settings.font_size + 4}pt;font-weight:bold;text-align:center;margin-bottom:8px;color:${settings.font_color}`;
        header.textContent = settings.header_text;
        page.appendChild(header);
    }
    const grid = document.createElement('div');
    grid.style.cssText = `display:grid;grid-template-columns:repeat(${settings.columns},1fr);gap:${settings.row_gap}mm ${settings.col_gap}mm;`;
    items.forEach(item => {
        const cell = document.createElement('div');
        cell.style.cssText = `padding:4px;background:${settings.bg_color};border:${settings.border_width}px solid ${settings.border_color};font-family:${settings.font_family};font-size:${settings.font_size}pt;color:${settings.font_color};word-break:break-word;`;
        if (tab === 'barcode' || tab === 'qrcode') cell.innerHTML = `<div>${escapeHtml(item.barcode)}</div>`;
        else if (tab === 'spine') cell.innerHTML = `<div>${escapeHtml(getSpineClassification(item))}</div>`;
        else if (tab === 'shelf') cell.innerHTML = `<div style="font-weight:bold">${escapeHtml(item.call_number || '')}</div>`;
        else cell.innerHTML = `<div style="font-weight:bold">${escapeHtml(item.category || '')}</div>`;
        grid.appendChild(cell);
    });
    page.appendChild(grid);
    body.appendChild(page);
    modal.show();
}

// ============================================================
// HELPERS
// ============================================================
function getItemsForTab(tab) {
    if (tab === 'barcode') return [...getSelectedBooks(), ...manualItems];
    if (tab === 'qrcode') return getSelectedQRBooks();
    if (tab === 'spine') return getSelectedSpineBooks();
    if (tab === 'shelf') {
        const callNumber = document.getElementById('shelfCallNumber').value.trim();
        if (!callNumber) return [];
        return Array.from({ length: parseInt(document.getElementById('shelfQty').value) || 1 }, () => ({
            call_number: callNumber,
            title: document.getElementById('shelfTitle').value.trim(),
            subtitle: document.getElementById('shelfSubtitle').value.trim()
        }));
    }
    if (tab === 'category') {
        const cat = document.getElementById('categorySelect').value;
        const customLabel = document.getElementById('categoryLabel').value.trim();
        const cats = cat ? [cat] : ['Fiction','Non-Fiction','Science','Fantasy','Classic','Reference'];
        return cats.map(c => ({ category: c, label: customLabel || c }));
    }
    return [];
}

function clearBarcodeSelection() {
    deselectAllBooks();
    manualItems = [];
    renderManualList();
    document.getElementById('barcodePreview').innerHTML = '<div class="text-center text-muted py-5" style="width:100%;"><i class="fas fa-barcode fa-3x mb-3 d-block" style="opacity:0.2;"></i>Select books and click Generate</div>';
    setStatus('barcode', 'Cleared');
}

function resetPrintSettings() {
    if (!confirm('Reset all print settings to defaults?')) return;
    const form = document.getElementById('printSettingsForm');
    form.querySelectorAll('input,select').forEach(el => {
        if (el.name && el.name.startsWith('print_')) {
            if (el.tagName === 'SELECT') el.selectedIndex = 0;
            else if (el.type === 'color') el.value = '#000000';
            else if (el.type === 'number') el.value = '0';
        }
    });
    showToast('Click Save to persist reset');
}

// ============================================================
// TEMPLATES
// ============================================================
function openTemplates() {
    renderTemplateList();
    new bootstrap.Modal(document.getElementById('templatesModal')).show();
}
function saveTemplate() {
    const name = document.getElementById('templateName').value.trim();
    if (!name) { showToast('Enter template name', 'error'); return; }
    const form = document.getElementById('printSettingsForm');
    const data = {};
    form.querySelectorAll('input,select').forEach(el => {
        if (el.name && el.name.startsWith('print_')) data[el.name] = el.value;
    });
    const templates = JSON.parse(localStorage.getItem('label_templates') || '{}');
    templates[name] = data;
    localStorage.setItem('label_templates', JSON.stringify(templates));
    document.getElementById('templateName').value = '';
    renderTemplateList();
    showToast(`Template "${name}" saved`);
}
function renderTemplateList() {
    const templates = JSON.parse(localStorage.getItem('label_templates') || '{}');
    const container = document.getElementById('templateList');
    const keys = Object.keys(templates);
    if (!keys.length) { container.innerHTML = '<div class="text-muted small">No templates saved yet.</div>'; return; }
    container.innerHTML = keys.map(k => `
        <div class="list-group-item d-flex justify-content-between align-items-center">
            <span>${escapeHtml(k)}</span>
            <div>
                <button class="btn btn-sm btn-outline-primary me-1" onclick="loadTemplate('${escapeHtml(k)}')">Load</button>
                <button class="btn btn-sm btn-outline-danger" onclick="deleteTemplate('${escapeHtml(k)}')">Delete</button>
            </div>
        </div>
    `).join('');
}
function loadTemplate(name) {
    const templates = JSON.parse(localStorage.getItem('label_templates') || '{}');
    const data = templates[name];
    if (!data) return;
    const form = document.getElementById('printSettingsForm');
    Object.entries(data).forEach(([k, v]) => {
        const el = form.querySelector(`[name="${k}"]`);
        if (el) el.value = v;
    });
    showToast(`Template "${name}" loaded. Click Save to persist.`);
}
function deleteTemplate(name) {
    if (!confirm(`Delete template "${name}"?`)) return;
    const templates = JSON.parse(localStorage.getItem('label_templates') || '{}');
    delete templates[name];
    localStorage.setItem('label_templates', JSON.stringify(templates));
    renderTemplateList();
    showToast(`Template "${name}" deleted`);
}

// ============================================================
// LAYOUT PRESETS
// ============================================================
const PRESETS = {
    avery5160: { columns: 3, row_gap: 0, col_gap: 2.5, margin_top: 12.7, margin_bottom: 12.7, margin_left: 4.7, margin_right: 4.7 },
    avery5163: { columns: 2, row_gap: 0, col_gap: 2.5, margin_top: 12.7, margin_bottom: 12.7, margin_left: 4.7, margin_right: 4.7 },
    avery5167: { columns: 4, row_gap: 0, col_gap: 2.5, margin_top: 12.7, margin_bottom: 12.7, margin_left: 4.7, margin_right: 4.7 }
};
function applyPreset(name) {
    const preset = PRESETS[name];
    if (!preset) return;
    const form = document.getElementById('printSettingsForm');
    Object.entries(preset).forEach(([k, v]) => {
        const el = form.querySelector(`[name="print_${k}"]`);
        if (el) el.value = v;
    });
    showToast(`Preset "${name}" applied. Click Save to persist.`);
}

// ============================================================
// KEYBOARD SHORTCUTS
// ============================================================
document.addEventListener('keydown', function (e) {
    if (e.target.matches('input, textarea, select')) return;
    if ((e.ctrlKey || e.metaKey) && e.key === 'p') { e.preventDefault(); showPrintPreview(currentTab); }
    if ((e.ctrlKey || e.metaKey) && e.key === 's') { e.preventDefault(); document.getElementById('printSettingsForm').submit(); }
    if ((e.ctrlKey || e.metaKey) && e.key === 'd') { e.preventDefault(); refreshActivePreview(); }
});

// ============================================================
// INIT
// ============================================================
document.addEventListener('DOMContentLoaded', function () {
    updateSelectedCount();
    updateSpineCount();
    updateQRCount();
    renderManualList();

    document.querySelectorAll('#bcOptionsBody input, #bcOptionsBody select').forEach(el => {
        el.addEventListener('change', refreshActivePreview);
        el.addEventListener('input', refreshActivePreview);
    });

    [
        'spineWidth','spineHeight',
        'spineShowClass','spineClassSize','spineClassColor',
        'spineClassAutoRule','spineClassOnlineFallback',
        'spineClassManual','spineClassSource',
        'spineShowAuthor','spineAuthorLength','spineAuthorCase','spineTitleCase','spineAuthorSeparator','spineCodeSize',
        'spineShowBarcode','spineBarcodeFormat','spineBarcodeWidth','spineBarcodeHeight',
        'spineBarcodeShowValue','spineBarcodeValueSize','spineBarcodeValuePos',
        'spineShowLibraryName','spineLibraryName','spineLibraryNameSize','spineLibraryNameColor','spineLibraryNamePos',
        'spineShowLogo','spineLogoWidth','spineLogoPos'
    ].forEach(id => {
        const el = document.getElementById(id);
        if (!el) return;
        el.addEventListener('change', refreshActivePreview);
        el.addEventListener('input', refreshActivePreview);
    });

    ['qrSize','qrEcc','qrColor','qrBg','shelfWidth','shelfHeight','shelfFontSize','shelfCallNumber','shelfTitle','shelfSubtitle','catWidth','catHeight','catFontSize','catFontColor','catBgColor'].forEach(id => {
        const el = document.getElementById(id);
        if (el) { el.addEventListener('change', refreshActivePreview); el.addEventListener('input', refreshActivePreview); }
    });

    toggleSpineClassSource();
    toggleSpineLogoOptions();

    const activeTab = document.querySelector('.label-tabs .nav-link.active');
    if (activeTab) currentTab = activeTab.dataset.labeltype || 'barcode';

    document.querySelectorAll('.collapse-body').forEach(el => {
        if (!el.classList.contains('collapsed')) el.style.maxHeight = el.scrollHeight + 'px';
    });

    // Ensure spineLibraryName input is showing the clean value
    const spineNameInput = document.getElementById('spineLibraryName');
    if (spineNameInput && window.VMS_INSTITUTION_NAME) {
        spineNameInput.value = window.VMS_INSTITUTION_NAME;
    }
});
</script>

<!-- ============================================================
SHARED FOOTER — with entity-collapse post-processing  [CHANGED v5.2]
============================================================ -->
<?php
$__labelsFooterOut = '';

ob_start();
try {
    if (function_exists('vms_footer_css')) { vms_footer_css(); }
    if (function_exists('vms_footer_js'))  { vms_footer_js();  }

    if (function_exists('vms_render_footer')) {
        vms_render_footer([
            'layout'           => 'compact',
            'institution_name' => $institutionName,
            'institutionName'  => $institutionName,
            'library_name'     => $institutionName,
            'site_name'        => $institutionName,
            'org_name'         => $institutionName,
            'no_escape'        => true,
        ]);
    }
} catch (Throwable $e) {
    error_log('[labels.php] footer render: ' . $e->getMessage());
}
$__labelsFooterOut = ob_get_clean();

if ($__labelsFooterOut !== '') {
    // Collapse &amp;amp;amp; → &amp;amp; → &amp; (up to 5 passes)
    $prev = null;
    $out  = $__labelsFooterOut;
    $i    = 0;
    while ($prev !== $out && $i < 5) {
        $prev = $out;
        $out  = str_replace('&amp;amp;', '&amp;', $out);
        $i++;
    }
    // Final collapse: "word &amp; word" → "word & word" (only between alphanumerics)
    $out = preg_replace_callback(
        '/(?<=[A-Za-z0-9])\s*&amp;\s*(?=[A-Za-z0-9])/',
        function () { return ' & '; },
        $out
    );
    echo $out;
}
?>

</body>
</html>
