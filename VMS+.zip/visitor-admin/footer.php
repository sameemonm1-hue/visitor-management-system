<?php
/**
 * Visitor Management System - Admin Footer
 * Version: 8.3 WORKING
 * – JSON endpoint for OPAC footer widget (returns designer credit)
 * – Compact admin footer: logo left, text center, protected attribution
 * – COMPLETE ALERT SYSTEM JAVASCRIPT
 * – FIX: Proper handling of special characters (&, <, >, quotes) in settings
 */

// ============================================================
// JSON ENDPOINT – MUST be first, before any output or includes
// ============================================================
if (isset($_GET['format']) && $_GET['format'] === 'json') {
    while (ob_get_level()) { ob_end_clean(); }

    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');
    header('Access-Control-Allow-Origin: *');

    echo json_encode([
        'label' => 'Designed by',
        'text'  => 'Sameermon M',
        'url'   => 'https://www.linkedin.com/in/sameermon-m-559692186'
    ]);
    exit;
}

// ============================================================
// NORMAL ADMIN FOOTER (only runs when format != json)
// ============================================================
$settings = getSettings();

// ------------------------------------------------------------
// SAFE OUTPUT HELPER
// Decodes any pre-encoded entities first (so "&amp;" becomes "&"),
// then re-encodes once for safe HTML output.
// This prevents double-encoding when settings are saved encoded.
// ------------------------------------------------------------
if (!function_exists('vms_esc')) {
    function vms_esc($value): string {
        if ($value === null) return '';
        $decoded = html_entity_decode((string)$value, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        return htmlspecialchars($decoded, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    }
}

// ------------------------------------------------------------
// SAFE URL HELPER (for the designer link, hrefs, etc.)
// ------------------------------------------------------------
if (!function_exists('vms_esc_url')) {
    function vms_esc_url($value): string {
        if ($value === null) return '';
        $decoded = html_entity_decode((string)$value, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        return htmlspecialchars($decoded, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    }
}

$footerBg = $settings['footer_bg'] ?? '#1e3c72';
$footerTextColor = $settings['footer_text_color'] ?? '#ffffff';
$footerText = $settings['footer_text'] ?? '';
$showFooterLogo = $settings['show_footer_logo'] ?? 1;
$institutionName = $settings['institution_name'] ?? 'Library';
$footerLogo = null;

// Get footer logo (with fallback to institution logo)
if ($showFooterLogo) {
    $uploadDir = __DIR__ . '/uploads/logos/';
    $logoPath = $settings['footer_logo'] ?? '';

    if (!empty($logoPath) && file_exists($uploadDir . $logoPath)) {
        $data = @file_get_contents($uploadDir . $logoPath);
        if ($data !== false) {
            $finfo = finfo_open(FILEINFO_MIME_TYPE);
            $mime = finfo_buffer($finfo, $data);
            finfo_close($finfo);
            $footerLogo = 'data:' . $mime . ';base64,' . base64_encode($data);
        }
    }

    if (empty($footerLogo)) {
        $instLogo = $settings['institution_logo'] ?? '';
        if (!empty($instLogo) && file_exists($uploadDir . $instLogo)) {
            $data = @file_get_contents($uploadDir . $instLogo);
            if ($data !== false) {
                $finfo = finfo_open(FILEINFO_MIME_TYPE);
                $mime = finfo_buffer($finfo, $data);
                finfo_close($finfo);
                $footerLogo = 'data:' . $mime . ';base64,' . base64_encode($data);
            }
        }
    }
}
?>
        </div>
    </main>
</div>

<!-- ============================================================
BOOTSTRAP JS
============================================================ -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/admin.js" defer></script>

<!-- ============================================================
SIDEBAR TOGGLE & UTILITIES
============================================================ -->
<script>
// Global toggleSidebar (also defined in alert script, but this ensures it exists)
if (typeof window.toggleSidebar !== 'function') {
    window.toggleSidebar = function() {
        var sidebar = document.getElementById('sidebar');
        var overlay = document.getElementById('sidebarOverlay');
        if (sidebar) sidebar.classList.toggle('show');
        if (overlay) overlay.classList.toggle('show');
    };
}

document.getElementById('sidebarOverlay')?.addEventListener('click', function() {
    document.getElementById('sidebar')?.classList.remove('show');
    this.classList.remove('show');
});

window.addEventListener('resize', function() {
    if (window.innerWidth > 992) {
        document.getElementById('sidebar')?.classList.remove('show');
        document.getElementById('sidebarOverlay')?.classList.remove('show');
    }
});

document.addEventListener('keydown', function(e) {
    if (e.ctrlKey && e.key === 'r') {
        e.preventDefault();
        location.reload();
    }
});

// Auto-dismiss bootstrap alerts
document.querySelectorAll('.alert:not(.alert-permanent)').forEach(function(el) {
    setTimeout(function() {
        try {
            var alert = bootstrap.Alert.getOrCreateInstance(el);
            if (alert) alert.close();
        } catch (e) {
            el.style.transition = 'opacity 0.5s';
            el.style.opacity = '0';
            setTimeout(function() { el.remove(); }, 500);
        }
    }, 5000);
});
</script>

<!-- ============================================================
GLOBAL ALERT SYSTEM JAVASCRIPT
============================================================ -->
<script>
(function() {
    'use strict';

    // ============================================================
    // CONFIG (from header.php's window.VMS_CONFIG)
    // ============================================================
    var CONFIG = window.VMS_CONFIG || {
        ajaxUrl: 'ajax.php',
        csrfToken: '',
        autoRefresh: 10000,
        soundEnabled: true,
        initialAlerts: 0,
        initialUnauth: 0
    };

    var lastCheckTimestamp = Math.floor(Date.now() / 1000);
    var currentAlertCount = parseInt(CONFIG.initialAlerts) || 0;
    var isFirstCheck = true;
    var isFetching = false;

    // ============================================================
    // UTILITIES
    // ============================================================
    function escapeHtml(str) {
        if (str === null || str === undefined) return '';
        var div = document.createElement('div');
        div.textContent = String(str);
        return div.innerHTML;
    }

    // ============================================================
    // PLAY ALERT SOUND (Web Audio API - no file needed)
    // ============================================================
    function playAlertSound() {
        if (!CONFIG.soundEnabled) return;

        try {
            var AudioCtx = window.AudioContext || window.webkitAudioContext;
            if (!AudioCtx) return;

            var ctx = new AudioCtx();
            var now = ctx.currentTime;

            var osc = ctx.createOscillator();
            var gain = ctx.createGain();

            osc.type = 'sine';
            osc.frequency.setValueAtTime(800, now);
            osc.frequency.setValueAtTime(1000, now + 0.15);
            osc.frequency.setValueAtTime(800, now + 0.30);

            gain.gain.setValueAtTime(0.3, now);
            gain.gain.exponentialRampToValueAtTime(0.01, now + 0.45);

            osc.connect(gain);
            gain.connect(ctx.destination);

            osc.start(now);
            osc.stop(now + 0.45);

            setTimeout(function() {
                try { ctx.close(); } catch (e) {}
            }, 1000);
        } catch (e) {
            console.log('[VMS] Sound error:', e);
        }
    }

    // ============================================================
    // TOAST NOTIFICATIONS
    // ============================================================
    function showToast(title, message, type, duration) {
        type = type || 'info';
        duration = duration || 6000;

        var container = document.getElementById('toastContainer');
        if (!container) {
            container = document.createElement('div');
            container.className = 'vms-toast-container';
            container.id = 'toastContainer';
            document.body.appendChild(container);
        }

        var icons = {
            success: 'fa-check-circle',
            danger:  'fa-exclamation-triangle',
            warning: 'fa-exclamation-circle',
            info:    'fa-info-circle'
        };

        var toast = document.createElement('div');
        toast.className = 'vms-toast ' + type;
        toast.innerHTML =
            '<div class="toast-icon"><i class="fas ' + (icons[type] || icons.info) + '"></i></div>' +
            '<div class="toast-content">' +
                '<div class="toast-title">' + escapeHtml(title) + '</div>' +
                '<div class="toast-message">' + escapeHtml(message) + '</div>' +
            '</div>' +
            '<button class="toast-close" onclick="this.parentElement.remove()">' +
                '<i class="fas fa-times"></i>' +
            '</button>';

        container.appendChild(toast);

        setTimeout(function() {
            toast.style.transition = 'all 0.3s ease';
            toast.style.opacity = '0';
            toast.style.transform = 'translateX(100%)';
            setTimeout(function() { toast.remove(); }, 300);
        }, duration);
    }

    // ============================================================
    // UPDATE BELL COUNT
    // ============================================================
    function updateBellCount(newCount) {
        currentAlertCount = newCount;

        var bell  = document.getElementById('alertBell');
        var count = document.getElementById('bellCount');

        if (!bell) return;

        if (newCount > 0) {
            bell.classList.remove('no-alerts');
            bell.classList.add('has-alerts');
            bell.setAttribute('title', newCount + ' pending alert(s)');

            if (count) {
                count.textContent = newCount;
            } else {
                var badge = document.createElement('span');
                badge.className = 'bell-count';
                badge.id = 'bellCount';
                badge.textContent = newCount;
                bell.appendChild(badge);
            }
        } else {
            bell.classList.remove('has-alerts');
            bell.classList.add('no-alerts');
            bell.setAttribute('title', 'No pending alerts');
            if (count) count.remove();
        }

        var headerBadge = document.getElementById('alertHeaderBadge');
        if (headerBadge) headerBadge.textContent = newCount + ' pending';
    }

    // ============================================================
    // UPDATE SIDEBAR BANNER
    // ============================================================
    function updateSidebarBanner(newCount) {
        var banner = document.getElementById('sidebarAlertBanner');
        var sidebar = document.getElementById('sidebar');
        var sidebarNav = sidebar ? sidebar.querySelector('.sidebar-nav') : null;

        if (newCount > 0) {
            if (!banner && sidebar && sidebarNav) {
                banner = document.createElement('a');
                banner.href = 'alerts.php';
                banner.className = 'sidebar-alert-banner';
                banner.id = 'sidebarAlertBanner';
                banner.innerHTML =
                    '<div class="d-flex align-items-center gap-2">' +
                        '<div class="alert-icon"><i class="fas fa-exclamation-triangle"></i></div>' +
                        '<div class="flex-grow-1">' +
                            '<div class="alert-count" id="sidebarAlertCount">' + newCount + '</div>' +
                            '<div class="alert-text" id="sidebarAlertText">Unauthorized Alert' + (newCount > 1 ? 's' : '') + '</div>' +
                        '</div>' +
                        '<div><i class="fas fa-chevron-right"></i></div>' +
                    '</div>';
                sidebarNav.parentNode.insertBefore(banner, sidebarNav);
            } else if (banner) {
                var countEl = document.getElementById('sidebarAlertCount');
                var textEl  = document.getElementById('sidebarAlertText');
                if (countEl) countEl.textContent = newCount;
                if (textEl)  textEl.textContent = 'Unauthorized Alert' + (newCount > 1 ? 's' : '');
            }
        } else if (banner) {
            banner.remove();
        }

        var badge = document.getElementById('sidebarAlertBadge');
        var alertLink = document.querySelector('.sidebar-nav .alert-nav-link');
        if (newCount > 0) {
            if (badge) {
                badge.textContent = newCount;
            } else if (alertLink) {
                badge = document.createElement('span');
                badge.className = 'badge badge-danger';
                badge.id = 'sidebarAlertBadge';
                badge.textContent = newCount;
                alertLink.appendChild(badge);
            }
        } else if (badge) {
            badge.remove();
        }

        var booksBadge = document.getElementById('booksBadge');
        var booksLink = document.querySelector('.sidebar-nav a[href="books.php"]');
        if (newCount > 0) {
            if (!booksBadge && booksLink) {
                booksBadge = document.createElement('span');
                booksBadge.className = 'badge badge-danger';
                booksBadge.id = 'booksBadge';
                booksBadge.textContent = newCount;
                booksLink.appendChild(booksBadge);
            } else if (booksBadge) {
                booksBadge.textContent = newCount;
            }
        } else if (booksBadge) {
            booksBadge.remove();
        }
    }

    // ============================================================
    // UPDATE GLOBAL BANNER
    // ============================================================
    function updateGlobalBanner(newCount) {
        var banner = document.getElementById('globalAlertBanner');
        var contentArea = document.querySelector('.content-area');

        if (newCount > 0) {
            if (!banner && contentArea) {
                banner = document.createElement('a');
                banner.href = 'alerts.php';
                banner.className = 'global-alert-banner';
                banner.id = 'globalAlertBanner';
                banner.innerHTML =
                    '<div class="banner-left">' +
                        '<div class="banner-icon"><i class="fas fa-exclamation-triangle"></i></div>' +
                        '<div>' +
                            '<div class="banner-title">🚨 UNAUTHORIZED BOOK EXIT' + (newCount > 1 ? 'S' : '') + ' DETECTED</div>' +
                            '<div class="banner-subtitle">' + newCount + ' pending alert' + (newCount > 1 ? 's' : '') + ' require your attention. Click to review.</div>' +
                        '</div>' +
                    '</div>' +
                    '<div class="banner-badge" id="globalBannerCount">' + newCount + '</div>';
                contentArea.insertBefore(banner, contentArea.firstChild);
            } else if (banner) {
                var bc = document.getElementById('globalBannerCount');
                if (bc) bc.textContent = newCount;
            }
        } else if (banner) {
            banner.remove();
        }
    }

    // ============================================================
    // UPDATE ALERT DROPDOWN
    // ============================================================
    function updateAlertDropdown(alerts) {
        var body = document.getElementById('alertDropdownBody');
        if (!body) return;

        var empty = document.getElementById('alertEmptyState');
        if (empty) empty.remove();

        for (var i = alerts.length - 1; i >= 0; i--) {
            var alert = alerts[i];
            var item = document.createElement('a');
            item.href = 'alerts.php?id=' + alert.id;
            item.className = 'alert-dropdown-item';
            item.innerHTML =
                '<div class="alert-title">' +
                    '<i class="fas fa-exclamation-triangle me-1"></i>' +
                    escapeHtml((alert.book_title || 'Unknown').substring(0, 40)) +
                '</div>' +
                '<div class="alert-subtitle">' +
                    '<i class="fas fa-barcode me-1"></i>' +
                    escapeHtml(alert.book_barcode || '') +
                '</div>' +
                '<div class="alert-time">' +
                    '<i class="fas fa-clock me-1"></i>Just now' +
                '</div>';
            body.insertBefore(item, body.firstChild);
        }

        var items = body.querySelectorAll('.alert-dropdown-item');
        for (var j = 5; j < items.length; j++) {
            items[j].remove();
        }
    }

    // ============================================================
    // CHECK FOR NEW ALERTS (MAIN POLLING FUNCTION)
    // ============================================================
    function checkForNewAlerts() {
        if (isFetching) return;
        isFetching = true;

        var url = CONFIG.ajaxUrl + '?action=get_pending_alerts&since=' + lastCheckTimestamp;

        fetch(url, {
            method: 'GET',
            headers: { 'X-Requested-With': 'XMLHttpRequest' },
            credentials: 'same-origin'
        })
        .then(function(res) {
            if (!res.ok) throw new Error('HTTP ' + res.status);
            return res.json();
        })
        .then(function(data) {
            isFetching = false;

            if (!data || !data.alerts) {
                isFirstCheck = false;
                return;
            }

            var newAlerts = data.alerts;

            if (newAlerts.length > 0) {
                var newTotal = isFirstCheck ? newAlerts.length : (currentAlertCount + newAlerts.length);

                updateBellCount(newTotal);
                updateSidebarBanner(newTotal);
                updateGlobalBanner(newTotal);

                if (!isFirstCheck) {
                    updateAlertDropdown(newAlerts);
                    playAlertSound();

                    showToast(
                        '🚨 Security Alert',
                        newAlerts.length + ' new unauthorized book exit' + (newAlerts.length > 1 ? 's' : '') + '!',
                        'danger',
                        8000
                    );
                }

                lastCheckTimestamp = Math.floor(Date.now() / 1000);
            }

            isFirstCheck = false;
        })
        .catch(function(err) {
            isFetching = false;
            isFirstCheck = false;
        });
    }

    // ============================================================
    // EXPORT GLOBAL HELPERS
    // ============================================================
    window.showVmsToast   = showToast;
    window.playAlertSound = playAlertSound;
    window.vmsCheckAlerts = checkForNewAlerts;

    // ============================================================
    // INITIALIZE
    // ============================================================
    document.addEventListener('DOMContentLoaded', function() {
        setTimeout(checkForNewAlerts, 3000);
        setInterval(checkForNewAlerts, CONFIG.autoRefresh || 10000);

        var resizeTimer;
        window.addEventListener('resize', function() {
            clearTimeout(resizeTimer);
            resizeTimer = setTimeout(function() {
                if (window.innerWidth > 992) {
                    var sidebar = document.getElementById('sidebar');
                    var overlay = document.getElementById('sidebarOverlay');
                    if (sidebar) sidebar.classList.remove('show');
                    if (overlay) overlay.classList.remove('show');
                }
            }, 200);
        });
    });

})();
</script>

<!-- ============================================================
FOOTER - Compact, logo left, text center, protected attribution
Uses vms_esc() to safely output settings that may contain &, <, >, quotes
============================================================ -->
<footer class="admin-footer" id="vmsAdminFooter"
        style="background: <?= vms_esc($footerBg) ?>; color: <?= vms_esc($footerTextColor) ?>;"
        oncontextmenu="return false;"
        onselectstart="return false;"
        ondragstart="return false;">
    <div class="admin-footer-inner">
        <?php if ($showFooterLogo && $footerLogo): ?>
            <img src="<?= $footerLogo ?>" alt="<?= vms_esc($institutionName) ?>"
                 class="admin-footer-logo" draggable="false">
        <?php else: ?>
            <span class="admin-footer-spacer"></span>
        <?php endif; ?>

        <div class="admin-footer-text">
            <?php if (!empty($footerText)): ?>
                <span><?= vms_esc($footerText) ?></span>
            <?php else: ?>
                <span>&copy; <?= date('Y') ?> <strong><?= vms_esc($institutionName) ?></strong></span>
            <?php endif; ?>
            <span class="admin-footer-sep">•</span>
            <span><?= function_exists('__') ? __('all_rights_reserved') : 'All rights reserved.' ?></span>
            <span class="admin-footer-sep">•</span>
            <span class="admin-footer-credit">
                <?= function_exists('__') ? __('designed_by') : 'Designed by' ?>
                <a href="https://www.linkedin.com/in/sameermon-m-559692186"
                   target="_blank"
                   rel="noopener noreferrer"
                   class="admin-footer-link"
                   title="Sameermon M on LinkedIn">Sameermon M</a>
            </span>
        </div>

        <span class="admin-footer-spacer" aria-hidden="true"></span>
    </div>
</footer>

<style>
/* ============================================================
ADMIN FOOTER - Compact, protected
============================================================ */
.admin-footer {
    margin-top: 24px;
    padding: 8px 20px;
    border-radius: 16px;
    font-size: 0.72rem;
    line-height: 1.2;
    user-select: none;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    -webkit-touch-callout: none;
    position: relative;
    overflow: hidden;
}

.admin-footer-inner {
    display: grid;
    grid-template-columns: 1fr auto 1fr;
    align-items: center;
    gap: 12px;
    min-height: 34px;
}

.admin-footer-logo {
    max-height: 28px;
    width: auto;
    object-fit: contain;
    justify-self: start;
    border-radius: 6px;
    pointer-events: none;
    -webkit-user-drag: none;
    user-drag: none;
    background: rgba(255,255,255,0.1);
    padding: 2px 6px;
}

.admin-footer-spacer {
    display: block;
    width: 28px;
    height: 28px;
    justify-self: start;
}

.admin-footer-text {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    flex-wrap: wrap;
    text-align: center;
    justify-self: center;
    white-space: nowrap;
}

.admin-footer-text > span {
    display: inline-block;
    margin: 0;
    padding: 0;
}

.admin-footer-sep {
    opacity: 0.5;
    font-size: 0.7rem;
}

.admin-footer-credit {
    display: inline-flex;
    align-items: center;
    gap: 4px;
}

.admin-footer-link {
    color: #ffd700;
    text-decoration: none;
    font-weight: 600;
    padding: 0 2px;
    position: relative;
    transition: color 0.2s ease, text-shadow 0.2s ease;
}

.admin-footer-link:hover,
.admin-footer-link:focus {
    color: #ffffff;
    text-shadow: 0 0 8px rgba(255, 215, 0, 0.6);
    outline: none;
}

.admin-footer-link::after {
    content: '';
    position: absolute;
    left: 2px;
    right: 2px;
    bottom: -1px;
    height: 1px;
    background: currentColor;
    transform: scaleX(0);
    transform-origin: center;
    transition: transform 0.25s ease;
}

.admin-footer-link:hover::after {
    transform: scaleX(1);
}

@media (max-width: 768px) {
    .admin-footer { padding: 6px 14px; font-size: 0.65rem; }
    .admin-footer-inner { grid-template-columns: auto 1fr auto; gap: 8px; min-height: 28px; }
    .admin-footer-logo { max-height: 22px; }
    .admin-footer-text { gap: 5px; white-space: normal; font-size: 0.6rem; }
}

@media (max-width: 480px) {
    .admin-footer { padding: 5px 10px; font-size: 0.58rem; }
    .admin-footer-logo { max-height: 18px; }
    .admin-footer-sep { display: none; }
    .admin-footer-text { flex-wrap: wrap; gap: 3px; }
}
</style>

<!-- ============================================================
ATTRIBUTION PROTECTION - Admin Footer
============================================================ -->
<script>
(function() {
    'use strict';

    var SIGNATURE = {
        text: 'Sameermon M',
        url: 'https://www.linkedin.com/in/sameermon-m-559692186'
    };

    function verifyFooter() {
        var footer = document.getElementById('vmsAdminFooter');
        if (!footer) return;

        var link = footer.querySelector('.admin-footer-link');
        if (!link) return;

        var url = link.getAttribute('href') || '';
        var text = (link.textContent || '').trim();

        if (url !== SIGNATURE.url || text !== SIGNATURE.text) {
            link.setAttribute('href', SIGNATURE.url);
            link.textContent = SIGNATURE.text;
            link.setAttribute('target', '_blank');
            link.setAttribute('rel', 'noopener noreferrer');
        }
    }

    verifyFooter();
    setInterval(verifyFooter, 3000);

    var footer = document.getElementById('vmsAdminFooter');
    if (footer) {
        ['contextmenu', 'selectstart', 'dragstart', 'copy', 'cut'].forEach(function(evt) {
            footer.addEventListener(evt, function(e) {
                e.preventDefault();
                return false;
            });
        });

        if (window.MutationObserver) {
            var observer = new MutationObserver(function() {
                verifyFooter();
            });
            observer.observe(footer, {
                childList: true,
                subtree: true,
                attributes: true,
                attributeFilter: ['href']
            });
        }
    }

    Object.defineProperty(window, '__VMS_ADMIN_SIGNATURE_LOCKED__', {
        value: SIGNATURE,
        writable: false,
        configurable: false
    });
})();
</script>

</body>
</html>
