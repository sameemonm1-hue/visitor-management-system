<?php
/**
 * Visitor Management System - Public Feedback Form
 * Version: 7.5 Advanced Edition
 * 
 * Public-facing form for visitors to submit feedback
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

$possiblePaths = [
    __DIR__ . '/../includes',
    '/usr/share/koha/intranet/cgi-bin/koha/visitor/includes',
];
$includePath = null;
foreach ($possiblePaths as $path) {
    if (file_exists($path . '/config.php')) { $includePath = $path; break; }
}
if (!$includePath) die('Config not found.');

define('VMS_INCLUDES', $includePath);
require_once VMS_INCLUDES . '/config.php';
require_once VMS_INCLUDES . '/functions.php';

if (session_status() === PHP_SESSION_NONE) {
    session_name('CGISESSID');
    if (isset($_COOKIE['CGISESSID'])) session_id($_COOKIE['CGISESSID']);
    session_start();
}

$db = getDB();
$settings = getSettings();
$institutionName = $settings['institution_name'] ?? 'Library';
$primaryColor = $settings['primary_color'] ?? '#1e3c72';

$submitted = false;
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $rating = (int)($_POST['rating'] ?? 0);
        $cleanliness = (int)($_POST['cleanliness_rating'] ?? 0);
        $staff = (int)($_POST['staff_rating'] ?? 0);
        $resources = (int)($_POST['resources_rating'] ?? 0);
        $comment = trim($_POST['comment'] ?? '');
        $category = trim($_POST['category'] ?? 'general');
        $recommend = isset($_POST['would_recommend']) ? 1 : 0;
        $name = trim($_POST['member_name'] ?? '');
        $memberId = trim($_POST['member_id'] ?? '');
        
        if ($rating < 1 || $rating > 5) {
            throw new Exception('Please select an overall rating');
        }
        
        $stmt = $db->prepare("
            INSERT INTO feedback 
            (member_id, member_name, rating, cleanliness_rating, staff_rating, resources_rating, comment, category, would_recommend, ip_address)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $memberId ?: null, $name ?: null, $rating,
            $cleanliness ?: null, $staff ?: null, $resources ?: null,
            $comment, $category, $recommend,
            $_SERVER['REMOTE_ADDR'] ?? null
        ]);
        
        $submitted = true;
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Share Your Feedback - <?= htmlspecialchars($institutionName) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background: linear-gradient(135deg, <?= $primaryColor ?>, #2a5298);
            min-height: 100vh;
            padding: 30px 15px;
            font-family: 'Inter', sans-serif;
        }
        .feedback-box {
            max-width: 600px;
            margin: 0 auto;
            background: white;
            border-radius: 24px;
            padding: 32px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.25);
        }
        .star-rating {
            display: flex;
            gap: 8px;
            justify-content: center;
            margin: 16px 0;
            direction: rtl;
        }
        .star-rating input { display: none; }
        .star-rating label {
            font-size: 2.5rem;
            color: #dee2e6;
            cursor: pointer;
            transition: all 0.2s;
        }
        .star-rating label:hover,
        .star-rating label:hover ~ label,
        .star-rating input:checked ~ label {
            color: #ffc107;
            transform: scale(1.1);
        }
        .star-rating-sm { gap: 4px; }
        .star-rating-sm label { font-size: 1.5rem; }
        .sub-rating-block { text-align: center; padding: 12px; background: #f8f9fa; border-radius: 12px; }
        .success-icon { font-size: 5rem; color: #28a745; }
    </style>
</head>
<body>
    <div class="feedback-box">
        <?php if ($submitted): ?>
            <div class="text-center">
                <i class="fas fa-check-circle success-icon mb-3"></i>
                <h2 class="fw-bold mb-2">Thank You!</h2>
                <p class="text-muted mb-4">Your feedback helps us improve our services.</p>
                <button onclick="location.reload()" class="btn btn-primary btn-lg">
                    <i class="fas fa-redo me-2"></i>Submit Another
                </button>
            </div>
        <?php else: ?>
            <div class="text-center mb-4">
                <h2 class="fw-bold" style="color:<?= $primaryColor ?>;">
                    <i class="fas fa-star text-warning me-2"></i>Share Your Feedback
                </h2>
                <p class="text-muted">Your opinion matters to us!</p>
            </div>

            <?php if ($error): ?>
                <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>

            <form method="POST">
                <!-- Overall Rating -->
                <div class="text-center mb-4">
                    <label class="form-label fw-bold fs-5">Overall Experience</label>
                    <div class="star-rating">
                        <input type="radio" name="rating" id="star5" value="5" required><label for="star5">★</label>
                        <input type="radio" name="rating" id="star4" value="4"><label for="star4">★</label>
                        <input type="radio" name="rating" id="star3" value="3"><label for="star3">★</label>
                        <input type="radio" name="rating" id="star2" value="2"><label for="star2">★</label>
                        <input type="radio" name="rating" id="star1" value="1"><label for="star1">★</label>
                    </div>
                    <div class="text-muted small" id="ratingText">Tap a star to rate</div>
                </div>

                <!-- Sub-ratings -->
                <div class="row g-3 mb-4">
                    <div class="col-md-4">
                        <div class="sub-rating-block">
                            <div class="small fw-semibold mb-1">🧹 Cleanliness</div>
                            <div class="star-rating star-rating-sm">
                                <?php for ($i = 5; $i >= 1; $i--): ?>
                                    <input type="radio" name="cleanliness_rating" id="c<?= $i ?>" value="<?= $i ?>">
                                    <label for="c<?= $i ?>">★</label>
                                <?php endfor; ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="sub-rating-block">
                            <div class="small fw-semibold mb-1">👥 Staff</div>
                            <div class="star-rating star-rating-sm">
                                <?php for ($i = 5; $i >= 1; $i--): ?>
                                    <input type="radio" name="staff_rating" id="s<?= $i ?>" value="<?= $i ?>">
                                    <label for="s<?= $i ?>">★</label>
                                <?php endfor; ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="sub-rating-block">
                            <div class="small fw-semibold mb-1">📚 Resources</div>
                            <div class="star-rating star-rating-sm">
                                <?php for ($i = 5; $i >= 1; $i--): ?>
                                    <input type="radio" name="resources_rating" id="r<?= $i ?>" value="<?= $i ?>">
                                    <label for="r<?= $i ?>">★</label>
                                <?php endfor; ?>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Name (optional) -->
                <div class="row g-3 mb-3">
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Your Name (optional)</label>
                        <input type="text" name="member_name" class="form-control" placeholder="Anonymous">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Member ID (optional)</label>
                        <input type="text" name="member_id" class="form-control">
                    </div>
                </div>

                <!-- Category -->
                <div class="mb-3">
                    <label class="form-label fw-semibold">What is this about?</label>
                    <select name="category" class="form-select">
                        <option value="general">General</option>
                        <option value="service">Service Quality</option>
                        <option value="facility">Facilities</option>
                        <option value="books">Book Collection</option>
                        <option value="staff">Staff</option>
                        <option value="cleanliness">Cleanliness</option>
                        <option value="suggestion">Suggestion</option>
                        <option value="complaint">Complaint</option>
                    </select>
                </div>

                <!-- Comment -->
                <div class="mb-3">
                    <label class="form-label fw-semibold">Your Comments</label>
                    <textarea name="comment" class="form-control" rows="4" placeholder="Tell us about your experience..."></textarea>
                </div>

                <!-- Recommend -->
                <div class="form-check mb-4">
                    <input class="form-check-input" type="checkbox" name="would_recommend" id="recommend" value="1">
                    <label class="form-check-label fw-semibold" for="recommend">
                        I would recommend this library to others
                    </label>
                </div>

                <button type="submit" class="btn btn-primary w-100 btn-lg">
                    <i class="fas fa-paper-plane me-2"></i>Submit Feedback
                </button>
            </form>
        <?php endif; ?>
    </div>

    <script>
        const ratingTexts = {
            1: '😞 Poor',
            2: '😐 Fair',
            3: '🙂 Good',
            4: '😊 Very Good',
            5: '🤩 Excellent!'
        };
        document.querySelectorAll('input[name="rating"]').forEach(input => {
            input.addEventListener('change', function() {
                document.getElementById('ratingText').textContent = ratingTexts[this.value] || '';
                document.getElementById('ratingText').style.fontWeight = '700';
                document.getElementById('ratingText').style.color = '#1e3c72';
            });
        });
    </script>
</body>
</html>