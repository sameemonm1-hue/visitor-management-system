/**
 * Visitor Management System - Admin JavaScript
 * Version: 7.4 FINAL - WORKING
 */

// ============================================================
// TOAST NOTIFICATIONS
// ============================================================
function showToast(message, type = 'success') {
    const container = document.getElementById('toastContainer') || (function() {
        const el = document.createElement('div');
        el.id = 'toastContainer';
        el.className = 'toast-container position-fixed top-0 end-0 p-3';
        el.style.zIndex = '9999';
        document.body.appendChild(el);
        return el;
    })();
    
    const toast = document.createElement('div');
    toast.className = `toast align-items-center text-white bg-${type} border-0 show`;
    toast.setAttribute('role', 'alert');
    
    const iconMap = {
        success: 'fa-check-circle',
        danger: 'fa-exclamation-circle',
        warning: 'fa-exclamation-triangle',
        info: 'fa-info-circle'
    };
    const icon = iconMap[type] || 'fa-info-circle';
    
    toast.innerHTML = `
        <div class="d-flex">
            <div class="toast-body">
                <i class="fas ${icon} me-2"></i> ${escapeHtml(message)}
            </div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
        </div>
    `;
    
    container.appendChild(toast);
    
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => toast.remove(), 300);
    }, 5000);
}

// ============================================================
// UTILITY FUNCTIONS
// ============================================================
function escapeHtml(str) {
    if (!str) return '';
    const d = document.createElement('div');
    d.textContent = str;
    return d.innerHTML;
}

function getCsrfToken() {
    return document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '';
}

function formatDate(date, format = 'd-m-Y') {
    if (!date) return '';
    const d = new Date(date);
    if (isNaN(d.getTime())) return date;
    const day = String(d.getDate()).padStart(2, '0');
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const year = d.getFullYear();
    const hours = String(d.getHours()).padStart(2, '0');
    const minutes = String(d.getMinutes()).padStart(2, '0');
    const seconds = String(d.getSeconds()).padStart(2, '0');
    const replacements = {
        'd-m-Y': `${day}-${month}-${year}`,
        'Y-m-d': `${year}-${month}-${day}`,
        'd/m/Y': `${day}/${month}/${year}`,
        'd-m-Y H:i': `${day}-${month}-${year} ${hours}:${minutes}`,
        'd-m-Y H:i:s': `${day}-${month}-${year} ${hours}:${minutes}:${seconds}`,
    };
    return replacements[format] || date;
}

// ============================================================
// CONFIRMATION DIALOG
// ============================================================
function confirmAction(message, callback) {
    const modal = document.createElement('div');
    modal.className = 'modal fade';
    modal.setAttribute('tabindex', '-1');
    modal.innerHTML = `
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-exclamation-triangle text-warning me-2"></i> Confirm</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body"><p>${escapeHtml(message)}</p></div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-danger confirm-btn">Confirm</button>
                </div>
            </div>
        </div>
    `;
    document.body.appendChild(modal);
    const modalInstance = new bootstrap.Modal(modal);
    modalInstance.show();
    modal.querySelector('.confirm-btn').addEventListener('click', function() {
        modalInstance.hide();
        if (typeof callback === 'function') callback();
        setTimeout(() => modal.remove(), 300);
    });
    modal.addEventListener('hidden.bs.modal', function() {
        setTimeout(() => modal.remove(), 300);
    });
}

// ============================================================
// TOGGLE SIDEBAR
// ============================================================
function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebarOverlay');
    if (sidebar) sidebar.classList.toggle('show');
    if (overlay) overlay.classList.toggle('show');
}

// ============================================================
// TABLE SEARCH
// ============================================================
function filterTable(inputId, tableId) {
    const input = document.getElementById(inputId);
    const table = document.getElementById(tableId);
    if (!input || !table) return;
    const filter = input.value.toLowerCase();
    const rows = table.getElementsByTagName('tr');
    for (let i = 1; i < rows.length; i++) {
        const cells = rows[i].getElementsByTagName('td');
        let found = false;
        for (let j = 0; j < cells.length; j++) {
            const text = cells[j].textContent || cells[j].innerText;
            if (text.toLowerCase().indexOf(filter) > -1) { found = true; break; }
        }
        rows[i].style.display = found ? '' : 'none';
    }
}

// ============================================================
// EXPORT FUNCTIONS
// ============================================================
function exportTableToCSV(tableId, filename) {
    const table = document.getElementById(tableId);
    if (!table) return;
    const rows = table.querySelectorAll('tr');
    const csv = [];
    rows.forEach(row => {
        const cells = row.querySelectorAll('th, td');
        const rowData = [];
        cells.forEach(cell => {
            let text = cell.textContent.trim();
            if (text.includes(',')) { text = '"' + text + '"'; }
            rowData.push(text);
        });
        csv.push(rowData.join(','));
    });
    const csvContent = csv.join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = (filename || 'export') + '.csv';
    link.click();
}

// ============================================================
// INITIALIZATION
// ============================================================
document.addEventListener('DOMContentLoaded', function() {
    // Auto-dismiss alerts
    document.querySelectorAll('.alert:not(.alert-permanent)').forEach(function(el) {
        setTimeout(function() {
            try {
                const alert = bootstrap.Alert.getOrCreateInstance(el);
                if (alert) alert.close();
            } catch (e) {
                el.style.transition = 'opacity 0.5s';
                el.style.opacity = '0';
                setTimeout(function() { el.remove(); }, 500);
            }
        }, 5000);
    });
    
    // Initialize tooltips
    document.querySelectorAll('[data-bs-toggle="tooltip"]').forEach(function(el) {
        new bootstrap.Tooltip(el);
    });
    
    // Initialize popovers
    document.querySelectorAll('[data-bs-toggle="popover"]').forEach(function(el) {
        new bootstrap.Popover(el);
    });
    
    // Color picker preview
    document.querySelectorAll('input[type="color"]').forEach(function(input) {
        input.addEventListener('input', function() {
            const preview = this.parentElement?.querySelector('.color-preview-box');
            if (preview) preview.style.background = this.value;
        });
    });
    
    // Keyboard shortcuts
    document.addEventListener('keydown', function(e) {
        if (e.ctrlKey && e.key === 'r') { e.preventDefault(); location.reload(); }
        if (e.ctrlKey && e.key === 'f') {
            const searchInput = document.querySelector('input[type="search"], input[name="search"]');
            if (searchInput) { e.preventDefault(); searchInput.focus(); }
        }
    });
});

// ============================================================
// EXPOSE FUNCTIONS GLOBALLY
// ============================================================
window.showToast = showToast;
window.escapeHtml = escapeHtml;
window.getCsrfToken = getCsrfToken;
window.confirmAction = confirmAction;
window.toggleSidebar = toggleSidebar;
window.filterTable = filterTable;
window.exportTableToCSV = exportTableToCSV;
window.formatDate = formatDate;
