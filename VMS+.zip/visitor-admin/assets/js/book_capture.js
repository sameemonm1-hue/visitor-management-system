/**
 * Visitor Management System — Book Photo Capture Module
 * Version: 8.5.1
 *
 * Small, dependency-free webcam wrapper. Loaded by both the admin
 * books.php page and the public kiosk index.php.
 *
 * Usage:
 *     await VMSBookCapture.start('videoElementId');   // → boolean
 *     const dataUrl = await VMSBookCapture.capture('videoElementId');
 *     VMSBookCapture.stop();
 *     VMSBookCapture.isActive();                      // → boolean
 *
 * Features:
 *   • Requests rear/front camera depending on device
 *   • 640×480 JPEG @ 0.85 quality (small payload)
 *   • Auto-cleans MediaStream tracks on stop
 *   • Never throws — always resolves; returns null on failure
 *   • Safe to call stop() multiple times
 */

(function (global) {
    'use strict';

    let activeStream = null;
    let attachedVideo = null;

    function stopStream() {
        if (activeStream) {
            try {
                activeStream.getTracks().forEach(function (track) {
                    try { track.stop(); } catch (e) { /* ignore */ }
                });
            } catch (e) { /* ignore */ }
            activeStream = null;
        }
        if (attachedVideo) {
            try { attachedVideo.srcObject = null; } catch (e) { /* ignore */ }
            attachedVideo = null;
        }
    }

    const VMSBookCapture = {

        isSupported: function () {
            return !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia);
        },

        isActive: function () {
            return !!activeStream;
        },

        /**
         * Start the webcam attached to an existing <video> element.
         * @param {string} videoElementId
         * @param {object} [opts]
         * @returns {Promise<boolean>}
         */
        start: function (videoElementId, opts) {
            return new Promise(function (resolve) {
                if (!VMSBookCapture.isSupported()) {
                    console.warn('[VMSBookCapture] getUserMedia not supported');
                    return resolve(false);
                }
                const video = document.getElementById(videoElementId);
                if (!video) {
                    console.warn('[VMSBookCapture] video element not found:', videoElementId);
                    return resolve(false);
                }

                // Already attached to the same element?
                if (activeStream && attachedVideo === video) {
                    return resolve(true);
                }
                // Attached to a different element → stop first
                if (activeStream) stopStream();

                const constraints = {
                    audio: false,
                    video: {
                        facingMode: (opts && opts.facingMode) || 'environment',
                        width:  { ideal: 640 },
                        height: { ideal: 480 }
                    }
                };

                navigator.mediaDevices.getUserMedia(constraints)
                    .then(function (stream) {
                        activeStream = stream;
                        attachedVideo = video;
                        video.srcObject = stream;
                        video.muted = true;
                        video.setAttribute('playsinline', '');
                        const playPromise = video.play();
                        if (playPromise && typeof playPromise.catch === 'function') {
                            playPromise.catch(function (e) {
                                console.warn('[VMSBookCapture] video.play() rejected:', e);
                            });
                        }
                        // Give the sensor ~250 ms to warm up
                        setTimeout(function () { resolve(true); }, 250);
                    })
                    .catch(function (err) {
                        console.warn('[VMSBookCapture] getUserMedia error:', err);
                        // Try front camera as a fallback (some desktops)
                        if (constraints.video.facingMode === 'environment') {
                            navigator.mediaDevices.getUserMedia({
                                audio: false,
                                video: { width: 640, height: 480 }
                            }).then(function (stream) {
                                activeStream = stream;
                                attachedVideo = video;
                                video.srcObject = stream;
                                setTimeout(function () { resolve(true); }, 250);
                            }).catch(function () {
                                resolve(false);
                            });
                        } else {
                            resolve(false);
                        }
                    });
            });
        },

        /**
         * Capture a single frame from the currently attached video.
         * @param {string} videoElementId
         * @returns {Promise<string|null>} data URL or null
         */
        capture: function (videoElementId) {
            return new Promise(function (resolve) {
                const video = document.getElementById(videoElementId);
                if (!video || !activeStream) {
                    return resolve(null);
                }

                // Wait for metadata if needed
                const doCapture = function () {
                    try {
                        const w = video.videoWidth  || 640;
                        const h = video.videoHeight || 480;

                        const canvas = document.createElement('canvas');
                        canvas.width  = w;
                        canvas.height = h;
                        const ctx = canvas.getContext('2d');
                        ctx.drawImage(video, 0, 0, w, h);

                        const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
                        resolve(dataUrl);
                    } catch (e) {
                        console.warn('[VMSBookCapture] capture error:', e);
                        resolve(null);
                    }
                };

                if (video.readyState >= 2) {
                    doCapture();
                } else {
                    const onReady = function () {
                        video.removeEventListener('loadeddata', onReady);
                        setTimeout(doCapture, 200);
                    };
                    video.addEventListener('loadeddata', onReady);
                    setTimeout(function () {
                        if (video.readyState < 2) doCapture();
                    }, 800);
                }
            });
        },

        /** Stop and release all resources. Safe to call multiple times. */
        stop: function () {
            stopStream();
        }
    };

    global.VMSBookCapture = VMSBookCapture;

})(window);