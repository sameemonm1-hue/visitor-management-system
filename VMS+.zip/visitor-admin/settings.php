<?php
/**
 * Visitor Management System - Settings
 * Version: 7.8 FINAL — HTML-entity fix (deep) + robust save
 *
 * CHANGELOG v7.8 (from v7.7):
 *   ── FIXED: "Library & information" now renders correctly in ALL
 *             settings fields and in the shared footer. Values like
 *             "Library &amp;amp; information" are collapsed to
 *             "Library & information" via a multi-pass decoder.
 *   ── NEW:   vms_clean_text()      — aggressive 5-pass entity decoder.
 *   ── CHANGED: vms_h() uses htmlspecialchars(..., false) so we never
 *               double-encode plain text.
 *   ── CHANGED: vms_prepare_text() now calls vms_clean_text() first,
 *               then sanitizeInput WITHOUT re-encoding.
 *   ── CHANGED: Footer include is buffered + post-processed so the
 *               shared footer.php cannot re-encode the institution
 *               name — same treatment as guests.php / error.php.
 *   ── CHANGED: $institutionName is normalized once at top and
 *               published to $GLOBALS + $settings so every include
 *               in this page reads the clean value.
 *   ── PRESERVED: purpose whitelist, renderPurposeOptions(), CSRF,
 *                 logo upload, cache clearing, reset defaults, all
 *                 tabs and toggles.
 *
 * CHANGELOG v7.7
 *   ── FIXED: institution_name / public_header_title / … double-encoded.
 *   ── NEW:   vms_normalize_text() / vms_h() / vms_field().
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

// ============================================================
// AUTO-DETECT INCLUDES PATH
// ============================================================
$possiblePaths = [
    __DIR__ . '/includes',
    dirname(__DIR__) . '/includes',
    '/usr/share/koha/intranet/cgi-bin/koha/visitor/includes',
    '/usr/share/koha/intranet/cgi-bin/visitor/includes',
];

$includePath = null;
foreach ($possiblePaths as $path) {
    if (file_exists($path . '/config.php')) {
        $includePath = $path;
        break;
    }
}

if (!$includePath) {
    $testPath = __DIR__;
    for ($i = 0; $i < 5; $i++) {
        $testPath = dirname($testPath);
        if (file_exists($testPath . '/includes/config.php')) {
            $includePath = $testPath . '/includes';
            break;
        }
    }
}

if (!$includePath) {
    die('Could not find includes directory.');
}

define('VMS_INCLUDES', $includePath);
require_once VMS_INCLUDES . '/config.php';
require_once VMS_INCLUDES . '/functions.php';
require_once VMS_INCLUDES . '/koha.php';
require_once VMS_INCLUDES . '/auth.php';

startSecureSession();
requireKohaLogin();
requireKohaRole('admin');

// ============================================================
// v7.8 — HTML ENTITY HELPERS (deep normalization)
// ============================================================
if (!function_exists('vms_clean_text')) {
    /**
     * Aggressively normalize a text value to plain text.
     *
     * Handles:
     *   "Library & information"          → "Library & information"
     *   "Library &amp; information"       → "Library & information"
     *   "Library &amp;amp; information"   → "Library & information"
     *   "Library &amp;amp;amp; info"      → "Library & information"
     *
     * Loops html_entity_decode until stable (max 5 passes), then
     * defensively collapses any residual literal entity sequences.
     */
    function vms_clean_text($value) {
        if ($value === null) return '';
        $raw = trim((string)$value);
        if ($raw === '') return '';

        if (!mb_check_encoding($raw, 'UTF-8')) {
            $fixed = @mb_convert_encoding($raw, 'UTF-8', 'ISO-8859-1');
            if ($fixed !== false && $fixed !== '') $raw = $fixed;
        }

        // Loop-decode until stable
        $prev = null; $out = $raw; $i = 0;
        while ($prev !== $out && $i < 5) {
            $prev = $out;
            $out  = html_entity_decode($out, ENT_QUOTES | ENT_HTML5, 'UTF-8');
            $i++;
        }

        // Defensive collapse of residual literal entity sequences
        $out = str_replace(
            ['&amp;amp;amp;', '&amp;amp;', '&amp;', '&AMP;', '&Amp;'],
            '&',
            $out
        );
        $out = str_replace(
            ['&quot;', '&#039;', '&#39;', '&apos;', '&lt;', '&gt;', '&nbsp;'],
            ['"',       "'",       "'",      "'",       '<',    '>',    ' '],
            $out
        );

        // Normalize whitespace (but preserve meaningful newlines for textareas)
        $out = preg_replace('/[ \t]+/u', ' ', $out);
        $out = trim($out);

        return $out;
    }
}

// Backwards-compatible alias for the old v7.7 name
if (!function_exists('vms_normalize_text')) {
    function vms_normalize_text($value) {
        return vms_clean_text($value);
    }
}

if (!function_exists('vms_h')) {
    /**
     * Safe HTML output — decode once, then encode once.
     * Uses the `false` flag for double_encode so we never re-encode
     * a plain-text "&" into "&amp;".
     */
    function vms_h($value) {
        return htmlspecialchars(
            vms_clean_text($value),
            ENT_QUOTES | ENT_HTML5,
            'UTF-8',
            false
        );
    }
}

if (!function_exists('vms_field')) {
    /**
     * Read a setting, normalized, with fallback.
     */
    function vms_field($settings, $key, $default = '') {
        $raw = $settings[$key] ?? $default;
        return vms_clean_text($raw);
    }
}

// ============================================================
// LOCAL FALLBACKS — purpose helpers
// ============================================================
if (!function_exists('getPurposeOptions')) {
    function getPurposeOptions(): array {
        return [
            'Reading/Study'     => ['icon' => '📚', 'label' => 'Reading/Study',     'i18n' => 'purpose_reading'],
            'Computer Uses'     => ['icon' => '💻', 'label' => 'Computer Uses',     'i18n' => 'purpose_computer_uses'],
            'Book Issue/Return' => ['icon' => '🔄', 'label' => 'Book Issue/Return', 'i18n' => 'purpose_issue_return'],
            'Research'          => ['icon' => '🔬', 'label' => 'Research',          'i18n' => 'purpose_research'],
            'Meeting'           => ['icon' => '👥', 'label' => 'Meeting',           'i18n' => 'purpose_meeting'],
            'Event'             => ['icon' => '🎉', 'label' => 'Event/Program',     'i18n' => 'purpose_event'],
            'Other'             => ['icon' => '📝', 'label' => 'Other',             'i18n' => 'purpose_other'],
        ];
    }
}
if (!function_exists('renderPurposeOptions')) {
    function renderPurposeOptions(?string $selected = null, string $lang = 'en'): string {
        $html = '';
        foreach (getPurposeOptions() as $value => $meta) {
            $translated = function_exists('__') ? __($meta['i18n'], $lang) : $meta['label'];
            if ($translated === $meta['i18n']) $translated = $meta['label'];
            $sel = ($selected === $value) ? ' selected' : '';
            $html .= sprintf(
                '<option value="%s"%s>%s %s</option>',
                htmlspecialchars($value, ENT_QUOTES, 'UTF-8'),
                $sel,
                $meta['icon'],
                htmlspecialchars($translated, ENT_QUOTES, 'UTF-8')
            );
        }
        return $html;
    }
}
if (!function_exists('vms_valid_purpose')) {
    function vms_valid_purpose(string $p): string {
        return array_key_exists($p, getPurposeOptions()) ? $p : 'Reading/Study';
    }
}

// ============================================================
// PAGE BOOTSTRAP
// ============================================================
$db       = getDB();
$settings = getSettings();
$lang     = $_SESSION['visitor_lang'] ?? 'en';
$message  = '';
$error    = '';

// ============================================================
// v7.8 — Normalize institution name once, publish everywhere
// ============================================================
$institutionName = vms_clean_text($settings['institution_name'] ?? 'Library');
if ($institutionName === '') $institutionName = 'Library';

$GLOBALS['institution_name'] = $institutionName;
$GLOBALS['institutionName']  = $institutionName;
$GLOBALS['INSTITUTION_NAME'] = $institutionName;
$settings['institution_name'] = $institutionName;

// ============================================================
// HELPERS
// ============================================================
if (!function_exists('getSettingsColumns')) {
    function getSettingsColumns($db) {
        try {
            $stmt = $db->query("SHOW COLUMNS FROM settings");
            return $stmt->fetchAll(PDO::FETCH_COLUMN);
        } catch (PDOException $e) {
            error_log("Error getting settings columns: " . $e->getMessage());
            return [];
        }
    }
}

if (!function_exists('safeUpdateSettings')) {
    function safeUpdateSettings($db, $data) {
        try {
            $existingColumns = getSettingsColumns($db);
            $sql = "UPDATE settings SET ";
            $fields = array();
            $params = array();
            foreach ($data as $key => $value) {
                if (in_array($key, $existingColumns)) {
                    $fields[] = "$key = ?";
                    $params[] = $value;
                }
            }
            if (empty($fields)) return false;
            $sql .= implode(", ", $fields) . " WHERE id = 1";
            $stmt = $db->prepare($sql);
            $result = $stmt->execute($params);
            clearCache('settings_all');
            clearCache('settings');
            return $result;
        } catch (PDOException $e) {
            error_log("safeUpdateSettings error: " . $e->getMessage());
            return false;
        }
    }
}

if (!function_exists('getUploadPath')) {
    function getUploadPath() {
        if (!defined('UPLOAD_PATH')) {
            return sys_get_temp_dir() . '/vms-logos/';
        }
        $path = UPLOAD_PATH . '/logos/';
        if (!is_dir($path)) {
            @mkdir($path, 0777, true);
            @chmod($path, 0777);
        }
        return $path;
    }
}

/**
 * v7.8 — Prepare a text field before storing.
 * Decodes once (removes existing entities), then sanitizes WITHOUT
 * re-encoding so "Library & information" stays as a literal "&".
 */
if (!function_exists('vms_prepare_text')) {
    function vms_prepare_text($value) {
        $decoded = vms_clean_text($value);
        if (function_exists('sanitizeInput')) {
            // sanitizeInput is expected to NOT htmlspecialchars the value
            // (it's meant for storage). If your implementation does, the
            // value will be stored as "Library &amp; information" — but
            // vms_clean_text() will collapse it back on read, so the UI
            // stays correct either way.
            return sanitizeInput($decoded);
        }
        return $decoded;
    }
}

// ============================================================
// LOGO UPLOAD
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['institution_logo']) && $_FILES['institution_logo']['error'] === UPLOAD_ERR_OK) {
    $uploadDir = getUploadPath();
    $fileInfo = pathinfo($_FILES['institution_logo']['name']);
    $extension = strtolower($fileInfo['extension'] ?? '');
    $allowedExtensions = ['jpg', 'jpeg', 'png', 'gif', 'svg', 'webp'];
    $maxFileSize = 2 * 1024 * 1024;

    if ($_FILES['institution_logo']['size'] > $maxFileSize) {
        $error = 'Logo file too large. Maximum size is 2MB.';
    } elseif (!in_array($extension, $allowedExtensions)) {
        $error = 'Invalid file type. Allowed: jpg, jpeg, png, gif, svg, webp';
    } else {
        $filename = 'logo_' . time() . '.' . $extension;
        $targetPath = $uploadDir . $filename;
        if (move_uploaded_file($_FILES['institution_logo']['tmp_name'], $targetPath)) {
            if (!empty($settings['institution_logo']) && file_exists($uploadDir . $settings['institution_logo'])) {
                @unlink($uploadDir . $settings['institution_logo']);
            }
            $existingColumns = getSettingsColumns($db);
            if (in_array('institution_logo', $existingColumns)) {
                $update = $db->prepare("UPDATE settings SET institution_logo = ? WHERE id = 1");
                $update->execute([$filename]);
                $message = 'Logo uploaded successfully!';
                $settings = getSettings();
                clearCache('settings_all');
            } else {
                $error = 'institution_logo column not found.';
            }
        } else {
            $error = 'Failed to upload logo.';
        }
    }
}

// Remove logo
if (isset($_GET['remove_logo'])) {
    $uploadDir = getUploadPath();
    if (!empty($settings['institution_logo']) && file_exists($uploadDir . $settings['institution_logo'])) {
        @unlink($uploadDir . $settings['institution_logo']);
    }
    $existingColumns = getSettingsColumns($db);
    if (in_array('institution_logo', $existingColumns)) {
        $db->prepare("UPDATE settings SET institution_logo = NULL WHERE id = 1")->execute([]);
        $message = 'Logo removed successfully!';
    }
    $settings = getSettings();
    clearCache('settings_all');
}

// ============================================================
// SAVE SETTINGS (POST)
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_settings'])) {

    $csrfOk = true;
    if (function_exists('verifyCSRFToken') && isset($_POST['csrf_token'])) {
        $csrfOk = verifyCSRFToken($_POST['csrf_token']);
    }

    if (!$csrfOk) {
        $error = 'Invalid security token. Please refresh and try again.';
    } else {
        try {
            $existingColumns = getSettingsColumns($db);
            $data = array();

            // --- Institution ---
            $institutionFields = ['institution_name', 'institution_short_name', 'institution_address', 'institution_phone', 'institution_email', 'institution_website', 'institution_city', 'institution_state', 'institution_country', 'institution_pin'];
            foreach ($institutionFields as $field) {
                if (in_array($field, $existingColumns) && isset($_POST[$field])) {
                    $data[$field] = vms_prepare_text($_POST[$field]);
                }
            }

            // --- Public header ---
            $publicFields = ['public_header_title', 'public_header_subtitle', 'public_header_text_color', 'public_header_bg_color', 'public_header_height', 'public_header_layout', 'public_show_header_logo', 'public_show_institution_name'];
            foreach ($publicFields as $field) {
                if (in_array($field, $existingColumns)) {
                    if (in_array($field, ['public_show_header_logo', 'public_show_institution_name'])) {
                        $data[$field] = isset($_POST[$field]) ? 1 : 0;
                    } elseif (isset($_POST[$field])) {
                        $data[$field] = vms_prepare_text($_POST[$field]);
                    }
                }
            }

            // --- Admin header ---
            $adminFields = ['header_text', 'header_subtext', 'header_bg', 'header_text_color', 'header_height', 'show_header_logo', 'show_institution_name'];
            foreach ($adminFields as $field) {
                if (in_array($field, $existingColumns)) {
                    if (in_array($field, ['show_header_logo', 'show_institution_name'])) {
                        $data[$field] = isset($_POST[$field]) ? 1 : 0;
                    } elseif (isset($_POST[$field])) {
                        $data[$field] = vms_prepare_text($_POST[$field]);
                    }
                }
            }

            // --- Appearance ---
            $appearanceFields = ['primary_color', 'secondary_color', 'accent_color', 'body_bg', 'font_family'];
            foreach ($appearanceFields as $field) {
                if (in_array($field, $existingColumns) && isset($_POST[$field])) {
                    $data[$field] = vms_prepare_text($_POST[$field]);
                }
            }

            // --- Guest ---
            $guestFields = ['guest_enabled', 'guest_prefix', 'guest_padding', 'guest_auto_exit', 'guest_max_inside', 'guest_session_timeout', 'guest_show_photo', 'guest_allow_self_exit'];
            foreach ($guestFields as $field) {
                if (in_array($field, $existingColumns)) {
                    if (in_array($field, ['guest_enabled', 'guest_show_photo', 'guest_allow_self_exit'])) {
                        $data[$field] = isset($_POST[$field]) ? 1 : 0;
                    } elseif (isset($_POST[$field])) {
                        $data[$field] = ($field === 'guest_padding') ? (int)$_POST[$field] : vms_prepare_text($_POST[$field]);
                    }
                }
            }

            // --- Entry/Exit (with whitelisted default_purpose) ---
            $entryFields = ['enable_rfid', 'enable_barcode', 'enable_webcam', 'require_purpose', 'allow_self_exit', 'auto_refresh', 'default_purpose'];
            foreach ($entryFields as $field) {
                if (in_array($field, $existingColumns)) {
                    if (in_array($field, ['enable_rfid', 'enable_barcode', 'enable_webcam', 'require_purpose', 'allow_self_exit'])) {
                        $data[$field] = isset($_POST[$field]) ? 1 : 0;
                    } elseif (isset($_POST[$field])) {
                        if ($field === 'auto_refresh') {
                            $data[$field] = (int)$_POST[$field];
                        } elseif ($field === 'default_purpose') {
                            $raw = trim($_POST[$field]);
                            $data[$field] = vms_valid_purpose($raw);
                            if ($data[$field] !== $raw) {
                                $error = 'Note: "' . htmlspecialchars($raw, ENT_QUOTES, 'UTF-8') . '" is not a valid purpose — saved as "Reading/Study".';
                            }
                        } else {
                            $data[$field] = vms_prepare_text($_POST[$field]);
                        }
                    }
                }
            }

            // --- Book ---
            $bookFields = ['book_scan_enabled', 'book_unauthorized_alert', 'book_exit_photo', 'book_camera_auto_capture', 'book_auto_clear_logs', 'book_clear_logs_days'];
            foreach ($bookFields as $field) {
                if (in_array($field, $existingColumns)) {
                    if (in_array($field, ['book_scan_enabled', 'book_unauthorized_alert', 'book_exit_photo', 'book_camera_auto_capture', 'book_auto_clear_logs'])) {
                        $data[$field] = isset($_POST[$field]) ? 1 : 0;
                    } elseif (isset($_POST[$field])) {
                        $data[$field] = (int)$_POST[$field];
                    }
                }
            }

            // --- Reports ---
            $reportFields = ['report_auto_generate', 'report_email_recipients', 'report_default_range', 'report_show_charts'];
            foreach ($reportFields as $field) {
                if (in_array($field, $existingColumns)) {
                    if (in_array($field, ['report_auto_generate', 'report_show_charts'])) {
                        $data[$field] = isset($_POST[$field]) ? 1 : 0;
                    } elseif (isset($_POST[$field])) {
                        $data[$field] = vms_prepare_text($_POST[$field]);
                    }
                }
            }

            // --- Notifications ---
            $notifyFields = ['notify_entry', 'notify_exit', 'notify_unauthorized_book', 'notify_email', 'notify_webhook'];
            foreach ($notifyFields as $field) {
                if (in_array($field, $existingColumns)) {
                    if (in_array($field, ['notify_entry', 'notify_exit', 'notify_unauthorized_book'])) {
                        $data[$field] = isset($_POST[$field]) ? 1 : 0;
                    } elseif (isset($_POST[$field])) {
                        $data[$field] = vms_prepare_text($_POST[$field]);
                    }
                }
            }

            // --- Security ---
            $securityFields = ['session_timeout', 'max_login_attempts', 'enable_https', 'enable_csrf', 'force_ssl', 'ip_whitelist'];
            foreach ($securityFields as $field) {
                if (in_array($field, $existingColumns)) {
                    if (in_array($field, ['enable_https', 'enable_csrf', 'force_ssl'])) {
                        $data[$field] = isset($_POST[$field]) ? 1 : 0;
                    } elseif (isset($_POST[$field])) {
                        $data[$field] = ($field === 'ip_whitelist') ? vms_prepare_text($_POST[$field]) : (int)$_POST[$field];
                    }
                }
            }

            // --- Maintenance ---
            $maintenanceFields = ['maintenance_mode', 'maintenance_message', 'debug_mode', 'log_activities', 'log_retention_days'];
            foreach ($maintenanceFields as $field) {
                if (in_array($field, $existingColumns)) {
                    if (in_array($field, ['maintenance_mode', 'debug_mode', 'log_activities'])) {
                        $data[$field] = isset($_POST[$field]) ? 1 : 0;
                    } elseif (isset($_POST[$field])) {
                        $data[$field] = ($field === 'maintenance_message') ? vms_prepare_text($_POST[$field]) : (int)$_POST[$field];
                    }
                }
            }

            // --- Footer ---
            $footerFields = ['footer_text', 'footer_bg', 'footer_text_color', 'show_footer_logo'];
            foreach ($footerFields as $field) {
                if (in_array($field, $existingColumns)) {
                    if ($field === 'show_footer_logo') {
                        $data[$field] = isset($_POST[$field]) ? 1 : 0;
                    } elseif (isset($_POST[$field])) {
                        $data[$field] = vms_prepare_text($_POST[$field]);
                    }
                }
            }

            // --- Display options ---
            $displayFields = ['show_quote', 'show_live_stats', 'show_purpose_chart', 'show_category_chart', 'show_cover_flow'];
            foreach ($displayFields as $field) {
                if (in_array($field, $existingColumns)) {
                    $data[$field] = isset($_POST[$field]) ? 1 : 0;
                }
            }

            // --- Messages ---
            $messageFields = ['tagline', 'welcome_message', 'goodbye_message'];
            foreach ($messageFields as $field) {
                if (in_array($field, $existingColumns) && isset($_POST[$field])) {
                    $data[$field] = vms_prepare_text($_POST[$field]);
                }
            }

            if (empty($data)) {
                if (empty($error)) $error = 'No valid settings to save.';
            } else {
                if (safeUpdateSettings($db, $data)) {
                    if (empty($error)) $message = 'Settings saved successfully!';
                    $settings = getSettings();

                    // Re-normalize the institution name after reload
                    $institutionName = vms_clean_text($settings['institution_name'] ?? 'Library');
                    if ($institutionName === '') $institutionName = 'Library';
                    $settings['institution_name'] = $institutionName;
                    $GLOBALS['institution_name'] = $institutionName;
                    $GLOBALS['institutionName']  = $institutionName;
                    $GLOBALS['INSTITUTION_NAME'] = $institutionName;
                } elseif (empty($error)) {
                    $error = 'Failed to save settings.';
                }
            }
        } catch (Exception $e) {
            if (empty($error)) $error = 'Error saving settings: ' . $e->getMessage();
        }
    }

    $lang = $_SESSION['visitor_lang'] ?? 'en';
}

// ============================================================
// SYSTEM ACTIONS
// ============================================================
if (isset($_GET['clear_cache'])) {
    clearCache();
    $message = 'Cache cleared successfully!';
}
if (isset($_GET['reset_settings'])) {
    $defaults = [
        'institution_name' => 'My Library',
        'header_text' => 'Visitor Management System',
        'public_header_title' => 'Visitor Management System',
        'public_header_subtitle' => 'Library Entry/Exit System',
        'tagline' => 'Library Entry/Exit System',
        'primary_color' => '#1e3c72',
        'guest_enabled' => 1,
        'enable_rfid' => 1,
        'enable_barcode' => 1,
        'auto_refresh' => 10,
        'show_cover_flow' => 1,
        'public_show_header_logo' => 1,
        'public_show_institution_name' => 1,
        'public_header_text_color' => '#ffffff',
        'public_header_bg_color' => '#1e3c72',
        'public_header_height' => '80px',
        'public_header_layout' => 'centered',
        'guest_prefix' => 'GUEST-',
        'guest_padding' => 4,
        'guest_max_inside' => 50,
        'guest_show_photo' => 1,
        'guest_allow_self_exit' => 1,
        'default_purpose' => 'Reading/Study',
    ];
    $existingColumns = getSettingsColumns($db);
    $setParts = [];
    $values = [];
    foreach ($defaults as $key => $value) {
        if (in_array($key, $existingColumns)) {
            $setParts[] = "$key = ?";
            $values[] = $value;
        }
    }
    if (!empty($setParts)) {
        $sql = "UPDATE settings SET " . implode(", ", $setParts) . " WHERE id = 1";
        $db->prepare($sql)->execute($values);
        clearCache('settings_all');
        clearCache();
        $settings = getSettings();

        // Re-normalize after reset
        $institutionName = vms_clean_text($settings['institution_name'] ?? 'My Library');
        $settings['institution_name'] = $institutionName;
        $GLOBALS['institution_name'] = $institutionName;
        $GLOBALS['institutionName']  = $institutionName;
        $GLOBALS['INSTITUTION_NAME'] = $institutionName;

        $message = 'Settings reset to defaults!';
    }
}

$pageTitle = 'System Settings';
include __DIR__ . '/header.php';
?>

<style>
.settings-section {
    background: #f8f9fa;
    border-radius: 12px;
    padding: 20px;
    margin-bottom: 20px;
    border-left: 4px solid #1e3c72;
}
.settings-section h6 {
    color: #1e3c72;
    font-weight: 700;
    margin-bottom: 15px;
}
.settings-section .form-label {
    font-weight: 500;
    font-size: 0.85rem;
}
.logo-preview {
    max-height: 80px;
    max-width: 200px;
    border-radius: 8px;
    border: 1px solid #dee2e6;
    padding: 5px;
    background: white;
    object-fit: contain;
}
.toggle-label {
    display: flex;
    align-items: center;
    gap: 10px;
    cursor: pointer;
}
.toggle-label input[type="checkbox"] {
    width: 18px;
    height: 18px;
    cursor: pointer;
}
.color-preview-box {
    display: inline-block;
    width: 30px;
    height: 30px;
    border-radius: 6px;
    border: 2px solid #dee2e6;
    vertical-align: middle;
    margin-left: 10px;
}
.nav-tabs .nav-link {
    color: #495057;
    font-weight: 500;
}
.nav-tabs .nav-link.active {
    color: #1e3c72;
    font-weight: 600;
}
.tab-pane { padding-top: 15px; }
.guest-settings-preview {
    background: #f8f9fa;
    border-radius: 12px;
    padding: 15px;
    border: 1px solid #e9ecef;
}
@media (max-width: 768px) {
    .settings-section { padding: 15px; }
    .nav-tabs .nav-link { font-size: 0.8rem; padding: 6px 10px; }
}
</style>

<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
        <h4 class="mb-0"><i class="fas fa-cog me-2 text-primary"></i>System Settings</h4>
        <span class="badge bg-primary rounded-pill px-3 py-2">v<?= defined('APP_VERSION') ? htmlspecialchars(APP_VERSION, ENT_QUOTES, 'UTF-8') : '7.8' ?></span>
    </div>

    <?php if ($message): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <i class="fas fa-check-circle me-2"></i> <?= vms_h($message) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="alert alert-warning alert-dismissible fade show">
            <i class="fas fa-exclamation-circle me-2"></i> <?= $error ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="card shadow-sm">
        <div class="card-body">
            <ul class="nav nav-tabs responsive-tabs" role="tablist">
                <li class="nav-item"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#general"><i class="fas fa-building me-1"></i> General</button></li>
                <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#public"><i class="fas fa-globe me-1"></i> Public Kiosk</button></li>
                <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#admin"><i class="fas fa-user-cog me-1"></i> Admin Panel</button></li>
                <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#appearance"><i class="fas fa-palette me-1"></i> Appearance</button></li>
                <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#guest"><i class="fas fa-user-friends me-1"></i> Guest</button></li>
                <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#entry"><i class="fas fa-door-open me-1"></i> Entry/Exit</button></li>
                <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#book"><i class="fas fa-book me-1"></i> Book</button></li>
                <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#report"><i class="fas fa-chart-line me-1"></i> Reports</button></li>
                <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#notification"><i class="fas fa-bell me-1"></i> Notifications</button></li>
                <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#security"><i class="fas fa-shield-alt me-1"></i> Security</button></li>
                <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#maintenance"><i class="fas fa-tools me-1"></i> Maintenance</button></li>
            </ul>

            <form method="POST" enctype="multipart/form-data">
                <?php if (function_exists('generateCSRFToken')): ?>
                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(generateCSRFToken(), ENT_QUOTES, 'UTF-8') ?>">
                <?php endif; ?>

                <div class="tab-content">

                    <!-- General Tab -->
                    <div class="tab-pane fade show active" id="general">
                        <div class="settings-section">
                            <h6><i class="fas fa-building me-2"></i>Institution Information</h6>
                            <div class="row g-3">
                                <div class="col-12 col-md-6">
                                    <label class="form-label">Institution Name <span class="text-danger">*</span></label>
                                    <input type="text" name="institution_name" class="form-control" value="<?= vms_h($settings['institution_name'] ?? 'Library') ?>" required>
                                </div>
                                <div class="col-12 col-md-6">
                                    <label class="form-label">Short Name</label>
                                    <input type="text" name="institution_short_name" class="form-control" value="<?= vms_h($settings['institution_short_name'] ?? '') ?>">
                                </div>
                                <div class="col-12">
                                    <label class="form-label">Address</label>
                                    <input type="text" name="institution_address" class="form-control" value="<?= vms_h($settings['institution_address'] ?? '') ?>">
                                </div>
                                <div class="col-12 col-md-4">
                                    <label class="form-label">City</label>
                                    <input type="text" name="institution_city" class="form-control" value="<?= vms_h($settings['institution_city'] ?? '') ?>">
                                </div>
                                <div class="col-12 col-md-4">
                                    <label class="form-label">State</label>
                                    <input type="text" name="institution_state" class="form-control" value="<?= vms_h($settings['institution_state'] ?? '') ?>">
                                </div>
                                <div class="col-12 col-md-4">
                                    <label class="form-label">PIN Code</label>
                                    <input type="text" name="institution_pin" class="form-control" value="<?= vms_h($settings['institution_pin'] ?? '') ?>">
                                </div>
                                <div class="col-12 col-md-4">
                                    <label class="form-label">Country</label>
                                    <input type="text" name="institution_country" class="form-control" value="<?= vms_h($settings['institution_country'] ?? 'India') ?>">
                                </div>
                                <div class="col-12 col-md-4">
                                    <label class="form-label">Phone</label>
                                    <input type="text" name="institution_phone" class="form-control" value="<?= vms_h($settings['institution_phone'] ?? '') ?>">
                                </div>
                                <div class="col-12 col-md-4">
                                    <label class="form-label">Email</label>
                                    <input type="email" name="institution_email" class="form-control" value="<?= vms_h($settings['institution_email'] ?? '') ?>">
                                </div>
                                <div class="col-12">
                                    <label class="form-label">Website</label>
                                    <input type="url" name="institution_website" class="form-control" value="<?= vms_h($settings['institution_website'] ?? '') ?>">
                                </div>
                                <div class="col-12">
                                    <label class="form-label">Institution Logo</label>
                                    <div class="mb-2">
                                        <?php
                                        $logoPath = defined('UPLOAD_PATH') ? UPLOAD_PATH . '/logos/' . ($settings['institution_logo'] ?? '') : '';
                                        if (!empty($settings['institution_logo']) && $logoPath && file_exists($logoPath)):
                                        ?>
                                            <img src="data:image/png;base64,<?= base64_encode(file_get_contents($logoPath)) ?>" class="logo-preview" alt="Logo">
                                            <a href="?remove_logo=1" class="btn btn-sm btn-danger ms-2" onclick="return confirm('Remove logo?')"><i class="fas fa-trash"></i> Remove</a>
                                        <?php else: ?>
                                            <span class="text-muted">No logo uploaded</span>
                                        <?php endif; ?>
                                    </div>
                                    <input type="file" name="institution_logo" class="form-control" accept="image/*">
                                    <small class="text-muted">Recommended: PNG or SVG, max 2MB</small>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Public Kiosk Tab -->
                    <div class="tab-pane fade" id="public">
                        <div class="settings-section">
                            <h6><i class="fas fa-globe me-2"></i>Public Header Settings</h6>
                            <div class="row g-3">
                                <div class="col-12 col-md-6">
                                    <label class="form-label">Public Header Title</label>
                                    <input type="text" name="public_header_title" class="form-control" value="<?= vms_h($settings['public_header_title'] ?? 'Visitor Management System') ?>">
                                </div>
                                <div class="col-12 col-md-6">
                                    <label class="form-label">Public Header Subtitle</label>
                                    <input type="text" name="public_header_subtitle" class="form-control" value="<?= vms_h($settings['public_header_subtitle'] ?? 'Library Entry/Exit System') ?>">
                                </div>
                                <div class="col-12 col-md-4">
                                    <label class="form-label">Background Color</label>
                                    <input type="color" name="public_header_bg_color" class="form-control form-control-color" value="<?= htmlspecialchars($settings['public_header_bg_color'] ?? '#1e3c72', ENT_QUOTES, 'UTF-8') ?>">
                                </div>
                                <div class="col-12 col-md-4">
                                    <label class="form-label">Text Color</label>
                                    <input type="color" name="public_header_text_color" class="form-control form-control-color" value="<?= htmlspecialchars($settings['public_header_text_color'] ?? '#ffffff', ENT_QUOTES, 'UTF-8') ?>">
                                </div>
                                <div class="col-12 col-md-4">
                                    <label class="form-label">Header Height</label>
                                    <input type="text" name="public_header_height" class="form-control" value="<?= vms_h($settings['public_header_height'] ?? '80px') ?>">
                                </div>
                                <div class="col-12 col-md-6">
                                    <label class="form-label">Header Layout</label>
                                    <select name="public_header_layout" class="form-select">
                                        <option value="centered" <?= ($settings['public_header_layout'] ?? 'centered') == 'centered' ? 'selected' : '' ?>>Centered</option>
                                        <option value="left" <?= ($settings['public_header_layout'] ?? 'centered') == 'left' ? 'selected' : '' ?>>Left Aligned</option>
                                        <option value="right" <?= ($settings['public_header_layout'] ?? 'centered') == 'right' ? 'selected' : '' ?>>Right Aligned</option>
                                        <option value="split" <?= ($settings['public_header_layout'] ?? 'centered') == 'split' ? 'selected' : '' ?>>Split</option>
                                    </select>
                                </div>
                                <div class="col-12 col-md-6">
                                    <label class="toggle-label">
                                        <input type="checkbox" name="public_show_header_logo" <?= ($settings['public_show_header_logo'] ?? 1) ? 'checked' : '' ?>>
                                        Show Header Logo
                                    </label>
                                    <label class="toggle-label">
                                        <input type="checkbox" name="public_show_institution_name" <?= ($settings['public_show_institution_name'] ?? 1) ? 'checked' : '' ?>>
                                        Show Institution Name
                                    </label>
                                </div>
                            </div>
                        </div>

                        <div class="settings-section">
                            <h6><i class="fas fa-eye me-2"></i>Public Display Options</h6>
                            <div class="row g-3">
                                <div class="col-12 col-md-4">
                                    <label class="toggle-label">
                                        <input type="checkbox" name="show_quote" <?= ($settings['show_quote'] ?? 1) ? 'checked' : '' ?>>
                                        Show Quote
                                    </label>
                                </div>
                                <div class="col-12 col-md-4">
                                    <label class="toggle-label">
                                        <input type="checkbox" name="show_live_stats" <?= ($settings['show_live_stats'] ?? 1) ? 'checked' : '' ?>>
                                        Live Statistics
                                    </label>
                                </div>
                                <div class="col-12 col-md-4">
                                    <label class="toggle-label">
                                        <input type="checkbox" name="show_purpose_chart" <?= ($settings['show_purpose_chart'] ?? 1) ? 'checked' : '' ?>>
                                        Purpose Chart
                                    </label>
                                </div>
                                <div class="col-12 col-md-4">
                                    <label class="toggle-label">
                                        <input type="checkbox" name="show_category_chart" <?= ($settings['show_category_chart'] ?? 1) ? 'checked' : '' ?>>
                                        Category Chart
                                    </label>
                                </div>
                                <div class="col-12 col-md-4">
                                    <label class="toggle-label">
                                        <input type="checkbox" name="show_cover_flow" <?= ($settings['show_cover_flow'] ?? 1) ? 'checked' : '' ?>>
                                        Cover Flow
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Admin Panel Tab -->
                    <div class="tab-pane fade" id="admin">
                        <div class="settings-section">
                            <h6><i class="fas fa-user-cog me-2"></i>Admin Panel Settings</h6>
                            <div class="row g-3">
                                <div class="col-12 col-md-6">
                                    <label class="form-label">Header Title</label>
                                    <input type="text" name="header_text" class="form-control" value="<?= vms_h($settings['header_text'] ?? 'Visitor Management') ?>">
                                </div>
                                <div class="col-12 col-md-6">
                                    <label class="form-label">Header Subtext</label>
                                    <input type="text" name="header_subtext" class="form-control" value="<?= vms_h($settings['header_subtext'] ?? '') ?>">
                                </div>
                                <div class="col-12 col-md-4">
                                    <label class="form-label">Header Background</label>
                                    <input type="color" name="header_bg" class="form-control form-control-color" value="<?= htmlspecialchars($settings['header_bg'] ?? '#1e3c72', ENT_QUOTES, 'UTF-8') ?>">
                                </div>
                                <div class="col-12 col-md-4">
                                    <label class="form-label">Header Text Color</label>
                                    <input type="color" name="header_text_color" class="form-control form-control-color" value="<?= htmlspecialchars($settings['header_text_color'] ?? '#ffffff', ENT_QUOTES, 'UTF-8') ?>">
                                </div>
                                <div class="col-12 col-md-4">
                                    <label class="form-label">Header Height</label>
                                    <input type="text" name="header_height" class="form-control" value="<?= vms_h($settings['header_height'] ?? '80px') ?>">
                                </div>
                                <div class="col-12 col-md-6">
                                    <label class="toggle-label">
                                        <input type="checkbox" name="show_header_logo" <?= ($settings['show_header_logo'] ?? 1) ? 'checked' : '' ?>>
                                        Show Header Logo
                                    </label>
                                </div>
                                <div class="col-12 col-md-6">
                                    <label class="toggle-label">
                                        <input type="checkbox" name="show_institution_name" <?= ($settings['show_institution_name'] ?? 1) ? 'checked' : '' ?>>
                                        Show Institution Name
                                    </label>
                                </div>
                            </div>
                        </div>
                        <div class="settings-section">
                            <h6><i class="fas fa-image me-2"></i>Footer Settings</h6>
                            <div class="row g-3">
                                <div class="col-12 col-md-6">
                                    <label class="form-label">Footer Background</label>
                                    <input type="color" name="footer_bg" class="form-control form-control-color" value="<?= htmlspecialchars($settings['footer_bg'] ?? '#1e3c72', ENT_QUOTES, 'UTF-8') ?>">
                                </div>
                                <div class="col-12 col-md-6">
                                    <label class="form-label">Footer Text Color</label>
                                    <input type="color" name="footer_text_color" class="form-control form-control-color" value="<?= htmlspecialchars($settings['footer_text_color'] ?? '#ffffff', ENT_QUOTES, 'UTF-8') ?>">
                                </div>
                                <div class="col-12">
                                    <label class="form-label">Footer Text</label>
                                    <input type="text" name="footer_text" class="form-control" value="<?= vms_h($settings['footer_text'] ?? '') ?>">
                                </div>
                                <div class="col-12">
                                    <label class="toggle-label">
                                        <input type="checkbox" name="show_footer_logo" <?= ($settings['show_footer_logo'] ?? 1) ? 'checked' : '' ?>>
                                        Show Footer Logo
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Appearance Tab -->
                    <div class="tab-pane fade" id="appearance">
                        <div class="settings-section">
                            <h6><i class="fas fa-palette me-2"></i>Color Scheme</h6>
                            <div class="row g-3">
                                <div class="col-6 col-md-3">
                                    <label class="form-label">Primary Color</label>
                                    <input type="color" name="primary_color" class="form-control form-control-color" value="<?= htmlspecialchars($settings['primary_color'] ?? '#1e3c72', ENT_QUOTES, 'UTF-8') ?>">
                                </div>
                                <div class="col-6 col-md-3">
                                    <label class="form-label">Secondary Color</label>
                                    <input type="color" name="secondary_color" class="form-control form-control-color" value="<?= htmlspecialchars($settings['secondary_color'] ?? '#2a5298', ENT_QUOTES, 'UTF-8') ?>">
                                </div>
                                <div class="col-6 col-md-3">
                                    <label class="form-label">Accent Color</label>
                                    <input type="color" name="accent_color" class="form-control form-control-color" value="<?= htmlspecialchars($settings['accent_color'] ?? '#ffc107', ENT_QUOTES, 'UTF-8') ?>">
                                </div>
                                <div class="col-6 col-md-3">
                                    <label class="form-label">Body Background</label>
                                    <input type="color" name="body_bg" class="form-control form-control-color" value="<?= htmlspecialchars($settings['body_bg'] ?? '#f0f2f5', ENT_QUOTES, 'UTF-8') ?>">
                                </div>
                                <div class="col-12 col-md-6">
                                    <label class="form-label">Font Family</label>
                                    <select name="font_family" class="form-select">
                                        <?php foreach (['Inter','Roboto','Open Sans','Lato','Montserrat','Poppins'] as $f): ?>
                                            <option value="<?= htmlspecialchars($f, ENT_QUOTES, 'UTF-8') ?>" <?= ($settings['font_family'] ?? 'Inter') == $f ? 'selected' : '' ?>><?= htmlspecialchars($f, ENT_QUOTES, 'UTF-8') ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Guest Tab -->
                    <div class="tab-pane fade" id="guest">
                        <div class="settings-section">
                            <h6><i class="fas fa-user-friends me-2 text-success"></i>Guest Settings</h6>
                            <div class="row g-3">
                                <div class="col-12">
                                    <label class="toggle-label">
                                        <input type="checkbox" name="guest_enabled" <?= ($settings['guest_enabled'] ?? 1) ? 'checked' : '' ?>>
                                        <span class="fw-semibold">Enable Guest Mode</span>
                                    </label>
                                </div>
                                <div class="col-12 col-md-4">
                                    <label class="form-label">Guest ID Prefix</label>
                                    <input type="text" name="guest_prefix" class="form-control" value="<?= vms_h($settings['guest_prefix'] ?? 'GUEST-') ?>">
                                </div>
                                <div class="col-12 col-md-4">
                                    <label class="form-label">Guest ID Padding</label>
                                    <input type="number" name="guest_padding" class="form-control" value="<?= (int)($settings['guest_padding'] ?? 4) ?>" min="1" max="10">
                                </div>
                                <div class="col-12 col-md-4">
                                    <label class="form-label">Max Guests Inside</label>
                                    <input type="number" name="guest_max_inside" class="form-control" value="<?= (int)($settings['guest_max_inside'] ?? 50) ?>" min="1" max="500">
                                </div>
                                <div class="col-12 col-md-4">
                                    <label class="form-label">Auto-Exit (minutes)</label>
                                    <input type="number" name="guest_auto_exit" class="form-control" value="<?= (int)($settings['guest_auto_exit'] ?? 0) ?>" min="0">
                                </div>
                                <div class="col-12 col-md-4">
                                    <label class="form-label">Session Timeout (minutes)</label>
                                    <input type="number" name="guest_session_timeout" class="form-control" value="<?= (int)($settings['guest_session_timeout'] ?? 60) ?>" min="5" max="1440">
                                </div>
                                <div class="col-12 col-md-6">
                                    <label class="toggle-label">
                                        <input type="checkbox" name="guest_show_photo" <?= ($settings['guest_show_photo'] ?? 1) ? 'checked' : '' ?>>
                                        Show Guest Photo
                                    </label>
                                </div>
                                <div class="col-12 col-md-6">
                                    <label class="toggle-label">
                                        <input type="checkbox" name="guest_allow_self_exit" <?= ($settings['guest_allow_self_exit'] ?? 1) ? 'checked' : '' ?>>
                                        Allow Self-Exit
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Entry/Exit Tab -->
                    <div class="tab-pane fade" id="entry">
                        <div class="settings-section">
                            <h6><i class="fas fa-door-open me-2"></i>Entry/Exit Settings</h6>
                            <div class="row g-3">
                                <div class="col-12 col-md-4">
                                    <label class="toggle-label">
                                        <input type="checkbox" name="enable_rfid" <?= ($settings['enable_rfid'] ?? 1) ? 'checked' : '' ?>>
                                        Enable RFID
                                    </label>
                                </div>
                                <div class="col-12 col-md-4">
                                    <label class="toggle-label">
                                        <input type="checkbox" name="enable_barcode" <?= ($settings['enable_barcode'] ?? 1) ? 'checked' : '' ?>>
                                        Enable Barcode
                                    </label>
                                </div>
                                <div class="col-12 col-md-4">
                                    <label class="toggle-label">
                                        <input type="checkbox" name="enable_webcam" <?= ($settings['enable_webcam'] ?? 0) ? 'checked' : '' ?>>
                                        Enable Webcam
                                    </label>
                                </div>
                                <div class="col-12 col-md-6">
                                    <label class="toggle-label">
                                        <input type="checkbox" name="require_purpose" <?= ($settings['require_purpose'] ?? 1) ? 'checked' : '' ?>>
                                        Require Purpose
                                    </label>
                                </div>
                                <div class="col-12 col-md-6">
                                    <label class="toggle-label">
                                        <input type="checkbox" name="allow_self_exit" <?= ($settings['allow_self_exit'] ?? 0) ? 'checked' : '' ?>>
                                        Allow Self-Exit
                                    </label>
                                </div>
                                <div class="col-12 col-md-6">
                                    <label class="form-label">Auto Refresh (seconds)</label>
                                    <input type="number" name="auto_refresh" class="form-control" value="<?= (int)($settings['auto_refresh'] ?? 10) ?>" min="0" max="300">
                                </div>
                                <div class="col-12 col-md-6">
                                    <label class="form-label">Default Purpose</label>
                                    <select name="default_purpose" class="form-select">
                                        <?= renderPurposeOptions($settings['default_purpose'] ?? 'Reading/Study', $lang) ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Book Tab -->
                    <div class="tab-pane fade" id="book">
                        <div class="settings-section">
                            <h6><i class="fas fa-book me-2"></i>Book Settings</h6>
                            <div class="row g-3">
                                <div class="col-12 col-md-6">
                                    <label class="toggle-label">
                                        <input type="checkbox" name="book_scan_enabled" <?= ($settings['book_scan_enabled'] ?? 1) ? 'checked' : '' ?>>
                                        Enable Book Scanning
                                    </label>
                                </div>
                                <div class="col-12 col-md-6">
                                    <label class="toggle-label">
                                        <input type="checkbox" name="book_unauthorized_alert" <?= ($settings['book_unauthorized_alert'] ?? 1) ? 'checked' : '' ?>>
                                        Alert on Unauthorized Book
                                    </label>
                                </div>
                                <div class="col-12 col-md-6">
                                    <label class="toggle-label">
                                        <input type="checkbox" name="book_exit_photo" <?= ($settings['book_exit_photo'] ?? 1) ? 'checked' : '' ?>>
                                        Capture Photo on Book Exit
                                    </label>
                                </div>
                                <div class="col-12 col-md-6">
                                    <label class="toggle-label">
                                        <input type="checkbox" name="book_camera_auto_capture" <?= ($settings['book_camera_auto_capture'] ?? 1) ? 'checked' : '' ?>>
                                        Auto-Capture Camera
                                    </label>
                                </div>
                                <div class="col-12 col-md-6">
                                    <label class="toggle-label">
                                        <input type="checkbox" name="book_auto_clear_logs" <?= ($settings['book_auto_clear_logs'] ?? 0) ? 'checked' : '' ?>>
                                        Auto-Clear Book Logs
                                    </label>
                                </div>
                                <div class="col-12 col-md-6">
                                    <label class="form-label">Clear Logs After (days)</label>
                                    <input type="number" name="book_clear_logs_days" class="form-control" value="<?= (int)($settings['book_clear_logs_days'] ?? 30) ?>" min="1">
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Reports Tab -->
                    <div class="tab-pane fade" id="report">
                        <div class="settings-section">
                            <h6><i class="fas fa-chart-line me-2"></i>Report Settings</h6>
                            <div class="row g-3">
                                <div class="col-12 col-md-6">
                                    <label class="toggle-label">
                                        <input type="checkbox" name="report_auto_generate" <?= ($settings['report_auto_generate'] ?? 0) ? 'checked' : '' ?>>
                                        Auto-Generate Reports
                                    </label>
                                </div>
                                <div class="col-12 col-md-6">
                                    <label class="toggle-label">
                                        <input type="checkbox" name="report_show_charts" <?= ($settings['report_show_charts'] ?? 1) ? 'checked' : '' ?>>
                                        Show Charts
                                    </label>
                                </div>
                                <div class="col-12">
                                    <label class="form-label">Email Recipients</label>
                                    <input type="text" name="report_email_recipients" class="form-control" value="<?= vms_h($settings['report_email_recipients'] ?? '') ?>">
                                </div>
                                <div class="col-12 col-md-6">
                                    <label class="form-label">Default Report Range</label>
                                    <select name="report_default_range" class="form-select">
                                        <option value="today" <?= ($settings['report_default_range'] ?? 'month') == 'today' ? 'selected' : '' ?>>Today</option>
                                        <option value="week" <?= ($settings['report_default_range'] ?? 'month') == 'week' ? 'selected' : '' ?>>Last 7 Days</option>
                                        <option value="month" <?= ($settings['report_default_range'] ?? 'month') == 'month' ? 'selected' : '' ?>>Last 30 Days</option>
                                        <option value="year" <?= ($settings['report_default_range'] ?? 'month') == 'year' ? 'selected' : '' ?>>Last Year</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Notifications Tab -->
                    <div class="tab-pane fade" id="notification">
                        <div class="settings-section">
                            <h6><i class="fas fa-bell me-2"></i>Notification Settings</h6>
                            <div class="row g-3">
                                <div class="col-12 col-md-6">
                                    <label class="toggle-label">
                                        <input type="checkbox" name="notify_entry" <?= ($settings['notify_entry'] ?? 1) ? 'checked' : '' ?>>
                                        Notify on Entry
                                    </label>
                                </div>
                                <div class="col-12 col-md-6">
                                    <label class="toggle-label">
                                        <input type="checkbox" name="notify_exit" <?= ($settings['notify_exit'] ?? 1) ? 'checked' : '' ?>>
                                        Notify on Exit
                                    </label>
                                </div>
                                <div class="col-12 col-md-6">
                                    <label class="toggle-label">
                                        <input type="checkbox" name="notify_unauthorized_book" <?= ($settings['notify_unauthorized_book'] ?? 1) ? 'checked' : '' ?>>
                                        Notify Unauthorized Book
                                    </label>
                                </div>
                                <div class="col-12">
                                    <label class="form-label">Notification Email</label>
                                    <input type="email" name="notify_email" class="form-control" value="<?= vms_h($settings['notify_email'] ?? '') ?>">
                                </div>
                                <div class="col-12">
                                    <label class="form-label">Webhook URL</label>
                                    <input type="url" name="notify_webhook" class="form-control" value="<?= vms_h($settings['notify_webhook'] ?? '') ?>">
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Security Tab -->
                    <div class="tab-pane fade" id="security">
                        <div class="settings-section">
                            <h6><i class="fas fa-shield-alt me-2"></i>Security Settings</h6>
                            <div class="row g-3">
                                <div class="col-12 col-md-6">
                                    <label class="form-label">Session Timeout (minutes)</label>
                                    <input type="number" name="session_timeout" class="form-control" value="<?= (int)($settings['session_timeout'] ?? 60) ?>" min="5" max="1440">
                                </div>
                                <div class="col-12 col-md-6">
                                    <label class="form-label">Max Login Attempts</label>
                                    <input type="number" name="max_login_attempts" class="form-control" value="<?= (int)($settings['max_login_attempts'] ?? 5) ?>" min="1" max="20">
                                </div>
                                <div class="col-12 col-md-6">
                                    <label class="toggle-label">
                                        <input type="checkbox" name="enable_https" <?= ($settings['enable_https'] ?? 0) ? 'checked' : '' ?>>
                                        Enable HTTPS
                                    </label>
                                </div>
                                <div class="col-12 col-md-6">
                                    <label class="toggle-label">
                                        <input type="checkbox" name="force_ssl" <?= ($settings['force_ssl'] ?? 0) ? 'checked' : '' ?>>
                                        Force SSL
                                    </label>
                                </div>
                                <div class="col-12 col-md-6">
                                    <label class="toggle-label">
                                        <input type="checkbox" name="enable_csrf" <?= ($settings['enable_csrf'] ?? 1) ? 'checked' : '' ?>>
                                        Enable CSRF
                                    </label>
                                </div>
                                <div class="col-12">
                                    <label class="form-label">IP Whitelist</label>
                                    <textarea name="ip_whitelist" class="form-control" rows="3"><?= vms_h($settings['ip_whitelist'] ?? '') ?></textarea>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Maintenance Tab -->
                    <div class="tab-pane fade" id="maintenance">
                        <div class="settings-section">
                            <h6><i class="fas fa-tools me-2"></i>Maintenance Settings</h6>
                            <div class="row g-3">
                                <div class="col-12 col-md-6">
                                    <label class="toggle-label">
                                        <input type="checkbox" name="maintenance_mode" <?= ($settings['maintenance_mode'] ?? 0) ? 'checked' : '' ?>>
                                        Maintenance Mode
                                    </label>
                                </div>
                                <div class="col-12 col-md-6">
                                    <label class="toggle-label">
                                        <input type="checkbox" name="debug_mode" <?= ($settings['debug_mode'] ?? 0) ? 'checked' : '' ?>>
                                        Debug Mode
                                    </label>
                                </div>
                                <div class="col-12 col-md-6">
                                    <label class="toggle-label">
                                        <input type="checkbox" name="log_activities" <?= ($settings['log_activities'] ?? 1) ? 'checked' : '' ?>>
                                        Log Activities
                                    </label>
                                </div>
                                <div class="col-12 col-md-6">
                                    <label class="form-label">Log Retention (days)</label>
                                    <input type="number" name="log_retention_days" class="form-control" value="<?= (int)($settings['log_retention_days'] ?? 30) ?>" min="1" max="365">
                                </div>
                                <div class="col-12">
                                    <label class="form-label">Maintenance Message</label>
                                    <textarea name="maintenance_message" class="form-control" rows="3"><?= vms_h($settings['maintenance_message'] ?? 'System is currently undergoing maintenance. Please check back later.') ?></textarea>
                                </div>
                            </div>
                        </div>

                        <div class="settings-section">
                            <h6><i class="fas fa-database me-2"></i>System Actions</h6>
                            <div class="row g-3">
                                <div class="col-12 col-md-4">
                                    <a href="?clear_cache=1" class="btn btn-warning w-100" onclick="return confirm('Clear all caches?')">
                                        <i class="fas fa-broom me-2"></i> Clear Cache
                                    </a>
                                </div>
                                <div class="col-12 col-md-4">
                                    <a href="?reset_settings=1" class="btn btn-danger w-100" onclick="return confirm('⚠️ Reset all settings to defaults?')">
                                        <i class="fas fa-undo me-2"></i> Reset Settings
                                    </a>
                                </div>
                                <div class="col-12 col-md-4">
                                    <a href="guests.php" class="btn btn-success w-100">
                                        <i class="fas fa-user-friends me-2"></i> Manage Guests
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

                <div class="mt-4 text-end">
                    <button type="submit" name="save_settings" class="btn btn-primary btn-lg px-5">
                        <i class="fas fa-save me-2"></i> Save All Settings
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    // Live color previews
    document.querySelectorAll('input[type="color"]').forEach(function (input) {
        input.addEventListener('input', function () {
            const preview = this.parentElement?.querySelector('.color-preview-box');
            if (preview) preview.style.background = this.value;
        });
    });

    // Restore active tab after save
    const activeTab = sessionStorage.getItem('vmsSettingsActiveTab');
    if (activeTab) {
        const btn = document.querySelector(`.nav-link[data-bs-target="${activeTab}"]`);
        if (btn) new bootstrap.Tab(btn).show();
    }
    document.querySelectorAll('.nav-link[data-bs-toggle="tab"]').forEach(btn => {
        btn.addEventListener('shown.bs.tab', function () {
            sessionStorage.setItem('vmsSettingsActiveTab', this.getAttribute('data-bs-target'));
        });
    });
});
</script>

<?php
// ============================================================
// FOOTER — with entity-collapse post-processing  [CHANGED v7.8]
// ============================================================
// The shared footer.php may re-encode the institution name, producing
// literal "&amp;" in the HTML. We buffer it and collapse any over-encoded
// entities so the browser shows the name exactly as typed.

$__settingsFooterOut = '';

ob_start();
try {
    include __DIR__ . '/footer.php';
} catch (Throwable $e) {
    error_log('[settings.php] footer include: ' . $e->getMessage());
}
$__settingsFooterOut = ob_get_clean();

if ($__settingsFooterOut !== '') {
    // Collapse &amp;amp;amp; → &amp;amp; → &amp; (up to 5 passes)
    $prev = null;
    $out  = $__settingsFooterOut;
    $i    = 0;
    while ($prev !== $out && $i < 5) {
        $prev = $out;
        $out  = str_replace('&amp;amp;', '&amp;', $out);
        $i++;
    }
    // Final collapse: "word &amp; word" → "word & word" (only between
    // alphanumerics, so we never touch &nbsp; &copy; &quot; etc.)
    $out = preg_replace_callback(
        '/(?<=[A-Za-z0-9])\s*&amp;\s*(?=[A-Za-z0-9])/',
        function () { return ' & '; },
        $out
    );
    echo $out;
}
?>
