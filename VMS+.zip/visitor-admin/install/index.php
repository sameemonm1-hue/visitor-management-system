<?php
/**
 * Visitor Management System - Installation Wizard
 * Version: 7.3 FINAL – Complete with Public Settings
 */

if (file_exists(__DIR__ . '/../.installed')) {
    header('Location: ../dashboard.php');
    exit;
}

$step = $_GET['step'] ?? 1;
$error = '';
$success = '';
$kohaOk = false;

if ($step == 1) {
    $requirements = [
        'php_version' => version_compare(PHP_VERSION, '7.4.0', '>='),
        'pdo_mysql' => extension_loaded('pdo_mysql'),
        'gd' => extension_loaded('gd'),
        'json' => extension_loaded('json'),
        'zip' => extension_loaded('zip'),
        'file_permissions' => is_writable(__DIR__ . '/../uploads/') && is_writable(__DIR__ . '/../logs/'),
    ];
    $allPassed = array_reduce($requirements, function($c, $i) { return $c && $i; }, true);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['install_db'])) {
    $dbHost = $_POST['db_host'] ?? 'localhost';
    $dbName = $_POST['db_name'] ?? 'visitor_management';
    $dbUser = $_POST['db_user'] ?? 'koha_library';
    $dbPass = $_POST['db_pass'] ?? '';
    $kohaHost = $_POST['koha_host'] ?? 'localhost';
    $kohaDb = $_POST['koha_db'] ?? 'koha_library';
    $kohaUser = $_POST['koha_user'] ?? 'koha_library';
    $kohaPass = $_POST['koha_pass'] ?? '';
    $kohaIntranet = $_POST['koha_intranet'] ?? 'http://127.0.1.1:8081';
    $kohaOpac = $_POST['koha_opac'] ?? 'http://127.0.1.1:8082';
    $institutionName = $_POST['institution_name'] ?? 'My Library';
    $publicHeaderTitle = $_POST['public_header_title'] ?? 'Visitor Management System';
    $publicHeaderSubtitle = $_POST['public_header_subtitle'] ?? 'Library Entry/Exit System';
    
    try {
        // Connect to MySQL
        $pdo = new PDO("mysql:host=$dbHost;charset=utf8mb4", $dbUser, $dbPass);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        // Create database
        $pdo->exec("CREATE DATABASE IF NOT EXISTS `$dbName`");
        $pdo->exec("USE `$dbName`");
        
        // Import schema
        $schema = file_get_contents(__DIR__ . '/schema.sql');
        $pdo->exec($schema);
        
        // Import triggers
        if (file_exists(__DIR__ . '/triggers.sql')) {
            $triggers = file_get_contents(__DIR__ . '/triggers.sql');
            $pdo->exec($triggers);
        }
        
        // Update settings with user input
        $updateSettings = $pdo->prepare("
            UPDATE settings SET 
                institution_name = ?,
                public_header_title = ?,
                public_header_subtitle = ?,
                header_text = ?
            WHERE id = 1
        ");
        $updateSettings->execute([$institutionName, $publicHeaderTitle, $publicHeaderSubtitle, $publicHeaderTitle]);
        
        // Test Koha connection
        try {
            $koha = new PDO("mysql:host=$kohaHost;dbname=$kohaDb;charset=utf8mb4", $kohaUser, $kohaPass);
            $koha->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $koha->query("SELECT 1 FROM borrowers LIMIT 1");
            $kohaOk = true;
            
            // Check sessions table
            $check = $koha->query("SHOW TABLES LIKE 'sessions'");
            if ($check->rowCount() == 0) {
                $koha->exec("
                    CREATE TABLE sessions (
                        sessionid VARCHAR(100) NOT NULL PRIMARY KEY,
                        borrowernumber INT(11) NOT NULL,
                        lasttime INT(11) NOT NULL,
                        INDEX (borrowernumber),
                        INDEX (lasttime)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
                ");
                $error = "Sessions table created in Koha.";
            }
        } catch (PDOException $e) {
            $error = "Koha connection failed: " . $e->getMessage();
            $kohaOk = false;
        }
        
        // Create config file
        $configContent = "<?php\n";
        $configContent .= "// ============================================================\n";
        $configContent .= "// DATABASE CONFIGURATION\n";
        $configContent .= "// ============================================================\n";
        $configContent .= "define('DB_HOST', '" . addslashes($dbHost) . "');\n";
        $configContent .= "define('DB_USER', '" . addslashes($dbUser) . "');\n";
        $configContent .= "define('DB_PASS', '" . addslashes($dbPass) . "');\n";
        $configContent .= "define('DB_NAME', '" . addslashes($dbName) . "');\n";
        $configContent .= "define('DB_CHARSET', 'utf8mb4');\n\n";
        
        $configContent .= "// ============================================================\n";
        $configContent .= "// KOHA DATABASE CONFIGURATION\n";
        $configContent .= "// ============================================================\n";
        $configContent .= "define('KOHA_ENABLED', " . ($kohaOk ? 'true' : 'false') . ");\n";
        $configContent .= "define('KOHA_HOST', '" . addslashes($kohaHost) . "');\n";
        $configContent .= "define('KOHA_DB', '" . addslashes($kohaDb) . "');\n";
        $configContent .= "define('KOHA_USER', '" . addslashes($kohaUser) . "');\n";
        $configContent .= "define('KOHA_PASS', '" . addslashes($kohaPass) . "');\n";
        $configContent .= "define('KOHA_CHARSET', 'utf8mb4');\n\n";
        
        $configContent .= "// ============================================================\n";
        $configContent .= "// KOHA URL CONFIGURATION\n";
        $configContent .= "// ============================================================\n";
        $configContent .= "define('KOHA_INTRANET_URL', '" . addslashes($kohaIntranet) . "');\n";
        $configContent .= "define('KOHA_OPAC_URL', '" . addslashes($kohaOpac) . "');\n\n";
        
        $configContent .= "// ============================================================\n";
        $configContent .= "// SITE CONFIGURATION\n";
        $configContent .= "// ============================================================\n";
        $configContent .= "define('SITE_NAME', '" . addslashes($institutionName) . "');\n";
        $configContent .= "define('SITE_VERSION', '7.3.0');\n";
        $configContent .= "define('SITE_TIMEZONE', 'Asia/Kolkata');\n\n";
        
        $configContent .= "// ============================================================\n";
        $configContent .= "// SECURITY CONFIGURATION\n";
        $configContent .= "// ============================================================\n";
        $configContent .= "define('SESSION_TIMEOUT', 3600);\n";
        $configContent .= "define('CSRF_TOKEN_LIFETIME', 3600);\n";
        $configContent .= "define('LOGIN_ATTEMPTS', 5);\n";
        $configContent .= "define('MAX_UPLOAD_SIZE', 5242880);\n\n";
        
        $configContent .= "// ============================================================\n";
        $configContent .= "// PATHS\n";
        $configContent .= "// ============================================================\n";
        $configContent .= "define('ROOT_PATH', dirname(__DIR__));\n";
        $configContent .= "define('INCLUDES_PATH', ROOT_PATH . '/includes');\n";
        $configContent .= "define('UPLOAD_PATH', ROOT_PATH . '/uploads');\n";
        $configContent .= "define('LOGS_PATH', ROOT_PATH . '/logs');\n\n";
        
        $configContent .= "// ============================================================\n";
        $configContent .= "// FEATURE FLAGS\n";
        $configContent .= "// ============================================================\n";
        $configContent .= "define('FEATURE_RFID', true);\n";
        $configContent .= "define('FEATURE_WEBCAM', false);\n";
        $configContent .= "define('FEATURE_BOOK_SCAN', true);\n";
        $configContent .= "define('FEATURE_GUEST_MODE', true);\n";
        $configContent .= "define('FEATURE_MULTI_LANGUAGE', true);\n";
        $configContent .= "define('FEATURE_COVER_FLOW', true);\n";
        $configContent .= "define('FEATURE_FORCE_EXIT', true);\n";
        $configContent .= "define('FEATURE_PDF_REPORTS', true);\n";
        $configContent .= "define('FEATURE_CAMERA_CAPTURE', true);\n\n";
        
        $configContent .= "// ============================================================\n";
        $configContent .= "// CACHE SETTINGS\n";
        $configContent .= "// ============================================================\n";
        $configContent .= "define('CACHE_ENABLED', true);\n";
        $configContent .= "define('CACHE_LIFETIME', 30);\n\n";
        
        $configContent .= "// ============================================================\n";
        $configContent .= "// INITIALIZE\n";
        $configContent .= "// ============================================================\n";
        $configContent .= "date_default_timezone_set(SITE_TIMEZONE);\n\n";
        
        $configContent .= "require_once __DIR__ . '/constants.php';\n";
        $configContent .= "require_once __DIR__ . '/db.php';\n";
        $configContent .= "require_once __DIR__ . '/functions.php';\n";
        $configContent .= "require_once __DIR__ . '/koha.php';\n";
        $configContent .= "require_once __DIR__ . '/auth.php';\n";
        $configContent .= "require_once __DIR__ . '/languages.php';\n";
        $configContent .= "?>";
        
        file_put_contents(__DIR__ . '/../includes/config.php', $configContent);
        file_put_contents(__DIR__ . '/../.installed', date('Y-m-d H:i:s'));
        
        $success = 'Installation completed!' . ($kohaOk ? ' Koha integration active.' : '');
        $step = 3;
    } catch (PDOException $e) {
        $error = 'Database error: ' . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Installation - Visitor Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #1e3c72, #2a5298);
            min-height: 100vh;
            padding: 40px 20px;
            font-family: 'Inter', sans-serif;
        }
        .install-container {
            max-width: 750px;
            margin: 0 auto;
        }
        .install-card {
            background: #fff;
            border-radius: 24px;
            padding: 40px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
        }
        .step-dot {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: #e9ecef;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            color: #6c757d;
            margin: 0 5px;
        }
        .step-dot.active {
            background: #1e3c72;
            color: #fff;
        }
        .step-dot.completed {
            background: #28a745;
            color: #fff;
        }
        .requirement-item {
            padding: 10px 15px;
            border-radius: 10px;
            margin-bottom: 8px;
            background: #f8f9fa;
            display: flex;
            justify-content: space-between;
        }
        .requirement-item.passed {
            background: #d4edda;
        }
        .requirement-item.failed {
            background: #f8d7da;
        }
        .btn-install {
            background: #1e3c72;
            border: none;
            padding: 12px 40px;
            border-radius: 12px;
            font-weight: 600;
            color: #fff;
        }
        .btn-install:hover {
            background: #2a5298;
            color: #fff;
        }
        .form-label {
            font-weight: 500;
        }
        .help-text {
            font-size: 0.75rem;
            color: #6c757d;
        }
        .public-settings-preview {
            background: #f8f9fa;
            border-radius: 12px;
            padding: 15px 20px;
            border: 1px solid #e9ecef;
        }
        .public-settings-preview .preview-header {
            background: #1e3c72;
            color: white;
            padding: 10px 15px;
            border-radius: 8px 8px 0 0;
            margin: -15px -20px 15px -20px;
            font-weight: 600;
        }
    </style>
</head>
<body>
<div class="install-container">
    <div class="install-card">
        <div class="text-center mb-4">
            <h2><i class="fas fa-door-open text-primary me-2"></i> Visitor Management</h2>
            <p class="text-muted">Installation Wizard v7.3</p>
        </div>
        
        <div class="text-center mb-4">
            <span class="step-dot <?= $step>=1?'active':'' ?>">1</span>
            <span class="step-dot <?= $step>=2?($step==2?'active':'completed'):'' ?>">2</span>
            <span class="step-dot <?= $step>=3?'completed':'' ?>">3</span>
        </div>
        
        <?php if ($error): ?>
            <div class="alert alert-warning"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        <?php if ($success): ?>
            <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
        <?php endif; ?>
        
        <?php if ($step==1): ?>
            <h4>System Requirements</h4>
            <?php foreach($requirements as $key=>$val): ?>
                <div class="requirement-item <?= $val?'passed':'failed' ?>">
                    <span><?= str_replace('_',' ',ucfirst($key)) ?></span>
                    <span><?= $val?'✅':'❌' ?></span>
                </div>
            <?php endforeach; ?>
            <?php if($allPassed): ?>
                <a href="?step=2" class="btn btn-install w-100">Continue</a>
            <?php else: ?>
                <div class="alert alert-warning">Please fix the issues above.</div>
            <?php endif; ?>
            
        <?php elseif($step==2): ?>
            <h4>Database Setup</h4>
            <form method="POST">
                <!-- Database Settings -->
                <div class="row g-3">
                    <div class="col-12">
                        <h6 class="border-bottom pb-2"><i class="fas fa-database text-primary me-2"></i>Database Configuration</h6>
                    </div>
                    <div class="col-12 col-md-6">
                        <label class="form-label">Database Host</label>
                        <input type="text" name="db_host" class="form-control" value="localhost" required>
                    </div>
                    <div class="col-12 col-md-6">
                        <label class="form-label">Database Name</label>
                        <input type="text" name="db_name" class="form-control" value="visitor_management" required>
                    </div>
                    <div class="col-12 col-md-6">
                        <label class="form-label">Database Username</label>
                        <input type="text" name="db_user" class="form-control" value="koha_library" required>
                    </div>
                    <div class="col-12 col-md-6">
                        <label class="form-label">Database Password</label>
                        <input type="password" name="db_pass" class="form-control">
                        <small class="help-text">Enter your MySQL password</small>
                    </div>
                </div>
                
                <!-- Koha Settings -->
                <div class="row g-3 mt-2">
                    <div class="col-12">
                        <h6 class="border-bottom pb-2"><i class="fas fa-book text-primary me-2"></i>Koha Integration</h6>
                    </div>
                    <div class="col-12 col-md-6">
                        <label class="form-label">Koha Host</label>
                        <input type="text" name="koha_host" class="form-control" value="localhost">
                    </div>
                    <div class="col-12 col-md-6">
                        <label class="form-label">Koha Database</label>
                        <input type="text" name="koha_db" class="form-control" value="koha_library">
                    </div>
                    <div class="col-12 col-md-6">
                        <label class="form-label">Koha Username</label>
                        <input type="text" name="koha_user" class="form-control" value="koha_library">
                    </div>
                    <div class="col-12 col-md-6">
                        <label class="form-label">Koha Password</label>
                        <input type="password" name="koha_pass" class="form-control">
                    </div>
                    <div class="col-12 col-md-6">
                        <label class="form-label">Koha Intranet URL</label>
                        <input type="text" name="koha_intranet" class="form-control" value="http://127.0.1.1:8081">
                        <small class="help-text">e.g., http://127.0.1.1:8081</small>
                    </div>
                    <div class="col-12 col-md-6">
                        <label class="form-label">Koha OPAC URL</label>
                        <input type="text" name="koha_opac" class="form-control" value="http://127.0.1.1:8082">
                        <small class="help-text">e.g., http://127.0.1.1:8082</small>
                    </div>
                </div>
                
                <!-- Institution Settings -->
                <div class="row g-3 mt-2">
                    <div class="col-12">
                        <h6 class="border-bottom pb-2"><i class="fas fa-building text-primary me-2"></i>Institution & Public Settings</h6>
                    </div>
                    <div class="col-12">
                        <label class="form-label">Institution Name</label>
                        <input type="text" name="institution_name" class="form-control" value="My Library" required>
                    </div>
                    <div class="col-12 col-md-6">
                        <label class="form-label">Public Header Title</label>
                        <input type="text" name="public_header_title" class="form-control" value="Visitor Management System">
                        <small class="help-text">Main title on the public kiosk</small>
                    </div>
                    <div class="col-12 col-md-6">
                        <label class="form-label">Public Header Subtitle</label>
                        <input type="text" name="public_header_subtitle" class="form-control" value="Library Entry/Exit System">
                        <small class="help-text">Subtitle on the public kiosk</small>
                    </div>
                </div>
                
                <!-- Public Preview -->
                <div class="public-settings-preview mt-3">
                    <div class="preview-header"><i class="fas fa-eye me-2"></i>Public Kiosk Preview</div>
                    <div style="background:#1e3c72;color:white;padding:12px 16px;border-radius:8px;text-align:center;">
                        <div style="font-size:1.1rem;font-weight:700;" id="previewTitle">Visitor Management System</div>
                        <div style="font-size:0.8rem;opacity:0.8;" id="previewSubtitle">Library Entry/Exit System</div>
                    </div>
                </div>
                
                <button type="submit" name="install_db" class="btn btn-install w-100 mt-4">
                    <i class="fas fa-rocket me-2"></i> Install System
                </button>
            </form>
            
            <script>
                // Live preview
                document.querySelector('[name="public_header_title"]')?.addEventListener('input', function() {
                    document.getElementById('previewTitle').textContent = this.value || 'Visitor Management System';
                });
                document.querySelector('[name="public_header_subtitle"]')?.addEventListener('input', function() {
                    document.getElementById('previewSubtitle').textContent = this.value || 'Library Entry/Exit System';
                });
                document.querySelector('[name="public_header_bg_color"]')?.addEventListener('input', function() {
                    document.querySelector('.public-settings-preview .preview-header').style.background = this.value;
                });
            </script>
            
        <?php elseif($step==3): ?>
            <div class="text-center">
                <div class="display-1 text-success mb-3"><i class="fas fa-check-circle"></i></div>
                <h3>Installation Complete!</h3>
                <p class="text-muted">Your Visitor Management System is ready.</p>
                
                <div class="alert alert-info">
                    <strong><i class="fas fa-info-circle me-2"></i>Default Admin Account</strong><br>
                    Use your Koha credentials to log in to the admin panel.
                </div>
                
                <div class="row g-3 mt-4">
                    <div class="col-md-6">
                        <a href="<?= KOHA_OPAC_URL ?>/visitor/" class="btn btn-primary w-100 py-3">
                            <i class="fas fa-door-open me-2"></i> Public Kiosk
                        </a>
                    </div>
                    <div class="col-md-6">
                        <a href="<?= KOHA_INTRANET_URL ?>/cgi-bin/koha/visitor/dashboard.php" class="btn btn-success w-100 py-3">
                            <i class="fas fa-user-shield me-2"></i> Admin Panel
                        </a>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
