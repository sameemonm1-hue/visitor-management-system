-- ============================================================================
-- Visitor Management System — Complete Schema
-- Version: 8.12 FINAL — Koha-integrated, fully self-contained, RE-RUN-SAFE
--
-- Idempotent: safe to run on fresh OR existing database — even repeatedly.
-- Uses temporary stored procedures to add columns/indexes only if missing.
-- All seed data is guarded with WHERE NOT EXISTS so re-runs never duplicate.
--
-- Tested on:
--   MySQL 5.7.44, MySQL 8.0.x, MariaDB 10.3.x, MariaDB 10.6.x, MariaDB 10.11.x
--
-- ----------------------------------------------------------------------------
-- Tables created (41):
--   CORE VMS (Koha-integrated):
--     settings, entry_exit_logs, book_exit_logs, book_alerts,
--     activity_log, purpose_stats, notifications_queue,
--     occupancy_snapshots, appointments, feedback,
--     computers, computer_sessions, computer_policies, computer_attendance,
--     system_users, system_user_logins, schema_migrations
--   EXTENDED VMS:
--     visitor_goals, badge_queue, audit_trail, lost_found, recommendations,
--     classification_data, members_extra
--   PUBLIC KIOSK SUPPORT:
--     quotes, notices, ebooks, book_metadata_cache
--   ADMIN SHELL / AUTH COMPATIBILITY:
--     institutions, members, users, session_logs, notification_logs,
--     module_permissions, user_preferences, quick_actions,
--     login_cards, staff_profiles, api_keys
--   STOCK VERIFICATION (v8.7 NEW):
--     vms_stock_verification_sessions
--     vms_stock_verification_scans
--
-- Views created (1):
--     entry_exit   -> alias for entry_exit_logs (legacy kiosk compatibility,
--                     exposes guest_photo in v8.9+)
--
-- Triggers created (1):
--     trg_purpose_stats   — aggregates daily purpose counters on insert
--
-- v8.12 CHANGELOG (fixes after review):
--   • FIXED: book_exit_logs.exit_time now has DEFAULT CURRENT_TIMESTAMP
--            so reports never see NULL exit_time.
--   • FIXED: added CHECK-equivalent for is_authorized via TINYINT(1) UNSIGNED.
--   • ADDED: book_exit_logs.created_by (INT NULL) — audit trail.
--   • ADDED: book_exit_logs.gate_number index for security gate queries.
--   • ADDED: book_exit_logs.photo_path index for alert page filters.
--   • ADDED: book_exit_logs composite index (book_barcode, exit_time) for reports.
--   • ADDED: entry_exit_logs.guest_photo index for photo lookups.
--   • ADDED: FK to koha_library.borrowers on computer_sessions.borrowernumber
--            (guarded — only if Koha DB is reachable at schema time; see NOTE).
--   • ADDED: FK vms_stock_verification_scans.session_id -> sessions.id.
--   • FIXED: backfill INSERT now uses NOT EXISTS so re-runs never duplicate
--            book_alerts even after manual deletes.
--   • FIXED: entry_exit VIEW — added guest_photo to the SELECT list (was
--            missing in the v8.11 view body).
--   • DOCUMENTED: book_exit_logs.guest_id references entry_exit_logs.id
--                 (there is no separate guests table).
--   • DOCUMENTED: book_exit_logs.borrowernumber references koha_library.borrowers
--                 (cross-DB, no FK enforced — kept as INT for portability).
--   • BUMPED: schema_migrations version to 8.12.0.
--   • PRESERVED: All v8.11 content (full book_exit_logs column set, stock
--                verification, entity normalisation, all seeds).
--
-- NOTE ON CROSS-DB FOREIGN KEYS:
--   MySQL/MariaDB does NOT support foreign keys across databases when the
--   referenced DB is in a different schema. Since Koha lives in
--   `koha_library` and VMS lives in `visitor_management`, we CANNOT add a
--   real FK from book_exit_logs.borrowernumber -> koha_library.borrowers.
--   Instead we rely on application-level validation in PHP. The FK is
--   documented in the comments for clarity but not enforced at DB level.
--   This is intentional and matches how Koha itself handles cross-DB links.
-- ============================================================================

-- ============================================================================
-- DATABASE + CHARACTER SET
-- ============================================================================
CREATE DATABASE IF NOT EXISTS visitor_management
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE visitor_management;

SET NAMES utf8mb4;
SET time_zone = '+00:00';
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

-- ============================================================================
-- HELPER: safe column addition
-- ============================================================================
DROP PROCEDURE IF EXISTS vms_add_column_if_missing;
DELIMITER //
CREATE PROCEDURE vms_add_column_if_missing(
    IN p_table VARCHAR(64),
    IN p_column VARCHAR(64),
    IN p_definition TEXT
)
BEGIN
    DECLARE col_exists INT DEFAULT 0;
    SELECT COUNT(*) INTO col_exists
      FROM information_schema.COLUMNS
     WHERE TABLE_SCHEMA = DATABASE()
       AND TABLE_NAME   = p_table
       AND COLUMN_NAME  = p_column;
    IF col_exists = 0 THEN
        SET @ddl = CONCAT('ALTER TABLE `', p_table, '` ADD COLUMN `', p_column, '` ', p_definition);
        PREPARE stmt FROM @ddl;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END //
DELIMITER ;

-- ============================================================================
-- HELPER: safe index addition
-- ============================================================================
DROP PROCEDURE IF EXISTS vms_add_index_if_missing;
DELIMITER //
CREATE PROCEDURE vms_add_index_if_missing(
    IN p_table VARCHAR(64),
    IN p_index VARCHAR(64),
    IN p_definition TEXT
)
BEGIN
    DECLARE idx_exists INT DEFAULT 0;
    SELECT COUNT(*) INTO idx_exists
      FROM information_schema.STATISTICS
     WHERE TABLE_SCHEMA = DATABASE()
       AND TABLE_NAME   = p_table
       AND INDEX_NAME   = p_index;
    IF idx_exists = 0 THEN
        SET @ddl = CONCAT('ALTER TABLE `', p_table, '` ADD INDEX `', p_index, '` ', p_definition);
        PREPARE stmt FROM @ddl;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END //
DELIMITER ;

-- ============================================================================
-- 0. SCHEMA MIGRATIONS TRACKER
-- ============================================================================
CREATE TABLE IF NOT EXISTS schema_migrations (
    id INT PRIMARY KEY AUTO_INCREMENT,
    version VARCHAR(50) NOT NULL UNIQUE,
    description VARCHAR(255) NULL,
    applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_version (version)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- 1. SETTINGS (singleton row id=1)
-- ============================================================================
CREATE TABLE IF NOT EXISTS settings (
    id INT PRIMARY KEY AUTO_INCREMENT,

    -- Institution
    institution_name VARCHAR(200) DEFAULT 'Library',
    institution_short_name VARCHAR(100) NULL,
    institution_address TEXT NULL,
    institution_phone VARCHAR(50) NULL,
    institution_email VARCHAR(200) NULL,
    institution_website VARCHAR(200) NULL,
    institution_city VARCHAR(100) NULL,
    institution_state VARCHAR(100) NULL,
    institution_country VARCHAR(100) DEFAULT 'India',
    institution_pin VARCHAR(20) NULL,
    institution_logo VARCHAR(255) NULL,

    -- Public kiosk header
    public_header_title VARCHAR(200) DEFAULT 'Visitor Management System',
    public_header_subtitle VARCHAR(200) DEFAULT 'Library Entry/Exit System',
    public_header_text_color VARCHAR(20) DEFAULT '#ffffff',
    public_header_bg_color VARCHAR(20) DEFAULT '#1e3c72',
    public_header_height VARCHAR(20) DEFAULT '80px',
    public_header_layout VARCHAR(20) DEFAULT 'centered',
    public_show_header_logo TINYINT(1) DEFAULT 1,
    public_show_institution_name TINYINT(1) DEFAULT 1,
    public_header_logo VARCHAR(255) NULL,
    public_header_bg VARCHAR(255) NULL,
    public_show_quote TINYINT(1) DEFAULT 1,
    public_show_stats TINYINT(1) DEFAULT 1,
    public_show_purpose_chart TINYINT(1) DEFAULT 1,
    public_show_cover_flow TINYINT(1) DEFAULT 1,
    public_show_category_chart TINYINT(1) DEFAULT 1,

    -- Admin header
    header_text VARCHAR(200) DEFAULT 'Visitor Management',
    header_subtext VARCHAR(200) NULL,
    header_bg VARCHAR(20) DEFAULT '#1e3c72',
    header_text_color VARCHAR(20) DEFAULT '#ffffff',
    header_height VARCHAR(20) DEFAULT '80px',
    show_header_logo TINYINT(1) DEFAULT 1,
    show_institution_name TINYINT(1) DEFAULT 1,
    header_logo VARCHAR(255) NULL,

    -- Footer
    footer_text TEXT NULL,
    footer_bg VARCHAR(20) DEFAULT '#1e3c72',
    footer_text_color VARCHAR(20) DEFAULT '#ffffff',
    footer_logo VARCHAR(255) NULL,
    show_footer_logo TINYINT(1) DEFAULT 1,

    -- Appearance
    primary_color VARCHAR(20) DEFAULT '#1e3c72',
    secondary_color VARCHAR(20) DEFAULT '#2a5298',
    accent_color VARCHAR(20) DEFAULT '#ffc107',
    body_bg VARCHAR(20) DEFAULT '#f0f2f5',
    font_family VARCHAR(50) DEFAULT 'Inter',

    -- Display toggles
    show_quote TINYINT(1) DEFAULT 1,
    show_live_stats TINYINT(1) DEFAULT 1,
    show_purpose_chart TINYINT(1) DEFAULT 1,
    show_category_chart TINYINT(1) DEFAULT 1,
    show_cover_flow TINYINT(1) DEFAULT 1,

    -- Messages
    tagline VARCHAR(200) DEFAULT 'Library Entry/Exit System',
    welcome_message VARCHAR(200) DEFAULT 'Welcome to the Library',
    goodbye_message VARCHAR(200) DEFAULT 'Thank you for visiting',

    -- Guest settings
    guest_enabled TINYINT(1) DEFAULT 1,
    guest_prefix VARCHAR(20) DEFAULT 'GUEST-',
    guest_padding INT DEFAULT 4,
    guest_number_padding INT DEFAULT 4,
    guest_daily_counter INT DEFAULT 1,
    guest_last_reset DATE NULL,
    guest_auto_exit INT DEFAULT 0,
    guest_max_inside INT DEFAULT 50,
    guest_session_timeout INT DEFAULT 60,
    guest_show_photo TINYINT(1) DEFAULT 1,
    guest_allow_self_exit TINYINT(1) DEFAULT 1,

    -- Entry/Exit
    enable_webcam TINYINT(1) DEFAULT 0,
    enable_webcam_capture TINYINT(1) DEFAULT 0,
    enable_rfid TINYINT(1) DEFAULT 1,
    enable_barcode TINYINT(1) DEFAULT 1,
    auto_refresh INT DEFAULT 10,
    require_purpose TINYINT(1) DEFAULT 1,
    allow_self_exit TINYINT(1) DEFAULT 0,
    default_purpose VARCHAR(100) DEFAULT 'Reading/Study',

    -- Book settings
    book_scan_enabled TINYINT(1) DEFAULT 1,
    book_unauthorized_alert TINYINT(1) DEFAULT 1,
    book_exit_photo TINYINT(1) DEFAULT 1,
    book_camera_auto_capture TINYINT(1) DEFAULT 1,
    book_camera_countdown INT DEFAULT 5,
    book_auto_clear_logs TINYINT(1) DEFAULT 0,
    book_clear_logs_days INT DEFAULT 30,

    -- Reports
    report_auto_generate TINYINT(1) DEFAULT 0,
    report_email_recipients TEXT NULL,
    report_default_range VARCHAR(20) DEFAULT 'month',
    report_show_charts TINYINT(1) DEFAULT 1,
    report_font_size INT DEFAULT 10,
    report_primary_color VARCHAR(20) DEFAULT '#1e3c72',
    report_logo_position VARCHAR(20) DEFAULT 'left',
    report_logo_right VARCHAR(255) DEFAULT '',
    report_logo VARCHAR(255) DEFAULT '',
    report_watermark_enabled TINYINT(1) DEFAULT 1,
    report_watermark_text VARCHAR(200) NULL,
    report_watermark_opacity INT DEFAULT 10,
    report_signature_enabled TINYINT(1) DEFAULT 0,
    report_signature_name VARCHAR(200) DEFAULT 'Librarian',
    report_signature_title VARCHAR(200) DEFAULT 'Chief Librarian',
    report_signature_image VARCHAR(255) NULL,
    report_footer_text VARCHAR(255) DEFAULT 'This is a system generated report',

    -- Notifications
    notify_entry TINYINT(1) DEFAULT 1,
    notify_exit TINYINT(1) DEFAULT 1,
    notify_unauthorized_book TINYINT(1) DEFAULT 1,
    notify_email VARCHAR(200) NULL,
    notify_webhook VARCHAR(500) NULL,

    -- Alert system
    alert_sound_enabled TINYINT(1) DEFAULT 1,
    alert_auto_refresh INT DEFAULT 10,
    alert_retention_days INT DEFAULT 90,

    -- SMS
    sms_enabled TINYINT(1) DEFAULT 0,
    sms_api_key VARCHAR(200) NULL,
    sms_sender_id VARCHAR(20) NULL,
    sms_recipient VARCHAR(20) NULL,

    -- Webhook
    webhook_url VARCHAR(500) NULL,
    enable_webhook TINYINT(1) DEFAULT 0,

    -- Security
    session_timeout INT DEFAULT 60,
    max_login_attempts INT DEFAULT 5,
    enable_https TINYINT(1) DEFAULT 0,
    enable_csrf TINYINT(1) DEFAULT 1,
    force_ssl TINYINT(1) DEFAULT 0,
    ip_whitelist TEXT NULL,

    -- Maintenance
    maintenance_mode TINYINT(1) DEFAULT 0,
    maintenance_message TEXT NULL,
    debug_mode TINYINT(1) DEFAULT 0,
    log_activities TINYINT(1) DEFAULT 1,
    log_retention_days INT DEFAULT 30,

    -- Occupancy
    max_capacity INT DEFAULT 100,
    enable_occupancy_alerts TINYINT(1) DEFAULT 1,
    occupancy_warning_percent INT DEFAULT 80,
    occupancy_critical_percent INT DEFAULT 95,

    -- Appointments
    enable_appointments TINYINT(1) DEFAULT 1,
    appointment_slot_duration INT DEFAULT 30,
    appointment_max_per_slot INT DEFAULT 5,

    -- Feature toggles
    enable_feedback TINYINT(1) DEFAULT 1,
    enable_dark_mode TINYINT(1) DEFAULT 1,

    -- Computer module
    system_auto_end_stale_hours INT DEFAULT 8,
    system_max_session_minutes INT DEFAULT 0,
    system_enforce_policy TINYINT(1) DEFAULT 1,
    system_default_policy_role VARCHAR(50) DEFAULT 'student',
    system_notify_on_start TINYINT(1) DEFAULT 0,
    system_notify_on_end TINYINT(1) DEFAULT 0,
    system_webhook_url VARCHAR(500) NULL,
    system_show_photos TINYINT(1) DEFAULT 1,
    system_allow_force_end TINYINT(1) DEFAULT 1,
    system_session_cooldown_seconds INT DEFAULT 60,

    -- Purpose marker (v8.6)
    purpose_include_computer_uses TINYINT(1) DEFAULT 1,

    -- Stock verification (v8.7)
    stock_verify_enabled TINYINT(1) DEFAULT 1,
    stock_verify_default_branch VARCHAR(50) DEFAULT NULL,
    stock_verify_auto_close_days INT DEFAULT 30,

    -- API
    api_key VARCHAR(200) NULL,

    -- Timestamps
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO settings (id) VALUES (1)
ON DUPLICATE KEY UPDATE id = id;

-- ============================================================================
-- 2. ENTRY / EXIT LOGS
-- v8.9 — guest_photo column added for guest name + photo capture feature
-- v8.12 — guest_photo index added for faster photo lookups
-- ============================================================================
CREATE TABLE IF NOT EXISTS entry_exit_logs (
    id INT PRIMARY KEY AUTO_INCREMENT,
    admno VARCHAR(50) NOT NULL,
    member_name VARCHAR(200) NOT NULL,
    member_category VARCHAR(100) NULL,
    guest_photo VARCHAR(255) NULL,               -- v8.9: filename of guest photo
    entry_date DATE NOT NULL,
    entry_time TIME NOT NULL,
    exit_time TIME NULL,
    purpose VARCHAR(200) NULL,
    status ENUM('inside','exited') DEFAULT 'inside',
    entry_type ENUM('member','guest') DEFAULT 'member',
    rfid_tag VARCHAR(100) NULL,
    gate_number VARCHAR(20) NULL,
    staff_id INT NULL,
    notes TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    INDEX idx_admno        (admno),
    INDEX idx_status       (status),
    INDEX idx_date         (entry_date),
    INDEX idx_entry_type   (entry_type),
    INDEX idx_created      (created_at),
    INDEX idx_staff        (staff_id),
    INDEX idx_status_date  (status, entry_date),
    INDEX idx_purpose      (purpose),
    INDEX idx_guest_photo  (guest_photo)          -- v8.12: photo filename lookup
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Idempotent safe-add for older installs (pre-v8.9).
CALL vms_add_column_if_missing('entry_exit_logs', 'guest_photo', 'VARCHAR(255) NULL');

-- Compatibility VIEW for the legacy public kiosk which uses `entry_exit`.
-- v8.12 — guest_photo explicitly included in the SELECT list.
DROP VIEW IF EXISTS entry_exit;
CREATE VIEW entry_exit AS
    SELECT
        id, admno, member_name, member_category, guest_photo,
        entry_date, entry_time, exit_time,
        purpose, status, entry_type,
        gate_number, staff_id, notes, created_at
    FROM entry_exit_logs;

-- ============================================================================
-- 3. BOOK EXIT LOGS (Koha-integrated)
-- v8.12 — full column set + created_by + extra indexes + FK documentation
-- ============================================================================
CREATE TABLE IF NOT EXISTS book_exit_logs (
    id INT PRIMARY KEY AUTO_INCREMENT,

    -- Book identity
    book_barcode VARCHAR(50) NOT NULL,
    book_title VARCHAR(200) NOT NULL,
    book_author VARCHAR(200) NULL,
    book_isbn VARCHAR(30) NULL,

    -- Person who took the book (either a Koha patron OR a VMS guest)
    member_admno VARCHAR(50) NULL,
    member_name VARCHAR(200) NULL,
    -- Koha patron borrowernumber. NOT enforced as FK because Koha lives
    -- in a different DB (koha_library) and MySQL/MariaDB do not support
    -- cross-database foreign keys. App-level validation in PHP is required.
    borrowernumber INT NULL,
    -- VMS guest — references entry_exit_logs.id where entry_type='guest'.
    -- Also NOT enforced as FK (same DB, but kept soft for simplicity).
    guest_id INT NULL,

    -- Exit event
    exit_time DATETIME DEFAULT CURRENT_TIMESTAMP,   -- v8.12: auto-default
    is_authorized TINYINT(1) UNSIGNED DEFAULT 0,    -- v8.12: UNSIGNED = 0/1 only
    authorized_by INT NULL,                          -- Koha borrowernumber (app-validated)
    photo_path VARCHAR(255) NULL,
    notes TEXT NULL,
    gate_number VARCHAR(20) NULL,
    rfid_tag VARCHAR(100) NULL,
    staff_id INT NULL,
    created_by INT NULL,                             -- v8.12: audit — who created row

    -- Alert lifecycle
    alert_sent TINYINT(1) DEFAULT 0,
    alert_sent_at DATETIME NULL,
    acknowledged TINYINT(1) DEFAULT 0,
    acknowledged_by INT NULL,
    acknowledged_at DATETIME NULL,

    -- Timestamps
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    -- Indexes
    INDEX idx_barcode       (book_barcode),
    INDEX idx_isbn          (book_isbn),
    INDEX idx_member        (member_admno),
    INDEX idx_borrower      (borrowernumber),
    INDEX idx_guest         (guest_id),
    INDEX idx_auth          (is_authorized),
    INDEX idx_authorized_by (authorized_by),
    INDEX idx_created       (created_at),
    INDEX idx_exit_time     (exit_time),
    INDEX idx_alert_sent    (alert_sent),
    INDEX idx_photo_path    (photo_path),                -- v8.12: alert filter
    INDEX idx_gate          (gate_number),                -- v8.12: gate query
    INDEX idx_status_time   (is_authorized, exit_time),   -- v8.12: report composite
    INDEX idx_barcode_time  (book_barcode, exit_time)     -- v8.12: report composite
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- v8.12: safe-add for all book_exit_logs columns (older installs)
CALL vms_add_column_if_missing('book_exit_logs', 'book_isbn',       'VARCHAR(30) NULL');
CALL vms_add_column_if_missing('book_exit_logs', 'borrowernumber',  'INT NULL');
CALL vms_add_column_if_missing('book_exit_logs', 'guest_id',        'INT NULL');
CALL vms_add_column_if_missing('book_exit_logs', 'exit_time',       'DATETIME DEFAULT CURRENT_TIMESTAMP');
CALL vms_add_column_if_missing('book_exit_logs', 'is_authorized',   'TINYINT(1) UNSIGNED DEFAULT 0');
CALL vms_add_column_if_missing('book_exit_logs', 'authorized_by',   'INT NULL');
CALL vms_add_column_if_missing('book_exit_logs', 'photo_path',      'VARCHAR(255) NULL');
CALL vms_add_column_if_missing('book_exit_logs', 'notes',           'TEXT NULL');
CALL vms_add_column_if_missing('book_exit_logs', 'rfid_tag',        'VARCHAR(100) NULL');
CALL vms_add_column_if_missing('book_exit_logs', 'gate_number',     'VARCHAR(20) NULL');
CALL vms_add_column_if_missing('book_exit_logs', 'staff_id',        'INT NULL');
CALL vms_add_column_if_missing('book_exit_logs', 'created_by',      'INT NULL');
CALL vms_add_column_if_missing('book_exit_logs', 'alert_sent',      'TINYINT(1) DEFAULT 0');
CALL vms_add_column_if_missing('book_exit_logs', 'alert_sent_at',   'DATETIME NULL');
CALL vms_add_column_if_missing('book_exit_logs', 'acknowledged',    'TINYINT(1) DEFAULT 0');
CALL vms_add_column_if_missing('book_exit_logs', 'acknowledged_by', 'INT NULL');
CALL vms_add_column_if_missing('book_exit_logs', 'acknowledged_at', 'DATETIME NULL');
CALL vms_add_column_if_missing('book_exit_logs', 'updated_at',      'TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP');

-- v8.12: safe-add for all book_exit_logs indexes
CALL vms_add_index_if_missing('book_exit_logs', 'idx_isbn',          '(book_isbn)');
CALL vms_add_index_if_missing('book_exit_logs', 'idx_borrower',      '(borrowernumber)');
CALL vms_add_index_if_missing('book_exit_logs', 'idx_guest',         '(guest_id)');
CALL vms_add_index_if_missing('book_exit_logs', 'idx_authorized_by', '(authorized_by)');
CALL vms_add_index_if_missing('book_exit_logs', 'idx_created',       '(created_at)');
CALL vms_add_index_if_missing('book_exit_logs', 'idx_exit_time',     '(exit_time)');
CALL vms_add_index_if_missing('book_exit_logs', 'idx_alert_sent',    '(alert_sent)');
CALL vms_add_index_if_missing('book_exit_logs', 'idx_photo_path',    '(photo_path)');
CALL vms_add_index_if_missing('book_exit_logs', 'idx_gate',          '(gate_number)');
CALL vms_add_index_if_missing('book_exit_logs', 'idx_status_time',   '(is_authorized, exit_time)');
CALL vms_add_index_if_missing('book_exit_logs', 'idx_barcode_time',  '(book_barcode, exit_time)');

-- ============================================================================
-- 4. BOOK ALERTS (security alert lifecycle)
-- ============================================================================
CREATE TABLE IF NOT EXISTS book_alerts (
    id INT PRIMARY KEY AUTO_INCREMENT,
    log_id INT NOT NULL,
    book_barcode VARCHAR(50) NOT NULL,
    book_title VARCHAR(200) NOT NULL,
    photo_path VARCHAR(255) NULL,

    acknowledged TINYINT(1) DEFAULT 0,
    acknowledged_by INT NULL,
    acknowledged_at DATETIME NULL,
    ack_note TEXT NULL,

    resolved TINYINT(1) DEFAULT 0,
    resolved_by INT NULL,
    resolved_at DATETIME NULL,
    resolution TEXT NULL,

    email_sent TINYINT(1) DEFAULT 0,
    sms_sent TINYINT(1) DEFAULT 0,
    webhook_sent TINYINT(1) DEFAULT 0,

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    INDEX idx_ack      (acknowledged),
    INDEX idx_res      (resolved),
    INDEX idx_created  (created_at),
    INDEX idx_log      (log_id),
    INDEX idx_status   (acknowledged, resolved)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- 5. ACTIVITY LOG
-- ============================================================================
CREATE TABLE IF NOT EXISTS activity_log (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NULL,
    username VARCHAR(100) NULL,
    action VARCHAR(100) NOT NULL,
    details TEXT NULL,
    ip_address VARCHAR(45) NULL,
    user_agent TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    INDEX idx_user     (user_id),
    INDEX idx_action   (action),
    INDEX idx_created  (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- 6. PURPOSE STATS
-- ============================================================================
CREATE TABLE IF NOT EXISTS purpose_stats (
    id INT PRIMARY KEY AUTO_INCREMENT,
    purpose VARCHAR(100) NOT NULL,
    count INT DEFAULT 0,
    date DATE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    UNIQUE KEY uniq_purpose_date (purpose, date),
    INDEX idx_date (date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- 7. NOTIFICATIONS QUEUE
-- ============================================================================
CREATE TABLE IF NOT EXISTS notifications_queue (
    id INT PRIMARY KEY AUTO_INCREMENT,
    recipient_type ENUM('member','staff','admin') DEFAULT 'staff',
    recipient_id VARCHAR(50) NULL,
    recipient_email VARCHAR(200) NULL,
    recipient_phone VARCHAR(20) NULL,
    channel ENUM('email','sms','push','webhook','alert') DEFAULT 'email',
    subject VARCHAR(200) NULL,
    message TEXT NOT NULL,
    status ENUM('pending','sent','failed') DEFAULT 'pending',
    attempts INT DEFAULT 0,
    error_message TEXT NULL,
    scheduled_at DATETIME NULL,
    sent_at DATETIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    INDEX idx_status     (status),
    INDEX idx_channel    (channel),
    INDEX idx_scheduled  (scheduled_at),
    INDEX idx_recipient  (recipient_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- 8. OCCUPANCY SNAPSHOTS
-- ============================================================================
CREATE TABLE IF NOT EXISTS occupancy_snapshots (
    id INT PRIMARY KEY AUTO_INCREMENT,
    snapshot_time DATETIME NOT NULL,
    inside_count INT DEFAULT 0,
    guest_count INT DEFAULT 0,
    total_count INT DEFAULT 0,
    capacity INT DEFAULT 100,
    occupancy_percent DECIMAL(5,2) DEFAULT 0.00,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    UNIQUE KEY uniq_minute (snapshot_time),
    INDEX idx_time (snapshot_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- 9. APPOINTMENTS
-- ============================================================================
CREATE TABLE IF NOT EXISTS appointments (
    id INT PRIMARY KEY AUTO_INCREMENT,
    member_id VARCHAR(50) NOT NULL,
    member_name VARCHAR(200) NOT NULL,
    member_phone VARCHAR(20) NULL,
    member_email VARCHAR(200) NULL,
    purpose VARCHAR(200) NULL,
    appointment_date DATE NOT NULL,
    appointment_time TIME NOT NULL,
    duration INT DEFAULT 30,
    status ENUM('pending','confirmed','checked_in','cancelled','no_show','completed') DEFAULT 'pending',
    notes TEXT NULL,
    staff_notes TEXT NULL,
    confirmation_code VARCHAR(20) UNIQUE,
    reminder_sent TINYINT(1) DEFAULT 0,
    checked_in_at DATETIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    INDEX idx_member     (member_id),
    INDEX idx_date       (appointment_date),
    INDEX idx_status     (status),
    INDEX idx_code       (confirmation_code),
    INDEX idx_date_time  (appointment_date, appointment_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- 10. FEEDBACK
-- ============================================================================
CREATE TABLE IF NOT EXISTS feedback (
    id INT PRIMARY KEY AUTO_INCREMENT,
    member_id VARCHAR(50) NULL,
    member_name VARCHAR(200) NULL,
    rating TINYINT NOT NULL,
    cleanliness_rating TINYINT NULL,
    staff_rating TINYINT NULL,
    resources_rating TINYINT NULL,
    comment TEXT NULL,
    category VARCHAR(50) DEFAULT 'general',
    would_recommend TINYINT(1) NULL,
    ip_address VARCHAR(45) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    INDEX idx_rating    (rating),
    INDEX idx_created   (created_at),
    INDEX idx_category  (category),
    INDEX idx_member    (member_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- 11. VISITOR GOALS
-- ============================================================================
CREATE TABLE IF NOT EXISTS visitor_goals (
    id INT PRIMARY KEY AUTO_INCREMENT,
    member_id VARCHAR(50) NOT NULL,
    goal_type ENUM('daily','weekly','monthly','yearly') DEFAULT 'daily',
    target_hours DECIMAL(5,2) DEFAULT 2.00,
    current_hours DECIMAL(5,2) DEFAULT 0.00,
    period_start DATE NOT NULL,
    period_end DATE NOT NULL,
    achieved TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    UNIQUE KEY uniq_member_period (member_id, goal_type, period_start),
    INDEX idx_member    (member_id),
    INDEX idx_achieved  (achieved)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- 12. BADGE QUEUE
-- ============================================================================
CREATE TABLE IF NOT EXISTS badge_queue (
    id INT PRIMARY KEY AUTO_INCREMENT,
    member_id VARCHAR(50) NOT NULL,
    member_name VARCHAR(200) NOT NULL,
    badge_type ENUM('visitor','member','guest','event') DEFAULT 'visitor',
    photo_path VARCHAR(255) NULL,
    qr_data TEXT NULL,
    printed TINYINT(1) DEFAULT 0,
    printed_at DATETIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    INDEX idx_printed (printed),
    INDEX idx_member  (member_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- 13. AUDIT TRAIL
-- ============================================================================
CREATE TABLE IF NOT EXISTS audit_trail (
    id INT PRIMARY KEY AUTO_INCREMENT,
    table_name VARCHAR(50) NOT NULL,
    record_id INT NOT NULL,
    action ENUM('create','update','delete') NOT NULL,
    old_values TEXT NULL,
    new_values TEXT NULL,
    user_id INT NULL,
    username VARCHAR(100) NULL,
    ip_address VARCHAR(45) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    INDEX idx_table_record (table_name, record_id),
    INDEX idx_user         (user_id),
    INDEX idx_created      (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- 14. LOST & FOUND
-- ============================================================================
CREATE TABLE IF NOT EXISTS lost_found (
    id INT PRIMARY KEY AUTO_INCREMENT,
    item_type VARCHAR(100) NOT NULL,
    description TEXT NOT NULL,
    found_location VARCHAR(200) NULL,
    found_by VARCHAR(200) NULL,
    found_date DATE NOT NULL,
    status ENUM('unclaimed','claimed','disposed') DEFAULT 'unclaimed',
    claimant_name VARCHAR(200) NULL,
    claimant_id VARCHAR(50) NULL,
    claimant_phone VARCHAR(20) NULL,
    claimed_date DATE NULL,
    storage_location VARCHAR(100) NULL,
    photo_path VARCHAR(255) NULL,
    notes TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    INDEX idx_status      (status),
    INDEX idx_found_date  (found_date),
    INDEX idx_item_type   (item_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- 15. RECOMMENDATIONS
-- ============================================================================
CREATE TABLE IF NOT EXISTS recommendations (
    id INT PRIMARY KEY AUTO_INCREMENT,
    member_id VARCHAR(50) NOT NULL,
    biblionumber INT NOT NULL,
    title VARCHAR(200) NULL,
    author VARCHAR(200) NULL,
    score DECIMAL(5,2) DEFAULT 0.00,
    reason VARCHAR(200) NULL,
    shown TINYINT(1) DEFAULT 0,
    clicked TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    INDEX idx_member (member_id),
    INDEX idx_score  (score),
    UNIQUE KEY uniq_rec (member_id, biblionumber)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- 16. CLASSIFICATION DATA (used by class.php + isbn.php)
-- ============================================================================
CREATE TABLE IF NOT EXISTS classification_data (
    id INT AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(20) NOT NULL UNIQUE,
    subjects TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_code (code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO classification_data (code, subjects)
SELECT * FROM (
    SELECT '000' AS code, 'Computer science|Generalities|General works' AS subjects
    UNION ALL SELECT '004', 'Data processing|Computer science|Computing'
    UNION ALL SELECT '005', 'Computer programming|Programming|Software'
    UNION ALL SELECT '005.133', 'Programming languages|Python|Java|C++|JavaScript'
    UNION ALL SELECT '006.3', 'Artificial intelligence|AI|Machine learning'
    UNION ALL SELECT '020', 'Library science|LIS'
    UNION ALL SELECT '025.3', 'Cataloging|Classification|Metadata'
    UNION ALL SELECT '100', 'Philosophy|Psychology'
    UNION ALL SELECT '150', 'Psychology|Mental processes'
    UNION ALL SELECT '200', 'Religion|Theology'
    UNION ALL SELECT '297', 'Islam|Muslims|Quran|Hadith'
    UNION ALL SELECT '300', 'Social sciences|Sociology|Economics'
    UNION ALL SELECT '320', 'Political science|Politics|Government'
    UNION ALL SELECT '330', 'Economics|Finance|Business'
    UNION ALL SELECT '370', 'Education|Teaching|Schools'
    UNION ALL SELECT '500', 'Science|Natural sciences'
    UNION ALL SELECT '510', 'Mathematics|Algebra|Geometry'
    UNION ALL SELECT '510.01', 'Mathematics|Statistics'
    UNION ALL SELECT '530', 'Physics|Mechanics|Thermodynamics'
    UNION ALL SELECT '540', 'Chemistry|Organic|Inorganic'
    UNION ALL SELECT '570', 'Biology|Life sciences|Genetics'
    UNION ALL SELECT '600', 'Technology|Applied sciences'
    UNION ALL SELECT '610', 'Medicine|Health|Medical sciences'
    UNION ALL SELECT '620', 'Engineering|Mechanical|Electrical'
    UNION ALL SELECT '650', 'Management|Business|Leadership'
    UNION ALL SELECT '700', 'Arts|Recreation|Music'
    UNION ALL SELECT '800', 'Literature|Rhetoric|Poetry'
    UNION ALL SELECT '820', 'English literature|British literature'
    UNION ALL SELECT '890', 'Arabic literature|Other literatures'
    UNION ALL SELECT '900', 'History|Geography|Biography'
    UNION ALL SELECT '940', 'European history|World War'
    UNION ALL SELECT '950', 'Asian history|Middle East'
    UNION ALL SELECT '960', 'African history|Africa'
    UNION ALL SELECT '970', 'North American history|USA'
    UNION ALL SELECT '980', 'South American history|Latin America'
) AS seed
WHERE (SELECT COUNT(*) FROM classification_data) = 0;

-- ============================================================================
-- 17. MEMBERS_EXTRA (idcards.php + class.php helper)
-- ============================================================================
CREATE TABLE IF NOT EXISTS members_extra (
    admno VARCHAR(50) PRIMARY KEY,
    designation TEXT NULL,
    academic_year VARCHAR(10) NULL,
    photo_path TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- 18. COMPUTERS (terminals)
-- ============================================================================
CREATE TABLE IF NOT EXISTS computers (
    id INT PRIMARY KEY AUTO_INCREMENT,
    computer_name VARCHAR(100) NOT NULL,
    ip_address VARCHAR(45) NULL,
    location VARCHAR(100) NULL,
    status ENUM('active','maintenance','offline') DEFAULT 'active',
    notes TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    UNIQUE KEY uniq_name (computer_name),
    INDEX idx_status   (status),
    INDEX idx_location (location)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- 19. COMPUTER SESSIONS
-- ============================================================================
CREATE TABLE IF NOT EXISTS computer_sessions (
    id INT PRIMARY KEY AUTO_INCREMENT,
    borrowernumber INT NOT NULL,
    computer_id INT NOT NULL,
    login_time DATETIME NOT NULL,
    logout_time DATETIME NULL,
    duration_minutes INT NULL,
    started_by INT NULL,
    ended_by INT NULL,
    notes TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    INDEX idx_borrower          (borrowernumber),
    INDEX idx_computer          (computer_id),
    INDEX idx_logout            (logout_time),
    INDEX idx_login             (login_time),
    INDEX idx_active            (logout_time, borrowernumber),
    INDEX idx_computer_active   (computer_id, logout_time),
    INDEX idx_borrower_date     (borrowernumber, login_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- 20. COMPUTER POLICIES
-- ============================================================================
CREATE TABLE IF NOT EXISTS computer_policies (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_role VARCHAR(50) NOT NULL,
    max_minutes_per_day INT DEFAULT 0,
    max_minutes_per_week INT DEFAULT 0,
    max_sessions_per_week INT DEFAULT 0,
    require_attendance TINYINT(1) DEFAULT 0,
    weekly_attendance_required INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    UNIQUE KEY uniq_role (user_role)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO computer_policies
    (user_role, max_minutes_per_day, max_minutes_per_week, max_sessions_per_week,
     require_attendance, weekly_attendance_required)
SELECT * FROM (
    SELECT 'student' AS user_role, 60 AS max_minutes_per_day, 240 AS max_minutes_per_week,
           3 AS max_sessions_per_week, 1 AS require_attendance, 1 AS weekly_attendance_required
    UNION ALL SELECT 'teacher', 120, 480, 10, 0, 0
    UNION ALL SELECT 'staff',   90,  360, 5,  1, 1
    UNION ALL SELECT 'visitor', 30,  120, 2,  0, 0
) AS seed
WHERE NOT EXISTS (SELECT 1 FROM computer_policies WHERE user_role = seed.user_role);

-- ============================================================================
-- 21. COMPUTER ATTENDANCE
-- ============================================================================
CREATE TABLE IF NOT EXISTS computer_attendance (
    id INT PRIMARY KEY AUTO_INCREMENT,
    borrowernumber INT NOT NULL,
    week_start_date DATE NOT NULL,
    sessions_count INT DEFAULT 0,
    total_minutes INT DEFAULT 0,
    compliant TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    UNIQUE KEY uniq_borrower_week (borrowernumber, week_start_date),
    INDEX idx_week       (week_start_date),
    INDEX idx_compliant  (compliant),
    INDEX idx_borrower   (borrowernumber)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- 22. SYSTEM USERS (service accounts)
-- ============================================================================
CREATE TABLE IF NOT EXISTS system_users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(64) NOT NULL,
    display_name VARCHAR(200) NOT NULL,
    api_key_hash VARCHAR(255) NOT NULL,
    api_key_prefix VARCHAR(12) NOT NULL,
    role ENUM('system','admin','cron','api') DEFAULT 'system',
    bound_borrowernumber INT NULL,
    enabled TINYINT(1) DEFAULT 1,
    last_used_at DATETIME NULL,
    last_ip VARCHAR(45) NULL,
    notes TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    UNIQUE KEY uniq_username (username),
    INDEX idx_enabled (enabled),
    INDEX idx_prefix  (api_key_prefix),
    INDEX idx_role    (role)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO system_users
    (username, display_name, api_key_hash, api_key_prefix, role, enabled, notes)
VALUES
    ('vms-system', 'VMS Service Account',
     '$2y$10$invalid.please.reset.via.system_user_setup.php',
     'vms-syst',
     'system', 1,
     'Primary service account for cron, webhook, and API. Reset key via system_user_setup.php')
ON DUPLICATE KEY UPDATE username = username;

-- ============================================================================
-- 23. SYSTEM USER LOGINS
-- ============================================================================
CREATE TABLE IF NOT EXISTS system_user_logins (
    id INT PRIMARY KEY AUTO_INCREMENT,
    system_user_id INT NOT NULL,
    source ENUM('cron','webhook','api','installer','cli') NOT NULL,
    action VARCHAR(100) NOT NULL,
    ip_address VARCHAR(45) NULL,
    user_agent TEXT NULL,
    success TINYINT(1) DEFAULT 1,
    details TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    INDEX idx_user     (system_user_id),
    INDEX idx_source   (source),
    INDEX idx_action   (action),
    INDEX idx_created  (created_at),
    INDEX idx_success  (success)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- 24. PUBLIC KIOSK — QUOTES
-- ============================================================================
CREATE TABLE IF NOT EXISTS quotes (
    id INT PRIMARY KEY AUTO_INCREMENT,
    text TEXT NOT NULL,
    author VARCHAR(200) NULL,
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    INDEX idx_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO quotes (text, author, is_active)
SELECT * FROM (
    SELECT 'The only thing you absolutely have to know is the location of the library.' AS text, 'Albert Einstein' AS author, 1 AS is_active
    UNION ALL SELECT 'Reading is to the mind what exercise is to the body.', 'Joseph Addison', 1
    UNION ALL SELECT 'A library is a hospital for the mind.', 'Unknown', 1
    UNION ALL SELECT 'Libraries store the energy that fuels the imagination.', 'Sidney Sheldon', 1
    UNION ALL SELECT 'A book is a dream that you hold in your hand.', 'Neil Gaiman', 1
    UNION ALL SELECT 'Libraries are not made; they grow.', 'Augustine Birrell', 1
    UNION ALL SELECT 'The library is not a shrine for the worship of books. It is a temple for the enlightenment of minds.', 'Unknown', 1
    UNION ALL SELECT 'Reading gives us someplace to go when we have to stay where we are.', 'Mason Cooley', 1
) AS seed
WHERE (SELECT COUNT(*) FROM quotes) = 0;

-- ============================================================================
-- 25. PUBLIC KIOSK — NOTICES
-- ============================================================================
CREATE TABLE IF NOT EXISTS notices (
    id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(200) NOT NULL,
    content TEXT NULL,
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    INDEX idx_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- 26. PUBLIC KIOSK — EBOOKS
-- ============================================================================
CREATE TABLE IF NOT EXISTS ebooks (
    id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(200) NOT NULL,
    author VARCHAR(200) NULL,
    subject VARCHAR(200) NULL,
    isbn VARCHAR(30) NULL,
    publisher VARCHAR(200) NULL,
    year VARCHAR(20) NULL,
    description TEXT NULL,
    cover_path VARCHAR(255) NULL,
    file_path VARCHAR(500) NULL,
    file_size BIGINT NULL,
    downloads INT DEFAULT 0,
    full_text MEDIUMTEXT NULL,
    cloud_file_id VARCHAR(255) DEFAULT '',
    storage_type VARCHAR(50) DEFAULT 'local',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    INDEX idx_subject      (subject),
    INDEX idx_storage_type (storage_type),
    INDEX idx_downloads    (downloads)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- 27. BOOK METADATA CACHE (used by ISBN fetcher)
-- ============================================================================
CREATE TABLE IF NOT EXISTS book_metadata_cache (
    id INT PRIMARY KEY AUTO_INCREMENT,
    isbn VARCHAR(30) NOT NULL UNIQUE,
    title VARCHAR(255) NULL,
    author VARCHAR(255) NULL,
    publisher VARCHAR(255) NULL,
    year VARCHAR(20) NULL,
    pages INT DEFAULT 0,
    cover_url VARCHAR(500) NULL,
    summary TEXT NULL,
    subjects VARCHAR(255) NULL,
    language VARCHAR(50) NULL,
    last_fetched TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    fetch_count INT DEFAULT 1,

    INDEX idx_isbn (isbn)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- 28. INSTITUTIONS (legacy fallback)
-- ============================================================================
CREATE TABLE IF NOT EXISTS institutions (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(200) NOT NULL,
    address TEXT NULL,
    contact VARCHAR(100) NULL,
    email VARCHAR(200) NULL,
    logo_path VARCHAR(255) NULL,
    status VARCHAR(20) DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO institutions (id, name, address, contact, email, status)
VALUES (1, 'Main Library', '123 Library Street, City', '+1234567890', 'library@example.com', 'active')
ON DUPLICATE KEY UPDATE id = id;

-- ============================================================================
-- 29. MEMBERS (local cache / legacy fallback — Koha is source of truth)
-- ============================================================================
CREATE TABLE IF NOT EXISTS members (
    id INT PRIMARY KEY AUTO_INCREMENT,
    admno VARCHAR(50) NOT NULL UNIQUE,
    name VARCHAR(200) NOT NULL,
    member_category VARCHAR(100) DEFAULT 'Student',
    class VARCHAR(50) NULL,
    division VARCHAR(50) NULL,
    roll_no VARCHAR(50) NULL,
    email VARCHAR(200) NULL,
    phone VARCHAR(30) NULL,
    mobile VARCHAR(30) NULL,
    parent_phone VARCHAR(30) NULL,
    address TEXT NULL,
    dob DATE NULL,
    gender VARCHAR(20) NULL,
    blood_group VARCHAR(10) NULL,
    admission_date DATE DEFAULT NULL,
    photo_path VARCHAR(255) NULL,
    active_books INT DEFAULT 0,
    total_issued INT DEFAULT 0,
    total_fines DECIMAL(10,2) DEFAULT 0,
    total_paid_fines DECIMAL(10,2) DEFAULT 0,
    security_deposit DECIMAL(10,2) DEFAULT 0,
    membership_expiry DATE NULL,
    designation VARCHAR(100) DEFAULT '',
    department VARCHAR(200) DEFAULT '',
    general_id VARCHAR(50) DEFAULT '',
    emergency_contact VARCHAR(50) DEFAULT '',
    notes TEXT NULL,
    status VARCHAR(20) DEFAULT 'active',
    koha_id VARCHAR(50) NULL,
    password VARCHAR(255) DEFAULT '',
    is_email_verified TINYINT(1) DEFAULT 0,
    verification_token VARCHAR(100) DEFAULT '',
    verification_expiry DATETIME NULL,
    approval_status VARCHAR(20) DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    INDEX idx_admno     (admno),
    INDEX idx_name      (name),
    INDEX idx_email     (email),
    INDEX idx_phone     (phone),
    INDEX idx_status    (status),
    INDEX idx_category  (member_category)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- 30. USERS (staff auth — legacy; Koha login is primary)
-- ============================================================================
CREATE TABLE IF NOT EXISTS users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    fullname VARCHAR(200) NOT NULL,
    email VARCHAR(200) NULL,
    role VARCHAR(50) DEFAULT 'staff',
    token_version INT DEFAULT 1,
    export_count INT DEFAULT 0,
    totp_secret VARCHAR(255) DEFAULT '',
    totp_enabled TINYINT(1) DEFAULT 0,
    login_attempts INT DEFAULT 0,
    locked_until DATETIME NULL,
    last_login DATETIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- 31. SESSION LOGS (staff / member audit trail)
-- ============================================================================
CREATE TABLE IF NOT EXISTS session_logs (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_type ENUM('admin','member') DEFAULT 'admin',
    username VARCHAR(100) NOT NULL,
    session_id VARCHAR(128) NULL,
    ip_address VARCHAR(45) NULL,
    user_agent TEXT NULL,
    login_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    logout_time DATETIME NULL,

    INDEX idx_username    (username),
    INDEX idx_login_time  (login_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- 32. NOTIFICATION LOGS (delivery receipts)
-- ============================================================================
CREATE TABLE IF NOT EXISTS notification_logs (
    id INT PRIMARY KEY AUTO_INCREMENT,
    recipient_type ENUM('member','admin','staff') DEFAULT 'member',
    recipient VARCHAR(200) NOT NULL,
    notification_type VARCHAR(100) NOT NULL,
    subject VARCHAR(255) NULL,
    message TEXT NULL,
    channel ENUM('email','sms','whatsapp','push') DEFAULT 'email',
    status ENUM('pending','sent','failed') DEFAULT 'pending',
    sent_at DATETIME NULL,
    error_message TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    INDEX idx_recipient  (recipient),
    INDEX idx_type       (notification_type),
    INDEX idx_status     (status),
    INDEX idx_created    (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- 33. MODULE PERMISSIONS
-- ============================================================================
CREATE TABLE IF NOT EXISTS module_permissions (
    id INT PRIMARY KEY AUTO_INCREMENT,
    role VARCHAR(50) NOT NULL,
    module_key VARCHAR(100) NOT NULL,
    can_access TINYINT(1) DEFAULT 1,

    UNIQUE KEY uniq_role_module (role, module_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- 34. USER PREFERENCES
-- ============================================================================
CREATE TABLE IF NOT EXISTS user_preferences (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    preference_key VARCHAR(100) NOT NULL,
    preference_value TEXT NULL,

    UNIQUE KEY uniq_user_pref (user_id, preference_key),
    INDEX idx_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- 35. QUICK ACTIONS
-- ============================================================================
CREATE TABLE IF NOT EXISTS quick_actions (
    id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(100) NOT NULL,
    icon_class VARCHAR(100) NOT NULL,
    link_url VARCHAR(255) NOT NULL,
    sort_order INT NOT NULL DEFAULT 0,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO quick_actions (title, icon_class, link_url, sort_order, is_active)
SELECT * FROM (
    SELECT 'Entry' AS title, 'fas fa-sign-in-alt' AS icon_class, 'entries.php' AS link_url, 1 AS sort_order, 1 AS is_active
    UNION ALL SELECT 'Exit',            'fas fa-sign-out-alt', 'exits.php',        2, 1
    UNION ALL SELECT 'Logs',            'fas fa-list',         'logs.php',         3, 1
    UNION ALL SELECT 'Reports',         'fas fa-chart-line',   'reports.php',      4, 1
    UNION ALL SELECT 'Books',           'fas fa-book',         'books.php',        5, 1
    UNION ALL SELECT 'Members',         'fas fa-users',        'members.php',      6, 1
    UNION ALL SELECT 'Alerts',          'fas fa-shield-alt',   'alerts.php',       7, 1
    UNION ALL SELECT 'Appointments',    'fas fa-calendar-check','appointments.php',8, 1
    UNION ALL SELECT 'Feedback',        'fas fa-star',         'feedback.php',     9, 1
    UNION ALL SELECT 'Settings',        'fas fa-cog',          'settings.php',    10, 1
) AS seed
WHERE (SELECT COUNT(*) FROM quick_actions) = 0;

-- ============================================================================
-- 36. LOGIN CARDS (public login page quick links)
-- ============================================================================
CREATE TABLE IF NOT EXISTS login_cards (
    id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(100) NOT NULL,
    icon_class VARCHAR(100) NOT NULL DEFAULT 'fas fa-info-circle',
    link_url VARCHAR(255) NOT NULL DEFAULT '#',
    sort_order INT DEFAULT 0,
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO login_cards (title, icon_class, link_url, sort_order, is_active)
SELECT * FROM (
    SELECT 'Library Timings' AS title, 'fas fa-clock' AS icon_class, '#' AS link_url, 1 AS sort_order, 1 AS is_active
    UNION ALL SELECT 'Contact Librarian','fas fa-envelope',       '#',                 2, 1
    UNION ALL SELECT 'Digital Resources','fas fa-database',       '../opac/ebooks.php',3, 1
    UNION ALL SELECT 'Ask a Question',   'fas fa-question-circle','../contact.php',    4, 1
) AS seed
WHERE (SELECT COUNT(*) FROM login_cards) = 0;

-- ============================================================================
-- 37. STAFF PROFILES (public display cards)
-- ============================================================================
CREATE TABLE IF NOT EXISTS staff_profiles (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(200) NOT NULL,
    designation VARCHAR(200) NOT NULL,
    photo_path VARCHAR(255) DEFAULT '',
    sort_order INT DEFAULT 0,
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO staff_profiles (name, designation, sort_order, is_active)
SELECT * FROM (
    SELECT 'Librarian' AS name, 'Head Librarian' AS designation, 1 AS sort_order, 1 AS is_active
    UNION ALL SELECT 'Assistant Librarian', 'Staff', 2, 1
) AS seed
WHERE (SELECT COUNT(*) FROM staff_profiles) = 0;

-- ============================================================================
-- 38. API KEYS (legacy REST API)
-- ============================================================================
CREATE TABLE IF NOT EXISTS api_keys (
    id INT PRIMARY KEY AUTO_INCREMENT,
    api_key VARCHAR(255) NOT NULL UNIQUE,
    name VARCHAR(200) NOT NULL,
    permissions VARCHAR(255) NOT NULL DEFAULT 'read',
    active TINYINT(1) DEFAULT 1,
    is_active TINYINT(1) DEFAULT 1,
    expires_at DATETIME NULL,
    last_used DATETIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    INDEX idx_api_key   (api_key),
    INDEX idx_is_active (is_active),
    INDEX idx_expires   (expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO api_keys (api_key, name, permissions, active, is_active)
VALUES ('lib-api-key-2024-secure', 'Default API Key', 'read,write', 1, 1)
ON DUPLICATE KEY UPDATE api_key = api_key;

-- ============================================================================
-- 39. STOCK VERIFICATION — SESSIONS (v8.7 NEW)
-- ============================================================================
CREATE TABLE IF NOT EXISTS vms_stock_verification_sessions (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    session_code    VARCHAR(20)  NOT NULL UNIQUE,
    title           VARCHAR(200) NOT NULL,
    description     TEXT         NULL,

    branch_filter   VARCHAR(50)  NULL,
    itype_filter    VARCHAR(50)  NULL,
    ccode_filter    VARCHAR(50)  NULL,
    location_filter VARCHAR(50)  NULL,

    status          ENUM('open','paused','closed') NOT NULL DEFAULT 'open',
    started_by      INT          NULL,
    started_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    closed_by       INT          NULL,
    closed_at       DATETIME     NULL,

    total_items     INT          NOT NULL DEFAULT 0,
    total_scanned   INT          NOT NULL DEFAULT 0,
    total_found     INT          NOT NULL DEFAULT 0,
    total_missing   INT          NOT NULL DEFAULT 0,
    total_misplaced INT          NOT NULL DEFAULT 0,
    total_damaged   INT          NOT NULL DEFAULT 0,

    notes           TEXT         NULL,
    created_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    INDEX idx_status     (status),
    INDEX idx_started_at (started_at),
    INDEX idx_branch     (branch_filter)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- 40. STOCK VERIFICATION — SCANS (v8.7 NEW, v8.12 FK added)
-- ============================================================================
CREATE TABLE IF NOT EXISTS vms_stock_verification_scans (
    id                BIGINT AUTO_INCREMENT PRIMARY KEY,
    session_id        INT          NOT NULL,
    itemnumber        INT          NULL,
    barcode           VARCHAR(50)  NOT NULL,

    title             VARCHAR(255) NULL,
    author            VARCHAR(255) NULL,
    itemcallnumber    VARCHAR(100) NULL,
    homebranch        VARCHAR(50)  NULL,
    holdingbranch     VARCHAR(50)  NULL,
    location          VARCHAR(50)  NULL,
    itype             VARCHAR(50)  NULL,
    ccode             VARCHAR(50)  NULL,

    found_location    VARCHAR(100) NULL,
    status            ENUM('found','missing','damaged','misplaced','not_found','withdrawn') NOT NULL,
    notes             TEXT         NULL,

    scanned_by        INT          NULL,
    scanned_at        DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    scan_duration_ms  INT          NULL,

    INDEX idx_session     (session_id),
    INDEX idx_itemnumber  (itemnumber),
    INDEX idx_barcode     (barcode),
    INDEX idx_status      (status),
    INDEX idx_scanned_at  (scanned_at),
    INDEX idx_uniq_scan   (session_id, itemnumber),

    CONSTRAINT fk_sv_scans_session
        FOREIGN KEY (session_id) REFERENCES vms_stock_verification_sessions(id)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Seed a demo stock verification session (only if none exist)
INSERT INTO vms_stock_verification_sessions
    (session_code, title, description, status)
SELECT
    CONCAT('DEMO-', DATE_FORMAT(NOW(), '%Y%m%d')),
    'Demo Stock Verification',
    'Auto-generated on install. Delete when ready.',
    'open'
WHERE NOT EXISTS (SELECT 1 FROM vms_stock_verification_sessions);

-- ============================================================================
-- 41. LEGACY SAFE-ADD: ensure columns/indexes on older installs
-- ============================================================================

-- entry_exit_logs — guest photo support
CALL vms_add_column_if_missing('entry_exit_logs', 'guest_photo', 'VARCHAR(255) NULL');

-- book_exit_logs — v8.12 full column set
CALL vms_add_column_if_missing('book_exit_logs', 'book_isbn',       'VARCHAR(30) NULL');
CALL vms_add_column_if_missing('book_exit_logs', 'borrowernumber',  'INT NULL');
CALL vms_add_column_if_missing('book_exit_logs', 'guest_id',        'INT NULL');
CALL vms_add_column_if_missing('book_exit_logs', 'exit_time',       'DATETIME DEFAULT CURRENT_TIMESTAMP');
CALL vms_add_column_if_missing('book_exit_logs', 'is_authorized',   'TINYINT(1) UNSIGNED DEFAULT 0');
CALL vms_add_column_if_missing('book_exit_logs', 'authorized_by',   'INT NULL');
CALL vms_add_column_if_missing('book_exit_logs', 'photo_path',      'VARCHAR(255) NULL');
CALL vms_add_column_if_missing('book_exit_logs', 'notes',           'TEXT NULL');
CALL vms_add_column_if_missing('book_exit_logs', 'rfid_tag',        'VARCHAR(100) NULL');
CALL vms_add_column_if_missing('book_exit_logs', 'gate_number',     'VARCHAR(20) NULL');
CALL vms_add_column_if_missing('book_exit_logs', 'staff_id',        'INT NULL');
CALL vms_add_column_if_missing('book_exit_logs', 'created_by',      'INT NULL');
CALL vms_add_column_if_missing('book_exit_logs', 'alert_sent',      'TINYINT(1) DEFAULT 0');
CALL vms_add_column_if_missing('book_exit_logs', 'alert_sent_at',   'DATETIME NULL');
CALL vms_add_column_if_missing('book_exit_logs', 'acknowledged',    'TINYINT(1) DEFAULT 0');
CALL vms_add_column_if_missing('book_exit_logs', 'acknowledged_by', 'INT NULL');
CALL vms_add_column_if_missing('book_exit_logs', 'acknowledged_at', 'DATETIME NULL');
CALL vms_add_column_if_missing('book_exit_logs', 'updated_at',      'TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP');

-- book_alerts
CALL vms_add_column_if_missing('book_alerts', 'acknowledged',    'TINYINT(1) DEFAULT 0');
CALL vms_add_column_if_missing('book_alerts', 'acknowledged_by', 'INT NULL');
CALL vms_add_column_if_missing('book_alerts', 'acknowledged_at', 'DATETIME NULL');
CALL vms_add_column_if_missing('book_alerts', 'ack_note',        'TEXT NULL');
CALL vms_add_column_if_missing('book_alerts', 'resolved',        'TINYINT(1) DEFAULT 0');
CALL vms_add_column_if_missing('book_alerts', 'resolved_by',     'INT NULL');
CALL vms_add_column_if_missing('book_alerts', 'resolved_at',     'DATETIME NULL');
CALL vms_add_column_if_missing('book_alerts', 'resolution',      'TEXT NULL');
CALL vms_add_column_if_missing('book_alerts', 'email_sent',      'TINYINT(1) DEFAULT 0');
CALL vms_add_column_if_missing('book_alerts', 'sms_sent',        'TINYINT(1) DEFAULT 0');
CALL vms_add_column_if_missing('book_alerts', 'webhook_sent',    'TINYINT(1) DEFAULT 0');

-- settings
CALL vms_add_column_if_missing('settings', 'book_camera_countdown',         'INT DEFAULT 5');
CALL vms_add_column_if_missing('settings', 'purpose_include_computer_uses', 'TINYINT(1) DEFAULT 1');
CALL vms_add_column_if_missing('settings', 'api_key',                       'VARCHAR(200) DEFAULT NULL');
CALL vms_add_column_if_missing('settings', 'enable_webcam_capture',         'TINYINT(1) DEFAULT 0');
CALL vms_add_column_if_missing('settings', 'report_font_size',              'INT DEFAULT 10');
CALL vms_add_column_if_missing('settings', 'report_primary_color',          "VARCHAR(20) DEFAULT '#1e3c72'");
CALL vms_add_column_if_missing('settings', 'report_logo_position',          "VARCHAR(20) DEFAULT 'left'");
CALL vms_add_column_if_missing('settings', 'report_logo_right',             "VARCHAR(255) DEFAULT ''");
CALL vms_add_column_if_missing('settings', 'report_logo',                   "VARCHAR(255) DEFAULT ''");
CALL vms_add_column_if_missing('settings', 'report_watermark_enabled',      'TINYINT(1) DEFAULT 1');
CALL vms_add_column_if_missing('settings', 'report_watermark_text',         'VARCHAR(200) DEFAULT NULL');
CALL vms_add_column_if_missing('settings', 'report_watermark_opacity',      'INT DEFAULT 10');
CALL vms_add_column_if_missing('settings', 'report_signature_enabled',      'TINYINT(1) DEFAULT 0');
CALL vms_add_column_if_missing('settings', 'report_signature_name',         "VARCHAR(200) DEFAULT 'Librarian'");
CALL vms_add_column_if_missing('settings', 'report_signature_title',        "VARCHAR(200) DEFAULT 'Chief Librarian'");
CALL vms_add_column_if_missing('settings', 'report_signature_image',        'VARCHAR(255) DEFAULT NULL');
CALL vms_add_column_if_missing('settings', 'report_footer_text',            "VARCHAR(255) DEFAULT 'This is a system generated report'");
CALL vms_add_column_if_missing('settings', 'guest_show_photo',              'TINYINT(1) DEFAULT 1');
CALL vms_add_column_if_missing('settings', 'guest_allow_self_exit',         'TINYINT(1) DEFAULT 1');
CALL vms_add_column_if_missing('settings', 'guest_last_reset',              'DATE DEFAULT NULL');
CALL vms_add_column_if_missing('settings', 'guest_number_padding',          'INT DEFAULT 4');
CALL vms_add_column_if_missing('settings', 'max_capacity',                  'INT DEFAULT 100');
CALL vms_add_column_if_missing('settings', 'enable_occupancy_alerts',       'TINYINT(1) DEFAULT 1');
CALL vms_add_column_if_missing('settings', 'occupancy_warning_percent',     'INT DEFAULT 80');
CALL vms_add_column_if_missing('settings', 'occupancy_critical_percent',    'INT DEFAULT 95');
CALL vms_add_column_if_missing('settings', 'enable_appointments',           'TINYINT(1) DEFAULT 1');
CALL vms_add_column_if_missing('settings', 'appointment_slot_duration',     'INT DEFAULT 30');
CALL vms_add_column_if_missing('settings', 'appointment_max_per_slot',      'INT DEFAULT 5');
CALL vms_add_column_if_missing('settings', 'enable_feedback',               'TINYINT(1) DEFAULT 1');
CALL vms_add_column_if_missing('settings', 'enable_dark_mode',              'TINYINT(1) DEFAULT 1');
CALL vms_add_column_if_missing('settings', 'sms_enabled',                   'TINYINT(1) DEFAULT 0');
CALL vms_add_column_if_missing('settings', 'sms_api_key',                   'VARCHAR(200) DEFAULT NULL');
CALL vms_add_column_if_missing('settings', 'sms_sender_id',                 'VARCHAR(20) DEFAULT NULL');
CALL vms_add_column_if_missing('settings', 'sms_recipient',                 'VARCHAR(20) DEFAULT NULL');
CALL vms_add_column_if_missing('settings', 'webhook_url',                   'VARCHAR(500) DEFAULT NULL');
CALL vms_add_column_if_missing('settings', 'enable_webhook',                'TINYINT(1) DEFAULT 0');
CALL vms_add_column_if_missing('settings', 'notify_email',                  'VARCHAR(200) DEFAULT NULL');
CALL vms_add_column_if_missing('settings', 'system_auto_end_stale_hours',   'INT DEFAULT 8');
CALL vms_add_column_if_missing('settings', 'system_max_session_minutes',    'INT DEFAULT 0');
CALL vms_add_column_if_missing('settings', 'system_enforce_policy',         'TINYINT(1) DEFAULT 1');
CALL vms_add_column_if_missing('settings', 'system_default_policy_role',    "VARCHAR(50) DEFAULT 'student'");
CALL vms_add_column_if_missing('settings', 'system_notify_on_start',        'TINYINT(1) DEFAULT 0');
CALL vms_add_column_if_missing('settings', 'system_notify_on_end',          'TINYINT(1) DEFAULT 0');
CALL vms_add_column_if_missing('settings', 'system_webhook_url',            'VARCHAR(500) DEFAULT NULL');
CALL vms_add_column_if_missing('settings', 'system_show_photos',            'TINYINT(1) DEFAULT 1');
CALL vms_add_column_if_missing('settings', 'system_allow_force_end',        'TINYINT(1) DEFAULT 1');
CALL vms_add_column_if_missing('settings', 'system_session_cooldown_seconds','INT DEFAULT 60');

-- v8.7: stock verification settings
CALL vms_add_column_if_missing('settings', 'stock_verify_enabled',        'TINYINT(1) DEFAULT 1');
CALL vms_add_column_if_missing('settings', 'stock_verify_default_branch', 'VARCHAR(50) DEFAULT NULL');
CALL vms_add_column_if_missing('settings', 'stock_verify_auto_close_days','INT DEFAULT 30');

-- Public kiosk display aliases used by header.php (v8.3+)
CALL vms_add_column_if_missing('settings', 'public_show_quote',          'TINYINT(1) DEFAULT 1');
CALL vms_add_column_if_missing('settings', 'public_show_stats',          'TINYINT(1) DEFAULT 1');
CALL vms_add_column_if_missing('settings', 'public_show_purpose_chart',  'TINYINT(1) DEFAULT 1');
CALL vms_add_column_if_missing('settings', 'public_show_cover_flow',     'TINYINT(1) DEFAULT 1');
CALL vms_add_column_if_missing('settings', 'public_show_category_chart', 'TINYINT(1) DEFAULT 1');

-- entry_exit_logs updated_at
CALL vms_add_column_if_missing('entry_exit_logs', 'updated_at', 'TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP');

-- computer_attendance updated_at
CALL vms_add_column_if_missing('computer_attendance', 'updated_at', 'TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP');

-- safe indexes
CALL vms_add_index_if_missing('entry_exit_logs',    'idx_entry_type',       '(entry_type)');
CALL vms_add_index_if_missing('entry_exit_logs',    'idx_created',          '(created_at)');
CALL vms_add_index_if_missing('entry_exit_logs',    'idx_staff',            '(staff_id)');
CALL vms_add_index_if_missing('entry_exit_logs',    'idx_status_date',      '(status, entry_date)');
CALL vms_add_index_if_missing('entry_exit_logs',    'idx_purpose',          '(purpose)');
CALL vms_add_index_if_missing('entry_exit_logs',    'idx_guest_photo',      '(guest_photo)');
CALL vms_add_index_if_missing('book_exit_logs',     'idx_isbn',             '(book_isbn)');
CALL vms_add_index_if_missing('book_exit_logs',     'idx_borrower',         '(borrowernumber)');
CALL vms_add_index_if_missing('book_exit_logs',     'idx_guest',            '(guest_id)');
CALL vms_add_index_if_missing('book_exit_logs',     'idx_authorized_by',    '(authorized_by)');
CALL vms_add_index_if_missing('book_exit_logs',     'idx_created',          '(created_at)');
CALL vms_add_index_if_missing('book_exit_logs',     'idx_exit_time',        '(exit_time)');
CALL vms_add_index_if_missing('book_exit_logs',     'idx_alert_sent',       '(alert_sent)');
CALL vms_add_index_if_missing('book_exit_logs',     'idx_photo_path',       '(photo_path)');
CALL vms_add_index_if_missing('book_exit_logs',     'idx_gate',             '(gate_number)');
CALL vms_add_index_if_missing('book_exit_logs',     'idx_status_time',      '(is_authorized, exit_time)');
CALL vms_add_index_if_missing('book_exit_logs',     'idx_barcode_time',     '(book_barcode, exit_time)');
CALL vms_add_index_if_missing('book_alerts',        'idx_status',           '(acknowledged, resolved)');
CALL vms_add_index_if_missing('computers',          'idx_location',         '(location)');
CALL vms_add_index_if_missing('computer_sessions',  'idx_active',           '(logout_time, borrowernumber)');
CALL vms_add_index_if_missing('computer_sessions',  'idx_computer_active',  '(computer_id, logout_time)');
CALL vms_add_index_if_missing('computer_sessions',  'idx_borrower_date',    '(borrowernumber, login_time)');
CALL vms_add_index_if_missing('computer_attendance','idx_borrower',         '(borrowernumber)');

-- v8.7: stock verification indexes
CALL vms_add_index_if_missing('vms_stock_verification_sessions', 'idx_status',     '(status)');
CALL vms_add_index_if_missing('vms_stock_verification_sessions', 'idx_started_at', '(started_at)');
CALL vms_add_index_if_missing('vms_stock_verification_sessions', 'idx_branch',     '(branch_filter)');
CALL vms_add_index_if_missing('vms_stock_verification_scans',    'idx_session',    '(session_id)');
CALL vms_add_index_if_missing('vms_stock_verification_scans',    'idx_itemnumber', '(itemnumber)');
CALL vms_add_index_if_missing('vms_stock_verification_scans',    'idx_barcode',    '(barcode)');
CALL vms_add_index_if_missing('vms_stock_verification_scans',    'idx_status',     '(status)');
CALL vms_add_index_if_missing('vms_stock_verification_scans',    'idx_scanned_at', '(scanned_at)');
CALL vms_add_index_if_missing('vms_stock_verification_scans',    'idx_uniq_scan',  '(session_id, itemnumber)');

-- cleanup procedures
DROP PROCEDURE IF EXISTS vms_add_column_if_missing;
DROP PROCEDURE IF EXISTS vms_add_index_if_missing;

-- ============================================================================
-- TRIGGERS (v8.12)
-- ============================================================================
DROP TRIGGER IF EXISTS trg_purpose_stats;
DROP TRIGGER IF EXISTS trg_guest_counter;
DROP TRIGGER IF EXISTS trg_auto_book_alert;
DROP TRIGGER IF EXISTS trg_stock_scan_update;

DELIMITER //

CREATE TRIGGER trg_purpose_stats
AFTER INSERT ON entry_exit_logs
FOR EACH ROW
BEGIN
    INSERT INTO purpose_stats (purpose, count, date)
    VALUES (COALESCE(NEW.purpose, 'Other'), 1, NEW.entry_date)
    ON DUPLICATE KEY UPDATE count = count + 1;
END //

DELIMITER ;

-- ============================================================================
-- BACKFILL: create alerts for pre-existing unauthorized book exits
-- v8.12 — uses NOT EXISTS to be fully idempotent (no duplicate alerts)
-- ============================================================================
INSERT INTO book_alerts (log_id, book_barcode, book_title, photo_path, created_at)
SELECT bel.id, bel.book_barcode, bel.book_title, bel.photo_path, bel.created_at
  FROM book_exit_logs bel
 WHERE bel.is_authorized = 0
   AND NOT EXISTS (SELECT 1 FROM book_alerts ba WHERE ba.log_id = bel.id);

UPDATE book_exit_logs bel
   SET bel.alert_sent = 1,
       bel.alert_sent_at = COALESCE(bel.alert_sent_at, NOW())
 WHERE bel.is_authorized = 0
   AND bel.alert_sent = 0
   AND EXISTS (SELECT 1 FROM book_alerts ba WHERE ba.log_id = bel.id);

-- ============================================================================
-- BACKFILL: recompute stock verification counters for existing sessions
-- ============================================================================
UPDATE vms_stock_verification_sessions s
   SET s.total_scanned   = (SELECT COUNT(*) FROM vms_stock_verification_scans x WHERE x.session_id = s.id),
       s.total_found     = (SELECT COUNT(*) FROM vms_stock_verification_scans x WHERE x.session_id = s.id AND x.status='found'),
       s.total_missing   = (SELECT COUNT(*) FROM vms_stock_verification_scans x WHERE x.session_id = s.id AND x.status='missing'),
       s.total_misplaced = (SELECT COUNT(*) FROM vms_stock_verification_scans x WHERE x.session_id = s.id AND x.status='misplaced'),
       s.total_damaged   = (SELECT COUNT(*) FROM vms_stock_verification_scans x WHERE x.session_id = s.id AND x.status='damaged')
 WHERE EXISTS (SELECT 1 FROM vms_stock_verification_scans x WHERE x.session_id = s.id);

-- ============================================================================
-- NORMALISE: legacy "&amp;" values in text fields to plain "&"
-- ============================================================================
UPDATE settings
   SET
       institution_name         = REPLACE(REPLACE(institution_name,         '&amp;amp;', '&'), '&amp;', '&'),
       institution_short_name   = REPLACE(REPLACE(institution_short_name,   '&amp;amp;', '&'), '&amp;', '&'),
       institution_address      = REPLACE(REPLACE(institution_address,      '&amp;amp;', '&'), '&amp;', '&'),
       public_header_title      = REPLACE(REPLACE(public_header_title,      '&amp;amp;', '&'), '&amp;', '&'),
       public_header_subtitle   = REPLACE(REPLACE(public_header_subtitle,   '&amp;amp;', '&'), '&amp;', '&'),
       header_text              = REPLACE(REPLACE(header_text,              '&amp;amp;', '&'), '&amp;', '&'),
       header_subtext           = REPLACE(REPLACE(header_subtext,           '&amp;amp;', '&'), '&amp;', '&'),
       footer_text              = REPLACE(REPLACE(footer_text,              '&amp;amp;', '&'), '&amp;', '&'),
       tagline                  = REPLACE(REPLACE(tagline,                  '&amp;amp;', '&'), '&amp;', '&'),
       welcome_message          = REPLACE(REPLACE(welcome_message,          '&amp;amp;', '&'), '&amp;', '&'),
       goodbye_message          = REPLACE(REPLACE(goodbye_message,          '&amp;amp;', '&'), '&amp;', '&'),
       maintenance_message      = REPLACE(REPLACE(maintenance_message,      '&amp;amp;', '&'), '&amp;', '&')
 WHERE id = 1;

-- ============================================================================
-- RECORD MIGRATION
-- ============================================================================
INSERT INTO schema_migrations (version, description)
VALUES ('8.12.0', 'Fixes: exit_time default, is_authorized UNSIGNED, created_by, photo/gate/barcode_time indexes, guest_photo index, FK on sv_scans.session_id, idempotent backfill, view guest_photo. Preserves all v8.11 features.')
ON DUPLICATE KEY UPDATE version = version;

-- ============================================================================
-- VERIFICATION
-- ============================================================================
SELECT 'Schema installation complete (v8.12).' AS status;

SELECT
    (SELECT COUNT(*) FROM information_schema.TABLES
      WHERE TABLE_SCHEMA = DATABASE() AND TABLE_TYPE = 'BASE TABLE') AS tables_total,
    (SELECT COUNT(*) FROM information_schema.VIEWS
      WHERE TABLE_SCHEMA = DATABASE()) AS views_total,
    (SELECT COUNT(*) FROM information_schema.TRIGGERS
      WHERE TRIGGER_SCHEMA = DATABASE()) AS triggers_total,
    (SELECT COUNT(*) FROM settings)              AS settings_rows,
    (SELECT COUNT(*) FROM system_users)          AS system_users_rows,
    (SELECT COUNT(*) FROM computer_policies)     AS policies_rows,
    (SELECT COUNT(*) FROM quotes)                AS quotes_rows,
    (SELECT COUNT(*) FROM quick_actions)         AS quick_actions_rows,
    (SELECT COUNT(*) FROM classification_data)   AS classification_rows,
    (SELECT COUNT(*) FROM vms_stock_verification_sessions) AS stock_sessions_rows,
    (SELECT COUNT(*) FROM vms_stock_verification_scans)    AS stock_scans_rows,
    (SELECT COUNT(*) FROM schema_migrations)     AS migrations_recorded;

SELECT
    'Critical tables present:' AS section,
    (SELECT COUNT(*) FROM information_schema.TABLES
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME IN (
            'settings','entry_exit_logs','book_exit_logs','book_alerts',
            'activity_log','purpose_stats','notifications_queue',
            'occupancy_snapshots','appointments','feedback',
            'computers','computer_sessions','computer_policies',
            'computer_attendance','system_users','system_user_logins',
            'schema_migrations','visitor_goals','badge_queue','audit_trail',
            'lost_found','recommendations','quotes','notices','ebooks',
            'book_metadata_cache','institutions','members','users',
            'session_logs','notification_logs','module_permissions',
            'user_preferences','quick_actions','login_cards',
            'staff_profiles','api_keys','classification_data',
            'members_extra',
            'vms_stock_verification_sessions',
            'vms_stock_verification_scans'
        )
    ) AS present_of_41;

SELECT
    'Views:' AS section,
    GROUP_CONCAT(TABLE_NAME ORDER BY TABLE_NAME) AS views_list
FROM information_schema.VIEWS
WHERE TABLE_SCHEMA = DATABASE();

-- Expected output: "trg_purpose_stats" ONLY
SELECT
    'Triggers:' AS section,
    GROUP_CONCAT(TRIGGER_NAME ORDER BY TRIGGER_NAME) AS trigger_list
FROM information_schema.TRIGGERS
WHERE TRIGGER_SCHEMA = DATABASE();

SELECT
    'v8.12 markers:' AS section,
    (SELECT purpose_include_computer_uses  FROM settings WHERE id = 1) AS computer_uses_enabled,
    (SELECT book_camera_countdown          FROM settings WHERE id = 1) AS camera_countdown,
    (SELECT stock_verify_enabled           FROM settings WHERE id = 1) AS stock_verify_enabled,
    (SELECT COUNT(*) FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME   = 'entry_exit_logs'
        AND COLUMN_NAME  = 'guest_photo')   AS guest_photo_column_present,
    (SELECT COUNT(*) FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME   = 'book_exit_logs'
        AND COLUMN_NAME  = 'created_by')    AS created_by_column_present,
    (SELECT COUNT(*) FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME   = 'book_exit_logs'
        AND COLUMN_NAME  = 'borrowernumber') AS borrowernumber_column_present,
    (SELECT COUNT(*) FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME   = 'book_exit_logs'
        AND COLUMN_NAME  = 'guest_id')      AS guest_id_column_present;

-- v8.12: verify book_exit_logs columns
SELECT
    'book_exit_logs columns (v8.12):' AS section,
    GROUP_CONCAT(COLUMN_NAME ORDER BY ORDINAL_POSITION) AS column_list
FROM information_schema.COLUMNS
WHERE TABLE_SCHEMA = DATABASE()
  AND TABLE_NAME = 'book_exit_logs';

-- v8.12: verify book_exit_logs indexes
SELECT
    'book_exit_logs indexes (v8.12):' AS section,
    GROUP_CONCAT(DISTINCT INDEX_NAME ORDER BY INDEX_NAME) AS index_list
FROM information_schema.STATISTICS
WHERE TABLE_SCHEMA = DATABASE()
  AND TABLE_NAME = 'book_exit_logs';

-- v8.12: verify FK on vms_stock_verification_scans
SELECT
    'Foreign keys:' AS section,
    CONSTRAINT_NAME,
    TABLE_NAME,
    COLUMN_NAME,
    REFERENCED_TABLE_NAME,
    REFERENCED_COLUMN_NAME
FROM information_schema.KEY_COLUMN_USAGE
WHERE TABLE_SCHEMA = DATABASE()
  AND REFERENCED_TABLE_NAME IS NOT NULL
ORDER BY TABLE_NAME, CONSTRAINT_NAME;

SELECT
    'Institution name after normalisation:' AS section,
    institution_name AS value
FROM settings WHERE id = 1;

SELECT
    'Guest photos summary:' AS section,
    (SELECT COUNT(*) FROM entry_exit_logs WHERE entry_type = 'guest')                       AS total_guests,
    (SELECT COUNT(*) FROM entry_exit_logs WHERE entry_type = 'guest'
       AND guest_photo IS NOT NULL AND guest_photo <> '')                                  AS guests_with_photo,
    (SELECT COUNT(*) FROM entry_exit_logs WHERE entry_type = 'guest'
       AND (guest_photo IS NULL OR guest_photo = ''))                                      AS guests_without_photo;

-- ============================================================================
-- END OF SCHEMA
-- ============================================================================