<?php
/**
 * Visitor Management System - Logs
 * Version: 7.6 FINAL – Added purpose filter
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

$possiblePaths = [
    __DIR__ . '/includes',
    dirname(__DIR__) . '/includes',
    '/usr/share/koha/intranet/cgi-bin/koha/visitor/includes',
    '/usr/share/koha/intranet/cgi-bin/visitor/includes',
];

$includePath = null;
foreach ($possiblePaths as $path) {
    if (file_exists($path . '/config.php')) {
        $includePath = $path;
        break;
    }
}
if (!$includePath) {
    $testPath = __DIR__;
    for ($i = 0; $i < 5; $i++) {
        $testPath = dirname($testPath);
        if (file_exists($testPath . '/includes/config.php')) {
            $includePath = $testPath . '/includes';
            break;
        }
    }
}
if (!$includePath) die('Could not find includes directory.');

define('VMS_INCLUDES', $includePath);
require_once VMS_INCLUDES . '/config.php';
require_once VMS_INCLUDES . '/functions.php';
require_once VMS_INCLUDES . '/koha.php';
require_once VMS_INCLUDES . '/auth.php';

startSecureSession();
requireKohaLogin();

$db = getDB();
$settings = getSettings();
$user = getCurrentUser();

// Filters
$from       = $_GET['from']       ?? date('Y-m-d', strtotime('-7 days'));
$to         = $_GET['to']         ?? date('Y-m-d');
$status     = $_GET['status']     ?? '';
$entryType  = $_GET['entry_type'] ?? '';
$purpose    = $_GET['purpose']    ?? '';        // UPDATED
$search     = $_GET['search']     ?? '';
$page       = max(1, (int)($_GET['page'] ?? 1));
$perPage    = 50;
$offset     = ($page - 1) * $perPage;

// Build query
$where  = "entry_date BETWEEN ? AND ?";
$params = [$from, $to];

if (!empty($status)) {
    $where .= " AND status = ?";
    $params[] = $status;
}
if (!empty($entryType)) {
    $where .= " AND entry_type = ?";
    $params[] = $entryType;
}
if (!empty($purpose)) {                                       // UPDATED
    $where .= " AND purpose = ?";
    $params[] = $purpose;
}
if (!empty($search)) {
    $where .= " AND (member_name LIKE ? OR admno LIKE ?)";
    $searchTerm = '%' . $search . '%';
    $params[] = $searchTerm;
    $params[] = $searchTerm;
}

// Total
$countStmt = $db->prepare("SELECT COUNT(*) FROM entry_exit_logs WHERE $where");
$countStmt->execute($params);
$total = (int)$countStmt->fetchColumn();
$pages = max(1, (int)ceil($total / $perPage));

// Logs
$stmt = $db->prepare("
    SELECT * FROM entry_exit_logs
    WHERE $where
    ORDER BY entry_date DESC, entry_time DESC
    LIMIT ? OFFSET ?
");
$stmt->execute(array_merge($params, [$perPage, $offset]));
$logs = $stmt->fetchAll();

// Distinct purposes for filter (UPDATED)
$allPurposes = [];
try {
    $allPurposes = $db->query("
        SELECT DISTINCT purpose FROM entry_exit_logs
         WHERE purpose IS NOT NULL AND purpose != ''
         ORDER BY purpose
    ")->fetchAll(PDO::FETCH_COLUMN);
} catch (PDOException $e) { /* ignore */ }

// Stats
$totalInside = (int)$db->query("SELECT COUNT(*) FROM entry_exit_logs WHERE status = 'inside'")->fetchColumn();
$totalToday  = (int)$db->query("SELECT COUNT(*) FROM entry_exit_logs WHERE entry_date = CURDATE()")->fetchColumn();
$totalGuests = (int)$db->query("SELECT COUNT(*) FROM entry_exit_logs WHERE entry_type = 'guest'")->fetchColumn();
$activeGuests= (int)$db->query("SELECT COUNT(*) FROM entry_exit_logs WHERE status = 'inside' AND entry_type = 'guest'")->fetchColumn();

$pageTitle = 'Entry/Exit Logs';
include __DIR__ . '/header.php';
?>

<style>
.log-filter-card {
    background: #f8f9fa;
    border-radius: 16px;
    padding: 20px;
    margin-bottom: 20px;
    border: 1px solid #e9ecef;
}
.log-summary {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
    gap: 12px;
    margin-bottom: 16px;
}
.log-summary-item {
    background: white;
    border-radius: 12px;
    padding: 12px 16px;
    text-align: center;
    border: 1px solid #e9ecef;
}
.log-summary-item .number {
    font-size: 1.3rem;
    font-weight: 700;
    color: #1e3c72;
}
.log-summary-item .label {
    font-size: 0.7rem;
    color: #6c757d;
}
.log-summary-item.guest .number {
    color: #20c997;
}
.purpose-badge {
    display: inline-block;
    padding: 2px 10px;
    border-radius: 12px;
    font-size: 0.72rem;
    font-weight: 600;
    background: #eef2f7;
    color: #1e3c72;
}
.purpose-badge.computer {
    background: #e6f4ff;
    color: #0c63e4;
}
@media (max-width: 768px) {
    .log-summary { grid-template-columns: repeat(2, 1fr); }
    .log-summary-item .number { font-size: 1rem; }
}
</style>

<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
        <h4 class="mb-0"><i class="fas fa-list me-2 text-primary"></i>Entry/Exit Logs</h4>
        <div class="d-flex gap-2">
            <a href="report_generator.php?format=pdf&from=<?= $from ?>&to=<?= $to ?>&type=entries&entry_type=<?= $entryType ?>&purpose=<?= urlencode($purpose) ?>"
               class="btn btn-danger btn-sm" target="_blank">
                <i class="fas fa-file-pdf me-1"></i> PDF
            </a>
            <a href="report_generator.php?format=excel&from=<?= $from ?>&to=<?= $to ?>&type=entries&entry_type=<?= $entryType ?>&purpose=<?= urlencode($purpose) ?>"
               class="btn btn-success btn-sm" target="_blank">
                <i class="fas fa-file-excel me-1"></i> Excel
            </a>
        </div>
    </div>

    <!-- Summary cards -->
    <div class="log-summary">
        <div class="log-summary-item">
            <div class="number"><?= number_format($total) ?></div>
            <div class="label">Matching Records</div>
        </div>
        <div class="log-summary-item">
            <div class="number" style="color:#28a745;"><?= number_format($totalInside) ?></div>
            <div class="label">Currently Inside</div>
        </div>
        <div class="log-summary-item">
            <div class="number" style="color:#17a2b8;"><?= number_format($totalToday) ?></div>
            <div class="label">Today's Entries</div>
        </div>
        <div class="log-summary-item guest">
            <div class="number"><?= number_format($totalGuests) ?></div>
            <div class="label">Total Guests</div>
        </div>
        <div class="log-summary-item guest">
            <div class="number" style="color:#20c997;"><?= number_format($activeGuests) ?></div>
            <div class="label">Active Guests</div>
        </div>
    </div>

    <div class="log-filter-card">
        <form method="GET" class="row g-3">
            <div class="col-6 col-md-2">
                <label class="form-label fw-semibold">From</label>
                <input type="date" name="from" class="form-control" value="<?= htmlspecialchars($from) ?>">
            </div>
            <div class="col-6 col-md-2">
                <label class="form-label fw-semibold">To</label>
                <input type="date" name="to" class="form-control" value="<?= htmlspecialchars($to) ?>">
            </div>
            <div class="col-6 col-md-2">
                <label class="form-label fw-semibold">Status</label>
                <select name="status" class="form-select">
                    <option value="">All</option>
                    <option value="inside" <?= $status=='inside'?'selected':'' ?>>Inside</option>
                    <option value="exited" <?= $status=='exited'?'selected':'' ?>>Exited</option>
                </select>
            </div>
            <div class="col-6 col-md-2">
                <label class="form-label fw-semibold">Type</label>
                <select name="entry_type" class="form-select">
                    <option value="">All</option>
                    <option value="member" <?= $entryType=='member'?'selected':'' ?>>Member</option>
                    <option value="guest"  <?= $entryType=='guest' ?'selected':'' ?>>Guest</option>
                </select>
            </div>
            <div class="col-6 col-md-2">
                <label class="form-label fw-semibold">Purpose</label>
                <!-- UPDATED: purpose filter -->
                <select name="purpose" class="form-select">
                    <option value="">All</option>
                    <?php foreach ($allPurposes as $p): ?>
                        <option value="<?= htmlspecialchars($p) ?>" <?= $purpose===$p?'selected':'' ?>>
                            <?= htmlspecialchars($p) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-12 col-md-2">
                <label class="form-label fw-semibold">Search</label>
                <div class="input-group">
                    <input type="text" name="search" class="form-control"
                           placeholder="Name or ID..." value="<?= htmlspecialchars($search) ?>">
                    <button type="submit" class="btn btn-primary"><i class="fas fa-search"></i></button>
                </div>
            </div>
            <div class="col-12">
                <button type="submit" class="btn btn-primary"><i class="fas fa-filter me-2"></i> Apply Filters</button>
                <a href="logs.php" class="btn btn-secondary"><i class="fas fa-undo me-2"></i> Reset</a>
            </div>
        </form>
    </div>

    <div class="card shadow-sm">
        <div class="card-header bg-white d-flex justify-content-between flex-wrap gap-2">
            <span><i class="fas fa-database me-2"></i> <?= number_format($total) ?> records</span>
            <span>Page <?= $page ?> of <?= $pages ?></span>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover mb-0" id="logsTable">
                    <thead class="table-light">
                        <tr>
                            <th>Date</th>
                            <th>Entry</th>
                            <th>Exit</th>
                            <th>Member</th>
                            <th>ID</th>
                            <th>Category</th>
                            <th>Type</th>
                            <th>Purpose</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($logs)): ?>
                            <tr>
                                <td colspan="9" class="text-center py-4 text-muted">
                                    <i class="fas fa-check-circle text-success me-2"></i> No records found
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($logs as $r): ?>
                                <tr>
                                    <td><?= htmlspecialchars($r['entry_date']) ?></td>
                                    <td><?= htmlspecialchars($r['entry_time']) ?></td>
                                    <td>
                                        <?php if (!empty($r['exit_time'])): ?>
                                            <?= htmlspecialchars($r['exit_time']) ?>
                                        <?php else: ?>
                                            <span class="badge bg-success">Inside</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><strong><?= htmlspecialchars($r['member_name']) ?></strong></td>
                                    <td><code><?= htmlspecialchars($r['admno']) ?></code></td>
                                    <td><?= htmlspecialchars($r['member_category'] ?? 'N/A') ?></td>
                                    <td>
                                        <span class="badge <?= ($r['entry_type'] ?? 'member') === 'guest' ? 'bg-success' : 'bg-primary' ?>">
                                            <?= ucfirst($r['entry_type'] ?? 'Member') ?>
                                        </span>
                                    </td>
                                    <td>
                                        <!-- UPDATED: highlight Computer Uses with a special badge -->
                                        <?php
                                        $p = $r['purpose'] ?? 'N/A';
                                        $cls = (stripos($p, 'computer') !== false) ? 'purpose-badge computer' : 'purpose-badge';
                                        ?>
                                        <span class="<?= $cls ?>">
                                            <?= htmlspecialchars($p) ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="badge <?= ($r['status'] ?? '') === 'inside' ? 'bg-success' : 'bg-secondary' ?>">
                                            <?= strtoupper($r['status'] ?? 'Unknown') ?>
                                        </span>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php if ($pages > 1): ?>
            <div class="card-footer bg-white">
                <nav>
                    <ul class="pagination justify-content-center mb-0 flex-wrap">
                        <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>">
                            <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page' => $page - 1])) ?>">Previous</a>
                        </li>
                        <?php for ($i = max(1, $page - 2); $i <= min($pages, $page + 2); $i++): ?>
                            <li class="page-item <?= $i == $page ? 'active' : '' ?>">
                                <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page' => $i])) ?>"><?= $i ?></a>
                            </li>
                        <?php endfor; ?>
                        <li class="page-item <?= $page >= $pages ? 'disabled' : '' ?>">
                            <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page' => $page + 1])) ?>">Next</a>
                        </li>
                    </ul>
                </nav>
            </div>
        <?php endif; ?>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const table = document.getElementById('logsTable');
    if (!table) return;
    const cardBody = table.closest('.card-body');
    if (cardBody) {
        const searchDiv = document.createElement('div');
        searchDiv.className = 'p-3 border-bottom';
        searchDiv.innerHTML = `
            <div class="d-flex gap-2">
                <input type="text" id="tableSearch" class="form-control form-control-sm"
                       placeholder="Search in table..." style="max-width:300px;">
                <button class="btn btn-sm btn-outline-secondary" onclick="clearTableSearch()">
                    <i class="fas fa-times"></i>
                </button>
                <button class="btn btn-sm btn-outline-success" onclick="exportTableToCSV('logsTable', 'logs_<?= date('Y-m-d') ?>')">
                    <i class="fas fa-file-csv"></i> Export CSV
                </button>
            </div>
        `;
        cardBody.insertBefore(searchDiv, table);
        document.getElementById('tableSearch').addEventListener('input', function () {
            const filter = this.value.toLowerCase();
            const rows = table.getElementsByTagName('tbody')[0]?.getElementsByTagName('tr') || [];
            for (let i = 0; i < rows.length; i++) {
                const text = rows[i].textContent.toLowerCase();
                rows[i].style.display = text.includes(filter) ? '' : 'none';
            }
        });
    }
});
function clearTableSearch() {
    const input = document.getElementById('tableSearch');
    if (input) { input.value = ''; input.dispatchEvent(new Event('input')); input.focus(); }
}
function exportTableToCSV(tableId, filename) {
    const table = document.getElementById(tableId);
    if (!table) return;
    const rows = table.querySelectorAll('tr');
    const csv = [];
    rows.forEach(row => {
        const cells = row.querySelectorAll('th, td');
        const rowData = [];
        cells.forEach(cell => {
            let text = cell.textContent.trim();
            if (text.includes(',')) { text = '"' + text + '"'; }
            rowData.push(text);
        });
        csv.push(rowData.join(','));
    });
    const csvContent = csv.join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = (filename || 'export') + '.csv';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}
</script>

<?php include __DIR__ . '/footer.php'; ?>
