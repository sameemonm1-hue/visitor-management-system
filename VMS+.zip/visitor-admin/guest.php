<?php
/**
 * Visitor Management System - Guest Management
 * Version: 8.0 STANDALONE — No header.php / footer.php dependency
 *
 * INDEPENDENT — unlike previous versions this file does NOT include
 * header.php or footer.php. It renders its own full page (HTML head,
 * navbar, content, footer) so it works on its own.
 *
 * RETAINED:
 *   • Optional guest name (auto-generates "Guest N" if blank)
 *   • Webcam photo capture (VMSBookCapture)
 *   • Inline rename modal (active cards + history table)
 *   • Rename writes GUEST_RENAME to activity_log
 *   • Single exit, force-exit-all
 *   • Stats strip, active guest cards, history table, search, CSV export
 *
 * FIX (v8.0):
 *   • Institution name aggressively normalized so footer renders
 *     "Library & information" with a single "&" — no "&amp;" leakage.
 *   • Footer is rendered inline (not from a shared partial) so we
 *     fully control the HTML output.
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

// ============================================================
// 1. AUTO-DETECT INCLUDES PATH (config/functions/koha/auth only)
// ============================================================
$possiblePaths = [
    __DIR__ . '/includes',
    dirname(__DIR__) . '/includes',
    '/usr/share/koha/intranet/cgi-bin/koha/visitor/includes',
    '/usr/share/koha/intranet/cgi-bin/visitor/includes',
];

$includePath = null;
foreach ($possiblePaths as $path) {
    if (file_exists($path . '/config.php')) {
        $includePath = $path;
        break;
    }
}

if (!$includePath) {
    $testPath = __DIR__;
    for ($i = 0; $i < 5; $i++) {
        $testPath = dirname($testPath);
        if (file_exists($testPath . '/includes/config.php')) {
            $includePath = $testPath . '/includes';
            break;
        }
    }
}

if (!$includePath) {
    die('Could not find includes directory.');
}

define('VMS_INCLUDES', $includePath);
require_once VMS_INCLUDES . '/config.php';
if (file_exists(VMS_INCLUDES . '/functions.php')) require_once VMS_INCLUDES . '/functions.php';
if (file_exists(VMS_INCLUDES . '/koha.php'))      require_once VMS_INCLUDES . '/koha.php';
if (file_exists(VMS_INCLUDES . '/auth.php'))      require_once VMS_INCLUDES . '/auth.php';

// Session + auth — fall back to a safe default if helpers are missing.
if (function_exists('startSecureSession')) {
    startSecureSession();
} elseif (session_status() === PHP_SESSION_NONE) {
    session_name('CGISESSID');
    if (isset($_COOKIE['CGISESSID'])) session_id($_COOKIE['CGISESSID']);
    session_start();
}

if (function_exists('requireKohaLogin')) {
    requireKohaLogin();
}

$db       = function_exists('getDB')       ? getDB()       : null;
$user     = function_exists('getCurrentUser') ? getCurrentUser() : ['id' => 0, 'username' => 'Staff'];
$settings = function_exists('getSettings') ? getSettings() : [];
$message  = '';
$error    = '';

if (!$db) {
    die('<div style="font-family:sans-serif;padding:20px;color:#c00;">'
      . '<h3>Database unavailable</h3>'
      . '<p>Could not connect to the VMS database. Check <code>includes/config.php</code>.</p>'
      . '</div>');
}

// Best-effort helpers that may be missing in some deployments
if (!function_exists('logActivity')) {
    function logActivity($userId, $action, $details = '') {
        // no-op fallback
    }
}
if (!function_exists('clearCache')) {
    function clearCache($key) { /* no-op */ }
}
if (!function_exists('timeAgo')) {
    function timeAgo($datetime) {
        $ts = strtotime($datetime);
        if (!$ts) return '—';
        $diff = time() - $ts;
        if ($diff < 60) return $diff . 's ago';
        if ($diff < 3600) return floor($diff / 60) . 'm ago';
        if ($diff < 86400) return floor($diff / 3600) . 'h ago';
        return floor($diff / 86400) . 'd ago';
    }
}
if (!defined('KOHA_OPAC_URL')) {
    define('KOHA_OPAC_URL', '');
}

// ============================================================
// 2. INSTITUTION NAME — deeply normalized to plain text
// ============================================================
if (!function_exists('guests_clean_institution')) {
    function guests_clean_institution(string $raw): string {
        $raw = trim($raw);
        if ($raw === '') return 'My Library';

        if (!mb_check_encoding($raw, 'UTF-8')) {
            $fixed = @mb_convert_encoding($raw, 'UTF-8', 'ISO-8859-1');
            if ($fixed !== false && $fixed !== '') $raw = $fixed;
        }

        $prev = null; $out = $raw; $i = 0;
        while ($prev !== $out && $i < 5) {
            $prev = $out;
            $out  = html_entity_decode($out, ENT_QUOTES | ENT_HTML5, 'UTF-8');
            $i++;
        }

        $out = str_replace(
            ['&amp;amp;amp;', '&amp;amp;', '&amp;', '&AMP;', '&Amp;'],
            '&',
            $out
        );
        $out = str_replace(
            ['&quot;', '&#039;', '&#39;', '&apos;', '&lt;', '&gt;', '&nbsp;'],
            ['"',       "'",       "'",      "'",       '<',    '>',    ' '],
            $out
        );

        $out = preg_replace('/\s+/u', ' ', $out);
        $out = trim($out);

        return $out !== '' ? $out : 'My Library';
    }
}

$institutionName = 'My Library';
if (is_array($settings) && !empty($settings['institution_name'])) {
    $institutionName = guests_clean_institution((string)$settings['institution_name']);
} elseif (defined('INSTITUTION_NAME') && trim((string)INSTITUTION_NAME) !== '') {
    $institutionName = guests_clean_institution((string)INSTITUTION_NAME);
}

$GLOBALS['institution_name'] = $institutionName;
$GLOBALS['institutionName']  = $institutionName;
$GLOBALS['INSTITUTION_NAME'] = $institutionName;
if (is_array($settings)) {
    $settings['institution_name'] = $institutionName;
}

// ============================================================
// 3. ENSURE guest_photo COLUMN (idempotent migration)
// ============================================================
$hasGuestPhotoCol = false;
try {
    $cols = $db->query("SHOW COLUMNS FROM entry_exit_logs")->fetchAll(PDO::FETCH_COLUMN);
    $hasGuestPhotoCol = in_array('guest_photo', $cols, true);

    if (!$hasGuestPhotoCol) {
        $db->exec("ALTER TABLE entry_exit_logs
                   ADD COLUMN guest_photo VARCHAR(255) NULL
                   AFTER member_category");
        $hasGuestPhotoCol = true;
    }
} catch (PDOException $e) {
    error_log('[guests.php] guest_photo migration failed: ' . $e->getMessage());
}

// ============================================================
// 4. PHOTO HELPERS
// ============================================================
if (!function_exists('vms_save_guest_photo')) {
    function vms_save_guest_photo(?string $dataUrl): ?string
    {
        if (empty($dataUrl) || !is_string($dataUrl)) return null;
        if (!preg_match('#^data:image/(jpeg|jpg|png|webp);base64,#i', $dataUrl, $m)) return null;

        $ext = strtolower($m[1]);
        if ($ext === 'jpeg') $ext = 'jpg';

        $raw = base64_decode(substr($dataUrl, strlen($m[0])), true);
        if ($raw === false || strlen($raw) < 200) return null;
        if (strlen($raw) > 3 * 1024 * 1024) return null;

        $baseDir = defined('UPLOAD_PATH') ? UPLOAD_PATH : (__DIR__ . '/../uploads');
        $dir     = rtrim($baseDir, '/') . '/guest_photos/';
        if (!is_dir($dir)) {
            @mkdir($dir, 0777, true);
            @chmod($dir, 0777);
        }
        if (!is_dir($dir) || !is_writable($dir)) {
            error_log('[guests.php] photo dir not writable: ' . $dir);
            return null;
        }

        $filename = 'guest_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
        $target   = $dir . $filename;

        if (@file_put_contents($target, $raw) === false) return null;
        @chmod($target, 0644);
        return $filename;
    }
}

if (!function_exists('vms_guest_photo_url')) {
    function vms_guest_photo_url(array $row): string
    {
        $file = trim((string)($row['guest_photo'] ?? ''));
        if ($file === '') return '';
        $baseDir = defined('UPLOAD_PATH') ? UPLOAD_PATH : (__DIR__ . '/../uploads');
        $path    = rtrim($baseDir, '/') . '/guest_photos/' . $file;
        if (!file_exists($path)) return '';
        return 'guest_photo.php?f=' . urlencode($file);
    }
}

if (!function_exists('vms_next_guest_id')) {
    function vms_next_guest_id(PDO $db, array $settings): array
    {
        $guestNum = (int)($db->query("SELECT guest_daily_counter FROM settings LIMIT 1")->fetchColumn() ?: 1);
        $prefix   = $settings['guest_prefix']  ?? 'GUEST-';
        $padding  = (int)($settings['guest_padding'] ?? 4);
        $admno    = $prefix . str_pad($guestNum, $padding, '0', STR_PAD_LEFT);
        return ['num' => $guestNum, 'admno' => $admno];
    }
}

// ============================================================
// 5. HANDLE MANUAL GUEST ENTRY  (guest name is OPTIONAL)
// ============================================================
if (isset($_POST['guest_in_manual'])) {
    $guestName  = trim($_POST['guest_name'] ?? '');
    $guestPhoto = trim($_POST['guest_photo_data'] ?? '');
    $purpose    = trim($_POST['guest_purpose'] ?? ($settings['default_purpose'] ?? 'Other'));

    if ($guestName !== '') {
        $guestName = function_exists('mb_substr')
            ? mb_substr($guestName, 0, 120, 'UTF-8')
            : substr($guestName, 0, 120);
    }

    $photoFilename = null;
    if ($guestPhoto !== '' && $hasGuestPhotoCol) {
        $photoFilename = vms_save_guest_photo($guestPhoto);
    }

    $next     = vms_next_guest_id($db, $settings);
    $guestNum = $next['num'];
    $admno    = $next['admno'];

    $autoNamed = false;
    if ($guestName === '') {
        $guestName = 'Guest ' . $guestNum;
        $autoNamed = true;
    }

    try {
        if ($hasGuestPhotoCol) {
            $db->prepare("
                INSERT INTO entry_exit_logs
                    (admno, member_name, member_category, guest_photo,
                     entry_date, entry_time, purpose, status, entry_type)
                VALUES (?, ?, 'Guest', ?, CURDATE(), CURTIME(), ?, 'inside', 'guest')
            ")->execute([$admno, $guestName, $photoFilename, $purpose]);
        } else {
            $db->prepare("
                INSERT INTO entry_exit_logs
                    (admno, member_name, member_category,
                     entry_date, entry_time, purpose, status, entry_type)
                VALUES (?, ?, 'Guest', CURDATE(), CURTIME(), ?, 'inside', 'guest')
            ")->execute([$admno, $guestName, $purpose]);
        }

        $db->query("UPDATE settings SET guest_daily_counter = guest_daily_counter + 1");

        logActivity(
            $user['id'] ?? 0,
            'GUEST_ENTRY',
            "Guest '{$guestName}' entered ({$admno})" .
            ($autoNamed ? ' [auto-named]' : '')
        );

        $message = "Guest \"{$guestName}\" entered as {$admno}";
        if ($autoNamed) $message .= ' — you can rename them below.';

        clearCache('settings_all');
        clearCache('stats');
        $settings = function_exists('getSettings') ? getSettings() : $settings;
    } catch (PDOException $e) {
        error_log('[guests.php] insert: ' . $e->getMessage());
        $error = 'Failed to record guest entry. Please try again.';
    }
}

// ============================================================
// 6. HANDLE GUEST RENAME
// ============================================================
if (isset($_POST['rename_guest'])) {
    $guestId = (int)($_POST['guest_id'] ?? 0);
    $newName = trim($_POST['new_name'] ?? '');

    if ($guestId <= 0) {
        $error = 'Invalid guest ID.';
    } else {
        if ($newName === '') $newName = 'Guest (unnamed)';
        $newName = function_exists('mb_substr')
            ? mb_substr($newName, 0, 120, 'UTF-8')
            : substr($newName, 0, 120);

        try {
            $stmt = $db->prepare("SELECT member_name FROM entry_exit_logs WHERE id = ? AND entry_type = 'guest' LIMIT 1");
            $stmt->execute([$guestId]);
            $old = $stmt->fetch();

            if (!$old) {
                $error = 'Guest not found.';
            } else {
                $db->prepare("UPDATE entry_exit_logs SET member_name = ? WHERE id = ?")
                   ->execute([$newName, $guestId]);

                logActivity(
                    $user['id'] ?? 0,
                    'GUEST_RENAME',
                    "Renamed guest #{$guestId}: '{$old['member_name']}' → '{$newName}'"
                );

                $message = "Guest renamed to \"{$newName}\".";
                clearCache('stats');
            }
        } catch (PDOException $e) {
            error_log('[guests.php] rename: ' . $e->getMessage());
            $error = 'Failed to rename guest.';
        }
    }
}

// ============================================================
// 7. HANDLE GUEST EXIT (single)
// ============================================================
if (isset($_POST['exit_guest'])) {
    $guestId = (int)$_POST['guest_id'];
    $stmt = $db->prepare("UPDATE entry_exit_logs SET exit_time = NOW(), status = 'exited' WHERE id = ? AND status = 'inside' AND entry_type = 'guest'");
    $stmt->execute([$guestId]);
    if ($stmt->rowCount() > 0) {
        logActivity($user['id'] ?? 0, 'GUEST_EXIT', "Guest exited ID: $guestId");
        $message = 'Guest exited successfully.';
        clearCache('stats');
    } else {
        $error = 'Guest not found or already exited.';
    }
}

// ============================================================
// 8. FORCE EXIT ALL GUESTS
// ============================================================
if (isset($_POST['force_exit_all_guests'])) {
    $stmt = $db->prepare("
        UPDATE entry_exit_logs
           SET exit_time = NOW(),
               status = 'exited',
               notes = CONCAT(IFNULL(notes, ''), ' [Force exited all guests at ', NOW(), ']')
         WHERE status = 'inside' AND entry_type = 'guest'
    ");
    $stmt->execute();
    $count = $stmt->rowCount();
    if ($count > 0) {
        logActivity($user['id'] ?? 0, 'FORCE_EXIT_ALL_GUESTS', "Force exited $count guests");
        $message = "Force exited {$count} guest" . ($count === 1 ? '' : "s") . ".";
        clearCache('stats');
    } else {
        $error = 'No active guests to exit.';
    }
}

// ============================================================
// 9. FETCH STATS + LISTS
// ============================================================
$activeGuests = (int)$db->query("SELECT COUNT(*) FROM entry_exit_logs WHERE status = 'inside' AND entry_type = 'guest'")->fetchColumn();
$todayGuests  = (int)$db->query("SELECT COUNT(*) FROM entry_exit_logs WHERE entry_date = CURDATE() AND entry_type = 'guest'")->fetchColumn();
$totalGuests  = (int)$db->query("SELECT COUNT(*) FROM entry_exit_logs WHERE entry_type = 'guest'")->fetchColumn();

$guests = $db->query("
    SELECT * FROM entry_exit_logs
     WHERE status = 'inside' AND entry_type = 'guest'
     ORDER BY entry_time DESC
")->fetchAll();

$guestHistory = $db->query("
    SELECT * FROM entry_exit_logs
     WHERE entry_type = 'guest'
     ORDER BY entry_date DESC, entry_time DESC
     LIMIT 100
")->fetchAll();

// ============================================================
// 10. RENDER FULL PAGE — no header.php / footer.php
// ============================================================
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Guest Management — <?= htmlspecialchars($institutionName, ENT_QUOTES, 'UTF-8', false) ?></title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

<style>
:root {
    --gm-primary: #1e3c72;
    --gm-secondary: #2a5298;
    --gm-success: #20c997;
    --gm-bg: #eef2f7;
}
* { box-sizing: border-box; }
body {
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
    background: var(--gm-bg);
    color: #1e293b;
    margin: 0;
    padding: 20px;
    min-height: 100vh;
}

/* ---------------- Header ---------------- */
.gm-header {
    background: linear-gradient(135deg, var(--gm-primary), var(--gm-secondary));
    color: #fff;
    padding: 18px 26px;
    border-radius: 16px;
    margin-bottom: 22px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 12px;
    box-shadow: 0 8px 28px rgba(30, 60, 114, 0.15);
}
.gm-header h4 { margin: 0; font-weight: 800; font-size: 1.35rem; }
.gm-header .gm-user { font-size: 0.85rem; opacity: 0.9; }
.gm-header .btn-light {
    background: rgba(255,255,255,0.15);
    color: #fff;
    border-color: rgba(255,255,255,0.25);
}
.gm-header .btn-light:hover {
    background: rgba(255,255,255,0.25);
    color: #fff;
}

/* ---------------- Stats ---------------- */
.guest-stats {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
    gap: 14px;
    margin-bottom: 22px;
}
.guest-stat-item {
    background: #fff;
    border-radius: 16px;
    padding: 18px 20px;
    text-align: center;
    border: 1px solid #e9ecef;
    box-shadow: 0 2px 10px rgba(0,0,0,.04);
    transition: transform .25s;
}
.guest-stat-item:hover { transform: translateY(-3px); box-shadow: 0 10px 28px rgba(0,0,0,.08); }
.guest-stat-item .number { font-size: 1.9rem; font-weight: 800; color: var(--gm-primary); line-height: 1; }
.guest-stat-item .label { font-size: 0.72rem; color: #6c757d; margin-top: 6px; text-transform: uppercase; letter-spacing: 0.5px; }
.guest-stat-item.guest .number { color: var(--gm-success); }

/* ---------------- Guest cards ---------------- */
.guest-card {
    background: #fff;
    border-radius: 16px;
    padding: 16px 20px;
    border: 1px solid #e9ecef;
    transition: all 0.3s;
    height: 100%;
}
.guest-card:hover { box-shadow: 0 4px 20px rgba(0,0,0,0.06); transform: translateY(-2px); }
.guest-card .guest-id {
    font-family: Consolas, monospace;
    font-size: 0.95rem;
    font-weight: 600;
    color: var(--gm-primary);
}
.guest-card .guest-time { font-size: 0.8rem; color: #6c757d; }
.guest-photo-thumb {
    width: 64px;
    height: 64px;
    border-radius: 12px;
    object-fit: cover;
    border: 2px solid #e9ecef;
    background: #f8f9fa;
    flex-shrink: 0;
}
.guest-photo-thumb.sm { width: 40px; height: 40px; border-radius: 8px; }
.guest-photo-thumb.placeholder {
    display: flex;
    align-items: center;
    justify-content: center;
    color: #adb5bd;
}

/* ---------------- Manual entry panel ---------------- */
.guest-in-panel {
    background: #f8f9fa;
    border-radius: 16px;
    padding: 22px;
    border: 1px solid #e9ecef;
    margin-bottom: 22px;
}
.guest-in-panel h5 { color: var(--gm-primary); font-weight: 700; }
.guest-in-panel .form-label { font-weight: 600; font-size: 0.85rem; color: #2c3e50; }
.guest-in-panel .form-label .opt-hint { font-weight: 500; color: #6c757d; font-size: 0.78rem; }
.guest-in-panel .form-control,
.guest-in-panel .form-select { border-radius: 10px; }

/* ---------------- Webcam ---------------- */
.webcam-preview {
    width: 100%;
    max-width: 320px;
    aspect-ratio: 4 / 3;
    background: #000;
    border-radius: 12px;
    object-fit: cover;
    border: 3px solid #dee2e6;
    display: none;
}
.webcam-placeholder {
    width: 100%;
    max-width: 320px;
    aspect-ratio: 4 / 3;
    background: #f0f2f5;
    border-radius: 12px;
    border: 3px dashed #dee2e6;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #adb5bd;
    flex-direction: column;
    gap: 8px;
    font-size: 0.85rem;
    text-align: center;
    padding: 10px;
}
.camera-status { font-size: 0.78rem; color: #6c757d; min-height: 18px; }

.rename-guest-btn {
    width: 32px;
    height: 32px;
    padding: 0;
    display: inline-flex;
    align-items: center;
    justify-content: center;
}

/* ---------------- Cards ---------------- */
.card { border-radius: 16px; border: 1px solid #e9ecef; }
.card-header {
    border-top-left-radius: 16px !important;
    border-top-right-radius: 16px !important;
}

/* ---------------- Footer ---------------- */
.gm-footer {
    background: linear-gradient(135deg, var(--gm-primary), var(--gm-secondary));
    color: #fff;
    padding: 16px 24px;
    border-radius: 14px;
    margin-top: 32px;
    font-size: 0.82rem;
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 12px;
}
.gm-footer .gm-brand { font-weight: 700; }
.gm-footer .gm-right { opacity: 0.85; }

/* ---------------- Responsive ---------------- */
@media (max-width: 768px) {
    body { padding: 12px; }
    .gm-header { padding: 14px 18px; }
    .gm-header h4 { font-size: 1.1rem; }
    .guest-stats { grid-template-columns: repeat(2, 1fr); }
    .guest-stat-item .number { font-size: 1.4rem; }
    .guest-in-panel { padding: 16px; }
    .gm-footer { flex-direction: column; text-align: center; }
}
</style>
</head>
<body>

<!-- ============================================================
     HEADER (inline — no header.php include)
     ============================================================ -->
<div class="gm-header">
    <div>
        <h4><i class="fas fa-user-friends me-2"></i>Guest Management</h4>
        <div class="gm-user mt-1">
            <i class="fas fa-book me-1"></i>
            <?= htmlspecialchars($institutionName, ENT_QUOTES, 'UTF-8', false) ?>
        </div>
    </div>
    <div class="d-flex align-items-center gap-3 flex-wrap">
        <span class="gm-user">
            <i class="fas fa-user-circle me-1"></i>
            <?= htmlspecialchars($user['username'] ?? 'Staff') ?>
        </span>
        <a href="dashboard.php" class="btn btn-light btn-sm">
            <i class="fas fa-arrow-left me-1"></i> VMS Dashboard
        </a>
    </div>
</div>

<div class="container-fluid px-0">

    <!-- ============================================================
         FLASH MESSAGES
         ============================================================ -->
    <?php if ($message): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <i class="fas fa-check-circle me-2"></i> <?= htmlspecialchars($message) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <i class="fas fa-exclamation-circle me-2"></i> <?= htmlspecialchars($error) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- ============================================================
         STATS STRIP
         ============================================================ -->
    <div class="guest-stats">
        <div class="guest-stat-item">
            <div class="number"><?= number_format($activeGuests) ?></div>
            <div class="label">Active Guests Inside</div>
        </div>
        <div class="guest-stat-item">
            <div class="number"><?= number_format($todayGuests) ?></div>
            <div class="label">Today's Guests</div>
        </div>
        <div class="guest-stat-item guest">
            <div class="number"><?= number_format($totalGuests) ?></div>
            <div class="label">Total Guests All Time</div>
        </div>
    </div>

    <!-- ============================================================
         NEW GUEST ENTRY PANEL
         ============================================================ -->
    <div class="guest-in-panel">
        <h5 class="mb-3">
            <i class="fas fa-user-plus me-2 text-success"></i>New Guest Entry
        </h5>

        <form method="POST" id="guestInForm" autocomplete="off">
            <div class="row g-3">

                <div class="col-12 col-md-5">
                    <label class="form-label" for="guestNameInput">
                        Guest Name
                        <span class="opt-hint">(optional — leave blank to auto-name)</span>
                    </label>
                    <input type="text"
                           name="guest_name"
                           id="guestNameInput"
                           class="form-control form-control-lg"
                           placeholder="Enter guest's full name (optional)"
                           maxlength="120"
                           autocomplete="off">

                    <label class="form-label mt-3" for="guestPurposeSelect">Purpose of Visit</label>
                    <select name="guest_purpose" id="guestPurposeSelect" class="form-select">
                        <?php
                        $defaultPurpose = $settings['default_purpose'] ?? 'Other';
                        if (function_exists('renderPurposeOptions')) {
                            echo renderPurposeOptions($defaultPurpose);
                        } else {
                            $purposes = ['Reading/Study','Computer Uses','Book Issue/Return','Research','Meeting','Event','Other'];
                            foreach ($purposes as $p) {
                                $sel = ($defaultPurpose === $p) ? ' selected' : '';
                                echo '<option value="' . htmlspecialchars($p, ENT_QUOTES) . '"' . $sel . '>'
                                   . htmlspecialchars($p) . '</option>';
                            }
                        }
                        ?>
                    </select>
                </div>

                <div class="col-12 col-md-4">
                    <label class="form-label">
                        Photo <span class="text-muted small">(optional)</span>
                    </label>

                    <video id="guestVideo" class="webcam-preview" autoplay playsinline muted></video>

                    <div id="guestVideoPlaceholder" class="webcam-placeholder">
                        <i class="fas fa-camera fa-2x"></i>
                        <span>Click "Take Photo" to activate camera</span>
                    </div>

                    <canvas id="guestCanvas" style="display:none;"></canvas>

                    <div class="d-flex gap-2 mt-2 flex-wrap">
                        <button type="button" class="btn btn-sm btn-outline-primary" id="btnStartCam">
                            <i class="fas fa-camera me-1"></i> Take Photo
                        </button>
                        <button type="button" class="btn btn-sm btn-success" id="btnCapture" style="display:none;">
                            <i class="fas fa-circle me-1"></i> Capture
                        </button>
                        <button type="button" class="btn btn-sm btn-outline-secondary" id="btnStopCam" style="display:none;">
                            <i class="fas fa-stop me-1"></i> Stop
                        </button>
                        <button type="button" class="btn btn-sm btn-outline-danger" id="btnClearPhoto" style="display:none;">
                            <i class="fas fa-trash me-1"></i> Clear
                        </button>
                    </div>

                    <div class="camera-status mt-2" id="cameraStatus"></div>

                    <input type="hidden" name="guest_photo_data" id="guestPhotoData" value="">
                    <img id="guestPhotoPreview"
                         class="guest-photo-thumb mt-2"
                         style="display:none; width:96px; height:96px;"
                         alt="Captured photo">
                </div>

                <div class="col-12 col-md-3 d-flex align-items-end">
                    <button type="submit"
                            name="guest_in_manual"
                            class="btn btn-success btn-lg w-100"
                            id="btnGuestIn">
                        <i class="fas fa-sign-in-alt me-2"></i> Guest In
                    </button>
                </div>

            </div>
        </form>
    </div>

    <!-- ============================================================
         QUICK ACTIONS
         ============================================================ -->
    <div class="card mb-4 shadow-sm">
        <div class="card-body">
            <div class="d-flex flex-wrap gap-2">
                <?php if (!empty(KOHA_OPAC_URL)): ?>
                <a href="<?= htmlspecialchars(KOHA_OPAC_URL) ?>/visitor/"
                   class="btn btn-primary"
                   target="_blank"
                   rel="noopener">
                    <i class="fas fa-door-open me-2"></i> Public Kiosk
                </a>
                <?php endif; ?>
                <?php if ($activeGuests > 0): ?>
                    <form method="POST"
                          onsubmit="return confirm('Force exit ALL active guests? This cannot be undone.');"
                          class="d-inline">
                        <button type="submit" name="force_exit_all_guests" class="btn btn-danger">
                            <i class="fas fa-exclamation-triangle me-2"></i> Force Exit All Guests
                        </button>
                    </form>
                <?php endif; ?>
                <a href="reports.php?range=today&report_type=guests" class="btn btn-outline-primary">
                    <i class="fas fa-chart-bar me-2"></i> Guest Report
                </a>
            </div>
        </div>
    </div>

    <!-- ============================================================
         ACTIVE GUESTS
         ============================================================ -->
    <div class="card shadow-sm">
        <div class="card-header bg-white d-flex justify-content-between align-items-center flex-wrap gap-2">
            <h5 class="mb-0"><i class="fas fa-users me-2"></i>Active Guests</h5>
            <span class="badge bg-success rounded-pill px-3 py-2">
                <?= count($guests) ?> Inside
            </span>
        </div>
        <div class="card-body">
            <?php if (empty($guests)): ?>
                <div class="text-center py-4 text-muted">
                    <i class="fas fa-user-friends fa-3x mb-3 d-block" style="opacity:0.2;"></i>
                    <p class="mb-0">No active guests currently inside</p>
                </div>
            <?php else: ?>
                <div class="row g-3">
                    <?php foreach ($guests as $g):
                        $photoUrl = vms_guest_photo_url($g);
                    ?>
                        <div class="col-12 col-md-6 col-lg-4">
                            <div class="guest-card">
                                <div class="d-flex justify-content-between align-items-start gap-3">
                                    <div class="d-flex gap-3 align-items-start flex-grow-1 min-w-0">
                                        <?php if ($photoUrl): ?>
                                            <img src="<?= htmlspecialchars($photoUrl) ?>"
                                                 class="guest-photo-thumb"
                                                 alt="<?= htmlspecialchars($g['member_name']) ?>">
                                        <?php else: ?>
                                            <div class="guest-photo-thumb placeholder">
                                                <i class="fas fa-user"></i>
                                            </div>
                                        <?php endif; ?>
                                        <div class="min-w-0">
                                            <div class="fw-semibold text-truncate">
                                                <?= htmlspecialchars($g['member_name']) ?>
                                            </div>
                                            <div class="guest-id">
                                                <?= htmlspecialchars($g['admno']) ?>
                                            </div>
                                            <div class="guest-time">
                                                <i class="fas fa-clock me-1"></i>
                                                Entry: <?= htmlspecialchars($g['entry_time']) ?>
                                            </div>
                                            <div class="guest-time text-warning">
                                                <i class="fas fa-hourglass-half me-1"></i>
                                                <?= htmlspecialchars(timeAgo($g['entry_date'] . ' ' . $g['entry_time'])) ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="d-flex flex-column gap-2">
                                        <button type="button"
                                                class="btn btn-sm btn-outline-primary rename-guest-btn"
                                                data-guest-id="<?= (int)$g['id'] ?>"
                                                data-guest-name="<?= htmlspecialchars($g['member_name']) ?>"
                                                title="Rename this guest">
                                            <i class="fas fa-pen"></i>
                                        </button>
                                        <form method="POST" onsubmit="return confirm('Exit this guest?');">
                                            <input type="hidden" name="guest_id" value="<?= (int)$g['id'] ?>">
                                            <button type="submit" name="exit_guest" class="btn btn-sm btn-success">
                                                <i class="fas fa-sign-out-alt"></i>
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- ============================================================
         GUEST HISTORY
         ============================================================ -->
    <div class="card shadow-sm mt-4">
        <div class="card-header bg-white d-flex justify-content-between align-items-center flex-wrap gap-2">
            <h5 class="mb-0"><i class="fas fa-history me-2"></i>Guest History</h5>
            <span class="badge bg-secondary rounded-pill px-3 py-2">
                <?= count($guestHistory) ?> Records
            </span>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover mb-0" id="guestHistoryTable">
                    <thead class="table-light">
                        <tr>
                            <th style="width:60px;">Photo</th>
                            <th>ID</th>
                            <th>Guest Name</th>
                            <th>Entry Date</th>
                            <th>Entry Time</th>
                            <th>Exit Time</th>
                            <th>Purpose</th>
                            <th>Status</th>
                            <th style="width:60px;">Edit</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($guestHistory)): ?>
                            <tr>
                                <td colspan="9" class="text-center py-4 text-muted">
                                    No guest history found
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($guestHistory as $g):
                                $photoUrl = vms_guest_photo_url($g);
                            ?>
                                <tr>
                                    <td>
                                        <?php if ($photoUrl): ?>
                                            <img src="<?= htmlspecialchars($photoUrl) ?>"
                                                 class="guest-photo-thumb sm"
                                                 alt="">
                                        <?php else: ?>
                                            <span class="text-muted small">—</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><code><?= htmlspecialchars($g['admno']) ?></code></td>
                                    <td><?= htmlspecialchars($g['member_name']) ?></td>
                                    <td><?= htmlspecialchars($g['entry_date']) ?></td>
                                    <td><?= htmlspecialchars($g['entry_time']) ?></td>
                                    <td>
                                        <?php if (!empty($g['exit_time'])): ?>
                                            <?= htmlspecialchars($g['exit_time']) ?>
                                        <?php else: ?>
                                            <span class="badge bg-success">Inside</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?= htmlspecialchars($g['purpose'] ?? 'N/A') ?></td>
                                    <td>
                                        <span class="badge <?= ($g['status'] ?? '') === 'inside' ? 'bg-success' : 'bg-secondary' ?>">
                                            <?= htmlspecialchars(strtoupper($g['status'] ?? 'Unknown')) ?>
                                        </span>
                                    </td>
                                    <td class="text-center">
                                        <button type="button"
                                                class="btn btn-sm btn-outline-primary rename-guest-btn"
                                                data-guest-id="<?= (int)$g['id'] ?>"
                                                data-guest-name="<?= htmlspecialchars($g['member_name']) ?>"
                                                title="Rename this guest">
                                            <i class="fas fa-pen"></i>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div><!-- /.container-fluid -->

<!-- ============================================================
     FOOTER (inline — no footer.php include)
     ============================================================ -->
<footer class="gm-footer">
    <div class="gm-brand">
        <i class="fas fa-book-open me-2"></i>
        &copy; <?= date('Y') ?> <?= htmlspecialchars($institutionName, ENT_QUOTES, 'UTF-8', false) ?>
    </div>
    <div class="gm-right">
        Guest Management · VMS v8.0
    </div>
</footer>

<!-- ============================================================
     RENAME GUEST MODAL
     ============================================================ -->
<div class="modal fade" id="renameGuestModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <form method="POST" class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="fas fa-pen me-2"></i>Rename Guest
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <input type="hidden" name="guest_id" id="renameGuestId" value="">

                <label class="form-label fw-semibold">Current name</label>
                <div class="mb-3">
                    <code id="renameGuestCurrent" class="text-muted">—</code>
                </div>

                <label class="form-label fw-semibold" for="renameGuestInput">
                    New name <span class="text-muted small">(leave blank to clear)</span>
                </label>
                <input type="text" name="new_name" id="renameGuestInput"
                       class="form-control form-control-lg"
                       maxlength="120" autocomplete="off"
                       placeholder="Enter new name or leave blank">

                <div class="small text-muted mt-2">
                    <i class="fas fa-info-circle me-1"></i>
                    Changes are applied immediately and logged in the activity trail.
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" name="rename_guest" class="btn btn-primary">
                    <i class="fas fa-save me-1"></i> Save Name
                </button>
            </div>
        </form>
    </div>
</div>

<!-- ============================================================
     SCRIPTS
     ============================================================ -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
// Institution name for client-side use (raw "&", not "&amp;").
window.VMS_INSTITUTION_NAME = <?= json_encode($institutionName, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
</script>

<!-- Book capture helper (safe load — the page still works without it) -->
<script src="assets/js/book_capture.js" onerror="console.warn('book_capture.js not loaded — camera disabled');"></script>

<script>
/* ============================================================
   Webcam capture
   ============================================================ */
(function () {
    'use strict';

    var videoEl      = document.getElementById('guestVideo');
    var placeholder  = document.getElementById('guestVideoPlaceholder');
    var photoData    = document.getElementById('guestPhotoData');
    var photoPrev    = document.getElementById('guestPhotoPreview');
    var btnStart     = document.getElementById('btnStartCam');
    var btnCapture   = document.getElementById('btnCapture');
    var btnStop      = document.getElementById('btnStopCam');
    var btnClear     = document.getElementById('btnClearPhoto');
    var statusEl     = document.getElementById('cameraStatus');

    function setStatus(msg) { if (statusEl) statusEl.textContent = msg || ''; }

    function showCaptured(dataUrl) {
        if (!dataUrl) return;
        photoData.value = dataUrl;
        photoPrev.src = dataUrl;
        photoPrev.style.display = 'block';
        if (btnClear) btnClear.style.display = '';
    }

    function clearCaptured() {
        photoData.value = '';
        photoPrev.src = '';
        photoPrev.style.display = 'none';
        if (btnClear) btnClear.style.display = 'none';
    }

    function resetCameraUI() {
        if (videoEl) videoEl.style.display = 'none';
        if (placeholder) placeholder.style.display = 'flex';
        if (btnStart) btnStart.style.display   = '';
        if (btnCapture) btnCapture.style.display = 'none';
        if (btnStop) btnStop.style.display    = 'none';
    }

    if (btnStart) {
        btnStart.addEventListener('click', function () {
            var cap = window.VMSBookCapture;
            if (!cap || !cap.start) {
                setStatus('Camera module not loaded — you can still enter the guest.');
                return;
            }
            setStatus('Starting camera…');
            cap.start('guestVideo').then(function (ok) {
                if (!ok) { setStatus('Camera unavailable.'); resetCameraUI(); return; }
                videoEl.style.display = 'block';
                placeholder.style.display = 'none';
                btnStart.style.display   = 'none';
                btnCapture.style.display = '';
                btnStop.style.display    = '';
                setStatus('Camera ready — click Capture.');
            });
        });
    }

    if (btnCapture) {
        btnCapture.addEventListener('click', function () {
            var cap = window.VMSBookCapture;
            if (!cap || !cap.capture) return;
            setStatus('Capturing…');
            cap.capture('guestVideo').then(function (dataUrl) {
                if (!dataUrl) { setStatus('Capture failed — try again.'); return; }
                showCaptured(dataUrl);
                setStatus('Photo captured.');
                if (cap.stop) cap.stop();
                resetCameraUI();
            });
        });
    }

    if (btnStop) {
        btnStop.addEventListener('click', function () {
            if (window.VMSBookCapture && window.VMSBookCapture.stop) window.VMSBookCapture.stop();
            resetCameraUI();
            setStatus('');
        });
    }

    if (btnClear) {
        btnClear.addEventListener('click', function () {
            clearCaptured();
            setStatus('Photo removed.');
        });
    }
})();

/* ============================================================
   Rename modal
   ============================================================ */
function openRenameModal(guestId, currentName) {
    var idEl    = document.getElementById('renameGuestId');
    var curEl   = document.getElementById('renameGuestCurrent');
    var input   = document.getElementById('renameGuestInput');
    var modalEl = document.getElementById('renameGuestModal');
    if (!idEl || !input || !modalEl) return;

    idEl.value = guestId;
    if (curEl) curEl.textContent = currentName || '—';
    input.value = (currentName && currentName !== 'Guest (unnamed)') ? currentName : '';
    new bootstrap.Modal(modalEl).show();

    modalEl.addEventListener('shown.bs.modal', function () {
        input.focus();
        input.select();
    }, { once: true });
}

document.addEventListener('click', function (e) {
    var btn = e.target.closest('.rename-guest-btn');
    if (!btn) return;
    e.preventDefault();
    var id   = btn.dataset.guestId;
    var name = btn.dataset.guestName || '';
    if (id) openRenameModal(id, name);
});

/* ============================================================
   History: search + CSV export
   ============================================================ */
document.addEventListener('DOMContentLoaded', function () {
    var table = document.getElementById('guestHistoryTable');
    if (!table) return;
    var cardBody = table.closest('.card-body');
    if (cardBody) {
        var searchDiv = document.createElement('div');
        searchDiv.className = 'p-3 border-bottom';
        searchDiv.innerHTML =
            '<div class="d-flex gap-2 flex-wrap">' +
                '<input type="text" id="tableSearch" class="form-control form-control-sm" ' +
                       'placeholder="Search guest history..." style="max-width:300px;">' +
                '<button class="btn btn-sm btn-outline-secondary" onclick="clearTableSearch()">' +
                    '<i class="fas fa-times"></i>' +
                '</button>' +
                '<button class="btn btn-sm btn-outline-success" ' +
                        'onclick="exportTableToCSV(\'guestHistoryTable\', \'guest_history_<?= date('Y-m-d') ?>\')">' +
                    '<i class="fas fa-file-csv"></i> Export CSV' +
                '</button>' +
            '</div>';
        cardBody.insertBefore(searchDiv, table);

        var searchInput = document.getElementById('tableSearch');
        if (searchInput) {
            searchInput.addEventListener('input', function () {
                var filter = this.value.toLowerCase();
                var tbody = table.getElementsByTagName('tbody')[0];
                if (!tbody) return;
                var rows = tbody.getElementsByTagName('tr');
                for (var i = 0; i < rows.length; i++) {
                    rows[i].style.display = rows[i].textContent.toLowerCase().indexOf(filter) !== -1 ? '' : 'none';
                }
            });
        }
    }
});

function clearTableSearch() {
    var input = document.getElementById('tableSearch');
    if (input) { input.value = ''; input.dispatchEvent(new Event('input')); input.focus(); }
}

function exportTableToCSV(tableId, filename) {
    var table = document.getElementById(tableId);
    if (!table) return;
    var rows = table.querySelectorAll('tr');
    var csv = [];
    rows.forEach(function (row) {
        var cells = row.querySelectorAll('th, td');
        var rowData = [];
        cells.forEach(function (cell) {
            var text = cell.textContent.trim().replace(/\s+/g, ' ');
            if (text.indexOf(',') !== -1 || text.indexOf('"') !== -1) {
                text = '"' + text.replace(/"/g, '""') + '"';
            }
            rowData.push(text);
        });
        csv.push(rowData.join(','));
    });
    var blob = new Blob([csv.join('\n')], { type: 'text/csv;charset=utf-8;' });
    var link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = (filename || 'export') + '.csv';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}
</script>

</body>
</html>
