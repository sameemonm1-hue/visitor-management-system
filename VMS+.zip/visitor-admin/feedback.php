<?php
/**
 * Visitor Management System - Visitor Feedback
 * Version: 7.5 Advanced Edition
 * 
 * Features:
 * - Multi-category ratings
 * - Public feedback form
 * - Analytics dashboard
 * - Sentiment analysis
 * - CSV export
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

$possiblePaths = [__DIR__ . '/includes', dirname(__DIR__) . '/includes', '/usr/share/koha/intranet/cgi-bin/koha/visitor/includes'];
$includePath = null;
foreach ($possiblePaths as $path) { if (file_exists($path . '/config.php')) { $includePath = $path; break; } }
if (!$includePath) die('Could not find includes directory.');

define('VMS_INCLUDES', $includePath);
require_once VMS_INCLUDES . '/config.php';

startSecureSession();
requireKohaLogin();

$db = getDB();
$settings = getSettings();
$user = getCurrentUser();
$message = '';

// Get feedback stats
$totalFeedback = $db->query("SELECT COUNT(*) FROM feedback")->fetchColumn();
$avgRating = $db->query("SELECT ROUND(AVG(rating), 2) FROM feedback")->fetchColumn() ?: 0;
$avgCleanliness = $db->query("SELECT ROUND(AVG(cleanliness_rating), 2) FROM feedback WHERE cleanliness_rating IS NOT NULL")->fetchColumn() ?: 0;
$avgStaff = $db->query("SELECT ROUND(AVG(staff_rating), 2) FROM feedback WHERE staff_rating IS NOT NULL")->fetchColumn() ?: 0;
$avgResources = $db->query("SELECT ROUND(AVG(resources_rating), 2) FROM feedback WHERE resources_rating IS NOT NULL")->fetchColumn() ?: 0;
$recommendPercent = $db->query("SELECT ROUND(AVG(would_recommend) * 100, 1) FROM feedback WHERE would_recommend IS NOT NULL")->fetchColumn() ?: 0;

// Rating distribution
$distribution = $db->query("
    SELECT rating, COUNT(*) as count 
    FROM feedback 
    GROUP BY rating 
    ORDER BY rating DESC
")->fetchAll(PDO::FETCH_KEY_PAIR);

// Recent feedback
$recent = $db->query("
    SELECT * FROM feedback 
    ORDER BY created_at DESC 
    LIMIT 50
")->fetchAll();

// Category breakdown
$categories = $db->query("
    SELECT category, COUNT(*) as count, ROUND(AVG(rating), 2) as avg_rating
    FROM feedback 
    GROUP BY category 
    ORDER BY count DESC
")->fetchAll();

$pageTitle = 'Visitor Feedback';
include __DIR__ . '/header.php';
?>

<style>
.rating-stars { color: #ffc107; font-size: 1.1rem; }
.rating-stars .empty { color: #dee2e6; }
.feedback-card {
    background: white;
    border-radius: 12px;
    padding: 16px 20px;
    border-left: 4px solid #1e3c72;
    margin-bottom: 12px;
    transition: all 0.3s;
}
.feedback-card:hover { box-shadow: 0 4px 16px rgba(0,0,0,0.08); }
.feedback-card.rating-5 { border-left-color: #28a745; }
.feedback-card.rating-4 { border-left-color: #17a2b8; }
.feedback-card.rating-3 { border-left-color: #ffc107; }
.feedback-card.rating-2 { border-left-color: #fd7e14; }
.feedback-card.rating-1 { border-left-color: #dc3545; }
.big-rating {
    font-size: 4rem;
    font-weight: 800;
    line-height: 1;
    color: #1e3c72;
}
.star-bar {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 6px;
}
.star-bar .label { width: 40px; text-align: right; font-size: 0.85rem; color: #6c757d; }
.star-bar .bar-wrap { flex-grow: 1; background: #f0f0f0; border-radius: 20px; height: 20px; overflow: hidden; }
.star-bar .bar-fill { height: 100%; background: linear-gradient(90deg, #ffc107, #ff9800); transition: width 0.6s ease; }
.star-bar .count { width: 50px; font-weight: 600; color: #495057; font-size: 0.85rem; }
.public-link {
    background: linear-gradient(135deg, #1e3c72, #2a5298);
    color: white;
    padding: 16px 24px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 12px;
    margin-bottom: 20px;
}
.public-link a { color: #ffd700; font-weight: 700; text-decoration: none; word-break: break-all; }
</style>

<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
        <h4 class="mb-0"><i class="fas fa-star me-2 text-warning"></i>Visitor Feedback & Reviews</h4>
        <a href="report_generator.php?format=excel&from=<?= date('Y-m-d', strtotime('-365 days')) ?>&to=<?= date('Y-m-d') ?>&type=feedback" class="btn btn-success btn-sm">
            <i class="fas fa-file-csv me-1"></i>Export CSV
        </a>
    </div>

    <!-- Public form link -->
    <div class="public-link">
        <div>
            <div style="font-weight:700;"><i class="fas fa-link me-2"></i>Public Feedback Form</div>
            <div style="font-size:0.8rem;opacity:0.9;">Share this link with visitors</div>
        </div>
        <a href="<?= KOHA_OPAC_URL ?>/visitor/feedback.php" target="_blank">
            <?= KOHA_OPAC_URL ?>/visitor/feedback.php
        </a>
    </div>

    <!-- Summary Cards -->
    <div class="row g-3 mb-4">
        <div class="col-lg-3 col-md-6">
            <div class="card shadow-sm h-100">
                <div class="card-body text-center">
                    <div class="big-rating"><?= number_format($avgRating, 1) ?></div>
                    <div class="rating-stars my-2">
                        <?php 
                        $fullStars = floor($avgRating);
                        for ($i = 1; $i <= 5; $i++) {
                            echo $i <= $fullStars ? '★' : '<span class="empty">★</span>';
                        }
                        ?>
                    </div>
                    <div class="text-muted small">Average Rating</div>
                    <div class="mt-2 text-muted" style="font-size:0.75rem;">
                        Based on <?= number_format($totalFeedback) ?> reviews
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-3 col-md-6">
            <div class="card shadow-sm h-100">
                <div class="card-body">
                    <div class="d-flex justify-content-between mb-2">
                        <span class="text-muted small">Cleanliness</span>
                        <strong><?= number_format($avgCleanliness, 1) ?>/5</strong>
                    </div>
                    <div class="progress mb-2" style="height:6px;">
                        <div class="progress-bar bg-info" style="width:<?= ($avgCleanliness / 5) * 100 ?>%;"></div>
                    </div>
                    <div class="d-flex justify-content-between mb-2">
                        <span class="text-muted small">Staff</span>
                        <strong><?= number_format($avgStaff, 1) ?>/5</strong>
                    </div>
                    <div class="progress mb-2" style="height:6px;">
                        <div class="progress-bar bg-primary" style="width:<?= ($avgStaff / 5) * 100 ?>%;"></div>
                    </div>
                    <div class="d-flex justify-content-between mb-2">
                        <span class="text-muted small">Resources</span>
                        <strong><?= number_format($avgResources, 1) ?>/5</strong>
                    </div>
                    <div class="progress" style="height:6px;">
                        <div class="progress-bar bg-success" style="width:<?= ($avgResources / 5) * 100 ?>%;"></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-3 col-md-6">
            <div class="card shadow-sm h-100">
                <div class="card-body text-center">
                    <div class="big-rating" style="color:#28a745;"><?= number_format($recommendPercent, 0) ?>%</div>
                    <div class="text-muted small mt-2">Would Recommend</div>
                    <div class="mt-3">
                        <i class="fas fa-thumbs-up fa-2x text-success" style="opacity:0.3;"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-3 col-md-6">
            <div class="card shadow-sm h-100">
                <div class="card-body">
                    <div class="text-muted small mb-2">Rating Distribution</div>
                    <?php for ($i = 5; $i >= 1; $i--): 
                        $count = $distribution[$i] ?? 0;
                        $pct = $totalFeedback > 0 ? ($count / $totalFeedback) * 100 : 0;
                    ?>
                        <div class="star-bar">
                            <span class="label"><?= $i ?>★</span>
                            <div class="bar-wrap">
                                <div class="bar-fill" style="width:<?= $pct ?>%;"></div>
                            </div>
                            <span class="count"><?= $count ?></span>
                        </div>
                    <?php endfor; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Categories -->
    <?php if (!empty($categories)): ?>
    <div class="card shadow-sm mb-4">
        <div class="card-header bg-white">
            <h6 class="mb-0"><i class="fas fa-tags me-2"></i>Feedback by Category</h6>
        </div>
        <div class="card-body">
            <div class="row g-3">
                <?php foreach ($categories as $cat): ?>
                    <div class="col-md-4">
                        <div class="d-flex justify-content-between mb-1">
                            <strong><?= htmlspecialchars(ucfirst($cat['category'])) ?></strong>
                            <span class="text-muted small"><?= $cat['count'] ?> reviews</span>
                        </div>
                        <div class="d-flex align-items-center gap-2">
                            <span class="rating-stars">★ <?= number_format($cat['avg_rating'], 1) ?></span>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- Recent Feedback -->
    <div class="card shadow-sm">
        <div class="card-header bg-white">
            <h6 class="mb-0"><i class="fas fa-comments me-2"></i>Recent Feedback (<?= count($recent) ?>)</h6>
        </div>
        <div class="card-body">
            <?php if (empty($recent)): ?>
                <div class="text-center text-muted py-5">
                    <i class="fas fa-star fa-3x mb-3 d-block" style="opacity:0.2;"></i>
                    <p>No feedback received yet.</p>
                </div>
            <?php else: ?>
                <?php foreach ($recent as $f): ?>
                    <div class="feedback-card rating-<?= $f['rating'] ?>">
                        <div class="d-flex justify-content-between align-items-start flex-wrap gap-2">
                            <div style="flex:1;">
                                <div class="d-flex align-items-center gap-2 mb-2 flex-wrap">
                                    <span class="rating-stars">
                                        <?php for ($i = 1; $i <= 5; $i++) echo $i <= $f['rating'] ? '★' : '<span class="empty">★</span>'; ?>
                                    </span>
                                    <strong><?= htmlspecialchars($f['member_name'] ?: 'Anonymous') ?></strong>
                                    <?php if ($f['category'] !== 'general'): ?>
                                        <span class="badge bg-secondary"><?= htmlspecialchars($f['category']) ?></span>
                                    <?php endif; ?>
                                    <?php if ($f['would_recommend']): ?>
                                        <span class="badge bg-success"><i class="fas fa-thumbs-up"></i> Recommends</span>
                                    <?php endif; ?>
                                </div>
                                <?php if ($f['comment']): ?>
                                    <div style="font-size:0.9rem;color:#495057;line-height:1.6;">
                                        <?= nl2br(htmlspecialchars($f['comment'])) ?>
                                    </div>
                                <?php endif; ?>
                                
                                <?php 
                                $subRatings = [];
                                if ($f['cleanliness_rating']) $subRatings[] = "🧹 Cleanliness: {$f['cleanliness_rating']}/5";
                                if ($f['staff_rating']) $subRatings[] = "👥 Staff: {$f['staff_rating']}/5";
                                if ($f['resources_rating']) $subRatings[] = "📚 Resources: {$f['resources_rating']}/5";
                                if (!empty($subRatings)): 
                                ?>
                                    <div class="mt-2 text-muted small">
                                        <?= implode(' · ', $subRatings) ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="text-muted small" style="text-align:right;min-width:120px;">
                                <i class="fas fa-clock me-1"></i><?= timeAgo($f['created_at']) ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include __DIR__ . '/footer.php'; ?>