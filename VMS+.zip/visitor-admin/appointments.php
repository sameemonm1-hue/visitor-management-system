<?php
/**
 * Visitor Management System - Appointment Booking
 * Version: 8.6 FINAL
 *
 * CHANGELOG v8.6:
 *   • Purpose dropdown now uses canonical list via renderPurposeOptions()
 *     (includes "Computer Uses")
 *   • Purpose validated via vms_valid_purpose() on save
 *   • Uses loaders chain (functions.php + koha.php + auth.php) for consistency
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

$possiblePaths = [
    __DIR__ . '/includes',
    dirname(__DIR__) . '/includes',
    '/usr/share/koha/intranet/cgi-bin/koha/visitor/includes',
];
$includePath = null;
foreach ($possiblePaths as $path) {
    if (file_exists($path . '/config.php')) { $includePath = $path; break; }
}
if (!$includePath) die('Could not find includes directory.');

define('VMS_INCLUDES', $includePath);
require_once VMS_INCLUDES . '/config.php';
require_once VMS_INCLUDES . '/functions.php';
require_once VMS_INCLUDES . '/koha.php';
require_once VMS_INCLUDES . '/auth.php';

startSecureSession();
requireKohaLogin();

$db = getDB();
$settings = getSettings();
$user = getCurrentUser();
$lang = $_SESSION['visitor_lang'] ?? 'en';
$message = '';
$error = '';

// ============================================================
// CREATE APPOINTMENT
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_appointment'])) {
    try {
        $memberId   = trim($_POST['member_id'] ?? '');
        $memberName = trim($_POST['member_name'] ?? '');
        // UPDATED: whitelist purpose
        $purpose    = vms_valid_purpose(trim($_POST['purpose'] ?? 'Reading/Study'));
        $date       = $_POST['appointment_date'] ?? '';
        $time       = $_POST['appointment_time'] ?? '';
        $duration   = (int)($_POST['duration'] ?? 30);
        $notes      = trim($_POST['notes'] ?? '');
        $phone      = trim($_POST['member_phone'] ?? '');
        $email      = trim($_POST['member_email'] ?? '');

        if (empty($memberId) || empty($memberName) || empty($date) || empty($time)) {
            throw new Exception('Please fill all required fields');
        }

        // Slot availability (uses settings from DB)
        $slotStmt = $db->prepare("
            SELECT COUNT(*) FROM appointments
            WHERE appointment_date = ? AND appointment_time = ?
            AND status NOT IN ('cancelled', 'no_show')
        ");
        $slotStmt->execute([$date, $time]);
        $slotCount = (int)$slotStmt->fetchColumn();

        $maxPerSlot = (int)($settings['appointment_max_per_slot'] ?? 5);
        if ($slotCount >= $maxPerSlot) {
            throw new Exception("This time slot is full ($slotCount/$maxPerSlot)");
        }

        $code = strtoupper(substr(md5(uniqid()), 0, 8));

        $stmt = $db->prepare("
            INSERT INTO appointments
            (member_id, member_name, member_phone, member_email, purpose,
             appointment_date, appointment_time, duration, notes, confirmation_code)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([$memberId, $memberName, $phone, $email, $purpose,
                        $date, $time, $duration, $notes, $code]);

        $message = "✅ Appointment booked! Confirmation code: <strong>$code</strong>";
        logActivity($user['id'] ?? 0, 'APPOINTMENT_CREATE', "Appointment: $memberName on $date $time");
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}

// ============================================================
// UPDATE STATUS
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $id     = (int)$_POST['appointment_id'];
    $status = $_POST['new_status'];
    if (in_array($status, ['pending','confirmed','checked_in','cancelled','no_show','completed'], true)) {
        $db->prepare("UPDATE appointments SET status = ? WHERE id = ?")->execute([$status, $id]);
        $message = "✅ Status updated to $status";
        logActivity($user['id'] ?? 0, 'APPOINTMENT_STATUS', "Appointment #$id → $status");
    }
}

// ============================================================
// CHECK-IN
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['check_in'])) {
    $id = (int)$_POST['appointment_id'];
    try {
        $stmt = $db->prepare("SELECT * FROM appointments WHERE id = ?");
        $stmt->execute([$id]);
        $apt = $stmt->fetch();

        if ($apt) {
            $db->prepare("UPDATE appointments SET status = 'checked_in', checked_in_at = NOW() WHERE id = ?")
               ->execute([$id]);

            // Add to entry log
            $insert = $db->prepare("
                INSERT INTO entry_exit_logs
                (admno, member_name, member_category, entry_date, entry_time,
                 purpose, status, entry_type)
                VALUES (?, ?, 'Appointment', CURDATE(), CURTIME(), ?, 'inside', 'member')
            ");
            $insert->execute([$apt['member_id'], $apt['member_name'],
                              vms_valid_purpose($apt['purpose'])]);

            clearCache('stats');
            $message = "✅ {$apt['member_name']} checked in";
            logActivity($user['id'] ?? 0, 'APPOINTMENT_CHECKIN', "Appointment #$id");
        }
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}

// ============================================================
// FETCH APPOINTMENTS
// ============================================================
$filterDate   = $_GET['date']   ?? date('Y-m-d');
$filterStatus = $_GET['status'] ?? 'all';

$where  = "appointment_date = ?";
$params = [$filterDate];
if ($filterStatus !== 'all') {
    $where   .= " AND status = ?";
    $params[] = $filterStatus;
}

$stmt = $db->prepare("SELECT * FROM appointments WHERE $where ORDER BY appointment_time, created_at");
$stmt->execute($params);
$appointments = $stmt->fetchAll();

$todayCount     = (int)$db->query("SELECT COUNT(*) FROM appointments WHERE appointment_date = CURDATE()")->fetchColumn();
$pendingCount   = (int)$db->query("SELECT COUNT(*) FROM appointments WHERE status = 'pending' AND appointment_date >= CURDATE()")->fetchColumn();
$checkedInToday = (int)$db->query("SELECT COUNT(*) FROM appointments WHERE status = 'checked_in' AND appointment_date = CURDATE()")->fetchColumn();

$pageTitle = 'Appointments';
include __DIR__ . '/header.php';
?>

<style>
.apt-card {
    background: white;
    border-radius: 12px;
    padding: 16px;
    border-left: 4px solid #1e3c72;
    margin-bottom: 10px;
    transition: all 0.3s;
}
.apt-card:hover { box-shadow: 0 4px 16px rgba(0,0,0,0.08); transform: translateX(3px); }
.apt-card.status-pending    { border-left-color: #ffc107; }
.apt-card.status-confirmed  { border-left-color: #17a2b8; }
.apt-card.status-checked_in { border-left-color: #28a745; }
.apt-card.status-cancelled  { border-left-color: #6c757d; opacity: 0.7; }
.apt-card.status-no_show    { border-left-color: #dc3545; opacity: 0.7; }
.apt-time { font-size: 1.5rem; font-weight: 700; color: #1e3c72; }
.apt-stat {
    background: white;
    border-radius: 12px;
    padding: 16px;
    text-align: center;
    border: 1px solid #e9ecef;
}
.apt-stat .num { font-size: 1.8rem; font-weight: 700; color: #1e3c72; }
.apt-stat .lbl { font-size: 0.7rem; color: #6c757d; text-transform: uppercase; }
</style>

<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
        <h4 class="mb-0"><i class="fas fa-calendar-check me-2 text-primary"></i>Appointment Booking</h4>
        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#newAptModal">
            <i class="fas fa-plus me-2"></i>New Appointment
        </button>
    </div>

    <?php if ($message): ?>
        <div class="alert alert-success alert-dismissible fade show"><?= $message ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show"><?= htmlspecialchars($error) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="row g-3 mb-4">
        <div class="col-6 col-md-3"><div class="apt-stat"><div class="num"><?= number_format($todayCount) ?></div><div class="lbl">Today</div></div></div>
        <div class="col-6 col-md-3"><div class="apt-stat"><div class="num" style="color:#ffc107;"><?= number_format($pendingCount) ?></div><div class="lbl">Pending</div></div></div>
        <div class="col-6 col-md-3"><div class="apt-stat"><div class="num" style="color:#28a745;"><?= number_format($checkedInToday) ?></div><div class="lbl">Checked In</div></div></div>
        <div class="col-6 col-md-3"><div class="apt-stat"><div class="num"><?= count($appointments) ?></div><div class="lbl">Showing</div></div></div>
    </div>

    <div class="card shadow-sm mb-3">
        <div class="card-body">
            <form method="GET" class="row g-2 align-items-end">
                <div class="col-12 col-md-4">
                    <label class="form-label fw-semibold small">Date</label>
                    <input type="date" name="date" class="form-control" value="<?= htmlspecialchars($filterDate) ?>">
                </div>
                <div class="col-12 col-md-4">
                    <label class="form-label fw-semibold small">Status</label>
                    <select name="status" class="form-select">
                        <option value="all"        <?= $filterStatus=='all'?'selected':'' ?>>All</option>
                        <option value="pending"    <?= $filterStatus=='pending'?'selected':'' ?>>Pending</option>
                        <option value="confirmed"  <?= $filterStatus=='confirmed'?'selected':'' ?>>Confirmed</option>
                        <option value="checked_in" <?= $filterStatus=='checked_in'?'selected':'' ?>>Checked In</option>
                        <option value="completed"  <?= $filterStatus=='completed'?'selected':'' ?>>Completed</option>
                        <option value="cancelled"  <?= $filterStatus=='cancelled'?'selected':'' ?>>Cancelled</option>
                        <option value="no_show"    <?= $filterStatus=='no_show'?'selected':'' ?>>No Show</option>
                    </select>
                </div>
                <div class="col-12 col-md-4">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-filter me-2"></i>Filter
                    </button>
                </div>
            </form>
        </div>
    </div>

    <div class="card shadow-sm">
        <div class="card-header bg-white">
            <h6 class="mb-0"><i class="fas fa-list me-2"></i>Appointments for <?= date('d M Y', strtotime($filterDate)) ?></h6>
        </div>
        <div class="card-body">
            <?php if (empty($appointments)): ?>
                <div class="text-center text-muted py-5">
                    <i class="fas fa-calendar-times fa-3x mb-3 d-block" style="opacity:0.2;"></i>
                    <p>No appointments for this date</p>
                </div>
            <?php else: foreach ($appointments as $apt): ?>
                <div class="apt-card status-<?= htmlspecialchars($apt['status']) ?>">
                    <div class="row align-items-center g-2">
                        <div class="col-12 col-md-2">
                            <div class="apt-time"><?= date('H:i', strtotime($apt['appointment_time'])) ?></div>
                            <div class="text-muted small"><?= (int)$apt['duration'] ?> min</div>
                        </div>
                        <div class="col-12 col-md-4">
                            <div class="fw-bold"><?= htmlspecialchars($apt['member_name']) ?></div>
                            <div class="text-muted small">
                                <i class="fas fa-id-card me-1"></i><?= htmlspecialchars($apt['member_id']) ?>
                                <?php if ($apt['member_phone']): ?>
                                    | <i class="fas fa-phone me-1"></i><?= htmlspecialchars($apt['member_phone']) ?>
                                <?php endif; ?>
                            </div>
                            <div class="small mt-1"><i class="fas fa-tag me-1"></i><?= htmlspecialchars($apt['purpose']) ?></div>
                        </div>
                        <div class="col-6 col-md-2">
                            <span class="badge bg-<?= 
                                $apt['status'] === 'pending'    ? 'warning text-dark' : 
                                ($apt['status'] === 'confirmed' ? 'info' : 
                                ($apt['status'] === 'checked_in'? 'success' : 
                                ($apt['status'] === 'cancelled' ? 'secondary' : 
                                ($apt['status'] === 'no_show'   ? 'danger' : 'primary')))) 
                            ?>">
                                <?= ucfirst(str_replace('_', ' ', $apt['status'])) ?>
                            </span>
                            <div class="text-muted small mt-1">
                                <i class="fas fa-key me-1"></i><?= htmlspecialchars($apt['confirmation_code']) ?>
                            </div>
                        </div>
                        <div class="col-6 col-md-4 text-md-end">
                            <?php if ($apt['status'] === 'pending'): ?>
                                <form method="POST" class="d-inline">
                                    <input type="hidden" name="appointment_id" value="<?= (int)$apt['id'] ?>">
                                    <input type="hidden" name="new_status" value="confirmed">
                                    <button type="submit" name="update_status" class="btn btn-sm btn-info">
                                        <i class="fas fa-check"></i> Confirm
                                    </button>
                                </form>
                            <?php endif; ?>

                            <?php if (in_array($apt['status'], ['pending', 'confirmed'], true)): ?>
                                <form method="POST" class="d-inline">
                                    <input type="hidden" name="appointment_id" value="<?= (int)$apt['id'] ?>">
                                    <button type="submit" name="check_in" class="btn btn-sm btn-success">
                                        <i class="fas fa-sign-in-alt"></i> Check In
                                    </button>
                                </form>
                            <?php endif; ?>

                            <?php if (!in_array($apt['status'], ['cancelled', 'completed'], true)): ?>
                                <form method="POST" class="d-inline" onsubmit="return confirm('Cancel this appointment?');">
                                    <input type="hidden" name="appointment_id" value="<?= (int)$apt['id'] ?>">
                                    <input type="hidden" name="new_status" value="cancelled">
                                    <button type="submit" name="update_status" class="btn btn-sm btn-outline-secondary">
                                        <i class="fas fa-times"></i>
                                    </button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php if ($apt['notes']): ?>
                        <div class="mt-2 small text-muted">
                            <i class="fas fa-sticky-note me-1"></i><?= htmlspecialchars($apt['notes']) ?>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endforeach; endif; ?>
        </div>
    </div>
</div>

<!-- New Appointment Modal -->
<div class="modal fade" id="newAptModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form method="POST">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title"><i class="fas fa-calendar-plus me-2"></i>New Appointment</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Member ID <span class="text-danger">*</span></label>
                            <input type="text" name="member_id" class="form-control" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Member Name <span class="text-danger">*</span></label>
                            <input type="text" name="member_name" class="form-control" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Phone</label>
                            <input type="text" name="member_phone" class="form-control">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Email</label>
                            <input type="email" name="member_email" class="form-control">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Date <span class="text-danger">*</span></label>
                            <input type="date" name="appointment_date" class="form-control"
                                   value="<?= date('Y-m-d') ?>" min="<?= date('Y-m-d') ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Time <span class="text-danger">*</span></label>
                            <input type="time" name="appointment_time" class="form-control" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Duration (minutes)</label>
                            <select name="duration" class="form-select">
                                <option value="15">15 minutes</option>
                                <option value="30" selected>30 minutes</option>
                                <option value="60">1 hour</option>
                                <option value="120">2 hours</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Purpose <span class="text-danger">*</span></label>
                            <!-- UPDATED: canonical purpose list (includes Computer Uses) -->
                            <select name="purpose" class="form-select" required>
                                <?= renderPurposeOptions($settings['default_purpose'] ?? 'Reading/Study', $lang) ?>
                            </select>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Notes</label>
                            <textarea name="notes" class="form-control" rows="2"></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="create_appointment" class="btn btn-primary">
                        <i class="fas fa-save me-2"></i>Book Appointment
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include __DIR__ . '/footer.php'; ?>
