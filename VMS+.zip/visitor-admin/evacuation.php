<?php
/**
 * Visitor Management System - Emergency Evacuation List
 * Version: 7.5 Advanced Edition
 * 
 * CRITICAL SAFETY FEATURE: Real-time list of everyone inside
 * Optimized for fast printing during emergencies
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

$possiblePaths = [__DIR__ . '/includes', dirname(__DIR__) . '/includes', '/usr/share/koha/intranet/cgi-bin/koha/visitor/includes'];
$includePath = null;
foreach ($possiblePaths as $path) { if (file_exists($path . '/config.php')) { $includePath = $path; break; } }
if (!$includePath) die('Could not find includes directory.');

define('VMS_INCLUDES', $includePath);
require_once VMS_INCLUDES . '/config.php';

startSecureSession();
requireKohaLogin();

$db = getDB();
$settings = getSettings();
$user = getCurrentUser();

// Get everyone inside
$inside = $db->query("
    SELECT * FROM entry_exit_logs 
    WHERE status = 'inside' 
    ORDER BY entry_type DESC, entry_time ASC
")->fetchAll();

$totalInside = count($inside);
$memberCount = count(array_filter($inside, fn($r) => ($r['entry_type'] ?? 'member') === 'member'));
$guestCount = count(array_filter($inside, fn($r) => ($r['entry_type'] ?? '') === 'guest'));

$pageTitle = 'Emergency Evacuation List';
include __DIR__ . '/header.php';
?>

<style>
.evac-header {
    background: linear-gradient(135deg, #dc3545, #c82333);
    color: white;
    padding: 30px;
    border-radius: 16px;
    margin-bottom: 24px;
    text-align: center;
}
.evac-header h1 { font-size: 2.5rem; font-weight: 800; margin: 0; }
.evac-header p { margin: 8px 0 0; font-size: 1.1rem; opacity: 0.95; }
.evac-stat {
    background: rgba(255,255,255,0.15);
    border-radius: 12px;
    padding: 16px;
    text-align: center;
    margin-top: 16px;
}
.evac-stat .num { font-size: 2.5rem; font-weight: 800; }
.evac-stat .lbl { font-size: 0.85rem; opacity: 0.9; text-transform: uppercase; letter-spacing: 1px; }
.evac-table {
    background: white;
    border-radius: 12px;
    overflow: hidden;
    box-shadow: 0 4px 20px rgba(0,0,0,0.08);
}
.evac-table table { width: 100%; border-collapse: collapse; font-size: 14px; }
.evac-table th {
    background: #1e3c72;
    color: white;
    padding: 14px 12px;
    text-align: left;
    font-weight: 700;
    font-size: 12px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}
.evac-table td {
    padding: 12px;
    border-bottom: 1px solid #e9ecef;
    vertical-align: middle;
}
.evac-table tr:hover td { background: #f8f9fa; }
.evac-table tr.guest-row td { background: #f0fff4; border-left: 4px solid #20c997; }
.evac-table tr:last-child td { border-bottom: none; }
.checkbox-cell { width: 40px; text-align: center; }
.checkbox-cell input[type="checkbox"] {
    width: 24px; height: 24px;
    cursor: pointer;
    accent-color: #dc3545;
}
.evac-name { font-weight: 700; font-size: 15px; color: #2c3e50; }
.evac-id { font-family: monospace; font-size: 13px; color: #6c757d; }
.evac-time { font-size: 13px; color: #495057; }
.evac-duration { font-weight: 600; color: #ffc107; }
.evac-badge {
    padding: 3px 10px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
}
.evac-badge.member { background: #e3f2fd; color: #1976d2; }
.evac-badge.guest { background: #d4edda; color: #155724; }
.emergency-actions {
    display: flex;
    gap: 12px;
    flex-wrap: wrap;
    margin-bottom: 20px;
}
.btn-emergency {
    padding: 12px 24px;
    border-radius: 12px;
    font-weight: 700;
    border: none;
    cursor: pointer;
    transition: all 0.3s;
}
.btn-evacuate {
    background: #dc3545;
    color: white;
    font-size: 1.1rem;
}
.btn-evacuate:hover { background: #c82333; transform: scale(1.02); }
.btn-print-list { background: #1e3c72; color: white; }
.btn-print-list:hover { background: #2a5298; }
@media print {
    .no-print { display: none !important; }
    body { padding: 0; background: white; }
    .evac-header { background: white !important; color: black !important; border-bottom: 3px solid #000; }
    .evac-table th { background: #000 !important; }
    .evac-table { box-shadow: none; }
    .evac-table tr { page-break-inside: avoid; }
}
</style>

<div class="container-fluid">
    <div class="emergency-actions no-print">
        <button onclick="window.print()" class="btn-emergency btn-print-list">
            <i class="fas fa-print me-2"></i>Print Evacuation List
        </button>
        <button onclick="location.reload()" class="btn-emergency btn-print-list">
            <i class="fas fa-sync me-2"></i>Refresh List
        </button>
        <a href="exits.php" class="btn-emergency btn-evacuate">
            <i class="fas fa-sign-out-alt me-2"></i>Go to Exit Page
        </a>
    </div>

    <div class="evac-header">
        <h1><i class="fas fa-exclamation-triangle me-2"></i>EMERGENCY EVACUATION LIST</h1>
        <p>Generated: <?= date('d M Y, H:i:s') ?> | Total Occupants: <strong><?= $totalInside ?></strong></p>
        
        <div class="row g-3">
            <div class="col-4">
                <div class="evac-stat">
                    <div class="num"><?= number_format($totalInside) ?></div>
                    <div class="lbl">Total Inside</div>
                </div>
            </div>
            <div class="col-4">
                <div class="evac-stat">
                    <div class="num"><?= number_format($memberCount) ?></div>
                    <div class="lbl">Members</div>
                </div>
            </div>
            <div class="col-4">
                <div class="evac-stat">
                    <div class="num"><?= number_format($guestCount) ?></div>
                    <div class="lbl">Guests</div>
                </div>
            </div>
        </div>
    </div>

    <div class="evac-table">
        <?php if (empty($inside)): ?>
            <div class="text-center py-5">
                <i class="fas fa-check-circle fa-4x text-success mb-3 d-block"></i>
                <h4 class="text-success">All Clear — No one inside</h4>
                <p class="text-muted">The library appears to be empty.</p>
            </div>
        <?php else: ?>
            <table>
                <thead>
                    <tr>
                        <th class="checkbox-cell no-print">✓</th>
                        <th style="width:60px;">#</th>
                        <th>Name</th>
                        <th>ID</th>
                        <th>Category</th>
                        <th>Type</th>
                        <th>Entry Time</th>
                        <th>Duration</th>
                        <th>Purpose</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i = 1; foreach ($inside as $person): 
                        $isGuest = ($person['entry_type'] ?? 'member') === 'guest';
                    ?>
                        <tr class="<?= $isGuest ? 'guest-row' : '' ?>">
                            <td class="checkbox-cell no-print">
                                <input type="checkbox" onchange="this.closest('tr').style.opacity = this.checked ? '0.4' : '1'; this.closest('tr').style.textDecoration = this.checked ? 'line-through' : 'none';">
                            </td>
                            <td><strong><?= $i++ ?></strong></td>
                            <td class="evac-name"><?= htmlspecialchars($person['member_name']) ?></td>
                            <td class="evac-id"><?= htmlspecialchars($person['admno']) ?></td>
                            <td><?= htmlspecialchars($person['member_category'] ?? 'N/A') ?></td>
                            <td>
                                <span class="evac-badge <?= $isGuest ? 'guest' : 'member' ?>">
                                    <?= $isGuest ? 'Guest' : 'Member' ?>
                                </span>
                            </td>
                            <td class="evac-time"><?= date('H:i:s', strtotime($person['entry_time'])) ?></td>
                            <td class="evac-duration"><?= timeAgo($person['entry_time']) ?></td>
                            <td><?= htmlspecialchars($person['purpose'] ?? 'N/A') ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>

    <div class="mt-3 text-center text-muted small">
        <i class="fas fa-info-circle me-1"></i> 
        Use the checkboxes (on screen only) to mark individuals as accounted for during evacuation.
        Print this list for emergency personnel.
    </div>
</div>

<?php include __DIR__ . '/footer.php'; ?>