<?php
/**
 * Visitor Management System - Dashboard
 * Version: 7.3 FINAL – Enhanced with responsive design and real-time stats
 * UNCOMPRESSED FULL VERSION
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/koha.php';
require_once __DIR__ . '/includes/auth.php';

startSecureSession();
requireKohaLogin();

$db = getDB();
$settings = getSettings();
$user = getCurrentUser();

if (!$user) {
    die('<div class="container mt-5"><div class="alert alert-danger">User not found. Your Koha session is valid, but we could not retrieve your user details.</div></div>');
}

$displayName = !empty($user['full_name']) ? $user['full_name'] : $user['username'];

// ============================================================
// GET STATS
// ============================================================
$stats = getCachedStats($db);
$recent = getCachedRecentActivity($db);

// ============================================================
// GET ADDITIONAL STATS
// ============================================================
$totalMembers = $db->query("SELECT COUNT(*) FROM members")->fetchColumn();
$totalBooks = $db->query("SELECT COUNT(*) FROM book_exit_logs")->fetchColumn();
$todayEntries = $db->query("SELECT COUNT(*) FROM entry_exit_logs WHERE entry_date = CURDATE()")->fetchColumn();
$todayExits = $db->query("SELECT COUNT(*) FROM entry_exit_logs WHERE entry_date = CURDATE() AND status = 'exited'")->fetchColumn();

// ============================================================
// GET HOURLY ACTIVITY FOR CHART
// ============================================================
$hourlyData = getHourlyActivity();

// ============================================================
// GET PURPOSE STATS FOR CHART
// ============================================================
$purposeData = getPurposeStats();

// ============================================================
// GREETING
// ============================================================
$hour = (int)date('G');
if ($hour < 12) $greeting = 'Good Morning 🌅';
elseif ($hour < 17) $greeting = 'Good Afternoon ☀️';
else $greeting = 'Good Evening 🌙';

$pageTitle = 'Dashboard';
include __DIR__ . '/header.php';
?>

<style>
/* ============================================================
   DASHBOARD STYLES
   ============================================================ */
.dashboard-stats {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
    gap: 16px;
    margin-bottom: 24px;
}

.stat-card-dashboard {
    background: white;
    border-radius: 16px;
    padding: 20px 18px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.04);
    transition: all 0.3s;
    border: 1px solid rgba(0, 0, 0, 0.04);
    display: flex;
    align-items: center;
    gap: 16px;
}

.stat-card-dashboard:hover {
    transform: translateY(-3px);
    box-shadow: 0 8px 25px rgba(0, 0, 0, 0.08);
}

.stat-card-dashboard .stat-icon {
    width: 48px;
    height: 48px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.3rem;
    color: white;
    flex-shrink: 0;
}

.stat-card-dashboard .stat-icon.primary { background: #1e3c72; }
.stat-card-dashboard .stat-icon.success { background: #28a745; }
.stat-card-dashboard .stat-icon.danger { background: #dc3545; }
.stat-card-dashboard .stat-icon.info { background: #17a2b8; }
.stat-card-dashboard .stat-icon.warning { background: #ffc107; }
.stat-card-dashboard .stat-icon.purple { background: #6f42c1; }

.stat-card-dashboard .stat-content {
    flex: 1;
    min-width: 0;
}

.stat-card-dashboard .stat-number {
    font-size: 1.6rem;
    font-weight: 700;
    color: #2c3e50;
    line-height: 1.2;
}

.stat-card-dashboard .stat-label {
    font-size: 0.75rem;
    color: #6c757d;
    margin: 0;
}

.stat-card-dashboard .stat-change {
    font-size: 0.7rem;
    font-weight: 600;
    padding: 2px 8px;
    border-radius: 20px;
    display: inline-block;
}

.stat-card-dashboard .stat-change.up { background: #d4edda; color: #155724; }
.stat-card-dashboard .stat-change.down { background: #f8d7da; color: #721c24; }
.stat-card-dashboard .stat-change.neutral { background: #e9ecef; color: #6c757d; }

.greeting-card {
    background: white;
    border-radius: 16px;
    padding: 20px 24px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.04);
    margin-bottom: 24px;
}

.avatar-lg {
    width: 56px;
    height: 56px;
    border-radius: 50%;
    overflow: hidden;
    background: #1e3c72;
    color: white;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.6rem;
    font-weight: 700;
    flex-shrink: 0;
}

.avatar-lg img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.quick-actions {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(100px, 1fr));
    gap: 10px;
    margin: 16px 0;
}

.quick-btn {
    background: white;
    border-radius: 12px;
    padding: 12px 10px;
    text-align: center;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
    transition: all 0.3s;
    text-decoration: none;
    color: #2c3e50;
    border: 1px solid transparent;
}

.quick-btn:hover {
    transform: translateY(-3px);
    box-shadow: 0 8px 25px rgba(0, 0, 0, 0.08);
    border-color: #1e3c72;
    color: #1e3c72;
}

.quick-btn i {
    font-size: 1.4rem;
    display: block;
    margin-bottom: 4px;
    color: #1e3c72;
}

.quick-btn span {
    font-size: 0.7rem;
    font-weight: 500;
}

.chart-container {
    position: relative;
    height: 250px;
}

@media (max-width: 768px) {
    .dashboard-stats {
        grid-template-columns: repeat(2, 1fr);
        gap: 10px;
    }
    .stat-card-dashboard {
        padding: 14px 12px;
    }
    .stat-card-dashboard .stat-number {
        font-size: 1.2rem;
    }
    .stat-card-dashboard .stat-icon {
        width: 36px;
        height: 36px;
        font-size: 1rem;
    }
    .chart-container {
        height: 200px;
    }
    .quick-actions {
        grid-template-columns: repeat(3, 1fr);
    }
}

@media (max-width: 480px) {
    .dashboard-stats {
        grid-template-columns: 1fr 1fr;
        gap: 8px;
    }
    .stat-card-dashboard {
        padding: 10px 8px;
    }
    .stat-card-dashboard .stat-number {
        font-size: 1rem;
    }
    .stat-card-dashboard .stat-icon {
        width: 30px;
        height: 30px;
        font-size: 0.8rem;
    }
    .stat-card-dashboard .stat-label {
        font-size: 0.6rem;
    }
    .quick-actions {
        grid-template-columns: repeat(3, 1fr);
        gap: 6px;
    }
    .quick-btn {
        padding: 8px 6px;
    }
    .quick-btn i {
        font-size: 1rem;
    }
    .quick-btn span {
        font-size: 0.6rem;
    }
}
</style>

<div class="container-fluid">
    <!-- ============================================================
    GREETING CARD
    ============================================================ -->
    <div class="greeting-card">
        <div class="d-flex align-items-center flex-wrap gap-3">
            <div class="avatar-lg">
                <?php if (!empty($user['photo'])): ?>
                    <img src="<?= $user['photo'] ?>" alt="Photo" loading="lazy">
                <?php else: ?>
                    <span><?= substr($displayName, 0, 1) ?></span>
                <?php endif; ?>
            </div>
            <div class="flex-grow-1">
                <h4 class="mb-0"><?= $greeting ?>, <?= htmlspecialchars($displayName) ?>!</h4>
                <small class="text-muted">
                    <i class="fas fa-user-tag"></i> <?= ucfirst($user['role'] ?? 'Viewer') ?>
                    <?php if (!empty($user['branch'])): ?>
                        | <i class="fas fa-building"></i> <?= htmlspecialchars($user['branch']) ?>
                    <?php endif; ?>
                    <?php if (!empty($user['department'])): ?>
                        | <i class="fas fa-graduation-cap"></i> <?= htmlspecialchars($user['department']) ?>
                    <?php endif; ?>
                </small>
            </div>
            <div class="ms-auto d-flex gap-2">
                <span class="badge bg-success"><i class="fas fa-database"></i> Connected</span>
                <span class="badge bg-info"><i class="fas fa-circle"></i> Live</span>
                <?php if ($settings['maintenance_mode'] ?? 0): ?>
                    <span class="badge bg-warning text-dark"><i class="fas fa-tools"></i> Maintenance</span>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- ============================================================
    QUICK ACTIONS
    ============================================================ -->
    <div class="quick-actions">
        <a href="entries.php" class="quick-btn">
            <i class="fas fa-sign-in-alt"></i>
            <span>Entry</span>
        </a>
        <a href="exits.php" class="quick-btn">
            <i class="fas fa-sign-out-alt"></i>
            <span>Exit</span>
        </a>
        <a href="logs.php" class="quick-btn">
            <i class="fas fa-list"></i>
            <span>Logs</span>
        </a>
        <a href="reports.php" class="quick-btn">
            <i class="fas fa-chart-line"></i>
            <span>Reports</span>
        </a>
        <a href="books.php" class="quick-btn">
            <i class="fas fa-book"></i>
            <span>Books</span>
        </a>
        <a href="members.php" class="quick-btn">
            <i class="fas fa-users"></i>
            <span>Members</span>
        </a>
        <a href="settings.php" class="quick-btn">
            <i class="fas fa-cog"></i>
            <span>Settings</span>
        </a>
        <a href="<?= KOHA_OPAC_URL ?>/visitor/" class="quick-btn" target="_blank">
            <i class="fas fa-door-open"></i>
            <span>Kiosk</span>
        </a>
    </div>

    <!-- ============================================================
    STATS CARDS
    ============================================================ -->
    <div class="dashboard-stats">
        <div class="stat-card-dashboard">
            <div class="stat-icon primary"><i class="fas fa-users"></i></div>
            <div class="stat-content">
                <div class="stat-number"><?= number_format($stats['inside'] ?? 0) ?></div>
                <div class="stat-label">Currently Inside</div>
            </div>
        </div>
        <div class="stat-card-dashboard">
            <div class="stat-icon success"><i class="fas fa-sign-in-alt"></i></div>
            <div class="stat-content">
                <div class="stat-number"><?= number_format($stats['today'] ?? 0) ?></div>
                <div class="stat-label">Today's Entries</div>
            </div>
        </div>
        <div class="stat-card-dashboard">
            <div class="stat-icon danger"><i class="fas fa-sign-out-alt"></i></div>
            <div class="stat-content">
                <div class="stat-number"><?= number_format($todayExits) ?></div>
                <div class="stat-label">Today's Exits</div>
            </div>
        </div>
        <div class="stat-card-dashboard">
            <div class="stat-icon warning"><i class="fas fa-exclamation-triangle"></i></div>
            <div class="stat-content">
                <div class="stat-number"><?= number_format($stats['unauthorized'] ?? 0) ?></div>
                <div class="stat-label">Unauthorized Books</div>
            </div>
        </div>
        <div class="stat-card-dashboard">
            <div class="stat-icon info"><i class="fas fa-user-tag"></i></div>
            <div class="stat-content">
                <div class="stat-number"><?= number_format($stats['guests'] ?? 0) ?></div>
                <div class="stat-label">Active Guests</div>
            </div>
        </div>
        <div class="stat-card-dashboard">
            <div class="stat-icon purple"><i class="fas fa-users"></i></div>
            <div class="stat-content">
                <div class="stat-number"><?= number_format($totalMembers) ?></div>
                <div class="stat-label">Total Members</div>
            </div>
        </div>
    </div>

    <!-- ============================================================
    CHARTS ROW
    ============================================================ -->
    <div class="row g-3 mb-4">
        <div class="col-12 col-md-8">
            <div class="card shadow-sm">
                <div class="card-header bg-white">
                    <h5 class="card-title mb-0"><i class="fas fa-chart-bar me-2 text-primary"></i>Hourly Activity</h5>
                </div>
                <div class="card-body">
                    <div class="chart-container">
                        <canvas id="hourlyChart"></canvas>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-12 col-md-4">
            <div class="card shadow-sm">
                <div class="card-header bg-white">
                    <h5 class="card-title mb-0"><i class="fas fa-chart-pie me-2 text-primary"></i>Purpose Distribution</h5>
                </div>
                <div class="card-body">
                    <div class="chart-container">
                        <canvas id="purposeChart"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ============================================================
    RECENT ACTIVITY
    ============================================================ -->
    <div class="card shadow-sm">
        <div class="card-header bg-white d-flex justify-content-between align-items-center flex-wrap gap-2">
            <h5 class="card-title mb-0"><i class="fas fa-history me-2 text-primary"></i>Recent Activity</h5>
            <a href="logs.php" class="btn btn-sm btn-outline-primary">View All</a>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>Member</th>
                            <th>ID</th>
                            <th>Entry</th>
                            <th>Exit</th>
                            <th>Purpose</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($recent)): ?>
                            <tr>
                                <td colspan="6" class="text-center py-4 text-muted">
                                    <i class="fas fa-check-circle text-success me-2"></i> No recent activity
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($recent as $r): ?>
                                <tr>
                                    <td><strong><?= htmlspecialchars($r['member_name'] ?? 'Unknown') ?></strong></td>
                                    <td><code><?= htmlspecialchars($r['admno'] ?? '') ?></code></td>
                                    <td><?= htmlspecialchars($r['entry_time'] ?? '') ?></td>
                                    <td>
                                        <?php if (!empty($r['exit_time'])): ?>
                                            <?= htmlspecialchars($r['exit_time']) ?>
                                        <?php else: ?>
                                            <span class="badge bg-success">Inside</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?= htmlspecialchars($r['purpose'] ?? 'N/A') ?></td>
                                    <td>
                                        <span class="badge <?= ($r['status'] ?? '') === 'inside' ? 'bg-success' : 'bg-secondary' ?>">
                                            <?= strtoupper($r['status'] ?? 'Unknown') ?>
                                        </span>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- ============================================================
    SYSTEM INFO
    ============================================================ -->
    <div class="row g-3 mt-2">
        <div class="col-12 col-md-6">
            <div class="card shadow-sm">
                <div class="card-header bg-white">
                    <h5 class="card-title mb-0"><i class="fas fa-info-circle me-2 text-primary"></i>System Information</h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-6">
                            <small class="text-muted">Version</small>
                            <div class="fw-bold"><?= APP_VERSION ?></div>
                        </div>
                        <div class="col-6">
                            <small class="text-muted">PHP Version</small>
                            <div class="fw-bold"><?= PHP_VERSION ?></div>
                        </div>
                        <div class="col-6 mt-2">
                            <small class="text-muted">Database</small>
                            <div class="fw-bold"><?= DB_NAME ?></div>
                        </div>
                        <div class="col-6 mt-2">
                            <small class="text-muted">Koha Status</small>
                            <div class="fw-bold">
                                <?= isKohaAvailable() ? '<span class="text-success">✅ Connected</span>' : '<span class="text-danger">❌ Not Connected</span>' ?>
                            </div>
                        </div>
                        <div class="col-6 mt-2">
                            <small class="text-muted">Server Time</small>
                            <div class="fw-bold"><?= date('d-m-Y H:i:s') ?></div>
                        </div>
                        <div class="col-6 mt-2">
                            <small class="text-muted">Timezone</small>
                            <div class="fw-bold"><?= SITE_TIMEZONE ?></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-12 col-md-6">
            <div class="card shadow-sm">
                <div class="card-header bg-white">
                    <h5 class="card-title mb-0"><i class="fas fa-tasks me-2 text-primary"></i>Quick Actions</h5>
                </div>
                <div class="card-body">
                    <div class="d-grid gap-2">
                        <button onclick="location.href='?clear_cache=1'" class="btn btn-outline-warning btn-sm">
                            <i class="fas fa-broom me-2"></i> Clear Cache
                        </button>
                        <button onclick="testKohaConnection()" class="btn btn-outline-info btn-sm">
                            <i class="fas fa-database me-2"></i> Test Koha Connection
                        </button>
                        <div id="kohaTestResult" class="mt-2"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- ============================================================
CHARTS
============================================================ -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // ============================================================
    // Hourly Chart
    // ============================================================
    const hourlyData = <?= json_encode($hourlyData) ?>;
    if (hourlyData && hourlyData.length > 0) {
        const hours = Array.from({length: 24}, (_, i) => i);
        const counts = hours.map(h => {
            const found = hourlyData.find(d => parseInt(d.hour) === h);
            return found ? parseInt(found.count) : 0;
        });
        const ctx = document.getElementById('hourlyChart').getContext('2d');
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: hours.map(h => String(h).padStart(2, '0') + ':00'),
                datasets: [{
                    label: 'Visits',
                    data: counts,
                    backgroundColor: 'rgba(30,60,114,0.6)',
                    borderColor: '#1e3c72',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    y: { 
                        beginAtZero: true, 
                        ticks: { stepSize: 1 },
                        grid: { color: 'rgba(0,0,0,0.05)' }
                    },
                    x: { 
                        ticks: { font: { size: 8 }, maxTicksLimit: 24 },
                        grid: { display: false }
                    }
                }
            }
        });
    } else {
        document.getElementById('hourlyChart').parentElement.innerHTML = 
            '<div class="text-center text-muted py-4">No hourly data available</div>';
    }

    // ============================================================
    // Purpose Chart
    // ============================================================
    const purposeData = <?= json_encode($purposeData) ?>;
    if (purposeData && purposeData.length > 0) {
        const colors = ['#1e3c72', '#28a745', '#ffc107', '#dc3545', '#17a2b8', '#6f42c1', '#fd7e14', '#20c997'];
        const ctx = document.getElementById('purposeChart').getContext('2d');
        new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: purposeData.map(d => d.purpose || 'Unknown'),
                datasets: [{
                    data: purposeData.map(d => parseInt(d.count) || 0),
                    backgroundColor: colors.slice(0, purposeData.length)
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { 
                        position: 'bottom', 
                        labels: { 
                            boxWidth: 10, 
                            padding: 6, 
                            font: { size: 8 },
                            usePointStyle: true
                        }
                    }
                }
            }
        });
    } else {
        document.getElementById('purposeChart').parentElement.innerHTML = 
            '<div class="text-center text-muted py-4">No purpose data available</div>';
    }
});

// ============================================================
// TEST KOHA CONNECTION
// ============================================================
function testKohaConnection() {
    const resultEl = document.getElementById('kohaTestResult');
    if (!resultEl) return;
    
    resultEl.innerHTML = '<div class="alert alert-info py-1 mb-0"><i class="fas fa-spinner fa-spin me-2"></i> Testing connection...</div>';
    
    fetch('ajax.php?action=test_koha', {
        method: 'GET',
        headers: { 'X-Requested-With': 'XMLHttpRequest' }
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            resultEl.innerHTML = '<div class="alert alert-success py-1 mb-0">✅ Koha connection successful</div>';
        } else {
            resultEl.innerHTML = '<div class="alert alert-danger py-1 mb-0">❌ ' + escapeHtml(data.message) + '</div>';
        }
    })
    .catch(err => {
        resultEl.innerHTML = '<div class="alert alert-danger py-1 mb-0">❌ Connection failed: ' + escapeHtml(err.message) + '</div>';
    });
}

function escapeHtml(str) {
    if (!str) return '';
    const d = document.createElement('div');
    d.textContent = str;
    return d.innerHTML;
}
</script>

<?php include __DIR__ . '/footer.php'; ?>
