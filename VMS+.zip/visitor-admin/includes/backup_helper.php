<?php
/**
 * VMS + Koha Unified Backup Helper
 * Version: 1.0
 *
 * Safe, memory-efficient SQL dumper for both databases.
 * No shell exec, no mysqldump dependency — pure PDO.
 */

if (!function_exists('vms_backup_quote')) {
    function vms_backup_quote(PDO $db, $value): string
    {
        if ($value === null) return 'NULL';
        if (is_int($value) || is_float($value)) return (string)$value;
        return $db->quote((string)$value);
    }
}

if (!function_exists('vms_backup_show_create')) {
    function vms_backup_show_create(PDO $db, string $name): array
    {
        $safe = str_replace('`', '``', $name);
        $stmt = $db->query("SHOW CREATE TABLE `$safe`");
        $row  = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$row) return ['type' => 'table', 'ddl' => ''];

        // Index 1 is always the DDL regardless of object type
        $values = array_values($row);
        $ddl    = $values[1] ?? '';
        $type   = (stripos($ddl, 'CREATE VIEW') !== false) ? 'view' : 'table';

        return ['type' => $type, 'ddl' => $ddl];
    }
}

if (!function_exists('vms_backup_dump_object')) {
    function vms_backup_dump_object(PDO $db, string $name, string $type, string $ddl): string
    {
        $safe = str_replace('`', '``', $name);

        if ($type === 'view') {
            return "-- ---------- View structure for `$name` ----------\n"
                 . "DROP VIEW IF EXISTS `$safe`;\n"
                 . $ddl . ";\n\n";
        }

        $out  = "-- ---------- Table structure for `$name` ----------\n";
        $out .= "DROP TABLE IF EXISTS `$safe`;\n";
        $out .= $ddl . ";\n\n";

        // Skip data for known Koha tables that are huge & regenerable
        $skipData = in_array($name, [
            'search_cache', 'session_cache', 'sessions',
            'action_logs', 'zebraqueue',
        ], true);

        if ($skipData) {
            $out .= "-- (data skipped for large/regenerable table)\n\n";
            return $out;
        }

        $rows = $db->query("SELECT * FROM `$safe`");
        if ($rows) {
            $buffer  = [];
            $counter = 0;
            while ($row = $rows->fetch(PDO::FETCH_ASSOC)) {
                $vals = array_map(fn($v) => vms_backup_quote($db, $v), array_values($row));
                $buffer[] = '(' . implode(',', $vals) . ')';
                $counter++;

                if (count($buffer) >= 500) {
                    $out .= "INSERT INTO `$safe` VALUES\n" . implode(",\n", $buffer) . ";\n";
                    $buffer = [];
                }
            }
            if (!empty($buffer)) {
                $out .= "INSERT INTO `$safe` VALUES\n" . implode(",\n", $buffer) . ";\n";
            }
            if ($counter > 0) $out .= "\n";
        }

        return $out;
    }
}

if (!function_exists('vms_backup_dump_database')) {
    /**
     * Dump an entire PDO-connected database.
     *
     * @param PDO    $db       Connection
     * @param string $dbName   Name for the header
     * @param array  $opts     ['include_data' => true, 'table_filter' => callable|null]
     * @return string          Full SQL text
     */
    function vms_backup_dump_database(PDO $db, string $dbName, array $opts = []): string
    {
        $includeData = $opts['include_data'] ?? true;
        $filter      = $opts['table_filter'] ?? null;

        $objects = $db->query("SHOW FULL TABLES")->fetchAll(PDO::FETCH_NUM);
        $tables  = [];
        $views   = [];

        foreach ($objects as $o) {
            $name = $o[0];
            $kind = $o[1] ?? '';
            if ($filter && !$filter($name, $kind)) continue;
            if ($kind === 'VIEW') $views[] = $name;
            else                  $tables[] = $name;
        }

        $sql  = "-- ============================================================\n";
        $sql .= "-- Backup of `$dbName`\n";
        $sql .= "-- Generated: " . date('Y-m-d H:i:s') . "\n";
        $sql .= "-- Tables: " . count($tables) . "  |  Views: " . count($views) . "\n";
        $sql .= "-- ============================================================\n\n";
        $sql .= "SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';\n";
        $sql .= "SET time_zone = '+00:00';\n";
        $sql .= "SET NAMES utf8mb4;\n";
        $sql .= "SET FOREIGN_KEY_CHECKS = 0;\n\n";

        foreach ($tables as $t) {
            $meta = vms_backup_show_create($db, $t);
            $sql .= vms_backup_dump_object($db, $t, $meta['type'], $meta['ddl']);
        }

        if (!empty($views)) {
            $sql .= "-- ============================================================\n";
            $sql .= "-- Views\n";
            $sql .= "-- ============================================================\n\n";
            foreach ($views as $v) {
                $meta = vms_backup_show_create($db, $v);
                $sql .= vms_backup_dump_object($db, $v, $meta['type'], $meta['ddl']);
            }
        }

        $sql .= "SET FOREIGN_KEY_CHECKS = 1;\n";
        $sql .= "-- Backup completed at " . date('Y-m-d H:i:s') . "\n";

        return $sql;
    }
}

if (!function_exists('vms_backup_ensure_dir')) {
    /**
     * Resolve a writable backup directory.
     * Order: LOGS_PATH/backups → __DIR__/../logs/backups → sys temp
     */
    function vms_backup_ensure_dir(): array
    {
        $candidates = [];
        if (defined('LOGS_PATH')) $candidates[] = rtrim(LOGS_PATH, '/') . '/backups';
        $candidates[] = dirname(__DIR__) . '/logs/backups';
        $candidates[] = sys_get_temp_dir() . '/vms_backups';

        foreach ($candidates as $dir) {
            if (!is_dir($dir)) { @mkdir($dir, 0775, true); @chmod($dir, 0775); }
            if (is_dir($dir) && is_writable($dir)) {
                return ['path' => $dir, 'writable' => true, 'fallback' => ($dir === end($candidates))];
            }
        }
        $tmp = sys_get_temp_dir() . '/vms_backups';
        @mkdir($tmp, 0775, true);
        return ['path' => $tmp, 'writable' => is_writable($tmp), 'fallback' => true];
    }
}

if (!function_exists('vms_backup_list_files')) {
    function vms_backup_list_files(string $dir, string $prefix = 'backup_'): array
    {
        $out = [];
        foreach (glob(rtrim($dir, '/') . '/' . $prefix . '*.sql') ?: [] as $f) {
            $out[] = [
                'name' => basename($f),
                'size' => filesize($f),
                'date' => filemtime($f),
                'path' => $f,
            ];
        }
        usort($out, fn($a, $b) => $b['date'] - $a['date']);
        return $out;
    }
}