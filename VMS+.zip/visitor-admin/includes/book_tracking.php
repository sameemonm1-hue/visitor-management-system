<?php
/**
 * Visitor Management System — Book Tracking Module
 * Version: 8.5.1 — Canonical unauthorized/issued fetch + record + photo
 *
 * This is the ONE file responsible for everything book-exit related:
 *   • Self-migrating table/column setup
 *   • Koha-aware book lookup (items + biblio + biblioitems + issues)
 *   • Authorized / unauthorized detection
 *   • Webcam photo persistence
 *   • Book-exit recording with alert auto-generation
 *   • Auto-exit of the borrower on authorized exit (RFID-like)
 *   • Query helpers for admin UI (list, count, delete, clear)
 *
 * Loaded by: ajax.php, books.php, index.php (public kiosk)
 */

require_once __DIR__ . '/config.php';

// ============================================================
// 1. SELF-MIGRATION
// ============================================================
if (!function_exists('vms_ensure_book_tracking_tables')) {
    /**
     * Ensure `book_exit_logs` and `book_alerts` exist with the columns
     * this module relies on. Safe to call on every request.
     */
    function vms_ensure_book_tracking_tables(): void
    {
        static $done = false;
        if ($done) return;
        $done = true;

        try {
            $db = getDB();

            // ---------- book_exit_logs ----------
            $db->exec("
                CREATE TABLE IF NOT EXISTS book_exit_logs (
                    id              INT PRIMARY KEY AUTO_INCREMENT,
                    book_barcode    VARCHAR(50)  NOT NULL,
                    book_title      VARCHAR(200) NOT NULL,
                    book_author     VARCHAR(200) NULL,
                    book_isbn       VARCHAR(30)  NULL,
                    member_admno    VARCHAR(50)  NULL,
                    member_name     VARCHAR(200) NULL,
                    exit_time       TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    is_authorized   TINYINT(1) DEFAULT 0,
                    photo_path      VARCHAR(255) NULL,
                    notes           TEXT         NULL,
                    gate_number     VARCHAR(20)  NULL,
                    staff_id        INT          NULL,
                    alert_sent      TINYINT(1) DEFAULT 0,
                    alert_sent_at   DATETIME     NULL,
                    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    INDEX idx_barcode     (book_barcode),
                    INDEX idx_member      (member_admno),
                    INDEX idx_auth        (is_authorized),
                    INDEX idx_created     (created_at),
                    INDEX idx_alert_sent  (alert_sent)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            ");

            // Safe-add missing columns (older installs)
            $want = [
                'book_isbn'   => "VARCHAR(30) NULL",
                'gate_number' => "VARCHAR(20) NULL",
                'staff_id'    => "INT NULL",
                'alert_sent'  => "TINYINT(1) DEFAULT 0",
                'alert_sent_at' => "DATETIME NULL",
            ];
            $have = $db->query("SHOW COLUMNS FROM book_exit_logs")->fetchAll(PDO::FETCH_COLUMN);
            foreach ($want as $col => $def) {
                if (!in_array($col, $have, true)) {
                    try { $db->exec("ALTER TABLE book_exit_logs ADD COLUMN `$col` $def"); }
                    catch (PDOException $e) { /* ignore */ }
                }
            }

            // ---------- book_alerts ----------
            $db->exec("
                CREATE TABLE IF NOT EXISTS book_alerts (
                    id               INT PRIMARY KEY AUTO_INCREMENT,
                    log_id           INT          NOT NULL,
                    book_barcode     VARCHAR(50)  NOT NULL,
                    book_title       VARCHAR(200) NOT NULL,
                    photo_path       VARCHAR(255) NULL,
                    acknowledged     TINYINT(1) DEFAULT 0,
                    acknowledged_by  INT        NULL,
                    acknowledged_at  DATETIME   NULL,
                    ack_note         TEXT       NULL,
                    resolved         TINYINT(1) DEFAULT 0,
                    resolved_by      INT        NULL,
                    resolved_at      DATETIME   NULL,
                    resolution       TEXT       NULL,
                    email_sent       TINYINT(1) DEFAULT 0,
                    sms_sent         TINYINT(1) DEFAULT 0,
                    webhook_sent     TINYINT(1) DEFAULT 0,
                    created_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    INDEX idx_log    (log_id),
                    INDEX idx_status (acknowledged, resolved),
                    INDEX idx_created (created_at)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            ");
        } catch (PDOException $e) {
            error_log('[VMS book_tracking] ensure tables: ' . $e->getMessage());
        }
    }
}

vms_ensure_book_tracking_tables();

// ============================================================
// 2. KOHA BOOK LOOKUP (with live loan status)
// ============================================================
if (!function_exists('vms_get_book_status')) {
    /**
     * Fetch a book from Koha with full loan status.
     *
     * Returns an array shaped for immediate use by both the kiosk and the
     * admin UI:
     *
     *  [
     *    'found'            => bool,
     *    'is_book'          => bool,
     *    'is_authorized'    => bool,          // currently issued?
     *    'book'             => [ ... book fields ... ],
     *    'loan'             => [ ... loan fields ... ] | null,
     *    'member'           => [ ... borrower fields + photo ... ] | null,
     *    'days_overdue'     => int,
     *    'message'          => string,
     *  ]
     */
    function vms_get_book_status(string $barcode): array
    {
        $barcode = trim($barcode);
        if ($barcode === '') {
            return ['found' => false, 'is_book' => false, 'is_authorized' => false,
                    'book' => null, 'loan' => null, 'member' => null,
                    'days_overdue' => 0, 'message' => 'Empty barcode'];
        }

        // Cache per request (avoid re-querying on kiosk double-fire)
        static $cache = [];
        $cacheKey = 'bc_' . md5($barcode);
        if (isset($cache[$cacheKey])) return $cache[$cacheKey];

        $koha = getKoha();
        if (!$koha) {
            return $cache[$cacheKey] = [
                'found' => false, 'is_book' => false, 'is_authorized' => false,
                'book' => null, 'loan' => null, 'member' => null,
                'days_overdue' => 0, 'message' => 'Koha database not reachable',
            ];
        }

        try {
            // Detect Koha issues PK column
            $issueIdCol = 'issue_id';
            try {
                $c = $koha->query("SHOW COLUMNS FROM issues LIKE 'issue_id'");
                if ($c->rowCount() === 0) {
                    $c = $koha->query("SHOW COLUMNS FROM issues LIKE 'id'");
                    if ($c->rowCount() > 0) $issueIdCol = 'id';
                }
            } catch (PDOException $e) { /* keep default */ }

            $sql = "
                SELECT
                    i.itemnumber,
                    i.barcode              AS barcode,
                    i.biblionumber         AS biblionumber,
                    i.itemcallnumber       AS callnumber,
                    i.homebranch,
                    i.holdingbranch,
                    i.location,
                    i.itype,
                    i.ccode,
                    i.notforloan,
                    i.damaged,
                    i.itemlost,
                    i.withdrawn,
                    i.price,

                    b.title                AS title,
                    b.author               AS author,
                    b.copyrightdate        AS copyrightdate,

                    bi.isbn                AS isbn,
                    bi.publishercode       AS publisher,
                    bi.publicationyear     AS year,

                    iss.{$issueIdCol}      AS issue_id,
                    iss.borrowernumber     AS borrowernumber,
                    iss.issuedate          AS issuedate,
                    iss.date_due           AS date_due,
                    iss.returndate         AS returndate,

                    br.cardnumber          AS member_cardnumber,
                    br.userid              AS member_userid,
                    br.surname             AS member_surname,
                    br.firstname           AS member_firstname,
                    br.title               AS member_title,
                    br.email               AS member_email,
                    br.mobile              AS member_mobile,
                    br.categorycode        AS member_categorycode

                FROM items i
                LEFT JOIN biblio       b   ON b.biblionumber    = i.biblionumber
                LEFT JOIN biblioitems  bi  ON bi.biblionumber   = i.biblionumber
                LEFT JOIN issues       iss ON iss.itemnumber    = i.itemnumber
                                          AND iss.returndate IS NULL
                LEFT JOIN borrowers    br  ON br.borrowernumber = iss.borrowernumber
                WHERE i.barcode = ?
                LIMIT 1
            ";

            $stmt = $koha->prepare($sql);
            $stmt->execute([$barcode]);
            $row = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$row) {
                return $cache[$cacheKey] = [
                    'found' => false, 'is_book' => false, 'is_authorized' => false,
                    'book' => null, 'loan' => null, 'member' => null,
                    'days_overdue' => 0, 'message' => 'Not a book barcode',
                ];
            }

            $isAuthorized = !empty($row['borrowernumber']);

            // Build book object
            $book = [
                'barcode'      => $row['barcode'],
                'itemnumber'   => (int)$row['itemnumber'],
                'biblionumber' => (int)$row['biblionumber'],
                'title'        => $row['title']  ?? 'Untitled',
                'author'       => $row['author'] ?? '',
                'isbn'         => $row['isbn']   ?? '',
                'publisher'    => $row['publisher'] ?? '',
                'year'         => $row['year']      ?? '',
                'callnumber'   => $row['callnumber'] ?? '',
                'homebranch'   => $row['homebranch'] ?? '',
                'holdingbranch'=> $row['holdingbranch'] ?? '',
                'notforloan'   => (int)$row['notforloan'],
                'damaged'      => (int)$row['damaged'],
                'itemlost'     => (int)$row['itemlost'],
                'withdrawn'    => (int)$row['withdrawn'],
                'price'        => (float)($row['price'] ?? 0),
            ];

            // Loan object (only if issued)
            $loan   = null;
            $member = null;
            $daysOverdue = 0;

            if ($isAuthorized) {
                $loan = [
                    'issue_id'       => (int)($row['issue_id'] ?? 0),
                    'borrowernumber' => (int)$row['borrowernumber'],
                    'issuedate'      => $row['issuedate'] ?? null,
                    'date_due'       => $row['date_due']  ?? null,
                ];

                if (!empty($row['date_due'])) {
                    $due = strtotime($row['date_due']);
                    if ($due && $due < time()) {
                        $daysOverdue = (int)floor((time() - $due) / 86400);
                    }
                }

                // Member object
                $parts = array_filter([
                    trim((string)($row['member_title']     ?? '')),
                    trim((string)($row['member_firstname'] ?? '')),
                    trim((string)($row['member_surname']   ?? '')),
                ], fn($p) => $p !== '');
                $fullName = implode(' ', $parts);
                if ($fullName === '') {
                    $fullName = $row['member_cardnumber'] ?? 'Unknown';
                }

                $member = [
                    'borrowernumber' => (int)$row['borrowernumber'],
                    'cardnumber'     => $row['member_cardnumber'] ?? '',
                    'userid'         => $row['member_userid']     ?? '',
                    'full_name'      => $fullName,
                    'email'          => $row['member_email']      ?? '',
                    'mobile'         => $row['member_mobile']     ?? '',
                    'categorycode'   => $row['member_categorycode'] ?? '',
                ];

                // Photo from patronimage
                try {
                    $imgStmt = $koha->prepare("
                        SELECT imagefile FROM patronimage
                        WHERE borrowernumber = ? LIMIT 1
                    ");
                    $imgStmt->execute([$row['borrowernumber']]);
                    $img = $imgStmt->fetch();
                    if ($img && !empty($img['imagefile'])) {
                        $member['photo_base64'] = 'data:image/jpeg;base64,'
                            . base64_encode($img['imagefile']);
                    }
                } catch (PDOException $e) { /* patronimage may not exist */ }
            }

            $msg = $isAuthorized
                ? 'Book is issued (authorized exit)'
                : 'Book is NOT issued (unauthorized exit)';

            return $cache[$cacheKey] = [
                'found'          => true,
                'is_book'        => true,
                'is_authorized'  => $isAuthorized,
                'book'           => $book,
                'loan'           => $loan,
                'member'         => $member,
                'days_overdue'   => $daysOverdue,
                'message'        => $msg,
            ];

        } catch (PDOException $e) {
            error_log('[VMS book_tracking] get_book_status: ' . $e->getMessage());
            return $cache[$cacheKey] = [
                'found' => false, 'is_book' => false, 'is_authorized' => false,
                'book' => null, 'loan' => null, 'member' => null,
                'days_overdue' => 0, 'message' => 'Koha lookup error',
            ];
        }
    }
}

// ============================================================
// 3. PHOTO CAPTURE — persist base64 dataURL to disk
// ============================================================
if (!function_exists('vms_save_book_exit_photo')) {
    /**
     * Save a base64 data-URL photo to /uploads/book_exit_photos/.
     *
     * Accepts:  "data:image/jpeg;base64,/9j/4AAQ..."
     * Returns:  filename (relative to the photos dir) on success, null on failure.
     */
    function vms_save_book_exit_photo(?string $dataUrl): ?string
    {
        if (empty($dataUrl) || !is_string($dataUrl)) return null;

        // Strip the data-url header
        if (!preg_match('#^data:image/(jpeg|jpg|png|webp);base64,#i', $dataUrl, $m)) {
            return null;
        }
        $ext  = strtolower($m[1]);
        if ($ext === 'jpg') $ext = 'jpeg';

        $raw = base64_decode(substr($dataUrl, strlen($m[0])), true);
        if ($raw === false || strlen($raw) < 200) {
            return null;
        }

        // Reject anything over 3 MB
        if (strlen($raw) > 3 * 1024 * 1024) {
            error_log('[VMS book_tracking] photo too large: ' . strlen($raw) . ' bytes');
            return null;
        }

        $dir = UPLOAD_PATH . '/book_exit_photos/';
        if (!is_dir($dir)) {
            @mkdir($dir, 0777, true);
            @chmod($dir, 0777);
        }

        $ext = $ext === 'jpeg' ? 'jpg' : $ext;
        $filename = 'unauth_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
        $target   = $dir . $filename;

        if (@file_put_contents($target, $raw) === false) {
            error_log('[VMS book_tracking] failed to write photo: ' . $target);
            return null;
        }
        @chmod($target, 0644);

        return $filename;
    }
}

// ============================================================
// 4. RECORD BOOK EXIT (the one function everything calls)
// ============================================================
if (!function_exists('vms_log_book_exit')) {
    /**
     * Record a book exit (authorized or unauthorized).
     *
     * @param string $barcode   Koha item barcode
     * @param array  $opts      Optional overrides:
     *      'photo_data'    => base64 data-URL (from webcam)
     *      'member_admno'  => override
     *      'member_name'   => override
     *      'gate_number'   => default 'MAIN'
     *      'notes'         => extra notes
     *      'staff_id'      => user id
     *      'auto_exit_borrower' => true (default) — exit borrower on authorized exit
     *
     * @return array {
     *    success        : bool
     *    log_id         : int|null
     *    is_authorized  : bool
     *    alert_created  : bool
     *    borrower_exited: bool
     *    photo_path     : string|null
     *    book           : array|null
     *    member         : array|null
     *    message        : string
     * }
     */
    function vms_log_book_exit(string $barcode, array $opts = []): array
    {
        vms_ensure_book_tracking_tables();

        $barcode = trim($barcode);
        if ($barcode === '') {
            return ['success' => false, 'log_id' => null, 'is_authorized' => false,
                    'alert_created' => false, 'borrower_exited' => false,
                    'photo_path' => null, 'book' => null, 'member' => null,
                    'message' => 'Empty barcode'];
        }

        $status = vms_get_book_status($barcode);
        if (!$status['found'] || !$status['is_book']) {
            return ['success' => false, 'log_id' => null, 'is_authorized' => false,
                    'alert_created' => false, 'borrower_exited' => false,
                    'photo_path' => null, 'book' => null, 'member' => null,
                    'message' => $status['message'] ?? 'Book not found'];
        }

        $book         = $status['book'];
        $member       = $status['member'];
        $isAuthorized = $status['is_authorized'];

        $memberAdmno = $opts['member_admno']
            ?? ($member['cardnumber'] ?? null);
        $memberName  = $opts['member_name']
            ?? ($member['full_name']  ?? null);
        $gate        = $opts['gate_number'] ?? 'MAIN';
        $notes       = $opts['notes'] ?? ($isAuthorized ? 'Authorized exit' : 'Unauthorized exit');
        $staffId     = (int)($opts['staff_id'] ?? ($_SESSION['koha_user_id'] ?? 0));
        $autoExit    = $opts['auto_exit_borrower'] ?? true;

        // ---------- Save photo ----------
        $photoPath = null;
        if (!empty($opts['photo_data'])) {
            $photoPath = vms_save_book_exit_photo($opts['photo_data']);
            if ($photoPath === null) {
                error_log('[VMS book_tracking] photo save failed for barcode ' . $barcode);
            }
        } elseif (!$isAuthorized) {
            // Unauthorized exits without photo are still allowed,
            // but flagged in notes.
            $notes .= ' [no photo captured]';
        }

        // ---------- Insert book_exit_logs ----------
        try {
            $db = getDB();
            $ins = $db->prepare("
                INSERT INTO book_exit_logs
                    (book_barcode, book_title, book_author, book_isbn,
                     member_admno, member_name,
                     is_authorized, photo_path, notes, gate_number, staff_id,
                     exit_time, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
            ");
            $ins->execute([
                $book['barcode'],
                $book['title'],
                $book['author'] ?? '',
                $book['isbn']   ?? '',
                $memberAdmno ?: null,
                $memberName  ?: null,
                $isAuthorized ? 1 : 0,
                $photoPath,
                $notes,
                $gate,
                $staffId,
            ]);
            $logId = (int)$db->lastInsertId();
        } catch (PDOException $e) {
            error_log('[VMS book_tracking] insert log: ' . $e->getMessage());
            return ['success' => false, 'log_id' => null, 'is_authorized' => $isAuthorized,
                    'alert_created' => false, 'borrower_exited' => false,
                    'photo_path' => $photoPath, 'book' => $book, 'member' => $member,
                    'message' => 'DB insert failed'];
        }

        // ---------- Unauthorized: create alert row + notify ----------
        $alertCreated = false;
        if (!$isAuthorized) {
            try {
                $db->prepare("
                    INSERT INTO book_alerts
                        (log_id, book_barcode, book_title, photo_path, created_at)
                    VALUES (?, ?, ?, ?, NOW())
                ")->execute([$logId, $book['barcode'], $book['title'], $photoPath]);

                $db->prepare("
                    UPDATE book_exit_logs
                       SET alert_sent = 1, alert_sent_at = NOW()
                     WHERE id = ?
                ")->execute([$logId]);

                $alertCreated = true;
            } catch (PDOException $e) {
                error_log('[VMS book_tracking] alert insert: ' . $e->getMessage());
            }

            // Fire external notifications (email / webhook / sms)
            if (function_exists('sendUnauthorizedBookAlert')) {
                try {
                    sendUnauthorizedBookAlert([
                        'barcode'     => $book['barcode'],
                        'title'       => $book['title'],
                        'author'      => $book['author'] ?? '',
                        'member_name' => $memberName,
                        'member_id'   => $memberAdmno,
                        'photo_path'  => $photoPath,
                        'staff_name'  => $_SESSION['koha_full_name'] ?? 'Kiosk',
                        'gate_number' => $gate,
                        'timestamp'   => date('Y-m-d H:i:s'),
                    ]);
                } catch (Throwable $e) {
                    error_log('[VMS book_tracking] notify: ' . $e->getMessage());
                }
            }
        }

        // ---------- Authorized: auto-exit borrower (RFID-like) ----------
        $borrowerExited = false;
        if ($isAuthorized && $autoExit && $memberAdmno) {
            try {
                $upd = $db->prepare("
                    UPDATE entry_exit_logs
                       SET exit_time = NOW(), status = 'exited'
                     WHERE admno = ? AND status = 'inside'
                ");
                $upd->execute([$memberAdmno]);
                $borrowerExited = $upd->rowCount() > 0;

                if ($borrowerExited) {
                    clearCache('stats');
                    clearCache('recent_activity');
                }
            } catch (PDOException $e) {
                error_log('[VMS book_tracking] auto-exit borrower: ' . $e->getMessage());
            }
        }

        // ---------- Activity log ----------
        if (function_exists('logActivity')) {
            logActivity(
                $staffId,
                $isAuthorized ? 'BOOK_EXIT_AUTH' : 'BOOK_EXIT_UNAUTH',
                "Book {$book['barcode']} — " . ($isAuthorized ? 'authorized' : 'UNAUTHORIZED')
            );
        }

        clearCache('stats');

        return [
            'success'         => true,
            'log_id'          => $logId,
            'is_authorized'   => $isAuthorized,
            'alert_created'   => $alertCreated,
            'borrower_exited' => $borrowerExited,
            'photo_path'      => $photoPath,
            'book'            => $book,
            'member'          => $member,
            'message'         => $isAuthorized
                ? 'Authorized book exit recorded'
                : 'UNAUTHORIZED book exit recorded',
        ];
    }
}

// ============================================================
// 5. QUERY HELPERS (for admin UI)
// ============================================================
if (!function_exists('vms_fetch_book_logs')) {
    /**
     * Fetch book exit logs, optionally filtered.
     *
     * @param array $opts {
     *    'unauthorized_only' => bool
     *    'limit'             => int (default 200)
     *    'offset'            => int
     *    'from'              => 'Y-m-d'
     *    'to'                => 'Y-m-d'
     * }
     */
    function vms_fetch_book_logs(array $opts = []): array
    {
        vms_ensure_book_tracking_tables();

        $only    = !empty($opts['unauthorized_only']);
        $limit   = max(1, min(1000, (int)($opts['limit'] ?? 200)));
        $offset  = max(0, (int)($opts['offset'] ?? 0));
        $from    = $opts['from'] ?? '';
        $to      = $opts['to']   ?? '';

        $where  = [];
        $params = [];

        if ($only) {
            $where[] = "is_authorized = 0";
        }
        if ($from !== '' && $to !== '') {
            $where[]  = "DATE(created_at) BETWEEN ? AND ?";
            $params[] = $from;
            $params[] = $to;
        }

        $sql = "SELECT * FROM book_exit_logs";
        if ($where) $sql .= " WHERE " . implode(' AND ', $where);
        $sql .= " ORDER BY created_at DESC LIMIT $limit OFFSET $offset";

        try {
            $stmt = getDB()->prepare($sql);
            $stmt->execute($params);
            return $stmt->fetchAll();
        } catch (PDOException $e) {
            error_log('[VMS book_tracking] fetch_book_logs: ' . $e->getMessage());
            return [];
        }
    }
}

if (!function_exists('vms_count_unauthorized_book_logs')) {
    function vms_count_unauthorized_book_logs(): int
    {
        try {
            return (int)getDB()
                ->query("SELECT COUNT(*) FROM book_exit_logs WHERE is_authorized = 0")
                ->fetchColumn();
        } catch (PDOException $e) {
            return 0;
        }
    }
}

if (!function_exists('vms_count_today_book_logs')) {
    function vms_count_today_book_logs(): int
    {
        try {
            return (int)getDB()
                ->query("SELECT COUNT(*) FROM book_exit_logs WHERE DATE(created_at) = CURDATE()")
                ->fetchColumn();
        } catch (PDOException $e) {
            return 0;
        }
    }
}

if (!function_exists('vms_delete_book_log')) {
    function vms_delete_book_log(int $id): bool
    {
        if ($id <= 0) return false;
        try {
            $db = getDB();
            // Cascade: remove linked alert rows first
            try {
                $db->prepare("DELETE FROM book_alerts WHERE log_id = ?")->execute([$id]);
            } catch (PDOException $e) { /* ignore */ }

            $stmt = $db->prepare("DELETE FROM book_exit_logs WHERE id = ?");
            $stmt->execute([$id]);
            return $stmt->rowCount() > 0;
        } catch (PDOException $e) {
            error_log('[VMS book_tracking] delete: ' . $e->getMessage());
            return false;
        }
    }
}

if (!function_exists('vms_clear_unauthorized_book_logs')) {
    function vms_clear_unauthorized_book_logs(): int
    {
        try {
            $db = getDB();
            try { $db->exec("DELETE FROM book_alerts WHERE acknowledged = 0 AND resolved = 0"); }
            catch (PDOException $e) { /* ignore */ }
            $stmt = $db->exec("DELETE FROM book_exit_logs WHERE is_authorized = 0");
            return (int)$stmt;
        } catch (PDOException $e) {
            error_log('[VMS book_tracking] clear: ' . $e->getMessage());
            return 0;
        }
    }
}