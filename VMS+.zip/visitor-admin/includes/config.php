<?php
/**
 * Visitor Management System - Main Configuration
 * Version: 7.3 FINAL – Complete with all settings
 * UNCOMPRESSED FULL VERSION
 */

// ============================================================
// ERROR REPORTING
// ============================================================
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

// ============================================================
// DATABASE CONFIGURATION
// ============================================================
define('DB_HOST', 'localhost');
define('DB_USER', 'koha_library');
define('DB_PASS', 'mysqlroot');
define('DB_NAME', 'visitor_management');
define('DB_CHARSET', 'utf8mb4');

// ============================================================
// KOHA DATABASE CONFIGURATION
// ============================================================
define('KOHA_ENABLED', true);
define('KOHA_HOST', 'localhost');
define('KOHA_DB', 'koha_library');
define('KOHA_USER', 'koha_library');
define('KOHA_PASS', 'mysqlroot');
define('KOHA_CHARSET', 'utf8mb4');

// ============================================================
// KOHA URL CONFIGURATION
// ============================================================
define('KOHA_INTRANET_URL', 'http://localhost:8081');
define('KOHA_OPAC_URL',     'http://localhost:8082');
// ============================================================
// SITE CONFIGURATION
// ============================================================
define('SITE_NAME', 'Visitor Management System');
define('SITE_VERSION', '7.3.0');
define('SITE_TIMEZONE', 'Asia/Kolkata');

// ============================================================
// SECURITY CONFIGURATION
// ============================================================
define('SESSION_TIMEOUT', 3600);
define('CSRF_TOKEN_LIFETIME', 3600);
define('LOGIN_ATTEMPTS', 5);
define('MAX_UPLOAD_SIZE', 5242880); // 5MB

// ============================================================
// PATHS
// ============================================================
define('ROOT_PATH', dirname(__DIR__));
define('INCLUDES_PATH', ROOT_PATH . '/includes');
define('UPLOAD_PATH', ROOT_PATH . '/uploads');
define('LOGS_PATH', ROOT_PATH . '/logs');

// ============================================================
// FEATURE FLAGS
// ============================================================
define('FEATURE_RFID', true);
define('FEATURE_WEBCAM', false);
define('FEATURE_BOOK_SCAN', true);
define('FEATURE_GUEST_MODE', true);
define('FEATURE_MULTI_LANGUAGE', true);
define('FEATURE_COVER_FLOW', true);
define('FEATURE_FORCE_EXIT', true);
define('FEATURE_PDF_REPORTS', true);
define('FEATURE_CAMERA_CAPTURE', true);

// ============================================================
// CACHE SETTINGS
// ============================================================
define('CACHE_ENABLED', true);
define('CACHE_LIFETIME', 30); // seconds

// ============================================================
// PUBLIC KIOSK DEFAULTS
// ============================================================
define('PUBLIC_AUTO_REFRESH', 10);
define('PUBLIC_SHOW_STATS', true);
define('PUBLIC_SHOW_QUOTE', true);
define('PUBLIC_FEATURE_GUEST', true);
define('PUBLIC_FEATURE_BOOK_SCAN', true);
define('PUBLIC_FEATURE_WEBCAM', false);
define('PUBLIC_FEATURE_RFID', true);
define('PUBLIC_FEATURE_COVER_FLOW', true);
define('PUBLIC_DEFAULT_LANG', 'en');

// ============================================================
// INITIALIZE
// ============================================================
date_default_timezone_set(SITE_TIMEZONE);

// Load core files
require_once __DIR__ . '/constants.php';
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/koha.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/languages.php';
?>
