<?php
/**
 * Visitor Management System - Koha Integration
 * Version: 8.6 FINAL
 *
 * KEY FIXES over v7.6:
 *   • getKohaBook() now joins biblio + biblioitems for title/author/isbn
 *   • issue_id column auto-detected (issue_id | id)
 *   • Negative caching for "not found" books (false sentinel)
 *   • Robust role detection with memoized caches
 */

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/functions.php';

if (!isset($GLOBALS['__koha_role_cache']))  $GLOBALS['__koha_role_cache']  = [];
if (!isset($GLOBALS['__koha_perms_cache'])) $GLOBALS['__koha_perms_cache'] = [];

// ============================================================
// MEMBER LOOKUP
// ============================================================
function getKohaMember($identifier) {
    $koha = getKoha();
    if (!$koha) return null;

    $identifier = trim((string)$identifier);
    if ($identifier === '') return null;

    $cacheKey = 'koha_member_' . md5($identifier);
    $cached = getCache($cacheKey);
    if ($cached !== null) return ($cached === false) ? null : $cached;

    try {
        $sqlTpl = "
            SELECT 
                b.borrowernumber, b.cardnumber, b.surname, b.firstname, b.title,
                b.sex AS gender, b.categorycode, b.branchcode,
                b.sort1 AS department, b.sort2 AS course,
                b.email, b.mobile, b.dateexpiry, b.dateenrolled, b.userid,
                c.description AS category_description,
                br.branchname AS branch_name
            FROM borrowers b
            LEFT JOIN categories c ON b.categorycode = c.categorycode
            LEFT JOIN branches  br ON b.branchcode  = br.branchcode
            WHERE (%s)
            AND b.dateexpiry > CURDATE()
            AND (b.gonenoaddress IS NULL OR b.gonenoaddress = 0)
            AND (b.lost IS NULL OR b.lost = 0)
            AND (b.debarred IS NULL OR b.debarred = 0)
            LIMIT 1
        ";

        $member = null;
        foreach ([
            'b.cardnumber = ?',
            'b.userid = ?',
        ] as $cond) {
            $stmt = $koha->prepare(sprintf($sqlTpl, $cond));
            $stmt->execute([$identifier]);
            if ($member = $stmt->fetch()) break;
        }
        if (!$member && is_numeric($identifier)) {
            $stmt = $koha->prepare(sprintf($sqlTpl, 'b.borrowernumber = ?'));
            $stmt->execute([$identifier]);
            $member = $stmt->fetch();
        }
        if (!$member) {
            setCache($cacheKey, false);
            return null;
        }

        $parts = array_filter([
            trim((string)($member['title']     ?? '')),
            trim((string)($member['firstname'] ?? '')),
            trim((string)($member['surname']   ?? '')),
        ], fn($p) => $p !== '');
        $member['full_name'] = $parts ? implode(' ', $parts) : ($member['cardnumber'] ?? 'Unknown');

        try {
            $stmt = $koha->prepare("SELECT imagefile FROM patronimage WHERE borrowernumber = ? LIMIT 1");
            $stmt->execute([$member['borrowernumber']]);
            $img = $stmt->fetch();
            if ($img && !empty($img['imagefile'])) {
                $member['photo_base64'] = 'data:image/jpeg;base64,' . base64_encode($img['imagefile']);
            }
        } catch (PDOException $e) {}

        setCache($cacheKey, $member);
        return $member;

    } catch (PDOException $e) {
        error_log("getKohaMember: " . $e->getMessage());
        return null;
    }
}

// ============================================================
// BOOK LOOKUP (title/author from biblio — fixed)
// ============================================================
function getKohaBook($barcode) {
    $koha = getKoha();
    if (!$koha) return null;

    $barcode = trim((string)$barcode);
    if ($barcode === '') return null;

    $cacheKey = 'koha_book_' . md5($barcode);
    $cached = getCache($cacheKey);
    if ($cached !== null) return ($cached === false) ? null : $cached;

    try {
        $issueIdCol = 'issue_id';
        try {
            if ($koha->query("SHOW COLUMNS FROM issues LIKE 'issue_id'")->rowCount() === 0) {
                if ($koha->query("SHOW COLUMNS FROM issues LIKE 'id'")->rowCount() > 0) {
                    $issueIdCol = 'id';
                }
            }
        } catch (PDOException $e) {}

        $sql = "
            SELECT
                i.barcode, i.itemnumber, i.biblionumber, i.itemcallnumber,
                i.homebranch, i.holdingbranch, i.location, i.itype, i.ccode,
                i.notforloan, i.damaged, i.itemlost, i.withdrawn, i.price,
                b.title          AS title,
                b.author         AS author,
                b.copyrightdate  AS copyrightdate,
                b.seriestitle    AS seriestitle,
                bi.isbn          AS isbn,
                bi.publishercode AS publishercode,
                bi.publicationyear AS publicationyear,
                iss.$issueIdCol  AS issue_id,
                iss.borrowernumber AS borrowernumber,
                iss.issuedate      AS issuedate,
                iss.date_due       AS date_due,
                iss.returndate     AS returndate,
                br.cardnumber    AS member_cardnumber,
                br.surname       AS member_surname,
                br.firstname     AS member_firstname,
                br.title         AS member_title
            FROM items i
            LEFT JOIN biblio       b   ON b.biblionumber    = i.biblionumber
            LEFT JOIN biblioitems  bi  ON bi.biblionumber   = i.biblionumber
            LEFT JOIN issues       iss ON iss.itemnumber    = i.itemnumber
                                       AND iss.returndate IS NULL
            LEFT JOIN borrowers    br  ON br.borrowernumber = iss.borrowernumber
            WHERE i.barcode = ?
            LIMIT 1
        ";
        $stmt = $koha->prepare($sql);
        $stmt->execute([$barcode]);
        $book = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$book) {
            setCache($cacheKey, false);
            return null;
        }

        if (!empty($book['member_cardnumber'])) {
            $parts = array_filter([
                trim((string)($book['member_title']     ?? '')),
                trim((string)($book['member_firstname'] ?? '')),
                trim((string)($book['member_surname']   ?? '')),
            ], fn($p) => $p !== '');
            $book['member_name'] = $parts ? implode(' ', $parts) : '';
        } else {
            $book['member_name'] = '';
        }

        $book['title']  = $book['title']  ?? '';
        $book['author'] = $book['author'] ?? '';

        setCache($cacheKey, $book);
        return $book;

    } catch (PDOException $e) {
        error_log('[VMS getKohaBook] ' . $e->getMessage());
        return null;
    }
}

// ============================================================
// PERMISSIONS / ROLE
// ============================================================
function getKohaPermissions($borrowernumber) {
    if (empty($borrowernumber)) return [];
    if (isset($GLOBALS['__koha_perms_cache'][$borrowernumber])) {
        return $GLOBALS['__koha_perms_cache'][$borrowernumber];
    }
    $sessionKey = 'perms_refresh_' . $borrowernumber;
    if (isset($_SESSION[$sessionKey]) && (time() - $_SESSION[$sessionKey]) < 300) {
        if (isset($_SESSION['koha_permissions']) && is_array($_SESSION['koha_permissions'])) {
            $GLOBALS['__koha_perms_cache'][$borrowernumber] = $_SESSION['koha_permissions'];
            return $_SESSION['koha_permissions'];
        }
    }

    $koha = getKoha();
    if (!$koha) return [];
    $permissions = [];
    try {
        $stmt = $koha->prepare("SELECT permission FROM user_permissions WHERE borrowernumber = ?");
        $stmt->execute([$borrowernumber]);
        $permissions = $stmt->fetchAll(PDO::FETCH_COLUMN) ?: [];
    } catch (PDOException $e) {}
    if ($borrowernumber == 1 && !in_array('superlibrarian', $permissions)) {
        $permissions[] = 'superlibrarian';
    }
    try {
        $stmt = $koha->prepare("SELECT flags FROM borrowers WHERE borrowernumber = ?");
        $stmt->execute([$borrowernumber]);
        $row = $stmt->fetch();
        if ($row && !empty($row['flags']) && !in_array('superlibrarian', $permissions)) {
            $permissions[] = 'superlibrarian';
        }
    } catch (PDOException $e) {}
    $GLOBALS['__koha_perms_cache'][$borrowernumber] = $permissions;
    return $permissions;
}

function getKohaRole($borrowernumber) {
    if (empty($borrowernumber)) return 'viewer';
    if (isset($GLOBALS['__koha_role_cache'][$borrowernumber])) {
        return $GLOBALS['__koha_role_cache'][$borrowernumber];
    }
    $perms = getKohaPermissions($borrowernumber);
    $role = 'viewer';

    if (in_array('superlibrarian', $perms, true)) {
        $role = 'admin';
    } elseif (array_intersect($perms, [
        'manage_sysprefs','manage_patrons','manage_circ_rules',
        'manage_acquisitions','manage_serials','manage_reports','manage_suggestions'
    ])) {
        $role = 'admin';
    } elseif (in_array('circulate', $perms, true) && array_intersect($perms, ['borrowers','edit_borrowers','editcatalogue'])) {
        $role = 'manager';
    } elseif (array_intersect($perms, ['circulate','editcatalogue','catalogue','tools','reports'])) {
        $role = 'staff';
    }
    if ($role === 'viewer' && $borrowernumber == 1) $role = 'admin';

    $GLOBALS['__koha_role_cache'][$borrowernumber] = $role;
    return $role;
}

// ============================================================
// SEARCH
// ============================================================
function searchKohaBooks($search, $limit = 20) {
    $koha = getKoha();
    if (!$koha) return [];
    try {
        $stmt = $koha->prepare("
            SELECT b.biblionumber, b.title, b.author, b.isbn, b.publicationyear,
                (SELECT COUNT(*) FROM items WHERE biblionumber = b.biblionumber
                    AND notforloan=0 AND damaged=0 AND itemlost=0 AND withdrawn=0) AS available_copies,
                (SELECT COUNT(*) FROM items i
                    JOIN issues iss ON i.itemnumber = iss.itemnumber
                    WHERE i.biblionumber = b.biblionumber AND iss.returndate IS NULL) AS issued_copies
            FROM biblio b
            WHERE b.title LIKE ? OR b.author LIKE ? OR b.isbn LIKE ?
            ORDER BY b.title LIMIT ?
        ");
        $q = '%' . $search . '%';
        $stmt->execute([$q, $q, $q, $limit]);
        return $stmt->fetchAll();
    } catch (PDOException $e) { return []; }
}

function searchKohaMembers($search, $limit = 20) {
    $koha = getKoha();
    if (!$koha) return [];
    try {
        $stmt = $koha->prepare("
            SELECT b.borrowernumber, b.cardnumber,
                   CONCAT(IFNULL(b.title,''), ' ', IFNULL(b.firstname,''), ' ', IFNULL(b.surname,'')) AS name,
                   b.categorycode, b.branchcode, b.email, b.mobile,
                   c.description AS category_description
            FROM borrowers b
            LEFT JOIN categories c ON b.categorycode = c.categorycode
            WHERE (b.cardnumber LIKE ? OR b.firstname LIKE ? OR b.surname LIKE ? OR b.userid LIKE ?)
            AND b.dateexpiry > CURDATE()
            ORDER BY b.surname LIMIT ?
        ");
        $q = '%' . $search . '%';
        $stmt->execute([$q, $q, $q, $q, $limit]);
        return $stmt->fetchAll();
    } catch (PDOException $e) { return []; }
}

function getKohaCategories() {
    $koha = getKoha();
    if (!$koha) return [];
    $cached = getCache('koha_categories');
    if ($cached !== null) return $cached;
    try {
        $data = $koha->query("SELECT categorycode, description, enrolmentperiod FROM categories ORDER BY description")->fetchAll();
        setCache('koha_categories', $data);
        return $data;
    } catch (PDOException $e) { return []; }
}

function getKohaBranches() {
    $koha = getKoha();
    if (!$koha) return [];
    $cached = getCache('koha_branches');
    if ($cached !== null) return $cached;
    try {
        $data = $koha->query("SELECT branchcode, branchname FROM branches ORDER BY branchname")->fetchAll();
        setCache('koha_branches', $data);
        return $data;
    } catch (PDOException $e) { return []; }
}

function getKohaStats() {
    $cached = getCache('koha_stats');
    if ($cached !== null) return $cached;
    $koha = getKoha();
    if (!$koha) return null;
    try {
        $stats = [
            'total_borrowers' => (int)$koha->query("SELECT COUNT(*) FROM borrowers WHERE dateexpiry > CURDATE()")->fetchColumn(),
            'total_items'     => (int)$koha->query("SELECT COUNT(*) FROM items WHERE notforloan=0 AND damaged=0 AND itemlost=0 AND withdrawn=0")->fetchColumn(),
            'total_issues'    => (int)$koha->query("SELECT COUNT(*) FROM issues WHERE returndate IS NULL")->fetchColumn(),
        ];
        setCache('koha_stats', $stats);
        return $stats;
    } catch (PDOException $e) { return null; }
}
