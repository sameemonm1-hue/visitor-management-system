<?php
/**
 * Visitor Management System - Bootstrap
 * Version: 8.6 FINAL
 *
 * Legacy bootstrap — now delegates to functions.php for canonical helpers.
 */

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/koha.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/languages.php';

// Alerts are loaded on-demand
$__alertsFile = __DIR__ . '/alerts.php';
if (file_exists($__alertsFile)) require_once $__alertsFile;

// Book tracking is loaded on-demand
$__btFile = __DIR__ . '/book_tracking.php';
if (file_exists($__btFile)) require_once $__btFile;
