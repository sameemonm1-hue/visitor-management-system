<?php
/**
 * Visitor Management System - Koha Authentication
 * Version: 7.5 FINAL – Enhanced with permission refresh & session optimization
 */

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/koha.php';

// ============================================================
// SESSION MANAGEMENT
// ============================================================
function startSecureSession() {
    if (session_status() === PHP_SESSION_NONE) {
        session_name('CGISESSID');
        if (isset($_COOKIE['CGISESSID'])) {
            session_id($_COOKIE['CGISESSID']);
        }
        // Session cookie hardening
        $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
        session_set_cookie_params([
            'lifetime' => 0,
            'path' => '/',
            'domain' => '',
            'secure' => $secure,
            'httponly' => true,
            'samesite' => 'Lax'
        ]);
        session_start();
    }
    
    // Regenerate session ID periodically (every 30 min)
    if (!isset($_SESSION['created_at'])) {
        $_SESSION['created_at'] = time();
    } elseif (time() - $_SESSION['created_at'] > 1800) {
        session_regenerate_id(true);
        $_SESSION['created_at'] = time();
    }
}

function destroySession() {
    $_SESSION = array();
    
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(
            session_name(),
            '',
            time() - 42000,
            $params["path"],
            $params["domain"],
            $params["secure"],
            $params["httponly"]
        );
    }
    
    session_destroy();
}

// ============================================================
// KOHA SESSION VALIDATION
// ============================================================
function validateKohaSession($sessionId) {
    $koha = getKoha();
    if (!$koha) return false;

    // Cache validation for 30 seconds
    $cacheKey = 'session_validate_' . md5($sessionId);
    $cached = getCache($cacheKey);
    if ($cached !== null) return $cached;

    try {
        $stmt = $koha->query("SHOW COLUMNS FROM sessions");
        $columns = $stmt->fetchAll(PDO::FETCH_COLUMN);
    } catch (PDOException $e) {
        error_log("validateKohaSession: Error checking sessions table: " . $e->getMessage());
        return false;
    }

    $result = false;

    if (in_array('a_session', $columns)) {
        // Koha 22.11+ style sessions
        try {
            $stmt = $koha->prepare("SELECT a_session FROM sessions WHERE id = ?");
            $stmt->execute([$sessionId]);
            $row = $stmt->fetch();
            if (!$row || empty($row['a_session'])) {
                setCache($cacheKey, false);
                return false;
            }

            $sessionData = $row['a_session'];
            $data = array();
            $lines = preg_split('/\r\n|\n|\r/', $sessionData);
            foreach ($lines as $line) {
                $line = trim($line);
                if (empty($line) || strpos($line, '---') === 0 || strpos($line, '_SESSION_') === 0) {
                    continue;
                }
                $parts = explode(':', $line, 2);
                if (count($parts) == 2) {
                    $data[trim($parts[0])] = trim($parts[1]);
                }
            }

            // Session expiry
            $lasttime = null;
            if (preg_match('/_SESSION_ATIME:\s*(\d+)/', $sessionData, $matches)) {
                $lasttime = (int)$matches[1];
            }
            if ($lasttime && (time() - $lasttime > 3600)) {
                setCache($cacheKey, false);
                return false;
            }

            $cardnumber = $data['cardnumber'] ?? null;
            $userid = $data['id'] ?? null;

            if ($cardnumber) {
                $stmt = $koha->prepare("SELECT borrowernumber FROM borrowers WHERE cardnumber = ? LIMIT 1");
                $stmt->execute([$cardnumber]);
                $borrower = $stmt->fetch();
                if ($borrower) {
                    $result = (int)$borrower['borrowernumber'];
                } else {
                    $stmt = $koha->prepare("SELECT borrowernumber FROM borrowers WHERE userid = ? LIMIT 1");
                    $stmt->execute([$cardnumber]);
                    $row = $stmt->fetch();
                    if ($row) $result = (int)$row['borrowernumber'];
                }
            }

            if (!$result && $userid) {
                $stmt = $koha->prepare("SELECT borrowernumber FROM borrowers WHERE userid = ? LIMIT 1");
                $stmt->execute([$userid]);
                $row = $stmt->fetch();
                if ($row) $result = (int)$row['borrowernumber'];
            }
            
        } catch (PDOException $e) {
            error_log("validateKohaSession: DB error: " . $e->getMessage());
        }
    } else {
        // Legacy session table
        try {
            $stmt = $koha->prepare("SELECT borrowernumber FROM sessions WHERE sessionid = ? AND lasttime > UNIX_TIMESTAMP() - 3600");
            $stmt->execute([$sessionId]);
            $row = $stmt->fetch();
            if ($row) $result = (int)$row['borrowernumber'];
        } catch (PDOException $e) {
            error_log("validateKohaSession: Fallback error: " . $e->getMessage());
        }
    }

    setCache($cacheKey, $result);
    return $result;
}

// ============================================================
// AUTHENTICATION FUNCTIONS
// ============================================================
function isKohaLoggedIn() {
    startSecureSession();
    return isset($_SESSION['koha_logged_in']) && $_SESSION['koha_logged_in'] === true;
}

/**
 * Refresh user permissions from Koha DB
 * Call to ensure permissions are up-to-date
 */
function refreshKohaPermissions() {
    if (!isKohaLoggedIn()) return false;
    
    $borrowernumber = $_SESSION['koha_user_id'] ?? null;
    if (!$borrowernumber) return false;
    
    $koha = getKoha();
    if (!$koha) return false;
    
    try {
        // Clear memo cache to force refresh
        unset($GLOBALS['__koha_role_cache'][$borrowernumber]);
        unset($GLOBALS['__koha_perms_cache'][$borrowernumber]);
        clearCache('koha_member_' . md5($borrowernumber));
        
        $_SESSION['koha_permissions'] = getKohaPermissions($borrowernumber);
        $_SESSION['koha_role'] = getKohaRole($borrowernumber);
        $_SESSION['permissions_refreshed'] = time();
        
        error_log("refreshKohaPermissions: User $borrowernumber role set to: " . $_SESSION['koha_role']);
        return true;
    } catch (Exception $e) {
        error_log("refreshKohaPermissions error: " . $e->getMessage());
        return false;
    }
}

function requireKohaLogin() {
    startSecureSession();

    // Already logged in
    if (isKohaLoggedIn()) {
        // Session timeout check
        if (isset($_SESSION['login_time']) && (time() - $_SESSION['login_time'] > SESSION_TIMEOUT)) {
            kohaLogout();
            $returnUrl = urlencode('http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']);
            $kohaLoginUrl = KOHA_INTRANET_URL . '/cgi-bin/koha/mainpage.pl?return=' . $returnUrl;
            header("Location: $kohaLoginUrl");
            exit;
        }
        
        // Refresh permissions if missing or stale (every 5 min)
        if (!isset($_SESSION['koha_role']) || 
            empty($_SESSION['koha_role']) ||
            !isset($_SESSION['permissions_refreshed']) ||
            (time() - ($_SESSION['permissions_refreshed'] ?? 0) > 300)) {
            refreshKohaPermissions();
        }
        
        return;
    }

    // Attempt auto-login via Koha session cookie
    if (isset($_COOKIE['CGISESSID'])) {
        $borrowernumber = validateKohaSession($_COOKIE['CGISESSID']);
        if ($borrowernumber) {
            $koha = getKoha();
            if ($koha) {
                try {
                    $stmt = $koha->prepare("
                        SELECT 
                            borrowernumber,
                            cardnumber,
                            userid,
                            CONCAT(IFNULL(title,''), ' ', IFNULL(firstname,''), ' ', IFNULL(surname,'')) AS full_name,
                            categorycode,
                            branchcode,
                            email,
                            mobile,
                            dateexpiry
                        FROM borrowers
                        WHERE borrowernumber = ?
                    ");
                    $stmt->execute([$borrowernumber]);
                    $borrower = $stmt->fetch();
                    
                    if ($borrower) {
                        $_SESSION['koha_logged_in'] = true;
                        $_SESSION['koha_user_id'] = $borrower['borrowernumber'];
                        $_SESSION['koha_username'] = $borrower['cardnumber'] ?? $borrower['userid'] ?? '';
                        $_SESSION['koha_full_name'] = !empty(trim($borrower['full_name'])) ? $borrower['full_name'] : $_SESSION['koha_username'];
                        $_SESSION['koha_category'] = $borrower['categorycode'];
                        $_SESSION['koha_branch'] = $borrower['branchcode'];
                        $_SESSION['koha_email'] = $borrower['email'] ?? '';
                        $_SESSION['koha_mobile'] = $borrower['mobile'] ?? '';
                        $_SESSION['login_time'] = time();

                        // Load permissions with fallback
                        $_SESSION['koha_permissions'] = getKohaPermissions($borrower['borrowernumber']);
                        $_SESSION['koha_role'] = getKohaRole($borrower['borrowernumber']);
                        $_SESSION['permissions_refreshed'] = time();

                        // Load patron image
                        $imgStmt = $koha->prepare("SELECT imagefile FROM patronimage WHERE borrowernumber = ? LIMIT 1");
                        $imgStmt->execute([$borrower['borrowernumber']]);
                        $image = $imgStmt->fetch();
                        if ($image && !empty($image['imagefile'])) {
                            $_SESSION['koha_photo'] = 'data:image/jpeg;base64,' . base64_encode($image['imagefile']);
                        }

                        logActivity($borrower['borrowernumber'], 'AUTO_LOGIN', "Auto-login via Koha session");
                        return;
                    }
                } catch (PDOException $e) {
                    error_log("Auto-login error: " . $e->getMessage());
                }
            }
        }
    }

    // Redirect to Koha login
    $returnUrl = urlencode('http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']);
    $kohaLoginUrl = KOHA_INTRANET_URL . '/cgi-bin/koha/mainpage.pl?return=' . $returnUrl;
    header("Location: $kohaLoginUrl");
    exit;
}

function kohaLogout() {
    if (isKohaLoggedIn()) {
        logActivity($_SESSION['koha_user_id'] ?? 0, 'LOGOUT', "Koha user logged out");
    }
    destroySession();
    $kohaLogoutUrl = KOHA_INTRANET_URL . '/cgi-bin/koha/mainpage.pl?logout=1';
    header("Location: $kohaLogoutUrl");
    exit;
}

// ============================================================
// USER FUNCTIONS
// ============================================================
function getCurrentUser() {
    if (!isKohaLoggedIn()) return null;
    
    $fullName = $_SESSION['koha_full_name'] ?? '';
    if (empty(trim($fullName))) {
        $fullName = $_SESSION['koha_username'] ?? 'User';
    }
    
    return [
        'id' => $_SESSION['koha_user_id'] ?? null,
        'username' => $_SESSION['koha_username'] ?? '',
        'full_name' => $fullName,
        'category' => $_SESSION['koha_category'] ?? '',
        'branch' => $_SESSION['koha_branch'] ?? '',
        'role' => $_SESSION['koha_role'] ?? 'viewer',
        'email' => $_SESSION['koha_email'] ?? '',
        'mobile' => $_SESSION['koha_mobile'] ?? '',
        'photo' => $_SESSION['koha_photo'] ?? null,
        'permissions' => $_SESSION['koha_permissions'] ?? []
    ];
}

function hasKohaRole($requiredRole) {
    $levels = ['viewer' => 0, 'staff' => 1, 'cataloger' => 2, 'manager' => 3, 'admin' => 4];
    $currentRole = $_SESSION['koha_role'] ?? 'viewer';
    $currentLevel = $levels[$currentRole] ?? 0;
    $requiredLevel = $levels[$requiredRole] ?? 0;
    return $currentLevel >= $requiredLevel;
}

function requireKohaRole($requiredRole) {
    requireKohaLogin();
    
    // Force refresh if role is missing
    if (!isset($_SESSION['koha_role']) || empty($_SESSION['koha_role'])) {
        refreshKohaPermissions();
    }
    
    if (!hasKohaRole($requiredRole)) {
        // One more attempt at refreshing before denying
        refreshKohaPermissions();
        
        if (!hasKohaRole($requiredRole)) {
            http_response_code(403);
            $currentRole = $_SESSION['koha_role'] ?? 'viewer';
            $userId = $_SESSION['koha_user_id'] ?? 'unknown';
            $username = $_SESSION['koha_username'] ?? 'unknown';
            
            // Log the denial for diagnostics
            error_log("Access DENIED: user_id=$userId ($username), current_role=$currentRole, required=$requiredRole");
            
            // Show friendly error page
            echo '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Access Denied</title>';
            echo '<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">';
            echo '<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">';
            echo '<style>body{background:#f0f2f5;padding:40px;font-family:Inter,sans-serif;}';
            echo '.card{background:white;border-radius:20px;padding:40px;max-width:600px;margin:0 auto;text-align:center;box-shadow:0 8px 30px rgba(0,0,0,0.08);}';
            echo '.icon{font-size:4rem;color:#dc3545;margin-bottom:20px;}</style></head><body>';
            echo '<div class="card">';
            echo '<div class="icon"><i class="fas fa-lock"></i></div>';
            echo '<h2>Access Denied</h2>';
            echo '<p class="text-muted">You do not have permission to access this page.</p>';
            echo '<hr>';
            echo '<div class="text-start mb-3">';
            echo '<p><strong>Your account:</strong> ' . htmlspecialchars($username) . '</p>';
            echo '<p><strong>Your role:</strong> <span class="badge bg-secondary">' . htmlspecialchars($currentRole) . '</span></p>';
            echo '<p><strong>Required role:</strong> <span class="badge bg-primary">' . htmlspecialchars($requiredRole) . '</span></p>';
            echo '</div>';
            echo '<div class="alert alert-info text-start small">';
            echo '<strong><i class="fas fa-info-circle me-1"></i>How to fix:</strong>';
            echo '<ol class="mb-0 mt-2">';
            echo '<li>Run <code>admin_override.php</code> (if available) to force admin role</li>';
            echo '<li>Or ask your Koha administrator to grant your account the <code>superlibrarian</code> permission</li>';
            echo '<li>Or run this SQL in the Koha database:<br>';
            echo '<code>INSERT INTO user_permissions (borrowernumber, permission) VALUES (' . (int)$userId . ', \'superlibrarian\');</code></li>';
            echo '</ol>';
            echo '</div>';
            echo '<a href="dashboard.php" class="btn btn-primary"><i class="fas fa-arrow-left me-2"></i>Back to Dashboard</a>';
            echo '</div></body></html>';
            exit;
        }
    }
}
