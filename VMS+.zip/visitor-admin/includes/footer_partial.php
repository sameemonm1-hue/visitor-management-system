<?php
/**
 * Visitor Management System - Shared Footer Partial
 * Version: 8.0 – Single source of truth
 *
 * Used by:
 *   - All admin pages (dashboard.php, entries.php, ..., footer.php wrapper)
 *   - Public kiosk (index.php public side)
 *   - Feedback page
 *
 * Renders identical footer as the OPAC encrypted protected footer:
 *   - Logo left (or spacer)
 *   - Center text with ©, institution, rights, credit
 *   - Same visual language: dark blue gradient, yellow hover, underline animation
 *   - Same LinkedIn URL and text
 *
 * The actual tamper protection lives in `footer_protection.js` (loaded once).
 */

if (!function_exists('vms_render_footer')) {

    /**
     * Render the footer HTML.
     *
     * @param array $opts {
     *   'bg'         => CSS color for footer background (defaults to settings)
     *   'text_color' => CSS color for footer text (defaults to settings)
     *   'logo'       => data-URI of logo, or null to use settings logo
     *   'logo_height'=> CSS height for logo image (default '28px')
     *   'layout'     => 'full' | 'compact'   (default 'full')
     *   'extra'      => optional HTML to append after the credit
     * }
     */
    function vms_render_footer(array $opts = []): void
    {
        // ---------- Load settings safely ----------
        $settings = [];
        if (function_exists('getSettings')) {
            try { $settings = getSettings() ?: []; } catch (Throwable $e) { $settings = []; }
        }

        $institutionName = $settings['institution_name'] ?? 'Library';
        $footerBg        = $opts['bg']         ?? ($settings['footer_bg']         ?? '#1e3c72');
        $footerTextColor = $opts['text_color'] ?? ($settings['footer_text_color'] ?? '#ffffff');
        $footerText      = $settings['footer_text'] ?? '';
        $showFooterLogo  = (int)($settings['show_footer_logo'] ?? 1);
        $logoHeight      = $opts['logo_height'] ?? '28px';
        $layout          = $opts['layout'] ?? 'full';

        // ---------- Resolve logo (data URI) ----------
        $logo = $opts['logo'] ?? null;
        if ($logo === null && $showFooterLogo) {
            $logo = vms_resolve_footer_logo($settings);
        }

        // ---------- Languages ----------
        $t = function (string $key, string $fallback) {
            if (function_exists('__')) {
                $v = __($key);
                if ($v !== $key) return $v;
            }
            return $fallback;
        };

        // ---------- Signature (must match OPAC encrypted footer) ----------
        $DESIGNER_TEXT = 'Sameermon M';
        $DESIGNER_URL  = 'https://www.linkedin.com/in/sameermon-m-559692186';

        $footerId = 'vmsFooter_' . substr(md5(($opts['bg'] ?? '') . microtime()), 0, 6);

        ?>
        <footer class="vms-footer vms-footer--<?= htmlspecialchars($layout) ?>"
                id="<?= $footerId ?>"
                data-vms-footer="protected"
                style="--vms-footer-bg: <?= htmlspecialchars($footerBg) ?>; --vms-footer-color: <?= htmlspecialchars($footerTextColor) ?>;"
                oncontextmenu="return false;"
                onselectstart="return false;"
                ondragstart="return false;">
            <div class="vms-footer-inner">
                <?php if ($logo): ?>
                    <img src="<?= htmlspecialchars($logo) ?>"
                         alt="<?= htmlspecialchars($institutionName) ?>"
                         class="vms-footer-logo"
                         style="height:<?= htmlspecialchars($logoHeight) ?>;"
                         draggable="false">
                <?php else: ?>
                    <span class="vms-footer-spacer" aria-hidden="true"></span>
                <?php endif; ?>

                <div class="vms-footer-text">
                    <?php if (!empty($footerText)): ?>
                        <span><?= htmlspecialchars($footerText) ?></span>
                    <?php else: ?>
                        <span>&copy; <?= date('Y') ?> <strong><?= htmlspecialchars($institutionName) ?></strong></span>
                    <?php endif; ?>
                    <span class="vms-footer-sep">•</span>
                    <span><?= htmlspecialchars($t('all_rights_reserved', 'All rights reserved.')) ?></span>
                    <span class="vms-footer-sep">•</span>
                    <span class="vms-footer-credit">
                        <?= htmlspecialchars($t('designed_by', 'Designed by')) ?>
                        <a href="<?= htmlspecialchars($DESIGNER_URL) ?>"
                           target="_blank"
                           rel="noopener noreferrer"
                           class="vms-footer-link"
                           data-credit="sameermon"
                           title="<?= htmlspecialchars($DESIGNER_TEXT) ?> on LinkedIn"><?= htmlspecialchars($DESIGNER_TEXT) ?></a>
                    </span>
                    <?php if (!empty($opts['extra'])): ?>
                        <span class="vms-footer-sep">•</span>
                        <span><?= $opts['extra'] ?></span>
                    <?php endif; ?>
                </div>

                <span class="vms-footer-spacer" aria-hidden="true"></span>
            </div>
        </footer>
        <?php
    }

    /**
     * Resolve footer logo → data URI. Prefers `footer_logo`,
     * falls back to `institution_logo`, then `public_header_logo`.
     */
    function vms_resolve_footer_logo(array $settings): ?string
    {
        $baseDirs = [];
        if (defined('UPLOAD_PATH'))          $baseDirs[] = rtrim(UPLOAD_PATH, '/') . '/logos/';
        if (defined('ROOT_PATH'))            $baseDirs[] = rtrim(ROOT_PATH, '/')   . '/uploads/logos/';
        if (defined('VMS_INCLUDES'))         $baseDirs[] = rtrim(VMS_INCLUDES, '/') . '/../uploads/logos/';

        $candidates = ['footer_logo', 'institution_logo', 'public_header_logo'];
        foreach ($candidates as $key) {
            $file = $settings[$key] ?? '';
            if (empty($file)) continue;
            foreach ($baseDirs as $dir) {
                $path = $dir . $file;
                if (is_file($path)) {
                    $data = @file_get_contents($path);
                    if ($data !== false) {
                        $finfo = finfo_open(FILEINFO_MIME_TYPE);
                        $mime  = $finfo ? finfo_buffer($finfo, $data) : 'image/png';
                        if ($finfo) finfo_close($finfo);
                        return 'data:' . $mime . ';base64,' . base64_encode($data);
                    }
                }
            }
        }
        return null;
    }

    /**
     * Emit the shared footer CSS (idempotent).
     * Call once per page — safe to call multiple times.
     */
    function vms_footer_css(): void
    {
        static $emitted = false;
        if ($emitted) return;
        $emitted = true;
        ?>
        <style id="vms-shared-footer-css">
        .vms-footer {
            margin-top: 24px;
            padding: 10px 20px;
            border-radius: 16px;
            font-size: 0.76rem;
            line-height: 1.35;
            user-select: none;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            -webkit-touch-callout: none;
            background: var(--vms-footer-bg, #1e3c72);
            color: var(--vms-footer-color, #ffffff);
            position: relative;
            contain: layout style paint;
        }
        .vms-footer-inner {
            display: grid;
            grid-template-columns: 1fr auto 1fr;
            align-items: center;
            gap: 12px;
            max-width: 1500px;
            margin: 0 auto;
            min-height: 34px;
        }
        .vms-footer-logo {
            justify-self: start;
            width: auto;
            max-width: 180px;
            object-fit: contain;
            border-radius: 6px;
            pointer-events: none;
            -webkit-user-drag: none;
            user-drag: none;
            background: rgba(255, 255, 255, 0.08);
            padding: 2px 6px;
        }
        .vms-footer-spacer {
            display: block;
            width: 28px;
            height: 28px;
            justify-self: start;
        }
        .vms-footer-text {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            flex-wrap: wrap;
            text-align: center;
            justify-self: center;
            white-space: nowrap;
        }
        .vms-footer-text > span { display: inline-block; margin: 0; padding: 0; }
        .vms-footer-sep { opacity: 0.5; font-size: 0.7rem; }
        .vms-footer-credit { display: inline-flex; align-items: center; gap: 4px; }
        .vms-footer-link {
            color: #ffd700;
            text-decoration: none;
            font-weight: 700;
            padding: 0 2px;
            position: relative;
            transition: color 0.2s ease, text-shadow 0.2s ease;
        }
        .vms-footer-link:hover,
        .vms-footer-link:focus {
            color: #ffffff;
            text-shadow: 0 0 8px rgba(255, 215, 0, 0.6);
            outline: none;
        }
        .vms-footer-link::after {
            content: '';
            position: absolute;
            left: 2px;
            right: 2px;
            bottom: -1px;
            height: 1px;
            background: currentColor;
            transform: scaleX(0);
            transform-origin: center;
            transition: transform 0.25s ease;
        }
        .vms-footer-link:hover::after { transform: scaleX(1); }

        .vms-footer--compact { padding: 6px 14px; font-size: 0.68rem; }
        .vms-footer--compact .vms-footer-inner { gap: 8px; min-height: 26px; }
        .vms-footer--compact .vms-footer-logo { max-width: 120px; padding: 1px 4px; }

        @media (max-width: 768px) {
            .vms-footer { padding: 6px 14px; font-size: 0.65rem; }
            .vms-footer-inner { grid-template-columns: auto 1fr auto; gap: 8px; min-height: 28px; }
            .vms-footer-logo { max-width: 90px; }
            .vms-footer-text { gap: 5px; white-space: normal; font-size: 0.6rem; }
        }
        @media (max-width: 480px) {
            .vms-footer { padding: 5px 10px; font-size: 0.58rem; }
            .vms-footer-sep { display: none; }
            .vms-footer-text { flex-wrap: wrap; gap: 3px; }
            .vms-footer-spacer { display: none; }
            .vms-footer-inner { grid-template-columns: 1fr; }
            .vms-footer-logo { justify-self: center; margin-bottom: 4px; }
        }
        @media print {
            .vms-footer { background: #fff !important; color: #333 !important; border: 1px solid #ddd !important; }
            .vms-footer-link { color: #1e3c72 !important; }
        }
        </style>
        <?php
    }

    /**
     * Emit the shared footer protection script (idempotent).
     * NO setInterval — event-driven only.
     */
    function vms_footer_js(): void
    {
        static $emitted = false;
        if ($emitted) return;
        $emitted = true;
        ?>
        <script id="vms-shared-footer-js">
        (function () {
            'use strict';
            var SIGNATURE = Object.freeze({
                TEXT: 'Sameermon M',
                URL:  'https://www.linkedin.com/in/sameermon-m-559692186',
                REL:  'noopener noreferrer',
                TARGET: '_blank'
            });

            function isDrifted(link) {
                if (!link) return true;
                return link.getAttribute('href')   !== SIGNATURE.URL
                    || link.getAttribute('target') !== SIGNATURE.TARGET
                    || link.getAttribute('rel')    !== SIGNATURE.REL
                    || (link.textContent || '').trim() !== SIGNATURE.TEXT;
            }

            function repair(link) {
                link.setAttribute('href',   SIGNATURE.URL);
                link.setAttribute('target', SIGNATURE.TARGET);
                link.setAttribute('rel',    SIGNATURE.REL);
                if ((link.textContent || '').trim() !== SIGNATURE.TEXT) {
                    link.textContent = SIGNATURE.TEXT;
                }
                link.setAttribute('data-credit', 'sameermon');
            }

            function verifyOne(footer) {
                if (!footer) return;
                var link = footer.querySelector('.vms-footer-link');
                if (isDrifted(link)) repair(link);
            }

            function verifyAll() {
                var footers = document.querySelectorAll('[data-vms-footer="protected"]');
                for (var i = 0; i < footers.length; i++) verifyOne(footers[i]);
            }

            // ---- Attach one MutationObserver per footer (scoped) ----
            var observed = new WeakSet();
            function attach(footer) {
                if (!footer || observed.has(footer)) return;
                observed.add(footer);
                if (!window.MutationObserver) return;
                var mo = new MutationObserver(function () {
                    verifyOne(footer);
                });
                mo.observe(footer, {
                    childList: true, subtree: true,
                    attributes: true, attributeFilter: ['href', 'target', 'rel']
                });
                ['contextmenu','selectstart','dragstart','copy','cut'].forEach(function (ev) {
                    footer.addEventListener(ev, function (e) { e.preventDefault(); return false; }, true);
                });
            }

            function boot() {
                var footers = document.querySelectorAll('[data-vms-footer="protected"]');
                for (var i = 0; i < footers.length; i++) attach(footers[i]);
                verifyAll();
            }

            if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded', boot, { once: true });
            } else {
                boot();
            }

            // Repair only when tab regains focus or before print
            document.addEventListener('visibilitychange', function () {
                if (document.visibilityState === 'visible') verifyAll();
            });
            window.addEventListener('beforeprint', verifyAll);

            // Keyboard guards (light)
            document.addEventListener('keydown', function (e) {
                if (e.key === 'F12') { e.preventDefault(); return false; }
                if (e.ctrlKey && !e.shiftKey && !e.altKey &&
                    (e.key === 'u' || e.key === 'U')) { e.preventDefault(); return false; }
                if (e.ctrlKey && e.shiftKey &&
                    ['I','i','J','j','C','c'].indexOf(e.key) !== -1) {
                    e.preventDefault(); return false;
                }
            });

            try {
                Object.defineProperty(window, '__VMS_FOOTER_SIGNATURE__', {
                    value: SIGNATURE, writable: false, configurable: false
                });
            } catch (e) {}
        })();
        </script>
        <?php
    }
}
