<?php
/**
 * Visitor Management System — Database Connection
 * Version: 8.6 FINAL (collision-safe)
 *
 * CHANGELOG v8.6:
 *   • Class renamed to VMSDatabase to avoid collision with Koha's own Database class
 *   • Wrapped in class_exists() guard — safe to include twice
 *   • Global helper functions guarded with function_exists()
 *   • Two separate connections: VMS (main) + Koha
 *   • PDO persistent connections for reduced handshake overhead
 *   • Auto-reconnect on first-use if initial connect failed
 *   • Retry loop with backoff for transient failures
 *   • Koha failure is non-fatal (Koha is optional; VMS core still runs)
 *   • Fatal die() only if VMS main DB is unreachable
 *   • isKohaAvailable() helper for graceful feature degradation
 *   • reconnectDB() / reconnectKoha() for runtime recovery
 */

require_once __DIR__ . '/config.php';

// ============================================================
// VMS DATABASE SINGLETON
// ------------------------------------------------------------
// Named VMSDatabase (not Database) to avoid clashing with any
// Database class that Koha or other plugins may have defined.
// ============================================================
if (!class_exists('VMSDatabase', false)) {

    class VMSDatabase
    {
        /** @var VMSDatabase|null */
        private static $instance = null;

        /** @var PDO|null */
        private $connection = null;

        /** @var PDO|null */
        private $kohaConnection = null;

        /** @var bool */
        private $mainConnected = false;

        /** @var bool */
        private $kohaConnected = false;

        /** @var int */
        private $connectionAttempts = 0;

        /** @var int */
        private $maxConnectionAttempts = 3;

        // ============================================================
        // SINGLETON
        // ============================================================
        private function __construct()
        {
            $this->connectMain();
            $this->connectKoha();
        }

        public static function getInstance(): self
        {
            if (self::$instance === null) {
                self::$instance = new self();
            }
            return self::$instance;
        }

        // ============================================================
        // VMS MAIN DATABASE
        // ------------------------------------------------------------
        // The VMS DB is required for the app to run at all.
        // If this fails after N attempts, we hard-stop with a clear message.
        // ============================================================
        private function connectMain(): bool
        {
            $this->connectionAttempts = 0;

            while ($this->connectionAttempts < $this->maxConnectionAttempts) {
                try {
                    $dsn = sprintf(
                        "mysql:host=%s;dbname=%s;charset=%s",
                        DB_HOST, DB_NAME, DB_CHARSET
                    );

                    $this->connection = new PDO($dsn, DB_USER, DB_PASS, [
                        PDO::ATTR_ERRMODE               => PDO::ERRMODE_EXCEPTION,
                        PDO::ATTR_DEFAULT_FETCH_MODE    => PDO::FETCH_ASSOC,
                        PDO::ATTR_EMULATE_PREPARES      => false,
                        PDO::ATTR_PERSISTENT            => true,
                        PDO::ATTR_TIMEOUT               => 5,
                        PDO::MYSQL_ATTR_INIT_COMMAND    => "SET NAMES " . DB_CHARSET,
                    ]);

                    $this->mainConnected = true;
                    return true;

                } catch (PDOException $e) {
                    $this->connectionAttempts++;
                    error_log(
                        "VMS DB connection attempt {$this->connectionAttempts}/{$this->maxConnectionAttempts} failed: "
                        . $e->getMessage()
                    );

                    if ($this->connectionAttempts >= $this->maxConnectionAttempts) {
                        $this->mainConnected = false;
                        die(
                            "VMS database connection failed after {$this->maxConnectionAttempts} attempts. "
                            . "Check DB_HOST/DB_USER/DB_PASS/DB_NAME in includes/config.php. "
                            . "Last error: " . htmlspecialchars($e->getMessage(), ENT_QUOTES)
                        );
                    }

                    sleep(1);
                }
            }

            return false;
        }

        // ============================================================
        // KOHA DATABASE (optional)
        // ------------------------------------------------------------
        // Koha is optional — the VMS still runs if this fails, but
        // member/book lookups return null and pages that rely on Koha
        // degrade gracefully.
        // ============================================================
        private function connectKoha(): bool
        {
            if (!defined('KOHA_ENABLED') || !KOHA_ENABLED) {
                error_log("Koha integration disabled in config.");
                $this->kohaConnected = false;
                return false;
            }

            try {
                $dsn = sprintf(
                    "mysql:host=%s;dbname=%s;charset=%s",
                    KOHA_HOST, KOHA_DB, KOHA_CHARSET
                );

                $this->kohaConnection = new PDO($dsn, KOHA_USER, KOHA_PASS, [
                    PDO::ATTR_ERRMODE               => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE    => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES      => false,
                    PDO::ATTR_PERSISTENT            => true,
                    PDO::ATTR_TIMEOUT               => 5,
                    PDO::MYSQL_ATTR_INIT_COMMAND    => "SET NAMES " . KOHA_CHARSET,
                ]);

                $this->kohaConnected = true;
                return true;

            } catch (PDOException $e) {
                error_log("Koha DB connection failed (non-fatal): " . $e->getMessage());
                $this->kohaConnected = false;
                return false;
            }
        }

        // ============================================================
        // ACCESSORS
        // ============================================================
        public function getConnection(): ?PDO
        {
            if (!$this->mainConnected || $this->connection === null) {
                $this->connectMain();
            }
            return $this->connection;
        }

        public function getKohaConnection(): ?PDO
        {
            if (!$this->kohaConnected || $this->kohaConnection === null) {
                $this->connectKoha();
            }
            return $this->kohaConnected ? $this->kohaConnection : null;
        }

        public function isKohaConnected(): bool
        {
            return $this->kohaConnected && $this->kohaConnection !== null;
        }

        public function isMainConnected(): bool
        {
            return $this->mainConnected && $this->connection !== null;
        }

        // ============================================================
        // RECONNECT HELPERS (runtime recovery)
        // ============================================================
        public function reconnectMain(): bool
        {
            $this->mainConnected  = false;
            $this->connection     = null;
            return $this->connectMain();
        }

        public function reconnectKoha(): bool
        {
            $this->kohaConnected  = false;
            $this->kohaConnection = null;
            return $this->connectKoha();
        }
    }
}

// ============================================================
// GLOBAL HELPERS
// ------------------------------------------------------------
// Every helper is guarded with function_exists() so double
// inclusion of this file never triggers a redeclare error.
// ============================================================
if (!function_exists('getDB')) {
    function getDB(): ?PDO
    {
        return VMSDatabase::getInstance()->getConnection();
    }
}

if (!function_exists('getKoha')) {
    function getKoha(): ?PDO
    {
        return VMSDatabase::getInstance()->getKohaConnection();
    }
}

if (!function_exists('isKohaAvailable')) {
    function isKohaAvailable(): bool
    {
        return VMSDatabase::getInstance()->isKohaConnected();
    }
}

if (!function_exists('reconnectDB')) {
    function reconnectDB(): bool
    {
        return VMSDatabase::getInstance()->reconnectMain();
    }
}

if (!function_exists('reconnectKoha')) {
    function reconnectKoha(): bool
    {
        return VMSDatabase::getInstance()->reconnectKoha();
    }
}
