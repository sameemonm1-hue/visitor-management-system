<?php
/**
 * Visitor Management System - Core Functions
 * Version: 8.6 FINAL – Canonical core with Computer Uses purpose
 *
 * This is the ONE canonical core file. It contains:
 *   - Caching (memoized + file-based)
 *   - Settings helpers
 *   - Stats helpers
 *   - Activity logging
 *   - CSRF
 *   - Sanitization / date helpers
 *   - Purpose of Visit canonical list (7 options)
 */

require_once __DIR__ . '/db.php';

// ============================================================
// CACHE (File-based with in-request memoization)
// ============================================================
if (!isset($GLOBALS['__mem_cache'])) {
    $GLOBALS['__mem_cache'] = [];
}

function getCache($key) {
    if (isset($GLOBALS['__mem_cache'][$key])) {
        $entry = $GLOBALS['__mem_cache'][$key];
        if ((time() - $entry['time']) < CACHE_LIFETIME) {
            return $entry['data'];
        }
    }
    if (!CACHE_ENABLED) return null;

    $file = sys_get_temp_dir() . '/vms_cache_' . md5($key);
    if (file_exists($file)) {
        $age = time() - filemtime($file);
        if ($age < CACHE_LIFETIME) {
            $data = @unserialize(file_get_contents($file));
            $GLOBALS['__mem_cache'][$key] = ['data' => $data, 'time' => time()];
            return $data;
        }
    }
    return null;
}

function setCache($key, $data) {
    $GLOBALS['__mem_cache'][$key] = ['data' => $data, 'time' => time()];
    if (!CACHE_ENABLED) return false;
    $file = sys_get_temp_dir() . '/vms_cache_' . md5($key);
    return @file_put_contents($file, serialize($data)) !== false;
}

function clearCache($key = null) {
    if ($key) {
        unset($GLOBALS['__mem_cache'][$key]);
        $file = sys_get_temp_dir() . '/vms_cache_' . md5($key);
        if (file_exists($file)) @unlink($file);
        return true;
    }
    $GLOBALS['__mem_cache'] = [];
    $files = glob(sys_get_temp_dir() . '/vms_cache_*');
    if ($files) foreach ($files as $f) @unlink($f);
    return true;
}

// ============================================================
// CACHED QUERIES
// ============================================================
function getCachedStats($db) {
    $cacheKey = 'stats';
    $data = getCache($cacheKey);
    if ($data !== null) return $data;
    try {
        $data = [
            'inside'       => (int)$db->query("SELECT COUNT(*) FROM entry_exit_logs WHERE status = 'inside'")->fetchColumn(),
            'today'        => (int)$db->query("SELECT COUNT(*) FROM entry_exit_logs WHERE entry_date = CURDATE()")->fetchColumn(),
            'total'        => (int)$db->query("SELECT COUNT(*) FROM entry_exit_logs")->fetchColumn(),
            'exits'        => (int)$db->query("SELECT COUNT(*) FROM entry_exit_logs WHERE status = 'exited'")->fetchColumn(),
            'unauthorized' => (int)$db->query("SELECT COUNT(*) FROM book_exit_logs WHERE is_authorized = 0")->fetchColumn(),
            'guests'       => (int)$db->query("SELECT COUNT(*) FROM entry_exit_logs WHERE status = 'inside' AND entry_type = 'guest'")->fetchColumn(),
        ];
        setCache($cacheKey, $data);
        return $data;
    } catch (PDOException $e) {
        return ['inside'=>0,'today'=>0,'total'=>0,'exits'=>0,'unauthorized'=>0,'guests'=>0];
    }
}

function getCachedRecentActivity($db) {
    $cacheKey = 'recent_activity';
    $data = getCache($cacheKey);
    if ($data !== null) return $data;
    try {
        $data = $db->query("SELECT * FROM entry_exit_logs ORDER BY created_at DESC LIMIT 10")->fetchAll();
        setCache($cacheKey, $data);
        return $data;
    } catch (PDOException $e) { return []; }
}

function getSettings() {
    $cacheKey = 'settings_all';
    $cached = getCache($cacheKey);
    if ($cached !== null) return $cached;
    $db = getDB();
    try {
        $stmt = $db->query("SELECT * FROM settings LIMIT 1");
        $settings = $stmt->fetch();
        if (!$settings) {
            $db->exec("INSERT INTO settings (id) VALUES (1)");
            $settings = $db->query("SELECT * FROM settings LIMIT 1")->fetch();
        }
        setCache($cacheKey, $settings);
        return $settings;
    } catch (PDOException $e) {
        error_log("Error fetching settings: " . $e->getMessage());
        return [];
    }
}

function updateSettings($data) {
    $db = getDB();
    try {
        $existingColumns = $db->query("SHOW COLUMNS FROM settings")->fetchAll(PDO::FETCH_COLUMN);
        $sql = "UPDATE settings SET ";
        $fields = []; $params = [];
        foreach ($data as $key => $value) {
            if (in_array($key, $existingColumns)) {
                $fields[] = "$key = ?";
                $params[] = $value;
            }
        }
        if (empty($fields)) { error_log("updateSettings: no valid columns"); return false; }
        $sql .= implode(", ", $fields) . " WHERE id = 1";
        $result = $db->prepare($sql)->execute($params);
        clearCache('settings_all');
        clearCache();
        return $result;
    } catch (PDOException $e) {
        error_log("Error updating settings: " . $e->getMessage());
        return false;
    }
}

// ============================================================
// PUBLIC SETTINGS HELPERS
// ============================================================
function getPublicSetting($key, $default = null) {
    $settings = getSettings();
    return isset($settings[$key]) ? $settings[$key] : $default;
}

function getPublicHeaderLogo() {
    $settings = getSettings();
    $logoPath = $settings['public_header_logo'] ?? '';
    $uploadDir = __DIR__ . '/../uploads/logos/';
    if (!empty($logoPath) && file_exists($uploadDir . $logoPath)) {
        $data = @file_get_contents($uploadDir . $logoPath);
        if ($data !== false) {
            $finfo = finfo_open(FILEINFO_MIME_TYPE);
            $mime = finfo_buffer($finfo, $data);
            finfo_close($finfo);
            return 'data:' . $mime . ';base64,' . base64_encode($data);
        }
    }
    return null;
}

function getPublicHeaderBg() {
    $settings = getSettings();
    $bgPath = $settings['public_header_bg'] ?? '';
    $uploadDir = __DIR__ . '/../uploads/logos/';
    if (!empty($bgPath) && file_exists($uploadDir . $bgPath)) {
        $data = @file_get_contents($uploadDir . $bgPath);
        if ($data !== false) {
            $finfo = finfo_open(FILEINFO_MIME_TYPE);
            $mime = finfo_buffer($finfo, $data);
            finfo_close($finfo);
            return 'data:' . $mime . ';base64,' . base64_encode($data);
        }
    }
    return null;
}

function getInstitution() {
    $settings = getSettings();
    return [
        'name'        => $settings['institution_name']  ?? 'Library',
        'logo_path'   => $settings['institution_logo']  ?? '',
        'header_text' => $settings['header_text']       ?? 'Visitor Management',
        'tagline'     => $settings['tagline']           ?? 'Library Entry/Exit System',
    ];
}

function getInstitutionLogo() {
    $settings = getSettings();
    $logoPath = $settings['institution_logo'] ?? '';
    $uploadDir = __DIR__ . '/../uploads/logos/';
    if (!empty($logoPath) && file_exists($uploadDir . $logoPath)) {
        return getImageBase64($uploadDir . $logoPath);
    }
    if (file_exists($uploadDir . 'logo.png')) {
        return getImageBase64($uploadDir . 'logo.png');
    }
    return null;
}

// ============================================================
// STATS
// ============================================================
function getCurrentStats() {
    $db = getDB();
    try {
        $stats = [
            'inside' => (int)$db->query("SELECT COUNT(*) FROM entry_exit_logs WHERE status = 'inside'")->fetchColumn(),
            'today'  => (int)$db->query("SELECT COUNT(*) FROM entry_exit_logs WHERE entry_date = CURDATE()")->fetchColumn(),
            'total'  => (int)$db->query("SELECT COUNT(*) FROM entry_exit_logs")->fetchColumn(),
        ];
        $gender = $db->query("
            SELECT
                SUM(CASE WHEN member_category LIKE '%Male%'   AND member_category NOT LIKE '%Female%' THEN 1 ELSE 0 END) as male,
                SUM(CASE WHEN member_category LIKE '%Female%' THEN 1 ELSE 0 END) as female,
                SUM(CASE WHEN member_category NOT LIKE '%Male%' AND member_category NOT LIKE '%Female%' THEN 1 ELSE 0 END) as other
            FROM entry_exit_logs WHERE status = 'inside'
        ")->fetch();
        $stats['male']   = (int)($gender['male']   ?? 0);
        $stats['female'] = (int)($gender['female'] ?? 0);
        $stats['other']  = (int)($gender['other']  ?? 0);
        return $stats;
    } catch (PDOException $e) {
        return ['inside'=>0,'today'=>0,'total'=>0,'male'=>0,'female'=>0,'other'=>0];
    }
}

function getTodayEntries() {
    try {
        return (int)getDB()->query("SELECT COUNT(*) FROM entry_exit_logs WHERE entry_date = CURDATE()")->fetchColumn();
    } catch (PDOException $e) { return 0; }
}

function getUnauthorizedBookCount() {
    try {
        return (int)getDB()->query("SELECT COUNT(*) FROM book_exit_logs WHERE is_authorized = 0")->fetchColumn();
    } catch (PDOException $e) { return 0; }
}

function getRecentActivity($limit = 10) {
    try {
        $stmt = getDB()->prepare("SELECT * FROM entry_exit_logs ORDER BY created_at DESC LIMIT ?");
        $stmt->execute([$limit]);
        return $stmt->fetchAll();
    } catch (PDOException $e) { return []; }
}

function getPurposeStats() {
    try {
        return getDB()->query("
            SELECT purpose, COUNT(*) as count
            FROM entry_exit_logs
            WHERE entry_date = CURDATE()
            GROUP BY purpose ORDER BY count DESC
        ")->fetchAll();
    } catch (PDOException $e) { return []; }
}

function getHourlyActivity() {
    try {
        return getDB()->query("
            SELECT HOUR(entry_time) as hour, COUNT(*) as count
            FROM entry_exit_logs WHERE entry_date = CURDATE()
            GROUP BY hour ORDER BY hour
        ")->fetchAll();
    } catch (PDOException $e) { return []; }
}

// ============================================================
// LOGGING
// ============================================================
function logActivity($userId, $action, $details) {
    try {
        $stmt = getDB()->prepare("
            INSERT INTO activity_log (user_id, username, action, details, ip_address, user_agent)
            VALUES (?, ?, ?, ?, ?, ?)
        ");
        $username = $_SESSION['koha_username']   ?? 'System';
        $ip       = $_SERVER['REMOTE_ADDR']      ?? '';
        $ua       = $_SERVER['HTTP_USER_AGENT']  ?? '';
        return $stmt->execute([$userId, $username, $action, $details, $ip, $ua]);
    } catch (PDOException $e) {
        error_log("logActivity: " . $e->getMessage());
        return false;
    }
}

// ============================================================
// UTILITIES
// ============================================================
function getImageBase64($filePath) {
    if (empty($filePath) || !file_exists($filePath)) return null;
    $data = @file_get_contents($filePath);
    if ($data === false) return null;
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime  = finfo_buffer($finfo, $data);
    finfo_close($finfo);
    return 'data:' . $mime . ';base64,' . base64_encode($data);
}

function getDefaultAvatar() {
    $svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200" width="200" height="200">'
         . '<defs><linearGradient id="bgGrad" x1="0%" y1="0%" x2="100%" y2="100%">'
         . '<stop offset="0%" style="stop-color:#667eea;stop-opacity:1" />'
         . '<stop offset="100%" style="stop-color:#764ba2;stop-opacity:1" />'
         . '</linearGradient></defs>'
         . '<circle cx="100" cy="100" r="95" fill="url(#bgGrad)" />'
         . '<circle cx="70" cy="85" r="8" fill="white" />'
         . '<circle cx="130" cy="85" r="8" fill="white" />'
         . '<circle cx="72" cy="87" r="3" fill="#333" />'
         . '<circle cx="132" cy="87" r="3" fill="#333" />'
         . '<path d="M75 115 Q100 140 125 115" stroke="white" stroke-width="4" fill="none" />'
         . '<rect x="85" y="140" width="30" height="25" rx="3" fill="#ffd700" />'
         . '<line x1="100" y1="140" x2="100" y2="165" stroke="#fff" stroke-width="2" />'
         . '</svg>';
    return 'data:image/svg+xml;base64,' . base64_encode($svg);
}

function generateCSRFToken() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        $_SESSION['csrf_token_time'] = time();
    }
    return $_SESSION['csrf_token'];
}

function verifyCSRFToken($token) {
    if (empty($_SESSION['csrf_token']) || $token !== $_SESSION['csrf_token']) return false;
    if (time() - $_SESSION['csrf_token_time'] > 3600) return false;
    return true;
}

function formatDate($date, $format = 'd-m-Y') {
    if (empty($date) || $date === '0000-00-00') return '';
    try { return date($format, strtotime($date)); } catch (Exception $e) { return $date; }
}

function timeAgo($datetime) {
    $time = strtotime($datetime);
    $diff = time() - $time;
    if ($diff < 60)     return 'Just now';
    if ($diff < 3600)   return floor($diff / 60) . ' min ago';
    if ($diff < 86400)  return floor($diff / 3600) . ' hrs ago';
    if ($diff < 604800) return floor($diff / 86400) . ' days ago';
    return date('d M Y', $time);
}

function sanitizeInput($input) {
    if (is_array($input)) return array_map('sanitizeInput', $input);
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

function getRandomQuote() {
    $quotes = [
        ['text' => 'The only thing you absolutely have to know is the location of the library.', 'author' => 'Albert Einstein'],
        ['text' => 'Reading is to the mind what exercise is to the body.', 'author' => 'Joseph Addison'],
        ['text' => 'A library is a hospital for the mind.', 'author' => 'Unknown'],
        ['text' => 'Libraries store the energy that fuels the imagination.', 'author' => 'Sidney Sheldon'],
        ['text' => 'A book is a dream that you hold in your hand.', 'author' => 'Neil Gaiman'],
        ['text' => 'Libraries are not made; they grow.', 'author' => 'Augustine Birrell'],
        ['text' => 'Reading gives us someplace to go when we have to stay where we are.', 'author' => 'Mason Cooley'],
    ];
    return $quotes[array_rand($quotes)];
}

// ============================================================
// PURPOSE OF VISIT — Canonical list (single source of truth)
// ============================================================
if (!function_exists('getPurposeOptions')) {
    function getPurposeOptions(): array {
        return [
            'Reading/Study'     => ['icon' => '📚', 'label' => 'Reading/Study',     'i18n' => 'purpose_reading'],
            'Computer Uses'     => ['icon' => '💻', 'label' => 'Computer Uses',     'i18n' => 'purpose_computer_uses'],
            'Book Issue/Return' => ['icon' => '🔄', 'label' => 'Book Issue/Return', 'i18n' => 'purpose_issue_return'],
            'Research'          => ['icon' => '🔬', 'label' => 'Research',          'i18n' => 'purpose_research'],
            'Meeting'           => ['icon' => '👥', 'label' => 'Meeting',           'i18n' => 'purpose_meeting'],
            'Event'             => ['icon' => '🎉', 'label' => 'Event/Program',     'i18n' => 'purpose_event'],
            'Other'             => ['icon' => '📝', 'label' => 'Other',             'i18n' => 'purpose_other'],
        ];
    }
}

if (!function_exists('renderPurposeOptions')) {
    function renderPurposeOptions(?string $selected = null, string $lang = 'en'): string {
        $html = '';
        foreach (getPurposeOptions() as $value => $meta) {
            $translated = function_exists('__') ? __($meta['i18n'], $lang) : $meta['label'];
            if ($translated === $meta['i18n']) $translated = $meta['label'];
            $sel = ($selected === $value) ? ' selected' : '';
            $html .= sprintf(
                '<option value="%s"%s>%s %s</option>',
                htmlspecialchars($value, ENT_QUOTES, 'UTF-8'),
                $sel, $meta['icon'],
                htmlspecialchars($translated, ENT_QUOTES, 'UTF-8')
            );
        }
        return $html;
    }
}

if (!function_exists('vms_valid_purpose')) {
    function vms_valid_purpose(string $p): string {
        return array_key_exists($p, getPurposeOptions()) ? $p : 'Reading/Study';
    }
}
