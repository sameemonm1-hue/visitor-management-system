<?php
/**
 * Visitor Management System - Constants
 * Version: 7.3 FINAL – Complete
 */

// ============================================================
// PATHS
// ============================================================
if (!defined('ROOT_PATH')) define('ROOT_PATH', dirname(__DIR__));
if (!defined('INCLUDES_PATH')) define('INCLUDES_PATH', ROOT_PATH . '/includes');
if (!defined('UPLOAD_PATH')) define('UPLOAD_PATH', ROOT_PATH . '/uploads');
if (!defined('LOGS_PATH')) define('LOGS_PATH', ROOT_PATH . '/logs');

// ============================================================
// APPLICATION
// ============================================================
if (!defined('APP_NAME')) define('APP_NAME', 'Visitor Management System');
if (!defined('APP_VERSION')) define('APP_VERSION', '8.6.0');
if (!defined('APP_AUTHOR')) define('APP_AUTHOR', 'Sameermon');
if (!defined('APP_YEAR')) define('APP_YEAR', date('Y'));

// ============================================================
// DATE/TIME FORMATS
// ============================================================
if (!defined('DATE_FORMAT')) define('DATE_FORMAT', 'Y-m-d');
if (!defined('TIME_FORMAT')) define('TIME_FORMAT', 'H:i:s');
if (!defined('DATETIME_FORMAT')) define('DATETIME_FORMAT', 'Y-m-d H:i:s');
if (!defined('DISPLAY_DATE_FORMAT')) define('DISPLAY_DATE_FORMAT', 'd-m-Y');
if (!defined('DISPLAY_TIME_FORMAT')) define('DISPLAY_TIME_FORMAT', 'h:i:s A');
if (!defined('DISPLAY_DATETIME_FORMAT')) define('DISPLAY_DATETIME_FORMAT', 'd-m-Y h:i:s A');

// ============================================================
// DEFAULTS
// ============================================================
if (!defined('DEFAULT_LANGUAGE')) define('DEFAULT_LANGUAGE', 'en');
if (!defined('DEFAULT_PAGE_SIZE')) define('DEFAULT_PAGE_SIZE', 50);
if (!defined('DEFAULT_PURPOSE')) define('DEFAULT_PURPOSE', 'Reading/Study');
if (!defined('DEFAULT_TIMEZONE')) define('DEFAULT_TIMEZONE', 'Asia/Kolkata');

// ============================================================
// PUBLIC KIOSK DEFAULTS
// ============================================================
if (!defined('PUBLIC_HEADER_TITLE')) define('PUBLIC_HEADER_TITLE', 'Visitor Management System');
if (!defined('PUBLIC_HEADER_SUBTITLE')) define('PUBLIC_HEADER_SUBTITLE', 'Library Entry/Exit System');
if (!defined('PUBLIC_HEADER_BG_COLOR')) define('PUBLIC_HEADER_BG_COLOR', '#1e3c72');
if (!defined('PUBLIC_HEADER_TEXT_COLOR')) define('PUBLIC_HEADER_TEXT_COLOR', '#ffffff');
if (!defined('PUBLIC_HEADER_HEIGHT')) define('PUBLIC_HEADER_HEIGHT', '80px');
if (!defined('PUBLIC_HEADER_LAYOUT')) define('PUBLIC_HEADER_LAYOUT', 'centered');
if (!defined('PUBLIC_SHOW_HEADER_LOGO')) define('PUBLIC_SHOW_HEADER_LOGO', true);
if (!defined('PUBLIC_SHOW_INSTITUTION_NAME')) define('PUBLIC_SHOW_INSTITUTION_NAME', true);

// ============================================================
// KOHA TABLES
// ============================================================
if (!defined('KOHA_BORROWERS_TABLE')) define('KOHA_BORROWERS_TABLE', 'borrowers');
if (!defined('KOHA_ITEMS_TABLE')) define('KOHA_ITEMS_TABLE', 'items');
if (!defined('KOHA_ISSUES_TABLE')) define('KOHA_ISSUES_TABLE', 'issues');
if (!defined('KOHA_CATEGORIES_TABLE')) define('KOHA_CATEGORIES_TABLE', 'categories');
if (!defined('KOHA_BRANCHES_TABLE')) define('KOHA_BRANCHES_TABLE', 'branches');
if (!defined('KOHA_PATRON_IMAGE_TABLE')) define('KOHA_PATRON_IMAGE_TABLE', 'patronimage');
if (!defined('KOHA_USER_PERMISSIONS_TABLE')) define('KOHA_USER_PERMISSIONS_TABLE', 'user_permissions');
if (!defined('KOHA_SESSIONS_TABLE')) define('KOHA_SESSIONS_TABLE', 'sessions');

// ============================================================
// CACHE
// ============================================================
if (!defined('CACHE_ENABLED')) define('CACHE_ENABLED', true);
if (!defined('CACHE_LIFETIME')) define('CACHE_LIFETIME', 30);

// ============================================================
// ERROR MESSAGES
// ============================================================
if (!defined('ERROR_DB_CONNECTION')) define('ERROR_DB_CONNECTION', 'Database connection failed.');
if (!defined('ERROR_INVALID_CREDENTIALS')) define('ERROR_INVALID_CREDENTIALS', 'Invalid username or password.');
if (!defined('ERROR_ACCESS_DENIED')) define('ERROR_ACCESS_DENIED', 'Access denied.');
if (!defined('ERROR_SESSION_EXPIRED')) define('ERROR_SESSION_EXPIRED', 'Session expired.');
if (!defined('ERROR_MEMBER_NOT_FOUND')) define('ERROR_MEMBER_NOT_FOUND', 'Member not found in Koha.');

// ============================================================
// SUCCESS MESSAGES
// ============================================================
if (!defined('SUCCESS_SAVED')) define('SUCCESS_SAVED', 'Changes saved successfully.');
if (!defined('SUCCESS_DELETED')) define('SUCCESS_DELETED', 'Record deleted successfully.');
if (!defined('SUCCESS_ADDED')) define('SUCCESS_ADDED', 'Record added successfully.');
if (!defined('SUCCESS_UPDATED')) define('SUCCESS_UPDATED', 'Record updated successfully.');
?>
