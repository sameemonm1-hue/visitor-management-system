<?php
/**
 * Visitor Management System - Multi-Language Support
 * Version: 7.5 FINAL – Complete with 13 languages + Computer Uses purpose
 *                    + Guest name OPTIONAL support
 *
 * CHANGELOG v7.5 (from v7.4):
 *   ── NEW: 'optional'               — inline hint "(optional)"
 *   ── NEW: 'skip'                   — Skip button label
 *   ── NEW: 'guest_name'             — field label
 *   ── NEW: 'guest_name_prompt'      — modal help text
 *   ── NEW: 'guest_name_placeholder' — input placeholder
 *   ── NEW: 'guest_anonymous'        — tag shown on auto-named guests
 *   ── NEW: 'auto_named'             — "Anonymous guest" hint
 *   ── NEW: 'guest_rename'           — rename modal title
 *   ── NEW: 'save_name'              — save button label
 *   ── NEW: 'rename_guest'           — action label
 *   ── PRESERVED: All 13 languages, all v7.4 keys, the canonical
 *                 "Computer Uses" purpose, __() + helpers + flags.
 */

$LANGUAGES = array(
    'en' => 'English',
    'hi' => 'हिन्दी',
    'ar' => 'العربية',
    'ml' => 'മലയാളം',
    'ta' => 'தமிழ்',
    'te' => 'తెలుగు',
    'fr' => 'Français',
    'es' => 'Español',
    'de' => 'Deutsch',
    'pt' => 'Português',
    'ru' => 'Русский',
    'zh' => '中文',
    'ja' => '日本語'
);

$TRANSLATIONS = array(

    // ============================================================
    // ENGLISH - Complete
    // ============================================================
    'en' => array(
        // Application
        'app_name' => 'Visitor Management System',
        'title' => 'Visitor Kiosk',
        'version' => 'Version',
        'powered_by' => 'Powered by',
        'created_by' => 'Created by',
        'designed_by' => 'Designed by',
        'copyright' => 'Copyright',
        'all_rights_reserved' => 'All rights reserved.',

        // Header
        'welcome' => 'Welcome',
        'goodbye' => 'Goodbye',
        'to_library' => 'to Library',
        'welcome_message' => 'Welcome to the Library',
        'goodbye_message' => 'Thank you for visiting',
        'tagline' => 'Library Entry/Exit System',

        // Scanner
        'scan_prompt' => 'Scan your library ID or book barcode',
        'scan_placeholder' => 'Scan barcode here...',
        'scan_id' => 'Scan ID',
        'scan_book' => 'Scan Book',

        // Purpose
        'purpose_label' => 'Purpose of Visit',
        'purpose_reading' => 'Reading/Study',
        'purpose_computer_uses' => 'Computer Uses',
        'purpose_issue_return' => 'Book Issue/Return',
        'purpose_research' => 'Research',
        'purpose_meeting' => 'Meeting',
        'purpose_event' => 'Event/Program',
        'purpose_other' => 'Other',

        // Guest
        'guest_entry' => 'GUEST IN',
        'guest_exit' => 'GUEST OUT',
        'guest_entry_success' => 'Guest {num} entered successfully.',
        'guest_exit_success' => 'Guest exited successfully.',
        'no_active_guests' => 'No active guests to exit.',

        // Guest name (optional) — NEW v7.5
        'optional'               => 'optional',
        'skip'                   => 'Skip',
        'guest_name'             => 'Guest Name',
        'guest_name_prompt'      => 'You may enter your name, or skip to continue as an unnamed guest.',
        'guest_name_placeholder' => 'Your full name (optional)',
        'guest_anonymous'        => 'Anonymous guest',
        'auto_named'             => 'Anonymous guest',
        'guest_rename'           => 'Rename Guest',
        'save_name'              => 'Save Name',
        'rename_guest'           => 'Rename Guest',

        // Stats
        'currently_inside' => 'Currently Inside',
        'visitors_today' => 'Visitors Today',
        'male' => 'Male',
        'female' => 'Female',
        'other' => 'Other',
        'inside_by_category' => 'Inside by Category',
        'live_status' => 'Live Status',
        'today' => 'Today',
        'current_time' => 'Current Time',
        'total_visits' => 'Total Visits',
        'unique_members' => 'Unique Members',
        'total_inside' => 'Total Inside',
        'total_exited' => 'Total Exited',
        'guest_count' => 'Guest Count',
        'entry_count' => 'Entry Count',
        'exit_count' => 'Exit Count',
        'unauthorized_count' => 'Unauthorized Count',

        // Purpose Stats
        'purpose_distribution' => 'Purpose Distribution',
        'recent_activity' => 'Recent Activity',
        'recent_activity_empty' => 'No recent activity.',

        // Messages
        'entry_recorded' => 'Entry recorded successfully',
        'exit_recorded' => 'Exit recorded successfully',
        'operation_failed' => 'Operation failed',
        'network_error' => 'Network error. Please try again.',
        'valid_id' => 'Please enter a valid ID',
        'member_not_found' => 'Member not found in Koha. Please check the ID and try again.',
        'member_exited' => 'Member exited',
        'book_authorized' => 'Book is issued (authorized exit)',
        'book_unauthorized' => 'Book not issued – unauthorized exit!',
        'book_issued_to' => 'Issued to',

        // Navigation
        'dashboard' => 'Dashboard',
        'logs' => 'Entry/Exit Logs',
        'reports' => 'Reports',
        'books' => 'Book Exits',
        'settings' => 'Settings',
        'logout' => 'Logout',
        'admin_panel' => 'Admin Panel',
        'public_kiosk' => 'Public Kiosk',
        'entry_exit_system' => 'Entry/Exit System',

        // Actions
        'action' => 'Action',
        'search' => 'Search',
        'reset' => 'Reset',
        'save' => 'Save',
        'cancel' => 'Cancel',
        'delete' => 'Delete',
        'edit' => 'Edit',
        'view' => 'View',
        'print' => 'Print',
        'export' => 'Export',
        'import' => 'Import',
        'sync' => 'Sync',
        'backup' => 'Backup',
        'restore' => 'Restore',
        'confirm' => 'Confirm',
        'yes' => 'Yes',
        'no' => 'No',
        'refresh' => 'Refresh',
        'clear' => 'Clear',
        'apply' => 'Apply',
        'filter' => 'Filter',
        'continue' => 'Continue',

        // Status
        'status' => 'Status',
        'success' => 'Success',
        'error' => 'Error',
        'warning' => 'Warning',
        'info' => 'Information',
        'loading' => 'Loading...',
        'processing' => 'Processing...',
        'please_wait' => 'Please wait...',
        'online' => 'Online',
        'offline' => 'Offline',
        'maintenance' => 'Maintenance Mode',

        // Entry/Exit
        'member_id' => 'Member ID',
        'member_name' => 'Member Name',
        'member_category' => 'Member Category',
        'purpose' => 'Purpose',
        'entry_time' => 'Entry Time',
        'exit_time' => 'Exit Time',
        'duration' => 'Duration',
        'force_exit' => 'Force Exit',
        'normal_exit' => 'Normal Exit',

        // Library
        'library_hours' => 'Library Hours',
        'open_days' => 'Open Days',
        'hours' => 'Hours',

        // Quote
        'quote_of_the_day' => 'Quote of the Day',
        'refresh_quote' => 'Refresh Quote',
        'quote_author_unknown' => 'Unknown',

        // Cover Flow
        'cover_flow' => 'New Arrivals',
        'book_details' => 'Book Details',
        'available' => 'Available',
        'issued' => 'Issued',
        'view_details' => 'View Details',
        'no_books' => 'No new arrivals available',
        'book_title' => 'Title',
        'book_author' => 'Author',
        'book_isbn' => 'ISBN',
        'book_publisher' => 'Publisher',
        'book_year' => 'Year',
        'book_status' => 'Status',
        'book_copies' => 'Copies',

        // Security
        'access_denied' => 'Access denied. You do not have permission to view this page.',
        'session_expired' => 'Your session has expired. Please login again.',
        'invalid_input' => 'Invalid input. Please check your entries.',
        'required_field' => 'This field is required.',
        'record_not_found' => 'Record not found.',

        // System
        'system_status' => 'System Status',
        'system_actions' => 'System Actions',
        'clear_logs' => 'Clear Logs',
        'optimize_db' => 'Optimize Database',
        'clear_cache' => 'Clear Cache',
        'reset_settings' => 'Reset Settings',
        'maintenance_mode' => 'Maintenance Mode',
        'debug_mode' => 'Debug Mode',
        'select_language' => 'Select Language',

        // Notifications
        'entry_success' => 'Entry recorded successfully',
        'exit_success' => 'Exit recorded successfully',
        'save_success' => 'Saved successfully!',
        'delete_success' => 'Deleted successfully!',
        'update_success' => 'Updated successfully!',
        'error_occurred' => 'An error occurred. Please try again.',
        'processing_request' => 'Processing your request...',
        'confirm_delete' => 'Are you sure you want to delete this record?',
        'confirm_action' => 'Are you sure you want to perform this action?',
        'no_records' => 'No records found.',
        'loading_data' => 'Loading data...',
        'search_results' => 'Search Results',
        'filter_results' => 'Filter Results',
        'clear_filters' => 'Clear Filters',
        'apply_filters' => 'Apply Filters',
        'export_data' => 'Export Data',
        'import_data' => 'Import Data',
        'backup_data' => 'Backup Data',
        'restore_data' => 'Restore Data',

        // Admin Settings
        'public_settings' => 'Public Kiosk Settings',
        'admin_settings' => 'Admin Panel Settings',
        'general_settings' => 'General Settings',
        'appearance_settings' => 'Appearance Settings',
        'guest_settings' => 'Guest Settings',
        'entry_exit_settings' => 'Entry/Exit Settings',
        'book_settings' => 'Book Settings',
        'report_settings' => 'Report Settings',
        'notification_settings' => 'Notification Settings',
        'security_settings' => 'Security Settings',
        'maintenance_settings' => 'Maintenance Settings',

        // Public Header Settings
        'public_header_title' => 'Public Header Title',
        'public_header_subtitle' => 'Public Header Subtitle',
        'public_header_logo' => 'Public Header Logo',
        'public_header_bg' => 'Public Header Background',
        'public_header_bg_color' => 'Background Color',
        'public_header_text_color' => 'Text Color',
        'public_header_height' => 'Header Height',
        'public_header_layout' => 'Header Layout',
        'public_show_header_logo' => 'Show Header Logo',
        'public_show_institution_name' => 'Show Institution Name',

        // Institution
        'institution_name' => 'Institution Name',
        'institution_short_name' => 'Short Name',
        'institution_address' => 'Address',
        'institution_phone' => 'Phone',
        'institution_email' => 'Email',
        'institution_website' => 'Website',
        'institution_city' => 'City',
        'institution_state' => 'State',
        'institution_country' => 'Country',
        'institution_pin' => 'PIN Code',
        'institution_logo' => 'Institution Logo',
    ),

    // ============================================================
    // HINDI - हिन्दी
    // ============================================================
    'hi' => array(
        'app_name' => 'आगंतुक प्रबंधन प्रणाली',
        'title' => 'आगंतुक कियोस्क',
        'scan_prompt' => 'अपना पुस्तकालय आईडी या पुस्तक बारकोड स्कैन करें',
        'scan_placeholder' => 'बारकोड यहां स्कैन करें...',
        'purpose_label' => 'यात्रा का उद्देश्य',
        'purpose_reading' => 'पठन/अध्ययन',
        'purpose_computer_uses' => 'कंप्यूटर उपयोग',
        'purpose_issue_return' => 'पुस्तक जारी/वापसी',
        'purpose_research' => 'शोध',
        'purpose_meeting' => 'बैठक',
        'purpose_event' => 'कार्यक्रम',
        'purpose_other' => 'अन्य',
        'guest_entry' => 'अतिथि प्रवेश',
        'guest_exit' => 'अतिथि निकास',
        'currently_inside' => 'वर्तमान में अंदर',
        'visitors_today' => 'आज के आगंतुक',
        'male' => 'पुरुष',
        'female' => 'महिला',
        'other' => 'अन्य',
        'inside_by_category' => 'श्रेणी के अनुसार अंदर',
        'recent_activity' => 'हाल की गतिविधि',
        'purpose_distribution' => 'उद्देश्य वितरण',
        'entry_recorded' => 'प्रवेश सफलतापूर्वक दर्ज किया गया',
        'exit_recorded' => 'निकास सफलतापूर्वक दर्ज किया गया',
        'operation_failed' => 'कार्य विफल',
        'network_error' => 'नेटवर्क त्रुटि। कृपया पुनः प्रयास करें।',
        'book_authorized' => 'पुस्तक जारी है (अधिकृत निकास)',
        'book_unauthorized' => 'पुस्तक जारी नहीं है - अनधिकृत निकास!',
        'book_issued_to' => 'को जारी किया गया',
        'member_exited' => 'सदस्य निकास किया',
        'valid_id' => 'कृपया एक वैध आईडी दर्ज करें',
        'today' => 'आज',
        'current_time' => 'वर्तमान समय',
        'library_hours' => 'पुस्तकालय समय',
        'open_days' => 'खुले दिन',
        'hours' => 'घंटे',
        'quote_of_the_day' => 'आज का सुविचार',
        'refresh_quote' => 'सुविचार ताज़ा करें',
        'quote_author_unknown' => 'अज्ञात',
        'dashboard' => 'डैशबोर्ड',
        'logs' => 'प्रवेश/निकास लॉग',
        'reports' => 'रिपोर्ट',
        'books' => 'पुस्तक निकास',
        'settings' => 'सेटिंग्स',
        'logout' => 'लॉगआउट',
        'all_rights_reserved' => 'सभी अधिकार सुरक्षित।',
        'designed_by' => 'द्वारा डिज़ाइन किया गया',
        'welcome' => 'स्वागत है',
        'goodbye' => 'अलविदा',
        'to_library' => 'पुस्तकालय में',
        'loading' => 'लोड हो रहा है...',
        'processing' => 'प्रक्रिया जारी...',
        'please_wait' => 'कृपया प्रतीक्षा करें...',
        'refresh' => 'ताज़ा करें',
        'status' => 'स्थिति',
        'member_not_found' => 'कोहा में सदस्य नहीं मिला। कृपया आईडी जांचें और पुनः प्रयास करें।',
        'no_active_guests' => 'निकास के लिए कोई सक्रिय अतिथि नहीं।',
        'guest_entry_success' => 'अतिथि {num} सफलतापूर्वक प्रवेश किया।',
        'guest_exit_success' => 'अतिथि सफलतापूर्वक निकास किया।',
        'visitor_log' => 'आगंतुक लॉग',
        'live_status' => 'लाइव स्थिति',
        'recent_activity_empty' => 'कोई हालिया गतिविधि नहीं।',
        'admin_panel' => 'व्यवस्थापक पैनल',
        'public_kiosk' => 'सार्वजनिक कियोस्क',
        'entry_exit_system' => 'प्रवेश/निकास प्रणाली',
        'scan_id' => 'आईडी स्कैन करें',
        'scan_book' => 'पुस्तक स्कैन करें',
        'member_id' => 'सदस्य आईडी',
        'member_name' => 'सदस्य का नाम',
        'member_category' => 'सदस्य श्रेणी',
        'purpose' => 'उद्देश्य',
        'entry_time' => 'प्रवेश समय',
        'exit_time' => 'निकास समय',
        'duration' => 'अवधि',
        'action' => 'कार्रवाई',
        'search' => 'खोजें',
        'reset' => 'रीसेट',
        'save' => 'सहेजें',
        'cancel' => 'रद्द करें',
        'delete' => 'हटाएं',
        'edit' => 'संपादित करें',
        'view' => 'देखें',
        'print' => 'प्रिंट करें',
        'export' => 'निर्यात करें',
        'import' => 'आयात करें',
        'sync' => 'सिंक करें',
        'backup' => 'बैकअप',
        'restore' => 'पुनर्स्थापित करें',
        'confirm' => 'पुष्टि करें',
        'yes' => 'हाँ',
        'no' => 'नहीं',
        'success' => 'सफलता',
        'error' => 'त्रुटि',
        'warning' => 'चेतावनी',
        'info' => 'जानकारी',
        'total_visits' => 'कुल दौरे',
        'unique_members' => 'अद्वितीय सदस्य',
        'unauthorized_books' => 'अनधिकृत पुस्तकें',
        'active_guests' => 'सक्रिय अतिथि',
        'force_exit' => 'बलपूर्वक निकास',
        'normal_exit' => 'सामान्य निकास',
        'clear_logs' => 'लॉग साफ़ करें',
        'optimize_db' => 'डेटाबेस अनुकूलित करें',
        'clear_cache' => 'कैश साफ़ करें',
        'reset_settings' => 'सेटिंग्स रीसेट करें',
        'maintenance_mode' => 'रखरखाव मोड',
        'debug_mode' => 'डीबग मोड',
        'system_actions' => 'सिस्टम क्रियाएँ',
        'cover_flow' => 'नई आगमन',
        'book_details' => 'पुस्तक विवरण',
        'available' => 'उपलब्ध',
        'issued' => 'जारी',
        'view_details' => 'विवरण देखें',
        'no_books' => 'कोई नई पुस्तकें उपलब्ध नहीं',
        'book_title' => 'शीर्षक',
        'book_author' => 'लेखक',
        'book_isbn' => 'आईएसबीएन',
        'book_publisher' => 'प्रकाशक',
        'book_year' => 'वर्ष',
        'book_status' => 'स्थिति',
        'book_copies' => 'प्रतियाँ',
        'today_visits' => 'आज के दौरे',
        'total_inside' => 'कुल अंदर',
        'total_exited' => 'कुल बाहर',
        'guest_count' => 'अतिथि गणना',
        'entry_count' => 'प्रवेश गणना',
        'exit_count' => 'निकास गणना',
        'unauthorized_count' => 'अनधिकृत गणना',
        'select_language' => 'भाषा चुनें',
        'welcome_message' => 'पुस्तकालय में आपका स्वागत है',
        'goodbye_message' => 'आने के लिए धन्यवाद',
        'entry_success' => 'प्रवेश सफलतापूर्वक दर्ज किया गया',
        'exit_success' => 'निकास सफलतापूर्वक दर्ज किया गया',
        'processing_request' => 'आपका अनुरोध संसाधित किया जा रहा है...',
        'error_occurred' => 'एक त्रुटि हुई। कृपया पुनः प्रयास करें।',
        'session_expired' => 'आपका सत्र समाप्त हो गया है। कृपया फिर से लॉगिन करें।',
        'access_denied' => 'पहुंच अस्वीकृत। आपको इस पृष्ठ को देखने की अनुमति नहीं है।',
        'record_not_found' => 'रिकॉर्ड नहीं मिला।',
        'invalid_input' => 'अमान्य इनपुट। कृपया अपनी प्रविष्टियाँ जांचें।',
        'required_field' => 'यह फ़ील्ड आवश्यक है।',
        'save_success' => 'सफलतापूर्वक सहेजा गया!',
        'delete_success' => 'सफलतापूर्वक हटा दिया गया!',
        'update_success' => 'सफलतापूर्वक अद्यतन किया गया!',
        'confirm_delete' => 'क्या आप इस रिकॉर्ड को हटाना चाहते हैं?',
        'confirm_action' => 'क्या आप यह कार्रवाई करना चाहते हैं?',
        'no_records' => 'कोई रिकॉर्ड नहीं मिला।',
        'loading_data' => 'डेटा लोड हो रहा है...',
        'search_results' => 'खोज परिणाम',
        'filter_results' => 'परिणाम फ़िल्टर करें',
        'clear_filters' => 'फ़िल्टर साफ़ करें',
        'apply_filters' => 'फ़िल्टर लागू करें',
        'export_data' => 'डेटा निर्यात करें',
        'import_data' => 'डेटा आयात करें',
        'backup_data' => 'डेटा बैकअप',
        'restore_data' => 'डेटा पुनर्स्थापित करें',
        'system_status' => 'सिस्टम स्थिति',
        'online' => 'ऑनलाइन',
        'offline' => 'ऑफलाइन',
        'maintenance' => 'रखरखाव मोड',
        'version' => 'संस्करण',
        'copyright' => 'कॉपीराइट',
        'all_rights' => 'सभी अधिकार सुरक्षित',
        'powered_by' => 'द्वारा संचालित',
        'created_by' => 'द्वारा निर्मित',
        'public_settings' => 'सार्वजनिक कियोस्क सेटिंग्स',
        'admin_settings' => 'व्यवस्थापक पैनल सेटिंग्स',
        'public_header_title' => 'सार्वजनिक हेडर शीर्षक',
        'public_header_subtitle' => 'सार्वजनिक हेडर उपशीर्षक',
        'public_header_logo' => 'सार्वजनिक हेडर लोगो',
        'public_header_bg' => 'सार्वजनिक हेडर पृष्ठभूमि',
        'institution_name' => 'संस्थान का नाम',

        // v7.5 — Guest name optional
        'optional'               => 'वैकल्पिक',
        'skip'                   => 'छोड़ें',
        'continue'               => 'जारी रखें',
        'guest_name'             => 'अतिथि का नाम',
        'guest_name_prompt'      => 'आप अपना नाम दर्ज कर सकते हैं, या अनाम अतिथि के रूप में जारी रखने के लिए छोड़ें।',
        'guest_name_placeholder' => 'आपका पूरा नाम (वैकल्पिक)',
        'guest_anonymous'        => 'अनाम अतिथि',
        'auto_named'             => 'अनाम अतिथि',
        'guest_rename'           => 'अतिथि का नाम बदलें',
        'save_name'              => 'नाम सहेजें',
        'rename_guest'           => 'अतिथि का नाम बदलें',
    ),

    // ============================================================
    // ARABIC - العربية
    // ============================================================
    'ar' => array(
        'app_name' => 'نظام إدارة الزوار',
        'title' => 'كشك الزوار',
        'scan_prompt' => 'امسح معرف المكتبة أو الباركود الخاص بالكتاب',
        'scan_placeholder' => 'امسح الباركود هنا...',
        'purpose_label' => 'الغرض من الزيارة',
        'purpose_reading' => 'قراءة/دراسة',
        'purpose_computer_uses' => 'استخدام الكمبيوتر',
        'purpose_issue_return' => 'إعارة/إرجاع كتاب',
        'purpose_research' => 'بحث',
        'purpose_meeting' => 'اجتماع',
        'purpose_event' => 'فعالية/برنامج',
        'purpose_other' => 'أخرى',
        'guest_entry' => 'دخول ضيف',
        'guest_exit' => 'خروج ضيف',
        'currently_inside' => 'داخل حالياً',
        'visitors_today' => 'زوار اليوم',
        'male' => 'ذكر',
        'female' => 'أنثى',
        'other' => 'أخرى',
        'inside_by_category' => 'داخل حسب الفئة',
        'recent_activity' => 'النشاط الأخير',
        'purpose_distribution' => 'توزيع الأغراض',
        'entry_recorded' => 'تم تسجيل الدخول بنجاح',
        'exit_recorded' => 'تم تسجيل الخروج بنجاح',
        'operation_failed' => 'فشلت العملية',
        'network_error' => 'خطأ في الشبكة. يرجى المحاولة مرة أخرى.',
        'book_authorized' => 'الكتاب مستعار (خروج مصرح به)',
        'book_unauthorized' => 'الكتاب غير مستعار – خروج غير مصرح به!',
        'book_issued_to' => 'مستعار لـ',
        'member_exited' => 'خرج العضو',
        'valid_id' => 'يرجى إدخال معرف صحيح',
        'today' => 'اليوم',
        'current_time' => 'الوقت الحالي',
        'library_hours' => 'ساعات المكتبة',
        'open_days' => 'أيام العمل',
        'hours' => 'ساعات',
        'quote_of_the_day' => 'اقتباس اليوم',
        'refresh_quote' => 'تحديث الاقتباس',
        'quote_author_unknown' => 'غير معروف',
        'dashboard' => 'لوحة التحكم',
        'logs' => 'سجلات الدخول/الخروج',
        'reports' => 'التقارير',
        'books' => 'خروج الكتب',
        'settings' => 'الإعدادات',
        'logout' => 'تسجيل الخروج',
        'all_rights_reserved' => 'جميع الحقوق محفوظة.',
        'designed_by' => 'صمم بواسطة',
        'welcome' => 'مرحباً',
        'goodbye' => 'مع السلامة',
        'to_library' => 'إلى المكتبة',
        'loading' => 'جار التحميل...',
        'processing' => 'جار المعالجة...',
        'please_wait' => 'يرجى الانتظار...',
        'refresh' => 'تحديث',
        'status' => 'الحالة',
        'member_not_found' => 'العضو غير موجود في كوها. يرجى التحقق من المعرف والمحاولة مرة أخرى.',
        'no_active_guests' => 'لا يوجد ضيوف نشطون للخروج.',
        'guest_entry_success' => 'دخل الضيف {num} بنجاح.',
        'guest_exit_success' => 'خرج الضيف بنجاح.',
        'visitor_log' => 'سجل الزوار',
        'live_status' => 'الحالة المباشرة',
        'recent_activity_empty' => 'لا يوجد نشاط حديث.',
        'admin_panel' => 'لوحة الإدارة',
        'public_kiosk' => 'الكشك العام',
        'entry_exit_system' => 'نظام الدخول/الخروج',
        'scan_id' => 'مسح المعرف',
        'scan_book' => 'مسح الكتاب',
        'member_id' => 'معرف العضو',
        'member_name' => 'اسم العضو',
        'member_category' => 'فئة العضو',
        'purpose' => 'الغرض',
        'entry_time' => 'وقت الدخول',
        'exit_time' => 'وقت الخروج',
        'duration' => 'المدة',
        'action' => 'الإجراء',
        'search' => 'بحث',
        'reset' => 'إعادة تعيين',
        'save' => 'حفظ',
        'cancel' => 'إلغاء',
        'delete' => 'حذف',
        'edit' => 'تعديل',
        'view' => 'عرض',
        'print' => 'طباعة',
        'export' => 'تصدير',
        'import' => 'استيراد',
        'sync' => 'مزامنة',
        'backup' => 'نسخ احتياطي',
        'restore' => 'استعادة',
        'confirm' => 'تأكيد',
        'yes' => 'نعم',
        'no' => 'لا',
        'success' => 'نجاح',
        'error' => 'خطأ',
        'warning' => 'تحذير',
        'info' => 'معلومات',
        'total_visits' => 'إجمالي الزيارات',
        'unique_members' => 'الأعضاء الفريدون',
        'unauthorized_books' => 'الكتب غير المصرح بها',
        'active_guests' => 'الضيوف النشطون',
        'force_exit' => 'خروج إجباري',
        'normal_exit' => 'خروج عادي',
        'clear_logs' => 'مسح السجلات',
        'optimize_db' => 'تحسين قاعدة البيانات',
        'clear_cache' => 'مسح الذاكرة المؤقتة',
        'reset_settings' => 'إعادة تعيين الإعدادات',
        'maintenance_mode' => 'وضع الصيانة',
        'debug_mode' => 'وضع التصحيح',
        'system_actions' => 'إجراءات النظام',
        'cover_flow' => 'الوافدون الجدد',
        'book_details' => 'تفاصيل الكتاب',
        'available' => 'متاح',
        'issued' => 'مستعار',
        'view_details' => 'عرض التفاصيل',
        'no_books' => 'لا توجد كتب جديدة متاحة',
        'book_title' => 'العنوان',
        'book_author' => 'المؤلف',
        'book_isbn' => 'ردمك',
        'book_publisher' => 'الناشر',
        'book_year' => 'السنة',
        'book_status' => 'الحالة',
        'book_copies' => 'النسخ',
        'today_visits' => 'زيارات اليوم',
        'total_inside' => 'إجمالي الداخل',
        'total_exited' => 'إجمالي الخارج',
        'guest_count' => 'عدد الضيوف',
        'entry_count' => 'عدد الدخول',
        'exit_count' => 'عدد الخروج',
        'unauthorized_count' => 'عدد غير المصرح به',
        'select_language' => 'اختر اللغة',
        'welcome_message' => 'مرحباً بكم في المكتبة',
        'goodbye_message' => 'شكراً لزيارتكم',
        'entry_success' => 'تم تسجيل الدخول بنجاح',
        'exit_success' => 'تم تسجيل الخروج بنجاح',
        'processing_request' => 'جاري معالجة طلبك...',
        'error_occurred' => 'حدث خطأ. يرجى المحاولة مرة أخرى.',
        'session_expired' => 'انتهت جلستك. يرجى تسجيل الدخول مرة أخرى.',
        'access_denied' => 'تم رفض الوصول. ليس لديك صلاحية لعرض هذه الصفحة.',
        'record_not_found' => 'السجل غير موجود.',
        'invalid_input' => 'إدخال غير صحيح. يرجى التحقق من مدخلاتك.',
        'required_field' => 'هذا الحقل مطلوب.',
        'save_success' => 'تم الحفظ بنجاح!',
        'delete_success' => 'تم الحذف بنجاح!',
        'update_success' => 'تم التحديث بنجاح!',
        'confirm_delete' => 'هل أنت متأكد من حذف هذا السجل؟',
        'confirm_action' => 'هل أنت متأكد من تنفيذ هذا الإجراء؟',
        'no_records' => 'لا توجد سجلات.',
        'loading_data' => 'جاري تحميل البيانات...',
        'search_results' => 'نتائج البحث',
        'filter_results' => 'تصفية النتائج',
        'clear_filters' => 'مسح الفلاتر',
        'apply_filters' => 'تطبيق الفلاتر',
        'export_data' => 'تصدير البيانات',
        'import_data' => 'استيراد البيانات',
        'backup_data' => 'نسخ احتياطي للبيانات',
        'restore_data' => 'استعادة البيانات',
        'system_status' => 'حالة النظام',
        'online' => 'متصل',
        'offline' => 'غير متصل',
        'maintenance' => 'وضع الصيانة',
        'version' => 'الإصدار',
        'copyright' => 'حقوق النشر',
        'all_rights' => 'جميع الحقوق محفوظة',
        'powered_by' => 'مدعوم من',
        'created_by' => 'تم إنشاؤه بواسطة',

        // v7.5 — Guest name optional
        'optional'               => 'اختياري',
        'skip'                   => 'تخطي',
        'continue'               => 'متابعة',
        'guest_name'             => 'اسم الضيف',
        'guest_name_prompt'      => 'يمكنك إدخال اسمك، أو التخطي للمتابعة كضيف مجهول.',
        'guest_name_placeholder' => 'اسمك الكامل (اختياري)',
        'guest_anonymous'        => 'ضيف مجهول',
        'auto_named'             => 'ضيف مجهول',
        'guest_rename'           => 'إعادة تسمية الضيف',
        'save_name'              => 'حفظ الاسم',
        'rename_guest'           => 'إعادة تسمية الضيف',
    ),

    // ============================================================
    // MALAYALAM
    // ============================================================
    'ml' => array(
        'app_name' => 'സന്ദർശക മാനേജ്മെന്റ് സിസ്റ്റം',
        'title' => 'സന്ദർശക കിയോസ്ക്',
        'purpose_computer_uses' => 'കമ്പ്യൂട്ടർ ഉപയോഗം',

        // v7.5 — Guest name optional
        'optional'               => 'ഓപ്ഷണൽ',
        'skip'                   => 'ഒഴിവാക്കുക',
        'continue'               => 'തുടരുക',
        'guest_name'             => 'അതിഥിയുടെ പേര്',
        'guest_name_prompt'      => 'നിങ്ങളുടെ പേര് നൽകാം, അല്ലെങ്കിൽ അജ്ഞാത അതിഥിയായി തുടരാൻ ഒഴിവാക്കുക.',
        'guest_name_placeholder' => 'നിങ്ങളുടെ മുഴുവൻ പേര് (ഓപ്ഷണൽ)',
        'guest_anonymous'        => 'അജ്ഞാത അതിഥി',
        'auto_named'             => 'അജ്ഞാത അതിഥി',
        'guest_rename'           => 'അതിഥിയുടെ പേര് മാറ്റുക',
        'save_name'              => 'പേര് സംരക്ഷിക്കുക',
        'rename_guest'           => 'അതിഥിയുടെ പേര് മാറ്റുക',
    ),

    // ============================================================
    // TAMIL
    // ============================================================
    'ta' => array(
        'app_name' => 'பார்வையாளர் மேலாண்மை அமைப்பு',
        'title' => 'பார்வையாளர் கியோஸ்க்',
        'purpose_computer_uses' => 'கணினி பயன்பாடு',

        'optional'               => 'விரும்பினால்',
        'skip'                   => 'தவிர்',
        'continue'               => 'தொடர்',
        'guest_name'             => 'விருந்தினர் பெயர்',
        'guest_name_prompt'      => 'உங்கள் பெயரை உள்ளிடலாம், அல்லது அநாமதேய விருந்தினராக தொடர தவிர்க்கவும்.',
        'guest_name_placeholder' => 'உங்கள் முழு பெயர் (விரும்பினால்)',
        'guest_anonymous'        => 'அநாமதேய விருந்தினர்',
        'auto_named'             => 'அநாமதேய விருந்தினர்',
        'guest_rename'           => 'விருந்தினர் பெயரை மாற்று',
        'save_name'              => 'பெயரை சேமி',
        'rename_guest'           => 'விருந்தினர் பெயரை மாற்று',
    ),

    // ============================================================
    // TELUGU
    // ============================================================
    'te' => array(
        'app_name' => 'విజిటర్ మేనేజ్మెంట్ సిస్టమ్',
        'title' => 'విజిటర్ కియోస్క్',
        'purpose_computer_uses' => 'కంప్యూటర్ వినియోగం',

        'optional'               => 'ఐచ్ఛికం',
        'skip'                   => 'దాటవేయి',
        'continue'               => 'కొనసాగించు',
        'guest_name'             => 'అతిథి పేరు',
        'guest_name_prompt'      => 'మీ పేరును నమోదు చేయవచ్చు, లేదా అనామక అతిథిగా కొనసాగడానికి దాటవేయండి.',
        'guest_name_placeholder' => 'మీ పూర్తి పేరు (ఐచ్ఛికం)',
        'guest_anonymous'        => 'అనామక అతిథి',
        'auto_named'             => 'అనామక అతిథి',
        'guest_rename'           => 'అతిథి పేరు మార్చు',
        'save_name'              => 'పేరు సేవ్ చేయి',
        'rename_guest'           => 'అతిథి పేరు మార్చు',
    ),

    // ============================================================
    // FRENCH
    // ============================================================
    'fr' => array(
        'app_name' => 'Système de Gestion des Visiteurs',
        'title' => 'Kiosque Visiteur',
        'purpose_computer_uses' => "Utilisation d'ordinateur",

        'optional'               => 'facultatif',
        'skip'                   => 'Passer',
        'continue'               => 'Continuer',
        'guest_name'             => 'Nom du visiteur',
        'guest_name_prompt'      => 'Vous pouvez saisir votre nom ou passer pour continuer en tant que visiteur anonyme.',
        'guest_name_placeholder' => 'Votre nom complet (facultatif)',
        'guest_anonymous'        => 'Visiteur anonyme',
        'auto_named'             => 'Visiteur anonyme',
        'guest_rename'           => 'Renommer le visiteur',
        'save_name'              => 'Enregistrer le nom',
        'rename_guest'           => 'Renommer le visiteur',
    ),

    // ============================================================
    // SPANISH
    // ============================================================
    'es' => array(
        'app_name' => 'Sistema de Gestión de Visitantes',
        'title' => 'Quiosco de Visitantes',
        'purpose_computer_uses' => 'Uso de computadora',

        'optional'               => 'opcional',
        'skip'                   => 'Omitir',
        'continue'               => 'Continuar',
        'guest_name'             => 'Nombre del visitante',
        'guest_name_prompt'      => 'Puede ingresar su nombre u omitir para continuar como visitante anónimo.',
        'guest_name_placeholder' => 'Su nombre completo (opcional)',
        'guest_anonymous'        => 'Visitante anónimo',
        'auto_named'             => 'Visitante anónimo',
        'guest_rename'           => 'Renombrar visitante',
        'save_name'              => 'Guardar nombre',
        'rename_guest'           => 'Renombrar visitante',
    ),

    // ============================================================
    // GERMAN
    // ============================================================
    'de' => array(
        'app_name' => 'Besucherverwaltungssystem',
        'title' => 'Besucher-Kiosk',
        'purpose_computer_uses' => 'Computernutzung',

        'optional'               => 'optional',
        'skip'                   => 'Überspringen',
        'continue'               => 'Weiter',
        'guest_name'             => 'Name des Besuchers',
        'guest_name_prompt'      => 'Sie können Ihren Namen eingeben oder überspringen, um als anonymer Besucher fortzufahren.',
        'guest_name_placeholder' => 'Ihr vollständiger Name (optional)',
        'guest_anonymous'        => 'Anonymer Besucher',
        'auto_named'             => 'Anonymer Besucher',
        'guest_rename'           => 'Besucher umbenennen',
        'save_name'              => 'Namen speichern',
        'rename_guest'           => 'Besucher umbenennen',
    ),

    // ============================================================
    // PORTUGUESE
    // ============================================================
    'pt' => array(
        'app_name' => 'Sistema de Gestão de Visitantes',
        'title' => 'Quiosque de Visitantes',
        'purpose_computer_uses' => 'Uso do computador',

        'optional'               => 'opcional',
        'skip'                   => 'Pular',
        'continue'               => 'Continuar',
        'guest_name'             => 'Nome do visitante',
        'guest_name_prompt'      => 'Você pode inserir seu nome ou pular para continuar como visitante anônimo.',
        'guest_name_placeholder' => 'Seu nome completo (opcional)',
        'guest_anonymous'        => 'Visitante anônimo',
        'auto_named'             => 'Visitante anônimo',
        'guest_rename'           => 'Renomear visitante',
        'save_name'              => 'Salvar nome',
        'rename_guest'           => 'Renomear visitante',
    ),

    // ============================================================
    // RUSSIAN
    // ============================================================
    'ru' => array(
        'app_name' => 'Система управления посетителями',
        'title' => 'Киоск посетителя',
        'purpose_computer_uses' => 'Использование компьютера',

        'optional'               => 'необязательно',
        'skip'                   => 'Пропустить',
        'continue'               => 'Продолжить',
        'guest_name'             => 'Имя посетителя',
        'guest_name_prompt'      => 'Вы можете ввести своё имя или пропустить, чтобы продолжить как анонимный посетитель.',
        'guest_name_placeholder' => 'Ваше полное имя (необязательно)',
        'guest_anonymous'        => 'Анонимный посетитель',
        'auto_named'             => 'Анонимный посетитель',
        'guest_rename'           => 'Переименовать посетителя',
        'save_name'              => 'Сохранить имя',
        'rename_guest'           => 'Переименовать посетителя',
    ),

    // ============================================================
    // CHINESE
    // ============================================================
    'zh' => array(
        'app_name' => '访客管理系统',
        'title' => '访客自助服务终端',
        'purpose_computer_uses' => '电脑使用',

        'optional'               => '可选',
        'skip'                   => '跳过',
        'continue'               => '继续',
        'guest_name'             => '访客姓名',
        'guest_name_prompt'      => '您可以输入姓名，或跳过后以匿名访客身份继续。',
        'guest_name_placeholder' => '您的全名（可选）',
        'guest_anonymous'        => '匿名访客',
        'auto_named'             => '匿名访客',
        'guest_rename'           => '重命名访客',
        'save_name'              => '保存姓名',
        'rename_guest'           => '重命名访客',
    ),

    // ============================================================
    // JAPANESE
    // ============================================================
    'ja' => array(
        'app_name' => '来館者管理システム',
        'title' => '来館者キオスク',
        'purpose_computer_uses' => 'パソコンの使用',

        'optional'               => '任意',
        'skip'                   => 'スキップ',
        'continue'               => '続行',
        'guest_name'             => '来館者名',
        'guest_name_prompt'      => 'お名前を入力するか、スキップして匿名の来館者として続行できます。',
        'guest_name_placeholder' => 'お名前（任意）',
        'guest_anonymous'        => '匿名の来館者',
        'auto_named'             => '匿名の来館者',
        'guest_rename'           => '来館者名を変更',
        'save_name'              => '名前を保存',
        'rename_guest'           => '来館者名を変更',
    ),
);

// ============================================================
// TRANSLATION FUNCTION
// ============================================================
function __($key, $lang = null) {
    global $TRANSLATIONS;

    if ($lang === null) {
        $lang = isset($_SESSION['visitor_lang']) ? $_SESSION['visitor_lang'] : 'en';
    }

    // Try to find translation
    if (isset($TRANSLATIONS[$lang][$key])) {
        return $TRANSLATIONS[$lang][$key];
    }

    // Fallback to English
    if (isset($TRANSLATIONS['en'][$key])) {
        return $TRANSLATIONS['en'][$key];
    }

    // Return key if no translation found
    return $key;
}

// ============================================================
// LANGUAGE HELPER FUNCTIONS
// ============================================================
function getAvailableLanguages() {
    global $LANGUAGES;
    return $LANGUAGES;
}

function getCurrentLanguage() {
    return isset($_SESSION['visitor_lang']) ? $_SESSION['visitor_lang'] : 'en';
}

function setLanguage($lang) {
    global $LANGUAGES;
    if (array_key_exists($lang, $LANGUAGES)) {
        $_SESSION['visitor_lang'] = $lang;
        return true;
    }
    return false;
}

function getLanguageName($lang) {
    global $LANGUAGES;
    return isset($LANGUAGES[$lang]) ? $LANGUAGES[$lang] : $lang;
}

function getLanguageSelector($selected = null) {
    global $LANGUAGES;

    if ($selected === null) {
        $selected = getCurrentLanguage();
    }

    $html = '<select class="form-select language-selector" onchange="window.location.href=\'?lang=\'+this.value">';
    foreach ($LANGUAGES as $code => $name) {
        $html .= '<option value="' . $code . '" ' . ($selected == $code ? 'selected' : '') . '>' . $name . '</option>';
    }
    $html .= '</select>';

    return $html;
}

function getLanguageFlags() {
    $flags = array(
        'en' => '🇬🇧',
        'hi' => '🇮🇳',
        'ar' => '🇸🇦',
        'ml' => '🇮🇳',
        'ta' => '🇮🇳',
        'te' => '🇮🇳',
        'fr' => '🇫🇷',
        'es' => '🇪🇸',
        'de' => '🇩🇪',
        'pt' => '🇵🇹',
        'ru' => '🇷🇺',
        'zh' => '🇨🇳',
        'ja' => '🇯🇵'
    );
    return $flags;
}

function getLanguageFlag($lang) {
    $flags = getLanguageFlags();
    return isset($flags[$lang]) ? $flags[$lang] : '🌐';
}
