<?php
/**
 * Visitor Management System - Alert System
 * Version: 8.0 - Complete Alert & Notification Management
 */

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/functions.php';

// ============================================================
// ALERT QUEUE FUNCTIONS
// ============================================================

/**
 * Add alert to the queue for display
 */
function addToAlertQueue($logId, $barcode, $title, $photoPath = '') {
    $db = getDB();
    try {
        $stmt = $db->prepare("
            INSERT INTO book_alerts (log_id, book_barcode, book_title, photo_path, acknowledged, resolved, created_at)
            VALUES (?, ?, ?, ?, 0, 0, NOW())
        ");
        $stmt->execute([$logId, $barcode, $title, $photoPath]);
        return $db->lastInsertId();
    } catch (PDOException $e) {
        error_log("addToAlertQueue error: " . $e->getMessage());
        return false;
    }
}

/**
 * Get pending alerts (unacknowledged)
 */
function getPendingAlerts($limit = 10) {
    $db = getDB();
    try {
        $stmt = $db->prepare("
            SELECT ba.*, bel.book_barcode, bel.book_title, bel.book_author,
                   bel.member_name, bel.member_admno
            FROM book_alerts ba
            LEFT JOIN book_exit_logs bel ON ba.log_id = bel.id
            WHERE ba.acknowledged = 0 AND ba.resolved = 0
            ORDER BY ba.created_at DESC
            LIMIT ?
        ");
        $stmt->execute([$limit]);
        return $stmt->fetchAll();
    } catch (PDOException $e) {
        error_log("getPendingAlerts error: " . $e->getMessage());
        return [];
    }
}

/**
 * Get new alerts since a timestamp
 */
function getNewAlerts($sinceTimestamp, $limit = 20) {
    $db = getDB();
    try {
        $stmt = $db->prepare("
            SELECT ba.*, bel.book_barcode, bel.book_title, bel.book_author,
                   bel.member_name, bel.member_admno
            FROM book_alerts ba
            LEFT JOIN book_exit_logs bel ON ba.log_id = bel.id
            WHERE ba.created_at > FROM_UNIXTIME(?) AND ba.acknowledged = 0
            ORDER BY ba.created_at DESC
            LIMIT ?
        ");
        $stmt->execute([$sinceTimestamp, $limit]);
        return $stmt->fetchAll();
    } catch (PDOException $e) {
        error_log("getNewAlerts error: " . $e->getMessage());
        return [];
    }
}

/**
 * Acknowledge an alert
 */
function acknowledgeAlert($alertId, $userId, $note = '') {
    $db = getDB();
    try {
        $stmt = $db->prepare("
            UPDATE book_alerts 
            SET acknowledged = 1, acknowledged_by = ?, acknowledged_at = NOW(), ack_note = ?
            WHERE id = ?
        ");
        $stmt->execute([$userId, $note, $alertId]);
        return $stmt->rowCount() > 0;
    } catch (PDOException $e) {
        error_log("acknowledgeAlert error: " . $e->getMessage());
        return false;
    }
}

/**
 * Resolve an alert
 */
function resolveAlert($alertId, $userId, $resolution = '') {
    $db = getDB();
    try {
        $stmt = $db->prepare("            UPDATE book_alerts 
            SET resolved = 1, resolved_by = ?, resolved_at = NOW(), resolution = ?
            WHERE id = ?
        ");
        $stmt->execute([$userId, $resolution, $alertId]);
        return $stmt->rowCount() > 0;
    } catch (PDOException $e) {
        error_log("resolveAlert error: " . $e->getMessage());
        return false;
    }
}

/**
 * Get alert statistics
 */
function getAlertStatistics() {
    $db = getDB();
    try {
        $stats = [];
        
        $stats['pending'] = (int)$db->query("
            SELECT COUNT(*) FROM book_alerts WHERE acknowledged = 0 AND resolved = 0
        ")->fetchColumn();
        
        $stats['acknowledged'] = (int)$db->query("
            SELECT COUNT(*) FROM book_alerts WHERE acknowledged = 1 AND resolved = 0
        ")->fetchColumn();
        
        $stats['resolved'] = (int)$db->query("
            SELECT COUNT(*) FROM book_alerts WHERE resolved = 1
        ")->fetchColumn();
        
        $stats['today'] = (int)$db->query("
            SELECT COUNT(*) FROM book_alerts WHERE DATE(created_at) = CURDATE()
        ")->fetchColumn();
        
        $stats['week'] = (int)$db->query("
            SELECT COUNT(*) FROM book_alerts WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
        ")->fetchColumn();
        
        $stats['month'] = (int)$db->query("
            SELECT COUNT(*) FROM book_alerts WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
        ")->fetchColumn();
        
        return $stats;
    } catch (PDOException $e) {
        error_log("getAlertStatistics error: " . $e->getMessage());
        return ['pending' => 0, 'acknowledged' => 0, 'resolved' => 0, 'today' => 0, 'week' => 0, 'month' => 0];
    }
}

// ============================================================
// NOTIFICATION FUNCTIONS
// ============================================================

/**
 * Send unauthorized book exit alert via multiple channels
 */
function sendUnauthorizedBookAlert($data) {
    $settings = getSettings();
    $results = [];
    
    // 1. Log the alert
    $results['logged'] = true;
    error_log("[UNAUTHORIZED BOOK ALERT] " . json_encode($data));
    
    // 2. Send email notification
    if (!empty($settings['notify_email'])) {
        $results['email'] = sendAlertEmail($settings['notify_email'], $data);
    }
    
    // 3. Send webhook notification
    if (!empty($settings['webhook_url']) && ($settings['enable_webhook'] ?? 0)) {
        $results['webhook'] = sendAlertWebhook($settings['webhook_url'], $data);
    }
    
    // 4. Send SMS if enabled
    if (($settings['sms_enabled'] ?? 0) && !empty($settings['sms_api_key'])) {
        $results['sms'] = sendAlertSMS($settings, $data);
    }
    
    // 5. Store in notifications queue
    storeNotification($data);
    
    return !empty(array_filter($results));
}

/**
 * Send alert email
 */
function sendAlertEmail($to, $data) {
    $settings = getSettings();
    $institutionName = $settings['institution_name'] ?? 'Library';
    
    $subject = "🚨 SECURITY ALERT: Unauthorized Book Exit - " . $data['title'];
    
    $body = "
    <html>
    <head>
        <style>
            body { font-family: Arial, sans-serif; }
            .alert-box { background: #fff5f5; border: 2px solid #dc3545; border-radius: 12px; padding: 20px; }
            .header { background: #dc3545; color: white; padding: 15px; border-radius: 8px; margin: -20px -20px 20px -20px; }
            .field { margin-bottom: 10px; }
            .label { font-weight: bold; color: #666; }
            .value { color: #333; }
            .footer { margin-top: 20px; padding-top: 15px; border-top: 1px solid #ddd; font-size: 12px; color: #999; }
        </style>
    </head>
    <body>
        <div class='alert-box'>
            <div class='header'>
                <h2 style='margin:0;'>🚨 UNAUTHORIZED BOOK EXIT ALERT</h2>
            </div>
            
            <div class='field'>
                <span class='label'>Book Title:</span>
                <span class='value'>" . htmlspecialchars($data['title']) . "</span>
            </div>
            
            <div class='field'>
                <span class='label'>Barcode:</span>
                <span class='value'>" . htmlspecialchars($data['barcode']) . "</span>
            </div>
            
            <div class='field'>
                <span class='label'>Author:</span>
                <span class='value'>" . htmlspecialchars($data['author'] ?? 'Unknown') . "</span>
            </div>
            
            " . (!empty($data['member_name']) ? "
            <div class='field'>
                <span class='label'>Member:</span>
                <span class='value'>" . htmlspecialchars($data['member_name']) . "</span>
            </div>
            " : "") . "
            
            <div class='field'>
                <span class='label'>Staff:</span>
                <span class='value'>" . htmlspecialchars($data['staff_name'] ?? 'Unknown') . "</span>
            </div>
            
            <div class='field'>
                <span class='label'>Gate:</span>
                <span class='value'>" . htmlspecialchars($data['gate_number'] ?? 'MAIN') . "</span>
            </div>
            
            <div class='field'>
                <span class='label'>Time:</span>
                <span class='value'>" . htmlspecialchars($data['timestamp']) . "</span>
            </div>
            
            <div class='footer'>
                This is an automated alert from " . htmlspecialchars($institutionName) . " Visitor Management System.
                Please investigate immediately.
            </div>
        </div>
    </body>
    </html>
    ";
    
    $headers = "MIME-Version: 1.0\r\n";
    $headers .= "Content-type: text/html; charset=UTF-8\r\n";
    $headers .= "From: " . ($settings['institution_email'] ?? 'noreply@library.local') . "\r\n";
    $headers .= "X-Priority: 1\r\n";
    $headers .= "X-MSMail-Priority: High\r\n";
    
    return @mail($to, $subject, $body, $headers);
}

/**
 * Send webhook notification
 */
function sendAlertWebhook($url, $data) {
    $payload = [
        'event' => 'unauthorized_book_exit',
        'severity' => 'high',
        'timestamp' => date('c'),
        'data' => $data
    ];
    
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => json_encode($payload),
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/json',
            'X-Alert-Type: unauthorized_book_exit',
            'X-Priority: high'
        ],
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 10,
        CURLOPT_SSL_VERIFYPEER => false
    ]);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    return $httpCode >= 200 && $httpCode < 300;
}

/**
 * Send SMS alert
 */
function sendAlertSMS($settings, $data) {
    $apiKey = $settings['sms_api_key'] ?? '';
    $senderId = $settings['sms_sender_id'] ?? '';
    $phone = $settings['sms_recipient'] ?? '';
    
    if (empty($apiKey) || empty($phone)) return false;
    
    $message = "SECURITY ALERT: Unauthorized book exit detected!\n" .
               "Book: {$data['title']}\n" .
               "Barcode: {$data['barcode']}\n" .
               "Time: {$data['timestamp']}";
    
    // Example using a generic SMS API - adjust based on your provider
    $url = "https://api.smsprovider.com/send";
    $params = [
        'api_key' => $apiKey,
        'sender_id' => $senderId,
        'recipient' => $phone,
        'message' => $message
    ];
    
    $ch = curl_init($url . '?' . http_build_query($params));
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 10
    ]);
    
    $response = curl_exec($ch);
    curl_close($ch);
    
    return !empty($response);
}

/**
 * Store notification in queue for later sending
 */
function storeNotification($data) {
    $db = getDB();
    $settings = getSettings();
    
    try {
        $stmt = $db->prepare("
            INSERT INTO notifications_queue 
            (recipient_type, channel, subject, message, status, scheduled_at)
            VALUES ('staff', 'alert', ?, ?, 'pending', NOW())
        ");
        
        $subject = "Unauthorized Book Exit: " . $data['title'];
        $message = json_encode($data);
        
        $stmt->execute([$subject, $message]);
        return $db->lastInsertId();
    } catch (PDOException $e) {
        error_log("storeNotification error: " . $e->getMessage());
        return false;
    }
}

// ============================================================
// MONITORING FUNCTIONS
// ============================================================

/**
 * Get real-time monitoring data
 */
function getMonitoringData() {
    $db = getDB();
    
    try {
        return [
            'unauthorized_today' => (int)$db->query("
                SELECT COUNT(*) FROM book_exit_logs 
                WHERE is_authorized = 0 AND DATE(created_at) = CURDATE()
            ")->fetchColumn(),
            
            'unauthorized_week' => (int)$db->query("
                SELECT COUNT(*) FROM book_exit_logs 
                WHERE is_authorized = 0 AND created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
            ")->fetchColumn(),
            
            'total_book_exits_today' => (int)$db->query("
                SELECT COUNT(*) FROM book_exit_logs 
                WHERE DATE(created_at) = CURDATE()
            ")->fetchColumn(),
            
            'pending_alerts' => (int)$db->query("
                SELECT COUNT(*) FROM book_alerts WHERE acknowledged = 0 AND resolved = 0
            ")->fetchColumn(),
            
            'last_unauthorized' => $db->query("
                SELECT book_barcode, book_title, created_at 
                FROM book_exit_logs 
                WHERE is_authorized = 0 
                ORDER BY created_at DESC 
                LIMIT 1
            ")->fetch(),
            
            'hourly_breakdown' => $db->query("
                SELECT HOUR(created_at) as hour, COUNT(*) as count 
                FROM book_exit_logs 
                WHERE is_authorized = 0 AND DATE(created_at) = CURDATE()
                GROUP BY hour 
                ORDER BY hour
            ")->fetchAll(),
            
            'top_members' => $db->query("
                SELECT member_name, COUNT(*) as count 
                FROM book_exit_logs 
                WHERE is_authorized = 0 AND member_name IS NOT NULL AND member_name != ''
                GROUP BY member_name 
                ORDER BY count DESC 
                LIMIT 5
            ")->fetchAll()
        ];
    } catch (PDOException $e) {
        error_log("getMonitoringData error: " . $e->getMessage());
        return [];
    }
}

/**
 * Get security dashboard summary
 */
function getSecurityDashboard() {
    $db = getDB();
    
    try {
        return [
            'alerts' => getAlertStatistics(),
            'monitoring' => getMonitoringData(),
            'recent_incidents' => $db->query("
                SELECT bel.*, ba.acknowledged, ba.resolved
                FROM book_exit_logs bel
                LEFT JOIN book_alerts ba ON bel.id = ba.log_id
                WHERE bel.is_authorized = 0
                ORDER BY bel.created_at DESC
                LIMIT 10
            ")->fetchAll()
        ];
    } catch (PDOException $e) {
        error_log("getSecurityDashboard error: " . $e->getMessage());
        return [];
    }
}
?>
