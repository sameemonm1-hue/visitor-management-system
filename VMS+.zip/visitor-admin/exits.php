<?php
/**
 * Visitor Management System - Exit Management
 * Version: 7.4 FINAL - WORKING
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

// Auto-detect paths
$possiblePaths = [
    __DIR__ . '/includes',
    dirname(__DIR__) . '/includes',
    '/usr/share/koha/intranet/cgi-bin/koha/visitor/includes',
    '/usr/share/koha/intranet/cgi-bin/visitor/includes',
];

$includePath = null;
foreach ($possiblePaths as $path) {
    if (file_exists($path . '/config.php')) {
        $includePath = $path;
        break;
    }
}

if (!$includePath) {
    $testPath = __DIR__;
    for ($i = 0; $i < 5; $i++) {
        $testPath = dirname($testPath);
        if (file_exists($testPath . '/includes/config.php')) {
            $includePath = $testPath . '/includes';
            break;
        }
    }
}

if (!$includePath) {
    die('Could not find includes directory.');
}

define('VMS_INCLUDES', $includePath);
require_once VMS_INCLUDES . '/config.php';
require_once VMS_INCLUDES . '/functions.php';
require_once VMS_INCLUDES . '/koha.php';
require_once VMS_INCLUDES . '/auth.php';

startSecureSession();
requireKohaLogin();

$db = getDB();
$user = getCurrentUser();
$settings = getSettings();
$message = '';
$searchError = '';
$searchResult = null;
$admno = $_GET['admno'] ?? '';

// Handle force exit
if (isset($_POST['force_exit'])) {
    $admno = trim($_POST['admno']);
    $find = $db->prepare("SELECT id, member_name, entry_type FROM entry_exit_logs WHERE admno = ? AND status = 'inside' ORDER BY entry_time DESC LIMIT 1");
    $find->execute([$admno]);
    $entry = $find->fetch();
    if ($entry) {
        $update = $db->prepare("UPDATE entry_exit_logs SET exit_time = NOW(), status = 'exited', notes = CONCAT(IFNULL(notes, ''), ' [Force exited by staff at ', NOW(), ']') WHERE id = ?");
        $update->execute([$entry['id']]);
        if ($entry['entry_type'] === 'guest') {
            $updateGuest = $db->prepare("UPDATE guests SET status = 'force_exited', exit_time = NOW(), duration = TIMESTAMPDIFF(MINUTE, entry_time, NOW()) WHERE guest_id = ? AND status = 'inside'");
            $updateGuest->execute([$admno]);
        }
        logActivity($user['id'] ?? 0, 'FORCE_EXIT', "Force exited {$entry['entry_type']}: $admno ({$entry['member_name']})");
        $message = "✅ Successfully force exited {$entry['member_name']}";
        $searchResult = null;
        clearCache('stats');
    } else {
        $message = "⚠️ Member is not currently inside";
    }
}

// Handle search
if (isset($_POST['search_member']) || $admno) {
    $admno = $admno ?: trim($_POST['admno']);
    if (strlen($admno) < 2) {
        $searchError = 'Please enter a valid ID';
    } else {
        $member = getKohaMember($admno);
        if ($member) {
            $entry = $db->prepare("SELECT id, entry_time, entry_type FROM entry_exit_logs WHERE admno = ? AND status = 'inside' ORDER BY entry_time DESC LIMIT 1");
            $entry->execute([$member['cardnumber']]);
            $entryData = $entry->fetch();
            if ($entryData) {
                $member['entry_id'] = $entryData['id'];
                $member['entry_time'] = $entryData['entry_time'];
                $member['entry_type'] = $entryData['entry_type'];
                $searchResult = $member;
            } else {
                $searchError = 'Member is not currently inside';
            }
        } else {
            $searchError = 'Member not found';
        }
    }
}

// Handle normal exit
if (isset($_POST['record_exit'])) {
    $entryId = (int)$_POST['entry_id'];
    $stmt = $db->prepare("SELECT admno, entry_type FROM entry_exit_logs WHERE id = ?");
    $stmt->execute([$entryId]);
    $entry = $stmt->fetch();
    $update = $db->prepare("UPDATE entry_exit_logs SET exit_time = CURTIME(), status = 'exited' WHERE id = ?");
    $update->execute([$entryId]);
    if ($entry && $entry['entry_type'] === 'guest') {
        $updateGuest = $db->prepare("UPDATE guests SET status = 'exited', exit_time = NOW(), duration = TIMESTAMPDIFF(MINUTE, entry_time, NOW()) WHERE guest_id = ? AND status = 'inside'");
        $updateGuest->execute([$entry['admno']]);
    }
    logActivity($user['id'], 'EXIT', "Exit recorded");
    $message = '✅ Exit recorded successfully';
    $searchResult = null;
    clearCache('stats');
}

// Handle guest exit
if (isset($_POST['guest_exit'])) {
    $guestId = (int)$_POST['guest_id'];
    $stmt = $db->prepare("UPDATE entry_exit_logs SET exit_time = NOW(), status = 'exited' WHERE id = ? AND status = 'inside' AND entry_type = 'guest'");
    $stmt->execute([$guestId]);
    if ($stmt->rowCount() > 0) {
        $stmt2 = $db->prepare("UPDATE guests SET status = 'exited', exit_time = NOW(), duration = TIMESTAMPDIFF(MINUTE, entry_time, NOW()) WHERE id = ? AND status = 'inside'");
        $stmt2->execute([$guestId]);
        logActivity($user['id'] ?? 0, 'GUEST_EXIT', "Guest exited ID: $guestId");
        $message = '✅ Guest exited successfully';
        clearCache('stats');
    } else {
        $message = '⚠️ Guest not found or already exited';
    }
}

// Get currently inside
$inside = $db->query("SELECT * FROM entry_exit_logs WHERE status = 'inside' ORDER BY entry_time DESC")->fetchAll();
$guestCount = $db->query("SELECT COUNT(*) FROM entry_exit_logs WHERE status = 'inside' AND entry_type = 'guest'")->fetchColumn();

$pageTitle = 'Exit Management';
include __DIR__ . '/header.php';
?>

<style>
.exit-search-card {
    background: #f8f9fa;
    border-radius: 16px;
    padding: 20px;
    margin-bottom: 20px;
    border: 1px solid #e9ecef;
}
.member-result-card {
    background: white;
    border-radius: 16px;
    padding: 20px;
    border: 1px solid #e9ecef;
    margin-top: 16px;
}
.member-avatar {
    width: 80px;
    height: 80px;
    border-radius: 50%;
    object-fit: cover;
    border: 3px solid #dc3545;
}
@media (max-width: 768px) {
    .member-avatar { width: 60px; height: 60px; }
}
</style>

<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
        <h4 class="mb-0"><i class="fas fa-sign-out-alt me-2 text-danger"></i>Exit Management</h4>
        <div class="d-flex gap-2">
            <span class="badge bg-danger rounded-pill px-3 py-2">
                <i class="fas fa-users me-1"></i> <?= count($inside) ?> Inside
            </span>
            <?php if ($guestCount > 0): ?>
                <span class="badge bg-success rounded-pill px-3 py-2">
                    <i class="fas fa-user-friends me-1"></i> <?= $guestCount ?> Guests
                </span>
            <?php endif; ?>
        </div>
    </div>
    
    <?php if ($message): ?>
        <div class="alert alert-<?= strpos($message, '⚠️') !== false ? 'warning' : 'success' ?> alert-dismissible fade show">
            <?= $message ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    <?php if ($searchError): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <?= htmlspecialchars($searchError) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="exit-search-card">
        <ul class="nav nav-tabs mb-3" role="tablist">
            <li class="nav-item">
                <button class="nav-link active" data-bs-toggle="tab" data-bs-target="#memberExitTab">
                    <i class="fas fa-user me-1"></i> Member
                </button>
            </li>
            <?php if ($guestCount > 0): ?>
                <li class="nav-item">
                    <button class="nav-link" data-bs-toggle="tab" data-bs-target="#guestExitTab">
                        <i class="fas fa-user-friends me-1"></i> Guest Exit
                        <span class="badge bg-success ms-1"><?= $guestCount ?></span>
                    </button>
                </li>
            <?php endif; ?>
        </ul>
        
        <div class="tab-content">
            <div class="tab-pane fade show active" id="memberExitTab">
                <form method="POST" class="row g-3">
                    <div class="col-12 col-md-8">
                        <label class="form-label fw-semibold">Member ID / Barcode</label>
                        <div class="input-group">
                            <span class="input-group-text bg-danger text-white"><i class="fas fa-id-card"></i></span>
                            <input type="text" name="admno" class="form-control form-control-lg" 
                                   placeholder="Enter Member ID" value="<?= htmlspecialchars($admno) ?>" required autofocus>
                        </div>
                    </div>
                    <div class="col-12 col-md-4 d-flex align-items-end">
                        <button type="submit" name="search_member" class="btn btn-danger w-100 btn-lg">
                            <i class="fas fa-search me-2"></i> Find Member
                        </button>
                    </div>
                </form>
            </div>
            
            <?php if ($guestCount > 0): ?>
                <div class="tab-pane fade" id="guestExitTab">
                    <div class="row g-3">
                        <div class="col-12">
                            <div class="alert alert-info">
                                <i class="fas fa-info-circle me-2"></i>
                                Select a guest from the list below to exit them.
                            </div>
                        </div>
                        <?php foreach ($inside as $row): ?>
                            <?php if (($row['entry_type'] ?? '') === 'guest'): ?>
                                <div class="col-12 col-md-6 col-lg-4">
                                    <div class="card border-success">
                                        <div class="card-body">
                                            <h6 class="card-title"><?= htmlspecialchars($row['member_name']) ?></h6>
                                            <p class="card-text small">
                                                <i class="fas fa-id-card me-1"></i> <?= htmlspecialchars($row['admno']) ?><br>
                                                <i class="fas fa-clock me-1"></i> Entry: <?= htmlspecialchars($row['entry_time']) ?><br>
                                                <i class="fas fa-hourglass-half me-1"></i> Duration: <?= timeAgo($row['entry_time']) ?>
                                            </p>
                                            <form method="POST" onsubmit="return confirm('Exit this guest?');">
                                                <input type="hidden" name="guest_id" value="<?= $row['id'] ?>">
                                                <button type="submit" name="guest_exit" class="btn btn-success w-100">
                                                    <i class="fas fa-sign-out-alt me-1"></i> Exit Guest
                                                </button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>
        
        <?php if (isset($searchResult)): ?>
            <div class="member-result-card">
                <div class="row align-items-center">
                    <div class="col-12 col-md-2 text-center mb-3 mb-md-0">
                        <?php if (!empty($searchResult['photo_base64'])): ?>
                            <img src="<?= $searchResult['photo_base64'] ?>" class="member-avatar" alt="Photo" loading="lazy">
                        <?php else: ?>
                            <div class="member-avatar bg-danger d-flex align-items-center justify-content-center mx-auto" 
                                 style="color:white;font-size:2rem;font-weight:bold;">
                                <?= substr($searchResult['full_name'], 0, 1) ?>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="col-12 col-md-5">
                        <h4 class="mb-1"><?= htmlspecialchars($searchResult['full_name']) ?></h4>
                        <div class="d-flex flex-wrap gap-2">
                            <span class="badge bg-primary"><?= htmlspecialchars($searchResult['category_description'] ?? $searchResult['categorycode']) ?></span>
                            <span class="badge bg-success"><i class="fas fa-circle me-1"></i> Inside</span>
                            <span class="badge bg-secondary"><i class="fas fa-clock me-1"></i> <?= htmlspecialchars($searchResult['entry_time']) ?></span>
                            <span class="badge <?= ($searchResult['entry_type'] ?? 'member') === 'guest' ? 'bg-success' : 'bg-info' ?>"><?= ucfirst($searchResult['entry_type'] ?? 'Member') ?></span>
                        </div>
                        <div class="mt-2 small text-muted">
                            <i class="fas fa-id-card me-1"></i> <?= htmlspecialchars($searchResult['cardnumber']) ?>
                            <?php if (!empty($searchResult['department'])): ?>
                                | <i class="fas fa-building me-1"></i> <?= htmlspecialchars($searchResult['department']) ?>
                            <?php endif; ?>
                        </div>
                        <div class="mt-1 small text-muted">
                            <i class="fas fa-clock me-1"></i> Duration: <?= timeAgo($searchResult['entry_time']) ?>
                        </div>
                    </div>
                    <div class="col-12 col-md-5 text-center text-md-end mt-3 mt-md-0">
                        <div class="d-flex gap-2 justify-content-center justify-content-md-end flex-wrap">
                            <form method="POST" class="d-inline">
                                <input type="hidden" name="entry_id" value="<?= $searchResult['entry_id'] ?>">
                                <button type="submit" name="record_exit" class="btn btn-success btn-lg">
                                    <i class="fas fa-sign-out-alt me-2"></i> Normal Exit
                                </button>
                            </form>
                            <form method="POST" class="d-inline" onsubmit="return confirm('⚠️ Are you sure you want to FORCE EXIT <?= htmlspecialchars($searchResult['full_name']) ?>? This bypasses normal checkout procedures.');">
                                <input type="hidden" name="admno" value="<?= htmlspecialchars($searchResult['cardnumber']) ?>">
                                <button type="submit" name="force_exit" class="btn btn-danger btn-lg">
                                    <i class="fas fa-exclamation-triangle me-2"></i> Force Exit
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <div class="card shadow-sm">
        <div class="card-header bg-white d-flex justify-content-between align-items-center flex-wrap gap-2">
            <h5 class="mb-0"><i class="fas fa-users me-2"></i>Currently Inside Library</h5>
            <span class="badge bg-primary rounded-pill px-3 py-2"><?= count($inside) ?> Members</span>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover mb-0" id="insideTable">
                    <thead class="table-light">
                        <tr>
                            <th>Member</th>
                            <th>ID</th>
                            <th>Entry Time</th>
                            <th>Duration</th>
                            <th>Purpose</th>
                            <th>Type</th>
                            <th class="text-center">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($inside)): ?>
                            <tr>
                                <td colspan="7" class="text-center py-4 text-muted">
                                    <i class="fas fa-check-circle text-success me-2"></i> No members currently inside
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($inside as $row): ?>
                                <tr>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <div class="rounded-circle bg-secondary text-white d-flex align-items-center justify-content-center me-2" 
                                                 style="width:32px;height:32px;font-size:0.8rem;font-weight:bold;flex-shrink:0;">
                                                <?= substr($row['member_name'] ?? 'U', 0, 1) ?>
                                            </div>
                                            <span class="fw-semibold"><?= htmlspecialchars($row['member_name']) ?></span>
                                        </div>
                                    </td>
                                    <td><code><?= htmlspecialchars($row['admno']) ?></code></td>
                                    <td><?= htmlspecialchars($row['entry_time']) ?></td>
                                    <td><span class="badge bg-warning text-dark"><?= timeAgo($row['entry_time']) ?></span></td>
                                    <td><?= htmlspecialchars($row['purpose'] ?? 'N/A') ?></td>
                                    <td>
                                        <span class="badge <?= ($row['entry_type'] ?? 'member') === 'guest' ? 'bg-success' : 'bg-primary' ?>">
                                            <?= ucfirst($row['entry_type'] ?? 'Member') ?>
                                        </span>
                                    </td>
                                    <td class="text-center">
                                        <div class="btn-group" role="group">
                                            <a href="?admno=<?= urlencode($row['admno']) ?>" class="btn btn-sm btn-success">
                                                <i class="fas fa-sign-out-alt"></i>
                                            </a>
                                            <button onclick="forceExitMember('<?= htmlspecialchars($row['admno']) ?>')" 
                                                    class="btn btn-sm btn-danger" title="Force Exit">
                                                <i class="fas fa-exclamation-triangle"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
function forceExitMember(admno) {
    if (!confirm(`⚠️ Are you sure you want to FORCE EXIT member ${admno}?`)) return;
    const btn = event?.target?.closest?.('button');
    if (btn) { btn.disabled = true; btn.innerHTML = '<span class="spinner-border spinner-border-sm"></span>'; }
    fetch('ajax.php?action=force_exit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'admno=' + encodeURIComponent(admno) + '&csrf_token=' + encodeURIComponent(getCsrfToken?.() || '')
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) { showToast?.(data.message, 'success') || alert(data.message); setTimeout(() => location.reload(), 1500); }
        else { showToast?.(data.message, 'danger') || alert(data.message); if (btn) { btn.disabled = false; btn.innerHTML = '<i class="fas fa-exclamation-triangle"></i>'; } }
    })
    .catch(err => { showToast?.('Network error: ' + err.message, 'danger') || alert('Network error'); if (btn) { btn.disabled = false; btn.innerHTML = '<i class="fas fa-exclamation-triangle"></i>'; } });
}
document.addEventListener('DOMContentLoaded', function() {
    const table = document.getElementById('insideTable');
    if (!table) return;
    const cardBody = table.closest('.card-body');
    if (cardBody) {
        const searchDiv = document.createElement('div');
        searchDiv.className = 'p-3 border-bottom';
        searchDiv.innerHTML = `
            <div class="d-flex gap-2">
                <input type="text" id="tableSearch" class="form-control form-control-sm" 
                       placeholder="Search members..." style="max-width:300px;">
                <button class="btn btn-sm btn-outline-secondary" onclick="clearTableSearch()">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        `;
        cardBody.insertBefore(searchDiv, table);
        document.getElementById('tableSearch').addEventListener('input', function() {
            const filter = this.value.toLowerCase();
            const rows = table.getElementsByTagName('tbody')[0]?.getElementsByTagName('tr') || [];
            for (let i = 0; i < rows.length; i++) {
                const text = rows[i].textContent.toLowerCase();
                rows[i].style.display = text.includes(filter) ? '' : 'none';
            }
        });
    }
});
function clearTableSearch() {
    const input = document.getElementById('tableSearch');
    if (input) { input.value = ''; input.dispatchEvent(new Event('input')); input.focus(); }
}
function getCsrfToken() { return document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || ''; }
function showToast(message, type) { if (typeof showToast === 'function') { showToast(message, type); } else { alert(message); } }
</script>

<?php include __DIR__ . '/footer.php'; ?>
